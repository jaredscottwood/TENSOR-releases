use std::{env, path::PathBuf, process::Command};
fn main() {
    println!("cargo:rerun-if-changed=resources/tensor.rc");
    println!("cargo:rerun-if-changed=resources/tensor.ico");
    if !env::var("TARGET")
        .unwrap_or_default()
        .ends_with("windows-msvc")
    {
        return;
    }
    if !cfg!(windows) {
        println!(
            "cargo:warning=Windows resource linking is performed by a native Windows build; cross-checking Rust code only."
        );
        return;
    }
    let output = PathBuf::from(env::var_os("OUT_DIR").unwrap()).join("tensor.res");
    let mut candidates = vec![PathBuf::from("rc.exe")];
    if let Some(programs) = env::var_os("ProgramFiles(x86)") {
        let kits = PathBuf::from(programs).join("Windows Kits/10/bin");
        if let Ok(entries) = std::fs::read_dir(kits) {
            let mut paths: Vec<_> = entries
                .filter_map(Result::ok)
                .map(|e| e.path().join("x64/rc.exe"))
                .filter(|p| p.is_file())
                .collect();
            paths.sort();
            paths.reverse();
            candidates.extend(paths);
        }
    }
    for compiler in candidates {
        if Command::new(compiler)
            .arg("/nologo")
            .arg("/fo")
            .arg(&output)
            .arg("resources/tensor.rc")
            .status()
            .is_ok_and(|status| status.success())
        {
            println!("cargo:rustc-link-arg-bin=tensor={}", output.display());
            return;
        }
    }
    panic!(
        "Could not compile the TENSOR icon resource. Install the Windows SDK / Visual Studio C++ build tools (rc.exe), and build again."
    );
}
