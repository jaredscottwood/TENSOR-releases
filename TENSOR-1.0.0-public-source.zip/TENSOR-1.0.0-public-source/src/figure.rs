//! Transparent figure export from the same fixed 3D model as the viewer.
//! Every format uses the same depth-tested raster so label occlusion is identical.
use crate::{
    jobs::atomic_write_bytes,
    render3d::{BACKGROUND, Raster},
    viewer::Viewer,
};
use anyhow::{Result, ensure};
use base64::Engine;
use std::{
    io::Write,
    path::{Path, PathBuf},
};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Format {
    Png,
    Svg,
    Pdf,
}
impl Format {
    pub fn extension(self) -> &'static str {
        match self {
            Self::Png => "png",
            Self::Svg => "svg",
            Self::Pdf => "pdf",
        }
    }
}
#[derive(Clone, Debug)]
pub struct FigureOptions {
    pub format: Format,
    pub width: usize,
    pub dpi: u32,
    pub labels: bool,
    pub transparent: bool,
}
impl Default for FigureOptions {
    fn default() -> Self {
        Self {
            format: Format::Png,
            width: 2400,
            dpi: 300,
            labels: true,
            transparent: true,
        }
    }
}
impl FigureOptions {
    pub fn dimensions(&self, viewer: &Viewer) -> Result<(usize, usize)> {
        ensure!(
            (128..=6000).contains(&self.width),
            "Figure width must be 128–6000 pixels"
        );
        ensure!((72..=1200).contains(&self.dpi), "DPI must be 72–1200");
        let size = viewer.reference_size();
        let height = (self.width as f64 * size[1] / size[0].max(1.))
            .round()
            .max(1.) as usize;
        ensure!(
            height <= 6000 && self.width * height <= 20_000_000,
            "Figure exceeds the 20-megapixel limit; reduce the pixel width"
        );
        Ok((self.width, height))
    }
}
pub fn encode_png(raster: &Raster, dpi: u32) -> Result<Vec<u8>> {
    let mut bytes = vec![];
    let mut encoder = png::Encoder::new(&mut bytes, raster.width as u32, raster.height as u32);
    encoder.set_color(png::ColorType::Rgba);
    encoder.set_depth(png::BitDepth::Eight);
    let pixels_per_metre = (dpi as f64 / 0.0254).round() as u32;
    encoder.set_pixel_dims(Some(png::PixelDimensions {
        xppu: pixels_per_metre,
        yppu: pixels_per_metre,
        unit: png::Unit::Meter,
    }));
    encoder.write_header()?.write_image_data(&raster.rgba)?;
    Ok(bytes)
}
fn xml(text: &str) -> String {
    text.replace('&', "&amp;")
        .replace('"', "&quot;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}
fn zlib(bytes: &[u8]) -> Result<Vec<u8>> {
    let mut encoder = flate2::write::ZlibEncoder::new(Vec::new(), flate2::Compression::default());
    encoder.write_all(bytes)?;
    Ok(encoder.finish()?)
}
fn stream(dictionary: &str, bytes: &[u8]) -> Vec<u8> {
    let mut data = format!("<< {dictionary} /Length {} >>\nstream\n", bytes.len()).into_bytes();
    data.extend(bytes);
    data.extend(b"\nendstream");
    data
}
fn pdf(raster: &Raster, options: &FigureOptions) -> Result<Vec<u8>> {
    let width = raster.width as f64 * 72. / options.dpi as f64;
    let height = raster.height as f64 * 72. / options.dpi as f64;
    let mut rgb = Vec::with_capacity(raster.width * raster.height * 3);
    let mut alpha = Vec::with_capacity(raster.width * raster.height);
    for pixel in raster.rgba.chunks_exact(4) {
        rgb.extend_from_slice(&pixel[..3]);
        alpha.push(pixel[3]);
    }
    let content = format!("q\n{width:.6} 0 0 {height:.6} 0 0 cm\n/Im0 Do\nQ\n");
    let objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>".to_vec(),
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>".to_vec(),
        format!("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {width:.6} {height:.6}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 6 0 R >>").into_bytes(),
        stream(
            &format!("/Type /XObject /Subtype /Image /Width {} /Height {} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /SMask 5 0 R", raster.width, raster.height),
            &zlib(&rgb)?,
        ),
        stream(
            &format!("/Type /XObject /Subtype /Image /Width {} /Height {} /ColorSpace /DeviceGray /BitsPerComponent 8 /Filter /FlateDecode", raster.width, raster.height),
            &zlib(&alpha)?,
        ),
        stream("", content.as_bytes()),
    ];
    let mut out = b"%PDF-1.4\n%\xE2\xE3\xCF\xD3\n".to_vec();
    let mut offsets = vec![0];
    for (index, object) in objects.iter().enumerate() {
        offsets.push(out.len());
        out.extend(format!("{} 0 obj\n", index + 1).as_bytes());
        out.extend(object);
        out.extend(b"\nendobj\n");
    }
    let xref = out.len();
    out.extend(format!("xref\n0 {}\n0000000000 65535 f \n", offsets.len()).as_bytes());
    for &offset in &offsets[1..] {
        out.extend(format!("{offset:010} 00000 n \n").as_bytes());
    }
    out.extend(
        format!(
            "trailer\n<< /Size {} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n",
            offsets.len()
        )
        .as_bytes(),
    );
    Ok(out)
}
pub fn export(viewer: &Viewer, options: &FigureOptions, path: &Path) -> Result<PathBuf> {
    ensure!(
        !viewer.coordinates.is_empty(),
        "Load a structure before exporting an image"
    );
    let mut path = path.to_path_buf();
    if path.extension().is_none() {
        path.set_extension(options.format.extension());
    }
    ensure!(
        path.extension().is_some_and(|extension| extension
            .to_string_lossy()
            .eq_ignore_ascii_case(options.format.extension())),
        "Use a .{} filename for the selected format",
        options.format.extension()
    );
    let (width, height) = options.dimensions(viewer)?;
    let mut raster = viewer.render_snapshot(width, height, true);
    if options.labels {
        viewer.paint_labels(&mut raster);
    }
    if !options.transparent {
        for pixel in raster.rgba.chunks_exact_mut(4) {
            let alpha = pixel[3] as f64 / 255.;
            for channel in 0..3 {
                pixel[channel] = (pixel[channel] as f64 * alpha
                    + BACKGROUND[channel] as f64 * (1. - alpha))
                    .round() as u8;
            }
            pixel[3] = 255;
        }
    }
    let bytes = match options.format {
        Format::Png => encode_png(&raster, options.dpi)?,
        Format::Svg => {
            let encoded =
                base64::engine::general_purpose::STANDARD.encode(encode_png(&raster, options.dpi)?);
            let labels = if options.labels {
                viewer.displayed_label_texts().join(", ")
            } else {
                "none".into()
            };
            let label_description = if options.labels {
                viewer.label_description()
            } else {
                "labels"
            };
            format!(
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{}in\" height=\"{}in\" viewBox=\"0 0 {width} {height}\">\n<title>TENSOR molecular structure</title>\n<desc>Transparent high-resolution molecular raster at {} DPI; depth-tested {}: {}.</desc>\n<image width=\"{width}\" height=\"{height}\" href=\"data:image/png;base64,{encoded}\"/>\n</svg>\n",
                width as f64 / options.dpi as f64,
                height as f64 / options.dpi as f64,
                options.dpi,
                label_description,
                xml(&labels)
            )
            .into_bytes()
        }
        Format::Pdf => pdf(&raster, options)?,
    };
    atomic_write_bytes(&path, &bytes)?;
    Ok(path)
}
