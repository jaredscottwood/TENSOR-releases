//! Graph automorphisms for conformer identity, and stereo-aware chemical
//! equivalence for NMR averaging. These are intentionally separate searches.
use crate::{jobs::Progress, math::*, molecule::*};
use anyhow::{Result, ensure};
use std::collections::{BTreeMap, BTreeSet, VecDeque};
pub const ENERGY_WINDOW: f64 = 0.20;
pub const RMSD_LIMIT: f64 = 0.10;
pub const MAX_DISPLACEMENT: f64 = 0.15;
pub const FREQ_RMSD: f64 = 2.;
pub const FREQ_MAX: f64 = 3.;
pub const HARTREE_TO_KCAL: f64 = 627.509474;
pub const R: f64 = 0.0019872036;

pub fn bond_ring(adj: &[Vec<usize>], a: usize, b: usize, largest: usize) -> Option<Vec<usize>> {
    let n = adj.len();
    let mut previous = vec![usize::MAX; n];
    previous[a] = a;
    let mut queue = VecDeque::from([a]);
    while let Some(current) = queue.pop_front() {
        if current == b {
            break;
        }
        for &next in &adj[current] {
            if (current == a && next == b) || (current == b && next == a) {
                continue;
            }
            if previous[next] == usize::MAX {
                previous[next] = current;
                queue.push_back(next);
            }
        }
    }
    if previous[b] == usize::MAX {
        return None;
    }
    let mut path = vec![b];
    let mut node = b;
    while node != a {
        node = previous[node];
        path.push(node);
    }
    if path.len() <= largest {
        Some(path)
    } else {
        None
    }
}
pub fn rings(adj: &[Vec<usize>], largest: usize) -> Vec<Vec<usize>> {
    let mut out = BTreeSet::new();
    for (a, ns) in adj.iter().enumerate() {
        for &b in ns {
            if a < b
                && let Some(mut r) = bond_ring(adj, a, b, largest)
            {
                r.sort();
                out.insert(r);
            }
        }
    }
    out.into_iter().collect()
}

/// Enumerate chordless cycles containing one specified bond. The returned
/// path starts at `a`, ends at `b`, and omits the direct `a`–`b` edge from the
/// path itself. Capping both cycle length and result count keeps dense or
/// malformed molecular graphs from causing an unbounded search.
pub fn chordless_bond_cycles(
    adj: &[Vec<usize>],
    a: usize,
    b: usize,
    largest: usize,
    limit: usize,
) -> Vec<Vec<usize>> {
    if a == b
        || a >= adj.len()
        || b >= adj.len()
        || largest < 3
        || limit == 0
        || !adj[a].contains(&b)
    {
        return Vec::new();
    }

    struct Search<'a> {
        adjacency: &'a [Vec<usize>],
        a: usize,
        b: usize,
        largest: usize,
        limit: usize,
        paths: Vec<Vec<usize>>,
    }
    impl Search<'_> {
        fn visit(&mut self, current: usize, seen: &mut [bool], path: &mut Vec<usize>) {
            if path.len() > self.largest || self.paths.len() >= self.limit {
                return;
            }
            // Continuing after reaching a vertex adjacent to the destination
            // would make that destination edge a chord of every later cycle.
            if current != self.a && self.adjacency[current].contains(&self.b) {
                if path.len() >= 2 {
                    let mut complete = path.clone();
                    complete.push(self.b);
                    self.paths.push(complete);
                }
                return;
            }
            for &next in &self.adjacency[current] {
                if self.paths.len() >= self.limit {
                    break;
                }
                if (current == self.a && next == self.b) || next == self.a || seen[next] {
                    continue;
                }
                if next == self.b {
                    if path.len() >= 2 {
                        let mut complete = path.clone();
                        complete.push(self.b);
                        self.paths.push(complete);
                    }
                    continue;
                }
                // A new vertex joined to an earlier nonconsecutive path
                // vertex would introduce a chord into the completed cycle.
                if path[..path.len().saturating_sub(1)]
                    .iter()
                    .any(|prior| self.adjacency[next].contains(prior))
                {
                    continue;
                }
                seen[next] = true;
                path.push(next);
                self.visit(next, seen, path);
                path.pop();
                seen[next] = false;
            }
        }
    }

    let mut search = Search {
        adjacency: adj,
        a,
        b,
        largest,
        limit,
        paths: Vec::new(),
    };
    let mut seen = vec![false; adj.len()];
    seen[a] = true;
    let mut path = vec![a];
    search.visit(a, &mut seen, &mut path);
    search.paths.sort();
    search.paths.dedup();
    search.paths
}
fn bfs(adj: &[Vec<usize>], start: usize) -> Vec<usize> {
    let mut out = vec![];
    let mut seen = vec![false; adj.len()];
    for root in std::iter::once(start).chain(0..adj.len()) {
        if seen[root] {
            continue;
        }
        seen[root] = true;
        out.push(root);
        let mut queue = VecDeque::from([root]);
        while let Some(a) = queue.pop_front() {
            for &b in &adj[a] {
                if !seen[b] {
                    seen[b] = true;
                    out.push(b);
                    queue.push_back(b);
                }
            }
        }
    }
    out
}
#[derive(Default)]
struct Registry(BTreeMap<String, usize>);
impl Registry {
    fn id(&mut self, key: String) -> usize {
        let next = self.0.len();
        *self.0.entry(key).or_insert(next)
    }
}
fn refine(adj: &[Vec<usize>], mut labels: Vec<usize>, registry: &mut Registry) -> Vec<usize> {
    let mut count = labels.iter().collect::<BTreeSet<_>>().len();
    for _ in 0..=adj.len() {
        let next: Vec<_> = adj
            .iter()
            .enumerate()
            .map(|(i, ns)| {
                let mut v: Vec<_> = ns.iter().map(|&j| labels[j]).collect();
                v.sort();
                registry.id(format!("R:{}:{v:?}", labels[i]))
            })
            .collect();
        let nc = next.iter().collect::<BTreeSet<_>>().len();
        labels = next;
        if count == nc {
            break;
        }
        count = nc;
    }
    labels
}
fn valence(e: &str) -> Option<usize> {
    match e {
        "H" | "F" | "Cl" | "Br" | "I" => Some(1),
        "O" | "S" => Some(2),
        "N" | "P" | "B" => Some(3),
        "C" => Some(4),
        _ => None,
    }
}
fn torsion_side(c: &[V3], [a, b, d, e]: [usize; 4]) -> Option<i32> {
    let axis = sub(c[d], c[b]);
    let length = norm(axis);
    if length < 1e-9 {
        return None;
    }
    let unit = mul(axis, 1. / length);
    let b1 = sub(c[a], c[b]);
    let b2 = sub(c[e], c[d]);
    let p1 = sub(b1, mul(unit, dot(b1, unit)));
    let p2 = sub(b2, mul(unit, dot(b2, unit)));
    let (l1, l2) = (norm(p1), norm(p2));
    if l1 < 1e-6 || l2 < 1e-6 {
        return None;
    }
    let cosine = dot(p1, p2) / (l1 * l2);
    if cosine.abs() < 0.08 {
        None
    } else {
        Some(if cosine > 0. { 1 } else { -1 })
    }
}
fn parity(c: &[V3], center: usize, neighbors: &[usize]) -> i32 {
    let vol = if neighbors.len() == 4 {
        volume(
            c[neighbors[0]],
            c[neighbors[1]],
            c[neighbors[2]],
            c[neighbors[3]],
        )
    } else {
        volume(c[center], c[neighbors[0]], c[neighbors[1]], c[neighbors[2]])
    };
    if vol > 0. { 1 } else { -1 }
}
#[derive(Clone, Debug)]
pub struct Equivalence {
    pub groups: Vec<Vec<usize>>,
    pub exhausted: bool,
    pub unverifiable: Vec<usize>,
}
struct EquivEngine {
    adj: Vec<Vec<usize>>,
    coordinates: Vec<V3>,
    registry: Registry,
    base: Vec<usize>,
    seeds: BTreeMap<usize, Vec<usize>>,
    centers: Vec<(usize, Vec<usize>)>,
    rigid: Vec<([usize; 4], i32)>,
    unverifiable: BTreeSet<usize>,
    exhausted: bool,
}
impl EquivEngine {
    fn new(m: &Molecule) -> Self {
        let adj = m.adjacency();
        let c = m.coords();
        let mut registry = Registry::default();
        let raw = m
            .atoms
            .iter()
            .enumerate()
            .map(|(i, a)| {
                registry.id(format!(
                    "A:{}:{}:{}:{}",
                    a.element,
                    a.charge,
                    a.isotope,
                    adj[i].len()
                ))
            })
            .collect();
        let base = refine(&adj, raw, &mut registry);
        let small: BTreeSet<_> = rings(&adj, 10)
            .into_iter()
            .filter(|r| matches!(r.len(), 3 | 4))
            .flatten()
            .collect();
        let mut centers = vec![];
        let mut unverifiable = BTreeSet::new();
        let mut sp2 = vec![false; adj.len()];
        for (i, ns) in adj.iter().enumerate() {
            let a = &m.atoms[i];
            let vol = if ns.len() == 4 {
                Some(volume(c[ns[0]], c[ns[1]], c[ns[2]], c[ns[3]]))
            } else if ns.len() == 3
                && (matches!(a.element.as_str(), "P" | "S" | "Se" | "As")
                    || (a.element == "N" && small.contains(&i)))
            {
                Some(volume(c[i], c[ns[0]], c[ns[1]], c[ns[2]]))
            } else {
                None
            };
            if vol.is_some_and(|v| v.abs() >= 0.02) {
                centers.push((i, ns.clone()));
            }
            if ns.len() >= 5 {
                unverifiable.insert(i);
                unverifiable.extend(ns);
            }
            if ns.len() == 2
                && a.charge == 0
                && valence(&a.element).is_some_and(|v| v >= 4)
                && ns.iter().all(|&j| adj[j].len() >= 3)
            {
                for &terminal in ns {
                    unverifiable.insert(terminal);
                    unverifiable.extend(adj[terminal].iter().filter(|&&j| j != i));
                }
            }
            let planar = ns.len() == 3 && volume(c[i], c[ns[0]], c[ns[1]], c[ns[2]]).abs() < 0.02;
            let deficient = ns.len() == 2
                && match valence(&a.element) {
                    None => true,
                    Some(expected) => {
                        if a.charge == 1 && matches!(a.element.as_str(), "N" | "O") {
                            ns.len() < expected + 1
                        } else if a.charge != 0 {
                            true
                        } else {
                            ns.len() < expected
                        }
                    }
                };
            sp2[i] = planar || deficient;
        }
        let mut rigid = vec![];
        for (i, ns) in adj.iter().enumerate() {
            for &j in ns {
                if j > i && sp2[i] && sp2[j] {
                    for &a in ns {
                        if a == j {
                            continue;
                        }
                        for &b in &adj[j] {
                            if b == i {
                                continue;
                            }
                            let atoms = [a, i, j, b];
                            if let Some(side) = torsion_side(&c, atoms) {
                                rigid.push((atoms, side));
                            }
                        }
                    }
                }
            }
        }
        Self {
            adj,
            coordinates: c,
            registry,
            base,
            seeds: BTreeMap::new(),
            centers,
            rigid,
            unverifiable,
            exhausted: false,
        }
    }
    fn seeded(&mut self, atom: usize) -> Vec<usize> {
        if let Some(v) = self.seeds.get(&atom) {
            return v.clone();
        }
        let mut s = self.base.clone();
        s[atom] = self.registry.id(format!("S:{}", s[atom]));
        let labels = refine(&self.adj, s, &mut self.registry);
        self.seeds.insert(atom, labels.clone());
        labels
    }
    fn constraints(&self, map: &[usize], sign: i32) -> bool {
        for (c, ns) in &self.centers {
            if map[*c] == usize::MAX || ns.iter().any(|&i| map[i] == usize::MAX) {
                continue;
            }
            let target: Vec<_> = ns.iter().map(|&i| map[i]).collect();
            if parity(&self.coordinates, *c, ns) * parity(&self.coordinates, map[*c], &target)
                != sign
            {
                return false;
            }
        }
        for &(atoms, side) in &self.rigid {
            if atoms.iter().any(|&i| map[i] == usize::MAX) {
                continue;
            }
            if torsion_side(&self.coordinates, atoms.map(|i| map[i]))
                .is_some_and(|image| image != side)
            {
                return false;
            }
        }
        true
    }
    fn mapping(
        &mut self,
        source: usize,
        target: usize,
        sign: i32,
        rigid: bool,
        progress: &Progress,
    ) -> Result<bool> {
        let sl = self.seeded(source);
        let tl = self.seeded(target);
        let n = self.adj.len();
        fn hist(v: &[usize]) -> BTreeMap<usize, usize> {
            let mut h = BTreeMap::new();
            for &x in v {
                *h.entry(x).or_default() += 1
            }
            h
        }
        if hist(&sl) != hist(&tl) {
            return Ok(false);
        }
        let candidates: Vec<Vec<usize>> = sl
            .iter()
            .map(|&l| (0..n).filter(|&j| tl[j] == l).collect())
            .collect();
        let order = bfs(&self.adj, source);
        let mut map = vec![usize::MAX; n];
        let mut reverse = map.clone();
        map[source] = target;
        reverse[target] = source;
        let mut budget = 2_000_000;
        #[allow(clippy::too_many_arguments)]
        fn search(
            e: &EquivEngine,
            pos: usize,
            order: &[usize],
            candidates: &[Vec<usize>],
            map: &mut [usize],
            reverse: &mut [usize],
            budget: &mut usize,
            sign: i32,
            rigid: bool,
            p: &Progress,
        ) -> Result<bool> {
            if pos == order.len() {
                return Ok(true);
            }
            let atom = order[pos];
            for &candidate in &candidates[atom] {
                if reverse[candidate] != usize::MAX {
                    continue;
                }
                if *budget == 0 {
                    return Ok(false);
                }
                *budget -= 1;
                if (*budget).is_multiple_of(4096) {
                    p.check()?;
                }
                if !legal_partial(&e.adj, map, reverse, atom, candidate) {
                    continue;
                }
                if rigid
                    && map
                        .iter()
                        .enumerate()
                        .filter(|(_, v)| **v != usize::MAX)
                        .any(|(i, &j)| {
                            (distance(e.coordinates[atom], e.coordinates[i])
                                - distance(e.coordinates[candidate], e.coordinates[j]))
                            .abs()
                                > 0.15
                        })
                {
                    continue;
                }
                map[atom] = candidate;
                reverse[candidate] = atom;
                if e.constraints(map, sign)
                    && search(
                        e,
                        pos + 1,
                        order,
                        candidates,
                        map,
                        reverse,
                        budget,
                        sign,
                        rigid,
                        p,
                    )?
                {
                    return Ok(true);
                }
                map[atom] = usize::MAX;
                reverse[candidate] = usize::MAX;
            }
            Ok(false)
        }
        let found = self.constraints(&map, sign)
            && search(
                self,
                1,
                &order,
                &candidates,
                &mut map,
                &mut reverse,
                &mut budget,
                sign,
                rigid,
                progress,
            )?;
        if budget == 0 {
            self.exhausted = true
        }
        Ok(found)
    }
    fn related(&mut self, a: usize, b: usize, p: &Progress) -> Result<bool> {
        if self.unverifiable.contains(&a) || self.unverifiable.contains(&b) {
            return Ok(false);
        }
        for rigid in [true, false] {
            for sign in [1, -1] {
                if self.mapping(a, b, sign, rigid, p)? {
                    return Ok(true);
                }
            }
        }
        Ok(false)
    }
}
fn legal_partial(adj: &[Vec<usize>], map: &[usize], reverse: &[usize], a: usize, b: usize) -> bool {
    !adj[a]
        .iter()
        .any(|&n| map[n] != usize::MAX && !adj[b].contains(&map[n]))
        && !adj[b]
            .iter()
            .any(|&n| reverse[n] != usize::MAX && !adj[a].contains(&reverse[n]))
}
pub fn equivalence(m: &Molecule, p: &Progress) -> Result<Equivalence> {
    m.validate()?;
    let mut engine = EquivEngine::new(m);
    let mut labels = BTreeMap::<usize, Vec<usize>>::new();
    for (i, &label) in engine.base.iter().enumerate() {
        labels.entry(label).or_default().push(i);
    }
    let mut groups: Vec<Vec<usize>> = vec![];
    let mut classes: Vec<_> = labels.into_values().collect();
    classes.sort_by_key(|v| v[0]);
    for members in classes {
        p.check()?;
        let mut local: Vec<Vec<usize>> = vec![];
        for atom in members {
            let mut matched = false;
            for g in &mut local {
                if engine.related(g[0], atom, p)? {
                    g.push(atom);
                    matched = true;
                    break;
                }
            }
            if !matched {
                local.push(vec![atom]);
            }
        }
        groups.extend(local.into_iter().filter(|g| g.len() > 1));
    }
    groups.sort_by_key(|g| g[0]);
    Ok(Equivalence {
        groups,
        exhausted: engine.exhausted,
        unverifiable: engine.unverifiable.into_iter().collect(),
    })
}
pub fn average_shifts(values: &Values, groups: &[Vec<usize>]) -> Values {
    let mut out = values.clone();
    for g in groups {
        let values: Vec<_> = g
            .iter()
            .filter_map(|i| values.get(i).map(|v| (*i, *v)))
            .collect();
        if values.len() > 1 {
            let avg = values.iter().map(|(_, v)| v).sum::<f64>() / values.len() as f64;
            for (i, _) in values {
                out.insert(i, avg);
            }
        }
    }
    out
}
pub fn average_couplings(
    values: &PairValues,
    groups: &[Vec<usize>],
    atom_count: usize,
) -> PairValues {
    let mut assigned = vec![false; atom_count];
    let mut all = groups.to_vec();
    for g in groups {
        for &i in g {
            assigned[i] = true
        }
    }
    for (i, used) in assigned.iter().enumerate() {
        if !used {
            all.push(vec![i])
        }
    }
    let mut group_index = vec![0; atom_count];
    for (id, g) in all.iter().enumerate() {
        for &i in g {
            group_index[i] = id
        }
    }
    let mut sums = BTreeMap::<Pair, (f64, usize)>::new();
    for (&(a, b), &v) in values {
        let key = pair(group_index[a], group_index[b]);
        let x = sums.entry(key).or_default();
        x.0 += v;
        x.1 += 1;
    }
    let mut out = PairValues::new();
    for ((a, b), (sum, n)) in sums {
        for &i in &all[a] {
            for &j in &all[b] {
                if i != j {
                    out.insert(pair(i, j), sum / n as f64);
                }
            }
        }
    }
    out
}
pub fn frequency_agreement(a: &[f64], b: &[f64]) -> Option<(f64, f64)> {
    if a.is_empty() || a.len() != b.len() {
        return None;
    }
    let (mut a, mut b) = (a.to_vec(), b.to_vec());
    a.sort_by(f64::total_cmp);
    b.sort_by(f64::total_cmp);
    let diffs: Vec<_> = a.iter().zip(b).map(|(a, b)| (a - b).abs()).collect();
    Some((
        (diffs.iter().map(|x| x * x).sum::<f64>() / diffs.len() as f64).sqrt(),
        diffs.into_iter().fold(0_f64, f64::max),
    ))
}
fn mass(e: &str) -> f64 {
    match e {
        "H" => 1.008,
        "B" => 10.81,
        "C" => 12.011,
        "N" => 14.007,
        "O" => 15.999,
        "F" => 18.998,
        "Na" => 22.990,
        "Mg" => 24.305,
        "Al" => 26.982,
        "Si" => 28.085,
        "P" => 30.974,
        "S" => 32.06,
        "Cl" => 35.45,
        "K" => 39.098,
        "Ca" => 40.078,
        "Fe" => 55.845,
        "Zn" => 65.38,
        "Se" => 78.971,
        "Br" => 79.904,
        "I" => 126.904,
        _ => 12.011,
    }
}
fn moments(m: &Molecule, c: &[V3]) -> [f64; 3] {
    let total = m.atoms.iter().map(|a| mass(&a.element)).sum::<f64>();
    let centre = mul(
        m.atoms
            .iter()
            .zip(c)
            .fold([0.; 3], |sum, (a, &p)| add(sum, mul(p, mass(&a.element)))),
        1. / total,
    );
    let mut tensor = [[0.; 3]; 3];
    for (a, &p) in m.atoms.iter().zip(c) {
        let r = sub(p, centre);
        let w = mass(&a.element);
        for i in 0..3 {
            for j in 0..3 {
                tensor[i][j] += w
                    * (if i == j {
                        dot(r, r) - r[i] * r[j]
                    } else {
                        -r[i] * r[j]
                    });
            }
        }
    }
    let (mut values, _) = eigen(tensor);
    values.sort_by(f64::total_cmp);
    values
}
fn dedup_labels(m: &Molecule, adj: &[Vec<usize>]) -> Vec<usize> {
    let mut shortest = vec![0; adj.len()];
    for ring in rings(adj, 10) {
        for &i in &ring {
            if shortest[i] == 0 || ring.len() < shortest[i] {
                shortest[i] = ring.len()
            }
        }
    }
    let mut registry = Registry::default();
    let labels = m
        .atoms
        .iter()
        .enumerate()
        .map(|(i, a)| {
            registry.id(format!(
                "D:{}:{}:{}:{}:{}",
                a.element,
                a.charge,
                a.isotope,
                adj[i].len(),
                shortest[i]
            ))
        })
        .collect();
    refine(adj, labels, &mut registry)
}
fn permutations(v: &[usize]) -> Vec<Vec<usize>> {
    fn rec(values: &mut Vec<usize>, pos: usize, out: &mut Vec<Vec<usize>>) {
        if pos == values.len() {
            out.push(values.clone());
            return;
        }
        for i in pos..values.len() {
            values.swap(pos, i);
            rec(values, pos + 1, out);
            values.swap(pos, i);
        }
    }
    let mut out = vec![];
    rec(&mut v.to_vec(), 0, &mut out);
    out.sort();
    out
}
fn orbit_match(
    adj: &[Vec<usize>],
    a: &[V3],
    b: &[V3],
    classes: &[Vec<usize>],
    p: &Progress,
) -> Result<Option<Vec<usize>>> {
    let mut classes = classes.to_vec();
    classes.sort_by_key(Vec::len);
    let singles: Vec<_> = classes
        .iter()
        .filter(|g| g.len() == 1)
        .flatten()
        .copied()
        .collect();
    let mut seed_classes = vec![];
    let mut trials = 1usize;
    let mut count = 0;
    if singles.len() >= 3 {
        seed_classes = singles.into_iter().map(|i| vec![i]).collect();
    } else {
        for g in &classes {
            let factorial = (1..=g.len()).fold(1usize, |a, b| a.saturating_mul(b));
            let candidate = trials.saturating_mul(factorial);
            if candidate > 720 && !seed_classes.is_empty() {
                break;
            }
            seed_classes.push(g.clone());
            trials = candidate;
            count += g.len();
            if count >= 3 {
                break;
            }
        }
        if count < 3 || trials > 720 {
            return Ok(None);
        }
    }
    let seeded: BTreeSet<_> = seed_classes.iter().flatten().copied().collect();
    let remaining: Vec<_> = classes
        .iter()
        .filter(|g| !seeded.contains(&g[0]))
        .cloned()
        .collect();
    let mut seeds = vec![vec![usize::MAX; a.len()]];
    for group in &seed_classes {
        let mut next = vec![];
        for seed in &seeds {
            for perm in permutations(group) {
                let mut s = seed.clone();
                for (&i, &j) in group.iter().zip(&perm) {
                    s[i] = j
                }
                next.push(s);
            }
        }
        seeds = next;
    }
    let ac = centroid(a);
    let bc = centroid(b);
    let mut best = None;
    let mut best_rmsd = f64::INFINITY;
    for seed in seeds {
        p.check()?;
        let mut map = seed.clone();
        let mut previous: Option<Vec<usize>> = None;
        let mut settled = false;
        for _ in 0..25 {
            let anchor_a: Vec<_> = (0..a.len())
                .filter(|&i| map[i] != usize::MAX)
                .map(|i| a[i])
                .collect();
            let anchor_b: Vec<_> = (0..a.len())
                .filter(|&i| map[i] != usize::MAX)
                .map(|i| b[map[i]])
                .collect();
            if anchor_a.len() < 3 {
                break;
            }
            let fit = superpose(&anchor_a, &anchor_b)?;
            let mut updated = seed.clone();
            for g in &remaining {
                let rotated: Vec<_> = g
                    .iter()
                    .map(|&i| add(transform(fit.rotation, sub(b[i], bc)), ac))
                    .collect();
                let cost: Vec<Vec<_>> = g
                    .iter()
                    .map(|&i| {
                        rotated
                            .iter()
                            .map(|&r| dot(sub(a[i], r), sub(a[i], r)))
                            .collect()
                    })
                    .collect();
                let assignment = hungarian(&cost);
                for (i, &atom) in g.iter().enumerate() {
                    updated[atom] = g[assignment[i]];
                }
            }
            if previous.as_ref() == Some(&updated) {
                map = updated;
                settled = true;
                break;
            }
            previous = Some(map);
            map = updated;
        }
        if !settled || map.contains(&usize::MAX) {
            continue;
        }
        let legal = (0..a.len()).all(|i| {
            let image: BTreeSet<_> = adj[i].iter().map(|&j| map[j]).collect();
            image == adj[map[i]].iter().copied().collect()
        });
        if !legal {
            continue;
        }
        let reordered: Vec<_> = map.iter().map(|&i| b[i]).collect();
        let rmsd = superpose(a, &reordered)?.rmsd;
        if rmsd < best_rmsd {
            best = Some(map);
            best_rmsd = rmsd
        }
        if best_rmsd <= RMSD_LIMIT * 0.1 {
            break;
        }
    }
    Ok(best)
}
pub fn graph_superposition(
    m: &Molecule,
    a: &[V3],
    b: &[V3],
    p: &Progress,
) -> Result<(Option<Superposition>, bool)> {
    ensure!(
        a.len() == m.atoms.len() && a.len() == b.len(),
        "Deduplication coordinate counts differ"
    );
    let adj = m.adjacency();
    let labels = dedup_labels(m, &adj);
    let mut by_label = BTreeMap::<usize, Vec<usize>>::new();
    for (i, &l) in labels.iter().enumerate() {
        by_label.entry(l).or_default().push(i);
    }
    let classes: Vec<_> = by_label.values().cloned().collect();
    if let Some(perm) = orbit_match(&adj, a, b, &classes, p)? {
        let target: Vec<_> = perm.iter().map(|&i| b[i]).collect();
        return Ok((Some(superpose(a, &target)?), false));
    }
    let n = a.len();
    let order = bfs(&adj, 0);
    let candidates: Vec<_> = labels.iter().map(|l| by_label[l].clone()).collect();
    let mut map = vec![usize::MAX; n];
    let mut reverse = map.clone();
    let (mut nodes, mut found) = (0usize, 0usize);
    let mut best = None;
    let mut truncated = false;
    #[allow(clippy::too_many_arguments)]
    fn search(
        pos: usize,
        order: &[usize],
        candidates: &[Vec<usize>],
        adj: &[Vec<usize>],
        map: &mut [usize],
        reverse: &mut [usize],
        a: &[V3],
        b: &[V3],
        nodes: &mut usize,
        found: &mut usize,
        best: &mut Option<Superposition>,
        truncated: &mut bool,
        p: &Progress,
    ) -> Result<bool> {
        if pos == order.len() {
            *found += 1;
            let target: Vec<_> = map.iter().map(|&i| b[i]).collect();
            let fit = superpose(a, &target)?;
            if best.as_ref().is_none_or(|x| fit.rmsd < x.rmsd) {
                *best = Some(fit)
            }
            if fit.rmsd <= RMSD_LIMIT && fit.maximum <= MAX_DISPLACEMENT {
                *best = Some(fit);
                return Ok(true);
            }
            if *found >= 500_000 {
                *truncated = true
            }
            return Ok(false);
        }
        let atom = order[pos];
        for &candidate in &candidates[atom] {
            if reverse[candidate] != usize::MAX {
                continue;
            }
            if *nodes >= 10_000_000 || *found >= 500_000 {
                *truncated = true;
                return Ok(false);
            }
            *nodes += 1;
            if (*nodes).is_multiple_of(4096) {
                p.check()?
            }
            if !legal_partial(adj, map, reverse, atom, candidate) {
                continue;
            }
            map[atom] = candidate;
            reverse[candidate] = atom;
            if search(
                pos + 1,
                order,
                candidates,
                adj,
                map,
                reverse,
                a,
                b,
                nodes,
                found,
                best,
                truncated,
                p,
            )? {
                return Ok(true);
            }
            map[atom] = usize::MAX;
            reverse[candidate] = usize::MAX;
        }
        Ok(false)
    }
    search(
        0,
        &order,
        &candidates,
        &adj,
        &mut map,
        &mut reverse,
        a,
        b,
        &mut nodes,
        &mut found,
        &mut best,
        &mut truncated,
        p,
    )?;
    Ok((best, truncated))
}
#[derive(Clone, Debug)]
pub struct DedupInput {
    pub number: usize,
    pub energy: Option<f64>,
    pub coordinates: Vec<V3>,
    pub frequencies: Vec<f64>,
}
#[derive(Clone, Debug)]
pub struct Duplicate {
    pub number: usize,
    pub representative: usize,
    pub energy_gap: f64,
    pub rmsd: f64,
    pub maximum: f64,
    pub frequencies: Option<(f64, f64)>,
}
#[derive(Clone, Debug, Default)]
pub struct DedupResult {
    pub survivors: BTreeSet<usize>,
    pub duplicates: Vec<Duplicate>,
    pub report: String,
}
pub fn deduplicate(
    m: &Molecule,
    inputs: &[DedupInput],
    enabled: bool,
    p: &Progress,
) -> Result<DedupResult> {
    let mut result = DedupResult::default();
    if !enabled {
        result.survivors.extend(inputs.iter().map(|x| x.number));
        result.report = "Deduplication disabled; all valid conformers retained.\n".into();
        return Ok(result);
    }
    let mut ordered: Vec<_> = inputs.iter().collect();
    ordered.sort_by(|a, b| {
        a.energy
            .unwrap_or(f64::INFINITY)
            .total_cmp(&b.energy.unwrap_or(f64::INFINITY))
            .then(a.number.cmp(&b.number))
    });
    let mut representatives: Vec<&DedupInput> = vec![];
    let mut cache = BTreeMap::new();
    let mut notes = vec![];
    for x in &ordered {
        if x.coordinates.len() == m.atoms.len() {
            cache.insert(x.number, moments(m, &x.coordinates));
        }
    }
    let (mut frequency_blocked, mut energy_screened, mut inertia_screened, mut exact) =
        (0, 0, 0, 0);
    for (index, candidate) in ordered.into_iter().enumerate() {
        if inputs.len() > 5 && (index % 5 == 0 || index + 1 == inputs.len()) {
            p.log(format!(
                "Duplicate check: conformer {} ({}/{})",
                candidate.number,
                index + 1,
                inputs.len()
            ));
        }
        p.check()?;
        if candidate.energy.is_none() || candidate.coordinates.len() != m.atoms.len() {
            result.survivors.insert(candidate.number);
            notes.push(format!(
                "Conformer {} retained without a geometry/energy gate.",
                candidate.number
            ));
            continue;
        }
        let mut best: Option<Duplicate> = None;
        for representative in &representatives {
            let gap =
                (candidate.energy.unwrap() - representative.energy.unwrap()) * HARTREE_TO_KCAL;
            if gap > ENERGY_WINDOW {
                energy_screened += 1;
                continue;
            }
            if cache[&candidate.number]
                .iter()
                .zip(cache[&representative.number])
                .any(|(a, b)| (a - b).abs() / a.abs().max(b.abs()).max(1e-9) > 0.05)
            {
                inertia_screened += 1;
                continue;
            }
            exact += 1;
            let (fit, truncated) =
                graph_superposition(m, &representative.coordinates, &candidate.coordinates, p)?;
            if truncated {
                notes.push(format!(
                    "Symmetry search capped for {} versus {}; a duplicate may remain unmerged.",
                    candidate.number, representative.number
                ));
            }
            let Some(fit) = fit else { continue };
            if fit.rmsd > RMSD_LIMIT || fit.maximum > MAX_DISPLACEMENT {
                continue;
            }
            let frequency =
                frequency_agreement(&representative.frequencies, &candidate.frequencies);
            if let Some((r, max)) = frequency
                && (r > FREQ_RMSD || max > FREQ_MAX)
            {
                frequency_blocked += 1;
                notes.push(format!("{} versus {}: frequency gate blocked merge (RMSD {r:.3}, maximum {max:.3} cm^-1).",candidate.number,representative.number));
                continue;
            }
            let record = Duplicate {
                number: candidate.number,
                representative: representative.number,
                energy_gap: gap,
                rmsd: fit.rmsd,
                maximum: fit.maximum,
                frequencies: frequency,
            };
            if best.as_ref().is_none_or(|b| record.rmsd < b.rmsd) {
                best = Some(record)
            }
        }
        if let Some(d) = best {
            result.duplicates.push(d)
        } else {
            result.survivors.insert(candidate.number);
            representatives.push(candidate);
        }
    }
    result.report = format!(
        "Conformer deduplication\nAll-atom, graph-legal symmetry; proper rotations only.\nEnergy window: 0.20 kcal/mol\nRMSD limit: 0.10 Angstrom\nMaximum displacement: 0.15 Angstrom\nFrequency RMSD / maximum: 2.0 / 3.0 cm^-1 when comparable spectra are available.\n\n{} considered; {} retained; {} duplicates.\nEnergy-screened pairs: {energy_screened}\nInertia-screened pairs: {inertia_screened}\nExact comparisons: {exact}\nFrequency-blocked pairs: {frequency_blocked}\n\n",
        inputs.len(),
        result.survivors.len(),
        result.duplicates.len()
    );
    for d in &result.duplicates {
        let frequency = d
            .frequencies
            .map(|(a, b)| format!("RMSD {a:.3}, max {b:.3} cm^-1"))
            .unwrap_or("not available / incomparable".into());
        result.report += &format!(
            "Conformer {} -> {}: ΔG {:.6} kcal/mol; RMSD {:.6} A; maximum {:.6} A; frequencies {frequency}\n",
            d.number, d.representative, d.energy_gap, d.rmsd, d.maximum
        );
    }
    for note in notes {
        result.report += &format!("\n{note}")
    }
    result.report.push('\n');
    Ok(result)
}
