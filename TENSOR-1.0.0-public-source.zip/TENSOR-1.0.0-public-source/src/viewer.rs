//! Interactive orthographic molecular view. The molecular solid is immutable
//! between loads; camera motion only transforms it for depth-correct rendering.
use crate::{
    branding::LABEL_FONT,
    math::*,
    molecule::*,
    render3d::{BACKGROUND, Camera, LABEL_COLOR, Raster, Scene},
};
use ab_glyph::{Font, FontArc, Glyph, PxScale, point};
use eframe::egui::{self, Color32, Pos2, Rect, Sense, Stroke, Vec2};
use std::{
    collections::BTreeMap,
    sync::{Arc, LazyLock},
};
static FONT: LazyLock<FontArc> =
    LazyLock::new(|| FontArc::try_from_slice(LABEL_FONT).expect("bundled label font"));

#[derive(Clone, Debug, PartialEq)]
struct FrameKey {
    width: usize,
    height: usize,
    rotation: M3,
    zoom: f64,
    pan: [f64; 2],
    antialias: bool,
    label_mode: LabelMode,
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum LabelMode {
    #[default]
    Shifts,
    AtomNumbers,
    None,
}

impl LabelMode {
    pub fn name(self) -> &'static str {
        match self {
            Self::Shifts => "Shift values",
            Self::AtomNumbers => "Atom numbers",
            Self::None => "None",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum SelectionMeasurement {
    Atom(usize),
    Distance { atoms: [usize; 2], angstrom: f64 },
    Angle { atoms: [usize; 3], degrees: f64 },
    Dihedral { atoms: [usize; 4], degrees: f64 },
    NotConnected,
    Degenerate,
}
#[derive(Clone, Debug)]
pub struct LabelPlacement {
    pub atom: usize,
    pub position: [f64; 2],
    pub depth: f64,
    pub text: String,
}
#[derive(Clone)]
pub struct Viewer {
    pub molecule: Molecule,
    pub coordinates: Vec<V3>,
    pub labels: BTreeMap<usize, String>,
    pub rotation: M3,
    pub zoom: f64,
    pub pan: [f64; 2],
    pub label_mode: LabelMode,
    pub selected_atoms: Vec<usize>,
    pub fit_next: bool,
    pub empty_message: String,
    pub last_rect: Option<Rect>,
    pub scene: Arc<Scene>,
    pub frames_rendered: usize,
    texture: Option<egui::TextureHandle>,
    frame_key: Option<FrameKey>,
}
impl Default for Viewer {
    fn default() -> Self {
        Self {
            molecule: Molecule::default(),
            coordinates: vec![],
            labels: BTreeMap::new(),
            rotation: matmul(rot_y(-30.), rot_x(20.)),
            zoom: 28.,
            pan: [0.; 2],
            label_mode: LabelMode::Shifts,
            selected_atoms: vec![],
            fit_next: false,
            empty_message: "Run an analysis to view a structure".into(),
            last_rect: None,
            scene: Arc::new(Scene::default()),
            frames_rendered: 0,
            texture: None,
            frame_key: None,
        }
    }
}
fn composite(pixel: &mut [u8], rgb: [u8; 3], coverage: f32) {
    let source = coverage.clamp(0., 1.);
    let dest = pixel[3] as f32 / 255.;
    let alpha = source + dest * (1. - source);
    if alpha <= 0. {
        return;
    }
    for channel in 0..3 {
        pixel[channel] =
            ((rgb[channel] as f32 * source + pixel[channel] as f32 * dest * (1. - source)) / alpha)
                .round()
                .clamp(0., 255.) as u8;
    }
    pixel[3] = (alpha * 255.).round() as u8;
}
fn label_layout(text: &str, center: [f64; 2], height: f32) -> Vec<Glyph> {
    let scale = height / FONT.height_unscaled();
    let ids: Vec<_> = text
        .chars()
        .map(|character| FONT.glyph_id(character))
        .collect();
    let mut total = 0.;
    let mut previous = None;
    for &id in &ids {
        if let Some(previous) = previous {
            total += FONT.kern_unscaled(previous, id) * scale;
        }
        total += FONT.h_advance_unscaled(id) * scale;
        previous = Some(id);
    }
    let mut x = center[0] as f32 - total / 2.;
    let baseline = center[1] as f32 + height * 0.30;
    let mut glyphs = vec![];
    previous = None;
    for id in ids {
        if let Some(previous) = previous {
            x += FONT.kern_unscaled(previous, id) * scale;
        }
        glyphs.push(Glyph {
            id,
            scale: PxScale::from(height),
            position: point(x, baseline),
        });
        x += FONT.h_advance_unscaled(id) * scale;
        previous = Some(id);
    }
    glyphs
}
impl Viewer {
    pub fn load(&mut self, molecule: &Molecule, labels: BTreeMap<usize, String>) {
        self.molecule = molecule.clone();
        let coordinates = molecule.coords();
        let center = centroid(&coordinates);
        self.coordinates = coordinates.into_iter().map(|v| sub(v, center)).collect();
        self.scene = Arc::new(Scene::from_molecule(molecule, &self.coordinates));
        self.labels = labels;
        self.selected_atoms.clear();
        self.fit_next = true;
        self.frame_key = None;
    }
    pub fn load_overlay(&mut self, molecules: &[&Molecule]) {
        const ACCENTS: [[u8; 3]; 10] = [
            [43, 148, 255],
            [255, 121, 82],
            [61, 201, 147],
            [197, 120, 255],
            [255, 190, 48],
            [45, 204, 211],
            [245, 94, 154],
            [151, 205, 75],
            [116, 143, 255],
            [255, 144, 32],
        ];
        self.clear();
        let Some(first) = molecules.first() else {
            return;
        };
        self.molecule = (*first).clone();
        let all: Vec<_> = molecules
            .iter()
            .flat_map(|molecule| molecule.coords())
            .collect();
        let center = centroid(&all);
        let mut scene = Scene::default();
        for (index, molecule) in molecules.iter().enumerate() {
            let points: Vec<_> = molecule
                .coords()
                .into_iter()
                .map(|point| sub(point, center))
                .collect();
            self.coordinates.extend(points.iter().copied());
            scene.solids.extend(
                Scene::from_molecule(molecule, &points)
                    .tinted(ACCENTS[index % ACCENTS.len()], 0.24)
                    .solids,
            );
        }
        self.scene = Arc::new(scene);
        self.labels.clear();
        self.label_mode = LabelMode::None;
        self.selected_atoms.clear();
        self.fit_next = true;
        self.frame_key = None;
    }
    pub fn clear(&mut self) {
        self.molecule = Molecule::default();
        self.coordinates.clear();
        self.labels.clear();
        self.selected_atoms.clear();
        self.scene = Arc::new(Scene::default());
        self.texture = None;
        self.frame_key = None;
        self.fit_next = false;
    }
    pub fn reset(&mut self) {
        self.rotation = matmul(rot_y(-30.), rot_x(20.));
        self.pan = [0.; 2];
        self.fit_next = true;
    }
    pub fn fit(&mut self, width: f64, height: f64) {
        if self.coordinates.is_empty() {
            self.fit_next = false;
            return;
        }
        let p: Vec<_> = self
            .coordinates
            .iter()
            .map(|&p| transform(self.rotation, p))
            .collect();
        let bounds = |axis: usize| {
            let lo = p.iter().map(|p| p[axis]).fold(f64::INFINITY, f64::min) - 0.3;
            let hi = p.iter().map(|p| p[axis]).fold(f64::NEG_INFINITY, f64::max) + 0.3;
            (lo, hi)
        };
        let (x0, x1) = bounds(0);
        let (y0, y1) = bounds(1);
        self.zoom = (width * 0.83 / (x1 - x0))
            .min(height * 0.83 / (y1 - y0))
            .clamp(2., 600.);
        self.pan = [-(x0 + x1) * self.zoom * 0.5, (y0 + y1) * self.zoom * 0.5];
        self.fit_next = false;
    }
    pub fn reference_size(&self) -> [f64; 2] {
        self.last_rect
            .map(|r| [r.width() as f64, r.height() as f64])
            .unwrap_or([800., 600.])
    }
    pub fn camera_for(&self, width: usize) -> Camera {
        let scale = width as f64 / self.reference_size()[0].max(1.);
        Camera {
            rotation: self.rotation,
            zoom: self.zoom * scale,
            pan: self.pan.map(|p| p * scale),
        }
    }
    pub fn render_snapshot(&self, width: usize, height: usize, antialias: bool) -> Raster {
        self.scene
            .render(width, height, self.camera_for(width), antialias)
    }
    pub fn label_positions(&self, width: f64, height: f64) -> Vec<LabelPlacement> {
        let scale = width / self.reference_size()[0].max(1.);
        let adjacency = self.molecule.adjacency();
        let source: Vec<_> = match self.label_mode {
            LabelMode::Shifts => self
                .labels
                .iter()
                .map(|(&index, label)| (index, label.clone()))
                .collect(),
            LabelMode::AtomNumbers => (0..self.molecule.atoms.len())
                .map(|index| (index, (index + 1).to_string()))
                .collect(),
            LabelMode::None => vec![],
        };
        let mut labels: Vec<_> = source
            .into_iter()
            .filter_map(|(index, label)| {
                let point = transform(self.rotation, *self.coordinates.get(index)?);
                if label.is_empty() {
                    return None;
                }
                let surface = if adjacency[index].is_empty() {
                    0.29
                } else {
                    0.13
                };
                Some(LabelPlacement {
                    atom: index,
                    depth: point[2] + surface,
                    position: [
                        width / 2. + (self.pan[0] + point[0] * self.zoom) * scale,
                        height / 2. + (self.pan[1] - point[1] * self.zoom - 11.) * scale,
                    ],
                    text: label,
                })
            })
            .collect();
        labels.sort_by(|a, b| a.depth.total_cmp(&b.depth));
        labels
    }
    pub fn paint_labels(&self, raster: &mut Raster) {
        if self.label_mode == LabelMode::None
            || (self.label_mode == LabelMode::Shifts && self.labels.is_empty())
        {
            return;
        }
        let camera = self.camera_for(raster.width);
        let origin = [
            raster.width as f64 / 2. + camera.pan[0],
            raster.height as f64 / 2. + camera.pan[1],
        ];
        let depth = self.scene.depth_test(camera);
        let factor = raster.width as f64 / self.reference_size()[0].max(1.);
        let height = (13. * factor) as f32;
        let radius = factor.ceil().max(1.) as i32;
        for label in self.label_positions(raster.width as f64, raster.height as f64) {
            let glyphs = label_layout(&label.text, label.position, height);
            let mut coverage = BTreeMap::<(i32, i32), f32>::new();
            for glyph in glyphs {
                if let Some(outline) = FONT.outline_glyph(glyph) {
                    let bounds = outline.px_bounds();
                    outline.draw(|x, y, value| {
                        let pixel = (
                            x as i32 + bounds.min.x as i32,
                            y as i32 + bounds.min.y as i32,
                        );
                        coverage
                            .entry(pixel)
                            .and_modify(|v| *v = v.max(value))
                            .or_insert(value);
                    });
                }
            }
            let mut edge = BTreeMap::<(i32, i32), f32>::new();
            for (&(x, y), &value) in &coverage {
                if value <= 0. {
                    continue;
                }
                for dy in -radius..=radius {
                    for dx in -radius..=radius {
                        if dx * dx + dy * dy <= radius * radius {
                            edge.entry((x + dx, y + dy))
                                .and_modify(|v| *v = v.max(value))
                                .or_insert(value);
                        }
                    }
                }
            }
            for (map, color) in [(&edge, [0, 0, 0]), (&coverage, LABEL_COLOR)] {
                for (&(x, y), &value) in map {
                    if x < 0 || y < 0 || x as usize >= raster.width || y as usize >= raster.height {
                        continue;
                    }
                    let world_x = (x as f64 + 0.5 - origin[0]) / camera.zoom;
                    let world_y = (origin[1] - y as f64 - 0.5) / camera.zoom;
                    if depth.occludes_label(world_x, world_y, label.depth, label.atom) {
                        continue;
                    }
                    let index = (y as usize * raster.width + x as usize) * 4;
                    composite(&mut raster.rgba[index..index + 4], color, value);
                }
            }
        }
    }

    pub fn displayed_label_texts(&self) -> Vec<String> {
        match self.label_mode {
            LabelMode::Shifts => self
                .labels
                .values()
                .filter(|label| !label.is_empty())
                .cloned()
                .collect(),
            LabelMode::AtomNumbers => (1..=self.molecule.atoms.len())
                .map(|number| number.to_string())
                .collect(),
            LabelMode::None => vec![],
        }
    }

    pub fn label_description(&self) -> &'static str {
        match self.label_mode {
            LabelMode::Shifts => "chemical-shift labels",
            LabelMode::AtomNumbers => "atom-number labels",
            LabelMode::None => "labels",
        }
    }

    fn projected_atom(&self, atom: usize, rect: Rect) -> Option<(Pos2, f64)> {
        let point = transform(self.rotation, *self.coordinates.get(atom)?);
        Some((
            rect.center()
                + Vec2::new(
                    (self.pan[0] + point[0] * self.zoom) as f32,
                    (self.pan[1] - point[1] * self.zoom) as f32,
                ),
            point[2],
        ))
    }

    pub fn atom_screen_position(&self, atom: usize, rect: Rect) -> Option<Pos2> {
        self.projected_atom(atom, rect)
            .map(|(position, _)| position)
    }

    /// Toggle the atom whose projected center is closest to the cursor. Screen
    /// distance is the primary criterion; exact projection ties prefer the
    /// frontmost atom. The selection order is retained for measurements.
    pub fn select_nearest_atom(&mut self, cursor: Pos2, rect: Rect) -> Option<usize> {
        let pick_radius = (self.zoom as f32 * 0.13).clamp(22., 42.);
        if !rect.contains(cursor) {
            return None;
        }
        let atom = (0..self.molecule.atoms.len())
            .filter_map(|atom| {
                let (position, depth) = self.projected_atom(atom, rect)?;
                let distance = position.distance_sq(cursor);
                (distance <= pick_radius * pick_radius).then_some((atom, distance, depth))
            })
            .min_by(|left, right| {
                left.1
                    .total_cmp(&right.1)
                    .then_with(|| right.2.total_cmp(&left.2))
                    .then_with(|| left.0.cmp(&right.0))
            })?
            .0;
        if let Some(index) = self
            .selected_atoms
            .iter()
            .position(|&selected| selected == atom)
        {
            self.selected_atoms.remove(index);
        } else if self.selected_atoms.len() < 4 {
            self.selected_atoms.push(atom);
        }
        Some(atom)
    }

    fn selected_sequence_is_connected(&self) -> bool {
        self.selected_atoms
            .windows(2)
            .all(|atoms| self.molecule.bonds.contains_key(&pair(atoms[0], atoms[1])))
    }

    pub fn selection_measurement(&self) -> Option<SelectionMeasurement> {
        let point = |index: usize| self.coordinates.get(index).copied();
        match self.selected_atoms.as_slice() {
            [] => None,
            &[atom] => Some(SelectionMeasurement::Atom(atom)),
            &[a, b] => Some(SelectionMeasurement::Distance {
                atoms: [a, b],
                angstrom: distance(point(a)?, point(b)?),
            }),
            &[a, b, c] => {
                if !self.selected_sequence_is_connected() {
                    return Some(SelectionMeasurement::NotConnected);
                }
                let (a, b, c) = (point(a)?, point(b)?, point(c)?);
                let (ba, bc) = (sub(a, b), sub(c, b));
                let denominator = norm(ba) * norm(bc);
                if denominator <= 1e-12 {
                    Some(SelectionMeasurement::Degenerate)
                } else {
                    Some(SelectionMeasurement::Angle {
                        atoms: [
                            self.selected_atoms[0],
                            self.selected_atoms[1],
                            self.selected_atoms[2],
                        ],
                        degrees: (dot(ba, bc) / denominator)
                            .clamp(-1., 1.)
                            .acos()
                            .to_degrees(),
                    })
                }
            }
            &[a, b, c, d] => {
                if !self.selected_sequence_is_connected() {
                    return Some(SelectionMeasurement::NotConnected);
                }
                let (a, b, c, d) = (point(a)?, point(b)?, point(c)?, point(d)?);
                if norm(cross(sub(a, b), sub(c, b))) <= 1e-12
                    || norm(cross(sub(c, b), sub(d, c))) <= 1e-12
                {
                    Some(SelectionMeasurement::Degenerate)
                } else {
                    Some(SelectionMeasurement::Dihedral {
                        atoms: [
                            self.selected_atoms[0],
                            self.selected_atoms[1],
                            self.selected_atoms[2],
                            self.selected_atoms[3],
                        ],
                        degrees: dihedral(a, b, c, d).to_degrees(),
                    })
                }
            }
            _ => unreachable!("viewer selections are limited to four atoms"),
        }
    }

    pub fn selected_atom_names(&self) -> Vec<String> {
        self.selected_atoms
            .iter()
            .filter_map(|&atom| {
                self.molecule
                    .atoms
                    .get(atom)
                    .map(|entry| format!("{}{}", entry.element, atom + 1))
            })
            .collect()
    }

    fn paint_selection(&self, painter: &egui::Painter, rect: Rect) {
        let projected: Vec<_> = self
            .selected_atoms
            .iter()
            .filter_map(|&atom| self.atom_screen_position(atom, rect))
            .collect();
        let connector = Stroke::new(1.6, Color32::from_rgba_unmultiplied(75, 218, 255, 215));
        for points in projected.windows(2) {
            let delta = points[1] - points[0];
            let length = delta.length();
            if length <= f32::EPSILON {
                continue;
            }
            let direction = delta / length;
            let mut start = 0.;
            while start < length {
                let end = (start + 6.).min(length);
                painter.line_segment(
                    [points[0] + direction * start, points[0] + direction * end],
                    connector,
                );
                start += 10.;
            }
        }
        let radius = (self.zoom as f32 * 0.18).clamp(12., 19.);
        for (order, position) in projected.into_iter().enumerate() {
            painter.circle_filled(
                position,
                radius,
                Color32::from_rgba_unmultiplied(50, 211, 255, 42),
            );
            painter.circle_stroke(
                position,
                radius,
                Stroke::new(2.4, Color32::from_rgb(80, 224, 255)),
            );
            painter.circle_stroke(
                position,
                radius + 4.,
                Stroke::new(1., Color32::from_rgba_unmultiplied(80, 224, 255, 120)),
            );
            let badge = position + Vec2::new(radius * 0.72, -radius * 0.72);
            painter.circle_filled(badge, 8., Color32::from_rgb(21, 66, 79));
            painter.text(
                badge,
                egui::Align2::CENTER_CENTER,
                (order + 1).to_string(),
                egui::FontId::proportional(11.),
                Color32::WHITE,
            );
        }
    }

    pub fn ui(&mut self, ui: &mut egui::Ui, size: Vec2) -> egui::Response {
        self.ui_internal(ui, size, false)
    }

    pub fn analysis_ui(&mut self, ui: &mut egui::Ui, size: Vec2) -> egui::Response {
        self.ui_internal(ui, size, true)
    }

    fn ui_internal(
        &mut self,
        ui: &mut egui::Ui,
        size: Vec2,
        allow_atom_selection: bool,
    ) -> egui::Response {
        let (rect, response) = ui.allocate_exact_size(size, Sense::click_and_drag());
        self.last_rect = Some(rect);
        if self.fit_next {
            self.fit(rect.width() as f64, rect.height() as f64);
        }
        if response.double_clicked() {
            self.reset();
            self.fit(rect.width() as f64, rect.height() as f64);
        }
        let middle_pick = allow_atom_selection && response.clicked_by(egui::PointerButton::Middle);
        let right_shift_pick = allow_atom_selection
            && response.hovered()
            && ui.input(|input| input.key_pressed(egui::Key::ShiftRight));
        if (middle_pick || right_shift_pick)
            && let Some(cursor) = response
                .hover_pos()
                .or_else(|| response.interact_pointer_pos())
        {
            self.select_nearest_atom(cursor, rect);
        }
        if response.dragged_by(egui::PointerButton::Primary) {
            let delta = ui.input(|i| i.pointer.delta());
            if delta != Vec2::ZERO {
                self.rotation = matmul(
                    matmul(rot_y(delta.x as f64 * 0.5), rot_x(delta.y as f64 * 0.5)),
                    self.rotation,
                );
            }
        }
        if response.dragged_by(egui::PointerButton::Secondary) {
            let delta = ui.input(|i| i.pointer.delta());
            self.pan[0] += delta.x as f64;
            self.pan[1] += delta.y as f64;
        }
        if response.hovered() {
            let scroll = ui.input(|i| i.smooth_scroll_delta.y);
            if scroll.abs() > 0.01 {
                self.zoom = (self.zoom * (scroll as f64 * 0.004).exp()).clamp(2., 1200.);
                // This viewer can live inside the high-DPI setup pane's outer
                // scroll area. A hovered wheel gesture belongs to molecular
                // zoom, so consume it before the parent area is evaluated.
                ui.ctx().input_mut(|input| {
                    input.smooth_scroll_delta.y = 0.;
                });
            }
        }
        let painter = ui.painter_at(rect);
        painter.rect_filled(
            rect,
            6,
            Color32::from_rgb(BACKGROUND[0], BACKGROUND[1], BACKGROUND[2]),
        );
        if self.coordinates.is_empty() {
            painter.text(
                rect.center(),
                egui::Align2::CENTER_CENTER,
                &self.empty_message,
                egui::FontId::proportional(17.),
                Color32::from_rgb(155, 166, 188),
            );
            return response;
        }
        // Interactive and idle frames use the same high-resolution,
        // antialiased path so the structure never softens during motion.
        let density = (ui.ctx().pixels_per_point() as f64).clamp(1., 2.);
        let dimension_cap = 1500.;
        let factor = density.min(dimension_cap / rect.width().max(rect.height()) as f64);
        let width = (rect.width() as f64 * factor).round().max(1.) as usize;
        let height = (rect.height() as f64 * factor).round().max(1.) as usize;
        let key = FrameKey {
            width,
            height,
            rotation: self.rotation,
            zoom: self.zoom,
            pan: self.pan,
            antialias: true,
            label_mode: self.label_mode,
        };
        if self.frame_key.as_ref() != Some(&key) {
            let mut raster = self.render_snapshot(width, height, true);
            if self.label_mode != LabelMode::None {
                self.paint_labels(&mut raster);
            }
            let image = egui::ColorImage::from_rgba_unmultiplied([width, height], &raster.rgba);
            if let Some(texture) = &mut self.texture {
                texture.set(image, egui::TextureOptions::LINEAR);
            } else {
                self.texture = Some(ui.ctx().load_texture(
                    "tensor-molecular-solid",
                    image,
                    egui::TextureOptions::LINEAR,
                ));
            }
            self.frames_rendered += 1;
            self.frame_key = Some(key);
        }
        if let Some(texture) = &self.texture {
            painter.image(
                texture.id(),
                rect,
                Rect::from_min_max(Pos2::ZERO, Pos2::new(1., 1.)),
                Color32::WHITE,
            );
        }
        if allow_atom_selection {
            self.paint_selection(&painter, rect);
        }
        response
    }
}
