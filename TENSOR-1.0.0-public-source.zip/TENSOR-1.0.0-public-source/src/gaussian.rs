use crate::{config::Scaling, math::round_decimal, molecule::*};
use anyhow::{Context, Result, ensure};
use regex::Regex;
use std::{
    collections::{BTreeMap, BTreeSet},
    path::{Path, PathBuf},
    sync::LazyLock,
};
static ENERGY: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"Sum of electronic and thermal Free Energies=\s*([-+0-9.eEdD]+)").unwrap()
});
static SHIELDING: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"^\s*(\d+)\s+([A-Z][a-z]?)\s+Isotropic\s*=\s*([-+0-9.eEdD]+)").unwrap()
});
static SCALE: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"s:\s*([-+0-9.eEdD]+)\s*i:\s*([-+0-9.eEdD]+)").unwrap());
static HAL: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"(\d+):s:([-+0-9.eEdD]+),i:([-+0-9.eEdD]+)").unwrap());
static CHARGES: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"\[([0-9:|+\-\s]*)\]").unwrap());
static CHARGE_PAIR: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"(\d+):([-+]?\d+)").unwrap());
static BOND: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"R\(\s*(\d+)\s*,\s*(\d+)\s*\)").unwrap());
static LEGACY_BOND: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"(\d+)-(\d+)-([0-9.]+)").unwrap());
static TEMPERATURE: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"Temperature\s+([-+0-9.eEdD]+)\s+Kelvin").unwrap());
static WBI_ROW: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^\s*(\d+)\.\s+[A-Za-z]{1,3}\s+(.*)$").unwrap());
static SOLVENT: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"(?i)solvent\s*=\s*([a-z][a-z0-9_-]*)").unwrap());
#[derive(Clone, Debug, Default)]
pub struct Frequencies {
    pub values: Vec<f64>,
    pub masses: Vec<f64>,
    pub forces: Vec<f64>,
    pub intensities: Vec<f64>,
}

#[cfg(test)]
mod topology_tests {
    use super::*;

    fn atom(element: &str) -> Atom {
        Atom {
            element: element.into(),
            ..Default::default()
        }
    }

    #[test]
    fn terminal_carbonyl_overrides_ambiguous_wiberg_band() {
        let mut molecule = Molecule {
            atoms: vec![atom("C"), atom("O"), atom("N")],
            bonds: [(pair(0, 1), 1.0), (pair(0, 2), 1.0)].into(),
            ..Default::default()
        };
        let raw = [(pair(0, 1), 1.5895), (pair(0, 2), 1.18)].into();
        let (_, overrides) = apply_wiberg_orders(&mut molecule, &raw);
        assert_eq!(overrides, 1);
        assert_eq!(molecule.bonds[&pair(0, 1)], 2.0);
        assert_eq!(raw[&pair(0, 1)], 1.5895);
    }

    #[test]
    fn comparable_terminal_oxygen_bonds_stay_delocalized() {
        let mut molecule = Molecule {
            atoms: vec![atom("C"), atom("O"), atom("O")],
            bonds: [(pair(0, 1), 1.0), (pair(0, 2), 1.0)].into(),
            ..Default::default()
        };
        let raw = [(pair(0, 1), 1.24), (pair(0, 2), 1.22)].into();
        let (_, overrides) = apply_wiberg_orders(&mut molecule, &raw);
        assert_eq!(overrides, 2);
        assert_eq!(molecule.bonds[&pair(0, 1)], 1.5);
        assert_eq!(molecule.bonds[&pair(0, 2)], 1.5);
    }

    #[test]
    fn nonterminal_oxygen_does_not_receive_a_carbonyl_override() {
        let mut molecule = Molecule {
            atoms: vec![atom("C"), atom("O"), atom("N"), atom("C")],
            bonds: [(pair(0, 1), 1.0), (pair(0, 2), 1.0), (pair(1, 3), 1.0)].into(),
            ..Default::default()
        };
        let raw = [(pair(0, 1), 1.5895), (pair(0, 2), 1.18), (pair(1, 3), 1.0)].into();
        let (_, overrides) = apply_wiberg_orders(&mut molecule, &raw);
        assert_eq!(overrides, 0);
        assert_eq!(molecule.bonds[&pair(0, 1)], 4.0);
    }
}
#[derive(Clone, Debug)]
pub struct GaussianLog {
    pub path: PathBuf,
    pub compound: String,
    pub number: usize,
    pub molecule: Molecule,
    pub energy: Option<f64>,
    pub temperature: f64,
    pub shieldings: BTreeMap<String, Values>,
    pub scaling: BTreeMap<String, Scaling>,
    pub halogen_scaling: BTreeMap<usize, Scaling>,
    pub wiberg_adjusted: usize,
    /// Bond-order depictions changed by conservative local-topology rules
    /// after the raw Wiberg thresholds were applied.
    pub topology_adjusted: usize,
    pub couplings: PairValues,
    pub frequencies: Frequencies,
    pub wiberg: PairValues,
    pub exclusions: Vec<String>,
    pub warnings: Vec<String>,
    pub solvents: BTreeSet<String>,
}
impl GaussianLog {
    pub fn valid(&self) -> bool {
        self.exclusions.is_empty()
    }
}
pub fn classify_wiberg(w: f64) -> Option<f64> {
    if w < 0.35 {
        None
    } else if w <= 1.3 {
        Some(1.)
    } else if w <= 1.6 {
        Some(4.)
    } else if w <= 2.4 {
        Some(2.)
    } else {
        Some(3.)
    }
}

/// Convert raw Wiberg indices to discrete display/export bond orders while
/// retaining the raw indices in `GaussianLog::wiberg`.
///
/// A Wiberg value near 1.5 is not, by itself, proof of aromaticity.  The only
/// local overrides made here are carbonyl patterns whose topology removes most
/// of that ambiguity.  Everything else keeps the established numeric bands.
fn apply_wiberg_orders(molecule: &mut Molecule, wiberg: &PairValues) -> (usize, usize) {
    let original = molecule.bonds.clone();
    for (edge, order) in &mut molecule.bonds {
        if let Some(&w) = wiberg.get(edge) {
            *order = classify_wiberg(w).unwrap_or(1.);
        }
    }

    let adjacency = molecule.adjacency();
    let mut overrides = BTreeMap::<Pair, f64>::new();
    for (carbon, atom) in molecule.atoms.iter().enumerate() {
        if atom.element != "C" || !(2..=3).contains(&adjacency[carbon].len()) {
            continue;
        }
        let terminal_oxygens: Vec<_> = adjacency[carbon]
            .iter()
            .copied()
            .filter(|&oxygen| {
                molecule.atoms[oxygen].element == "O"
                    && molecule.atoms[oxygen].charge <= 0
                    && adjacency[oxygen].len() == 1
            })
            .collect();
        match terminal_oxygens.as_slice() {
            [oxygen] => {
                let edge = pair(carbon, *oxygen);
                if wiberg.get(&edge).is_some_and(|&w| w > 1.30 && w <= 1.60) {
                    overrides.insert(edge, 2.0);
                }
            }
            [first, second] => {
                let a = pair(carbon, *first);
                let b = pair(carbon, *second);
                if let (Some(&wa), Some(&wb)) = (wiberg.get(&a), wiberg.get(&b))
                    && wa >= 1.05
                    && wb >= 1.05
                    && wa <= 1.60
                    && wb <= 1.60
                    && (wa - wb).abs() <= 0.18
                    && wa + wb >= 2.35
                {
                    overrides.insert(a, 1.5);
                    overrides.insert(b, 1.5);
                }
            }
            _ => {}
        }
    }
    for (edge, order) in &overrides {
        if let Some(current) = molecule.bonds.get_mut(edge) {
            *current = *order;
        }
    }
    let changed = molecule
        .bonds
        .iter()
        .filter(|(edge, order)| original.get(edge).is_some_and(|old| old != *order))
        .count();
    (changed, overrides.len())
}
pub fn parse_wiberg(text: &str) -> PairValues {
    let mut out = PairValues::new();
    let mut inside = false;
    let mut columns = vec![];
    for line in text.lines() {
        let s = line.trim();
        if !inside {
            if s.starts_with("Wiberg bond index matrix in the NAO basis") {
                inside = true
            }
            continue;
        }
        if s.starts_with("Wiberg bond index, Totals by atom")
            || s.starts_with("Atom-atom overlap-weighted")
            || s.starts_with("MO bond order")
        {
            break;
        }
        if let Some(rest) = s.strip_prefix("Atom")
            && let Ok(ids) = rest
                .split_whitespace()
                .map(str::parse::<usize>)
                .collect::<std::result::Result<Vec<_>, _>>()
        {
            columns = ids;
        }
        if let Some(c) = WBI_ROW.captures(line)
            && let Ok(row) = c[1].parse::<usize>()
        {
            for (col, value) in columns.iter().zip(c[2].split_whitespace()) {
                if row > 0
                    && *col > 0
                    && let Ok(v) = float(value)
                {
                    out.insert(pair(row - 1, *col - 1), v);
                }
            }
        }
    }
    out
}
fn symbol(z: usize) -> Option<&'static str> {
    const ELEMENTS: &str = "X H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og";
    ELEMENTS.split_whitespace().nth(z).filter(|_| z > 0)
}
pub fn standard_orientation(text: &str) -> Result<Vec<Atom>> {
    let lines: Vec<_> = text.lines().collect();
    let start = lines
        .iter()
        .rposition(|l| l.contains("Standard orientation:"))
        .context("No final Standard orientation block")?;
    let mut atoms = vec![];
    let mut closed = false;
    for line in lines.iter().skip(start + 5) {
        if line.contains("-----") {
            closed = true;
            break;
        }
        let p: Vec<_> = line.split_whitespace().collect();
        ensure!(p.len() >= 6, "Malformed final coordinate row: {line:?}");
        let index: usize = p[0].parse()?;
        ensure!(
            index == atoms.len() + 1,
            "Nonsequential Gaussian atom numbering"
        );
        let z: usize = p[1].parse()?;
        let element = symbol(z)
            .context("Unsupported Gaussian atomic number")?
            .to_string();
        atoms.push(Atom {
            element,
            xyz: [float(p[3])?, float(p[4])?, float(p[5])?],
            charge: 0,
            isotope: 0,
        });
    }
    ensure!(
        closed && !atoms.is_empty(),
        "Truncated final Standard orientation block"
    );
    Ok(atoms)
}
fn title_text(lines: &[&str], i: usize) -> String {
    let mut s = lines[i].trim().to_string();
    // Gaussian may wrap a long charge or per-atom scaling block.
    for line in lines.iter().skip(i + 1).take(128) {
        let line = line.trim();
        if line.is_empty()
            || line.starts_with("----")
            || line.starts_with("Symbolic")
            || line.starts_with("Charge")
            || line.starts_with("Redundant")
            || line.starts_with("NAtoms")
        {
            break;
        }
        if !s.contains('[') && !s.contains("hal{") && SCALE.is_match(&s) {
            break;
        }
        if (s.contains('[') && s.contains(']')) || (s.contains("hal{") && s.contains('}')) {
            break;
        }
        if line.contains("Isotropic") || line.starts_with('#') {
            break;
        }
        s.push_str(line);
    }
    s
}
pub fn parse_log(path: &Path) -> Result<GaussianLog> {
    let (compound, number) = number_name(path).context("Expected {compound}_{number}.log")?;
    let text = std::fs::read(path).with_context(|| format!("Cannot read {}", path.display()))?;
    parse_log_text(&String::from_utf8_lossy(&text), path, &compound, number)
}
pub fn parse_log_text(
    text: &str,
    path: &Path,
    compound: &str,
    number: usize,
) -> Result<GaussianLog> {
    safe_name(compound)?;
    let atoms = standard_orientation(text)?;
    let lines: Vec<_> = text.lines().collect();
    let marker = Regex::new(&format!(
        r"(?:^|[^A-Za-z0-9_]){}_0*{}_(?:(\d+))?(opt|carbon|proton|fluorine|nitrogen|cc)(?:[^A-Za-z]|$)",
        regex::escape(compound),
        number
    ))?;
    let mut molecule = Molecule {
        title: format!("{compound}_{number}"),
        atoms,
        ..Default::default()
    };
    let mut shieldings = BTreeMap::<String, Values>::new();
    let mut scaling = BTreeMap::new();
    let mut halogen = BTreeMap::new();
    let mut current = None::<String>;
    let mut coupling_active = false;
    let mut coupling_closed = true;
    let mut columns = vec![];
    let mut couplings = PairValues::new();
    let mut opt_title = String::new();
    let mut seen_carbon = false;
    let mut last_title = 0;
    let mut exclusions = vec![];
    let mut warnings = vec![];
    let mut frequencies = Frequencies::default();
    let solvents = SOLVENT
        .captures_iter(text)
        .map(|capture| capture[1].to_ascii_lowercase())
        .collect();
    for (i, line) in lines.iter().enumerate() {
        // Ignore the archive's backslash-delimited copies of the titles.
        if !line.contains('\\')
            && let Some(c) = marker.captures(line)
        {
            let kind = &c[2];
            last_title = i;
            let title = title_text(&lines, i);
            if kind == "opt" {
                if opt_title.is_empty() {
                    opt_title = title.clone();
                }
                current = None;
            } else if kind != "cc" {
                current = Some(kind.into());
                shieldings.insert(kind.to_string(), Values::new());
                scaling.remove(kind);
                if kind == "carbon" {
                    halogen.clear();
                }
                if kind == "carbon" {
                    seen_carbon = true;
                }
            } else {
                current = None;
            }
            coupling_active = false;
            if let Some(c) = SCALE.captures(&title) {
                let sc = Scaling::new(float(&c[1])?, float(&c[2])?);
                sc.apply(0.)?;
                // A later calculation of a nucleus replaces its earlier title.
                // Never infer a method from a numeric title prefix.
                scaling.insert(kind.to_string(), sc);
            }
            if let Some(start) = title.find("hal{")
                && let Some(end) = title[start..].find('}')
            {
                for c in HAL.captures_iter(&title[start + 4..start + end]) {
                    let atom: usize = c[1].parse()?;
                    ensure!(
                        atom > 0 && atom <= molecule.atoms.len(),
                        "Invalid atom in halogen scaling title"
                    );
                    let sc = Scaling::new(float(&c[2])?, float(&c[3])?);
                    sc.apply(0.)?;
                    halogen.insert(atom - 1, sc);
                }
            }
            continue;
        }
        if line.contains("Total nuclear spin-spin coupling J (Hz):") {
            coupling_active = true;
            coupling_closed = false;
            current = None;
            columns.clear();
            couplings.clear();
            continue;
        }
        if line.contains("End of Minotr F.D. properties file") {
            current = None;
            if coupling_active {
                coupling_closed = true
            }
            coupling_active = false;
            continue;
        }
        if let Some(kind) = &current
            && let Some(c) = SHIELDING.captures(line)
        {
            let required = match kind.as_str() {
                "carbon" => "C",
                "proton" => "H",
                "fluorine" => "F",
                "nitrogen" => "N",
                _ => "",
            };
            if &c[2] == required {
                let a: usize = c[1].parse()?;
                ensure!(
                    a > 0 && a <= molecule.atoms.len(),
                    "Shielding atom index out of range"
                );
                ensure!(
                    molecule.atoms[a - 1].element == required,
                    "Shielding element disagrees with geometry at atom {a}"
                );
                shieldings
                    .entry(kind.clone())
                    .or_default()
                    .insert(a - 1, float(&c[3])?);
            }
        }
        if coupling_active {
            let parts: Vec<_> = line.split_whitespace().collect();
            if parts.is_empty() {
                continue;
            }
            if parts.iter().all(|p| p.chars().all(|c| c.is_ascii_digit())) {
                columns = parts
                    .iter()
                    .filter_map(|p| p.parse::<usize>().ok())
                    .collect();
            } else if let Ok(row) = parts[0].parse::<usize>() {
                for (&col, s) in columns.iter().zip(&parts[1..]) {
                    if let Ok(v) = float(s) {
                        ensure!(
                            row > 0
                                && col > 0
                                && row <= molecule.atoms.len()
                                && col <= molecule.atoms.len(),
                            "Coupling atom index out of range"
                        );
                        if row != col && v.abs() < 1e10 {
                            couplings.insert(pair(row - 1, col - 1), round_decimal(v, 2));
                        }
                    }
                }
            }
        }
        let s = line.trim();
        for (prefix, out) in [
            ("Frequencies", &mut frequencies.values),
            ("Red. masses", &mut frequencies.masses),
            ("Frc consts", &mut frequencies.forces),
            ("IR Inten", &mut frequencies.intensities),
        ] {
            if s.starts_with(prefix)
                && let Some((_, values)) = s.split_once("--")
            {
                for token in values.split_whitespace() {
                    out.push(float(token)?);
                }
            }
        }
    }
    ensure!(
        !opt_title.is_empty(),
        "No matching optimization title found for {compound}_{number}"
    );
    if let Some(c) = CHARGES.captures(&opt_title) {
        for pair in CHARGE_PAIR.captures_iter(&c[1]) {
            let a: usize = pair[1].parse()?;
            ensure!(
                a > 0 && a <= molecule.atoms.len(),
                "Out-of-range formal charge in title"
            );
            molecule.atoms[a - 1].charge = pair[2].parse()?;
        }
    }
    let start = lines
        .iter()
        .position(|s| s.contains("Initial Parameters"))
        .context("No Initial Parameters connectivity block")?;
    let mut found = false;
    for line in lines.iter().skip(start + 1).take(5000) {
        if let Some(c) = BOND.captures(line) {
            let a: usize = c[1].parse()?;
            let b: usize = c[2].parse()?;
            ensure!(
                a > 0 && b > 0 && a <= molecule.atoms.len() && b <= molecule.atoms.len(),
                "Connectivity atom index out of range"
            );
            molecule.bonds.insert(pair(a - 1, b - 1), 1.);
            found = true;
        } else if found
            && (line.trim().starts_with("----") || line.contains("A(") || line.contains("D("))
        {
            break;
        }
    }
    ensure!(
        found || molecule.atoms.len() == 1,
        "No bond connectivity recovered from Initial Parameters"
    );
    for c in LEGACY_BOND.captures_iter(&opt_title) {
        let a: usize = c[1].parse()?;
        let b: usize = c[2].parse()?;
        if a > 0
            && b > 0
            && let Some(order) = molecule.bonds.get_mut(&pair(a - 1, b - 1))
        {
            *order = float(&c[3])?;
        }
    }
    let wiberg = parse_wiberg(text);
    let mut wiberg_adjusted = 0;
    let mut topology_adjusted = 0;
    if wiberg.is_empty() {
        warnings.push("No Wiberg matrix: retaining supplied connectivity bond orders.".into());
    } else {
        (wiberg_adjusted, topology_adjusted) = apply_wiberg_orders(&mut molecule, &wiberg);
        if topology_adjusted > 0 {
            warnings.push(format!(
                "Applied {topology_adjusted} conservative carbonyl/delocalized C–O topology override(s); raw Wiberg indices are retained in the report."
            ));
        }
    }
    molecule.validate()?;
    let energy = ENERGY.captures(text).map(|c| float(&c[1])).transpose()?;
    let temperature = TEMPERATURE
        .captures(text)
        .map(|c| float(&c[1]))
        .transpose()?
        .unwrap_or(298.);
    ensure!(temperature > 0., "Nonpositive log temperature");
    if text.contains("Convergence failure") {
        exclusions.push("convergence failure".into())
    }
    if text.contains("Error termination") {
        exclusions.push("error termination".into())
    }
    let imag = frequencies.values.iter().filter(|&&f| f < -12.).count();
    if imag > 0 {
        exclusions.push(format!("{imag} frequency/frequencies below -12 cm^-1"))
    }
    if !seen_carbon {
        exclusions.push("carbon calculation section missing".into())
    }
    if lines
        .iter()
        .rposition(|s| s.contains("Normal termination"))
        .is_none_or(|i| i < last_title)
    {
        exclusions.push("final job has no normal termination".into());
    }
    if !coupling_closed {
        warnings.push("Truncated coupling matrix was discarded.".into());
        couplings.clear();
    }
    if frequencies.values.is_empty() {
        warnings.push(
            "No vibrational frequencies: deduplication cannot use the frequency gate.".into(),
        );
    }
    Ok(GaussianLog {
        path: path.to_path_buf(),
        compound: compound.into(),
        number,
        molecule,
        energy,
        temperature,
        shieldings,
        scaling,
        halogen_scaling: halogen,
        wiberg_adjusted,
        topology_adjusted,
        couplings,
        frequencies,
        wiberg,
        exclusions,
        warnings,
        solvents,
    })
}
