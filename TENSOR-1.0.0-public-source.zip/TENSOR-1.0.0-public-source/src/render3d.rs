//! Fixed molecular geometry with analytic capsule surfaces and per-pixel depth.
//! Camera movement never changes the molecular model or its bond-offset planes.
use crate::{math::*, molecule::*, symmetry::chordless_bond_cycles};
use rayon::prelude::*;

pub type Rgb = [u8; 3];
pub const BACKGROUND: Rgb = [20, 20, 26];
pub const LABEL_COLOR: Rgb = [255, 213, 28];
const BOND_RADIUS: f64 = 0.115;
const DELOCALIZED_DASH_RADIUS: f64 = 0.047;
/// A fixed centerline separation gives every ordinary ring the same visible
/// surface-to-surface clearance: 0.220 - 0.115 - 0.047 = 0.058 model units.
const DELOCALIZED_CENTERLINE_OFFSET: f64 = 0.220;

pub fn element_color(element: &str) -> Rgb {
    let rgb: [f64; 3] = match element {
        "H" => [0.95, 0.95, 0.95],
        "C" => [0.42, 0.44, 0.47],
        "N" => [0.07, 0.20, 0.97],
        "O" => [0.90, 0.07, 0.07],
        "F" => [0.50, 0.90, 0.15],
        "Cl" => [0.12, 0.94, 0.12],
        "Br" => [0.65, 0.16, 0.16],
        "I" => [0.58, 0., 0.58],
        "S" => [1., 1., 0.19],
        "P" => [1., 0.5, 0.],
        "Na" => [0.67, 0.36, 0.95],
        "K" => [0.56, 0.25, 0.83],
        "Ca" => [0.24, 1., 0.],
        "Mg" => [0.54, 1., 0.],
        "Fe" => [0.88, 0.4, 0.2],
        "Zn" => [0.49, 0.5, 0.69],
        _ => [0.75; 3],
    };
    rgb.map(|x| (255. * x) as u8)
}

#[derive(Clone, Debug, PartialEq)]
pub struct Solid {
    pub a: V3,
    pub b: V3,
    pub radius: f64,
    pub ca: Rgb,
    pub cb: Rgb,
    pub dashed: bool,
    /// Atom endpoints that own this bond capsule. Isolated-atom spheres and
    /// synthetic/test solids leave this unset.
    pub atoms: Option<(usize, usize)>,
}
#[derive(Clone, Debug, Default, PartialEq)]
pub struct Scene {
    pub solids: Vec<Solid>,
}
fn mix(a: V3, b: V3, t: f64) -> V3 {
    add(mul(a, 1. - t), mul(b, t))
}
fn unit(v: V3) -> V3 {
    let n = norm(v);
    if n > 1e-12 {
        mul(v, 1. / n)
    } else {
        [1., 0., 0.]
    }
}

fn is_delocalized(order: f64) -> bool {
    (order - 1.5).abs() < 0.1 || (order - 4.).abs() < 0.1
}

fn delocalized_ring_score(molecule: &Molecule, ring: &[usize], a: usize, b: usize) -> usize {
    ring.windows(2)
        .filter(|edge| {
            molecule
                .bonds
                .get(&pair(edge[0], edge[1]))
                .is_some_and(|&order| is_delocalized(order))
        })
        .count()
        + usize::from(
            molecule
                .bonds
                .get(&pair(a, b))
                .is_some_and(|&order| is_delocalized(order)),
        )
}

/// Select local chordless rings for a delocalized bond. A partially
/// delocalized fused system keeps the single best-supported ring. If the bond
/// is shared by multiple fully delocalized local rings, retain those rings so
/// the renderer can place one guide into each geometrically distinct face.
fn delocalized_bond_rings(
    molecule: &Molecule,
    adjacency: &[Vec<usize>],
    a: usize,
    b: usize,
    largest: usize,
) -> Vec<Vec<usize>> {
    let mut candidates = chordless_bond_cycles(adjacency, a, b, largest, 4096);
    let compare = |left: &[usize], right: &[usize]| {
        let left_score = delocalized_ring_score(molecule, left, a, b);
        let right_score = delocalized_ring_score(molecule, right, a, b);
        left_score
            .cmp(&right_score)
            .then_with(|| (left_score * right.len()).cmp(&(right_score * left.len())))
            .then_with(|| right.len().cmp(&left.len()))
            .then_with(|| right.cmp(left))
    };
    candidates.sort_by(|left, right| compare(right, left));
    let mut fully_delocalized: Vec<_> = candidates
        .iter()
        .filter(|ring| delocalized_ring_score(molecule, ring, a, b) == ring.len())
        .cloned()
        .collect();
    if fully_delocalized.len() >= 2 {
        fully_delocalized
            .sort_by(|left, right| left.len().cmp(&right.len()).then_with(|| left.cmp(right)));
        fully_delocalized
    } else {
        candidates.into_iter().take(1).collect()
    }
}

#[cfg(test)]
fn delocalized_bond_ring(
    molecule: &Molecule,
    adjacency: &[Vec<usize>],
    a: usize,
    b: usize,
    largest: usize,
) -> Option<Vec<usize>> {
    delocalized_bond_rings(molecule, adjacency, a, b, largest)
        .into_iter()
        .next()
}

/// Build a centered dash guide with a constant absolute bond-to-guide
/// separation. The ring centroid determines direction only; it no longer
/// scales the separation, so five- and six-membered rings have the same
/// visible clearance. Extremely narrow/distorted geometry caps the movement
/// before it can pass too far through the local ring interior.
fn delocalized_dash_guide(
    points: &[V3],
    ring: &[usize],
    a: usize,
    b: usize,
    fallback_normal: V3,
) -> (V3, V3) {
    let center = centroid(&ring.iter().map(|&atom| points[atom]).collect::<Vec<_>>());
    let axis = unit(sub(points[b], points[a]));
    let midpoint = mix(points[a], points[b], 0.5);
    let toward_center = sub(center, midpoint);
    let inward = sub(toward_center, mul(axis, dot(toward_center, axis)));
    let inward_length = norm(inward);
    let direction = if inward_length > 1e-8 {
        unit(inward)
    } else if dot(fallback_normal, toward_center) < 0. {
        mul(fallback_normal, -1.)
    } else {
        fallback_normal
    };

    let distance = if inward_length > 1e-8 {
        DELOCALIZED_CENTERLINE_OFFSET.min(inward_length * 0.65)
    } else {
        DELOCALIZED_CENTERLINE_OFFSET
    };
    let offset = mul(direction, distance);
    (
        add(mix(points[a], points[b], 0.11), offset),
        add(mix(points[a], points[b], 0.89), offset),
    )
}

fn delocalized_dash_guides(
    points: &[V3],
    rings: &[Vec<usize>],
    a: usize,
    b: usize,
    fallback_normal: V3,
) -> Vec<(V3, V3)> {
    if rings.is_empty() {
        return vec![(
            add(
                points[a],
                mul(fallback_normal, DELOCALIZED_CENTERLINE_OFFSET),
            ),
            add(
                points[b],
                mul(fallback_normal, DELOCALIZED_CENTERLINE_OFFSET),
            ),
        )];
    }
    let bond_midpoint = mix(points[a], points[b], 0.5);
    let mut selected: Vec<((V3, V3), V3)> = Vec::new();
    for ring in rings {
        let guide = delocalized_dash_guide(points, ring, a, b, fallback_normal);
        let direction = unit(sub(mix(guide.0, guide.1, 0.5), bond_midpoint));
        if selected
            .iter()
            .any(|(_, existing)| dot(*existing, direction) > 0.5)
        {
            continue;
        }
        selected.push((guide, direction));
        if selected.len() == 2 {
            break;
        }
    }
    selected.into_iter().map(|(guide, _)| guide).collect()
}

impl Scene {
    pub fn from_molecule(molecule: &Molecule, points: &[V3]) -> Self {
        let mut scene = Self::default();
        let adj = molecule.adjacency();
        let colors: Vec<_> = molecule
            .atoms
            .iter()
            .map(|a| element_color(&a.element))
            .collect();
        for (&(a, b), &order) in &molecule.bonds {
            let axis = unit(sub(points[b], points[a]));
            let mut normal = None;
            // The offset direction is defined once in molecular coordinates.
            for (center, ns, excluded) in [(a, &adj[a], b), (b, &adj[b], a)] {
                for &neighbor in ns {
                    if neighbor == excluded {
                        continue;
                    }
                    let v = sub(points[neighbor], points[center]);
                    let perpendicular = sub(v, mul(axis, dot(v, axis)));
                    if norm(perpendicular) > 1e-6 {
                        normal = Some(unit(perpendicular));
                        break;
                    }
                }
                if normal.is_some() {
                    break;
                }
            }
            let normal = normal.unwrap_or_else(|| {
                let basis = if axis[0].abs() < 0.7 {
                    [1., 0., 0.]
                } else {
                    [0., 1., 0.]
                };
                unit(sub(basis, mul(axis, dot(basis, axis))))
            });
            let mut bond = |offset: V3, radius: f64| {
                scene.solids.push(Solid {
                    a: add(points[a], offset),
                    b: add(points[b], offset),
                    radius,
                    ca: colors[a],
                    cb: colors[b],
                    dashed: false,
                    atoms: Some(pair(a, b)),
                })
            };
            if (order - 3.).abs() < 0.1 {
                for t in [-0.19, 0., 0.19] {
                    bond(mul(normal, t), 0.065);
                }
            } else if (order - 2.).abs() < 0.1 {
                for t in [-0.12, 0.12] {
                    bond(mul(normal, t), 0.072);
                }
            } else {
                bond([0.; 3], BOND_RADIUS);
                if is_delocalized(order) {
                    let rings = delocalized_bond_rings(molecule, &adj, a, b, 12);
                    for (inner_a, inner_b) in delocalized_dash_guides(points, &rings, a, b, normal)
                    {
                        let length = norm(sub(inner_b, inner_a));
                        let count = (length / 0.48).round().clamp(2., 4.) as usize;
                        for k in 0..count {
                            let start = (k as f64 + 0.29) / count as f64;
                            let end = (k as f64 + 0.71) / count as f64;
                            let color = if (start + end) * 0.5 < 0.5 {
                                colors[a]
                            } else {
                                colors[b]
                            };
                            scene.solids.push(Solid {
                                a: mix(inner_a, inner_b, start),
                                b: mix(inner_a, inner_b, end),
                                radius: DELOCALIZED_DASH_RADIUS,
                                ca: color,
                                cb: color,
                                dashed: true,
                                atoms: Some(pair(a, b)),
                            });
                        }
                    }
                }
            }
        }
        for (i, &center) in points.iter().enumerate() {
            if !adj[i].is_empty() {
                continue;
            }
            let radius = 0.27;
            scene.solids.push(Solid {
                a: center,
                b: center,
                radius,
                ca: colors[i],
                cb: colors[i],
                dashed: false,
                atoms: None,
            });
        }
        scene
    }

    /// Blend element colours with a conformer accent while preserving the
    /// familiar element palette.  This is used only for multi-conformer
    /// overlays; ordinary structure rendering is unchanged.
    pub fn tinted(mut self, accent: Rgb, amount: f64) -> Self {
        let amount = amount.clamp(0., 1.);
        let blend = |base: Rgb| {
            std::array::from_fn(|i| {
                (base[i] as f64 * (1. - amount) + accent[i] as f64 * amount)
                    .round()
                    .clamp(0., 255.) as u8
            })
        };
        for solid in &mut self.solids {
            solid.ca = blend(solid.ca);
            solid.cb = blend(solid.cb);
        }
        self
    }

    pub fn render(&self, width: usize, height: usize, camera: Camera, antialias: bool) -> Raster {
        let samples = if antialias { 2 } else { 1 };
        let w = width * samples;
        let h = height * samples;
        let zoom = camera.zoom * samples as f64;
        let pan = camera.pan.map(|p| p * samples as f64);
        let origin = [w as f64 / 2. + pan[0], h as f64 / 2. + pan[1]];
        let projected: Vec<_> = self
            .solids
            .iter()
            .map(|solid| Projected::new(solid, camera.rotation, origin, zoom, w, h))
            .collect();
        let mut rgba = vec![0u8; w * h * 4];
        let stripe = 32;
        rgba.par_chunks_mut(w * 4 * stripe)
            .enumerate()
            .for_each(|(tile, pixels)| {
                let y0 = tile * stripe;
                let y1 = (y0 + stripe).min(h);
                let mut depth = vec![f64::NEG_INFINITY; (y1 - y0) * w];
                for solid in &projected {
                    let miny = solid.bounds[1].max(y0);
                    let maxy = solid.bounds[3].min(y1);
                    if miny >= maxy {
                        continue;
                    }
                    for y in miny..maxy {
                        let wy = (origin[1] - (y as f64 + 0.5)) / zoom;
                        for x in solid.bounds[0]..solid.bounds[2] {
                            let wx = (x as f64 + 0.5 - origin[0]) / zoom;
                            if let Some(hit) = solid.hit(wx, wy) {
                                let index = (y - y0) * w + x;
                                if hit.z > depth[index] {
                                    depth[index] = hit.z;
                                    let color = lighting(hit.normal, hit.color);
                                    pixels[index * 4..index * 4 + 3].copy_from_slice(&color);
                                    pixels[index * 4 + 3] = 255;
                                }
                            }
                        }
                    }
                }
            });
        if samples == 1 {
            return Raster {
                width,
                height,
                rgba,
            };
        }
        // Average coverage in premultiplied space, then return unassociated RGBA.
        let mut down = vec![0u8; width * height * 4];
        down.par_chunks_mut(width * 4)
            .enumerate()
            .for_each(|(y, row)| {
                for x in 0..width {
                    let mut sum = [0u32; 3];
                    let mut covered = 0;
                    for dy in 0..2 {
                        for dx in 0..2 {
                            let offset = ((y * 2 + dy) * w + x * 2 + dx) * 4;
                            if rgba[offset + 3] > 0 {
                                covered += 1;
                                for c in 0..3 {
                                    sum[c] += rgba[offset + c] as u32;
                                }
                            }
                        }
                    }
                    if let [Some(red), Some(green), Some(blue)] =
                        sum.map(|value| value.checked_div(covered))
                    {
                        row[x * 4] = red as u8;
                        row[x * 4 + 1] = green as u8;
                        row[x * 4 + 2] = blue as u8;
                        row[x * 4 + 3] = (covered * 255 / 4) as u8;
                    }
                }
            });
        Raster {
            width,
            height,
            rgba: down,
        }
    }

    pub fn depth_test(&self, camera: Camera) -> DepthTest {
        DepthTest {
            projected: self
                .solids
                .iter()
                .map(|solid| Projected::new(solid, camera.rotation, [0.; 2], 1., 1, 1))
                .collect(),
        }
    }
}

pub struct DepthTest {
    projected: Vec<Projected>,
}
impl DepthTest {
    pub fn depth_at(&self, x: f64, y: f64) -> Option<f64> {
        self.projected
            .iter()
            .filter_map(|solid| solid.hit(x, y).map(|hit| hit.z))
            .max_by(f64::total_cmp)
    }

    /// Preserve ordinary molecular depth occlusion while allowing a label to
    /// sit over every bond capsule attached to its own atom.
    pub fn occludes_label(&self, x: f64, y: f64, label_depth: f64, atom: usize) -> bool {
        self.projected
            .iter()
            .filter(|solid| !solid.atoms.is_some_and(|(a, b)| a == atom || b == atom))
            .filter_map(|solid| solid.hit(x, y))
            .any(|hit| hit.z > label_depth + 1e-6)
    }
}

#[derive(Clone, Copy, Debug)]
pub struct Camera {
    pub rotation: M3,
    pub zoom: f64,
    pub pan: [f64; 2],
}
#[derive(Clone, Debug)]
pub struct Raster {
    pub width: usize,
    pub height: usize,
    pub rgba: Vec<u8>,
}
#[derive(Clone, Copy)]
struct Hit {
    z: f64,
    normal: V3,
    color: Rgb,
}
struct Projected {
    a: V3,
    b: V3,
    d: V3,
    inv_length2: f64,
    cylinder_a: f64,
    radius: f64,
    ca: Rgb,
    cb: Rgb,
    atoms: Option<(usize, usize)>,
    bounds: [usize; 4],
}
impl Projected {
    fn new(
        s: &Solid,
        rotation: M3,
        origin: [f64; 2],
        zoom: f64,
        width: usize,
        height: usize,
    ) -> Self {
        let a = transform(rotation, s.a);
        let b = transform(rotation, s.b);
        let d = sub(b, a);
        let length2 = dot(d, d);
        let inv_length2 = if length2 > 1e-20 { 1. / length2 } else { 0. };
        let minx = (origin[0] + (a[0].min(b[0]) - s.radius) * zoom)
            .floor()
            .clamp(0., width as f64) as usize;
        let maxx = (origin[0] + (a[0].max(b[0]) + s.radius) * zoom)
            .ceil()
            .clamp(0., width as f64) as usize;
        let miny = (origin[1] - (a[1].max(b[1]) + s.radius) * zoom)
            .floor()
            .clamp(0., height as f64) as usize;
        let maxy = (origin[1] - (a[1].min(b[1]) - s.radius) * zoom)
            .ceil()
            .clamp(0., height as f64) as usize;
        Self {
            a,
            b,
            d,
            inv_length2,
            cylinder_a: (d[0] * d[0] + d[1] * d[1]) * inv_length2,
            radius: s.radius,
            ca: s.ca,
            cb: s.cb,
            atoms: s.atoms,
            bounds: [minx, miny, maxx, maxy],
        }
    }
    fn hit(&self, x: f64, y: f64) -> Option<Hit> {
        let r2 = self.radius * self.radius;
        let mut hit = None;
        for center in [self.a, self.b] {
            let dx = x - center[0];
            let dy = y - center[1];
            let q = r2 - dx * dx - dy * dy;
            if q >= 0. {
                let dz = q.sqrt();
                let z = center[2] + dz;
                if hit.as_ref().is_none_or(|h: &Hit| z > h.z) {
                    let position = [x, y, z];
                    let t = dot(sub(position, self.a), self.d) * self.inv_length2;
                    hit = Some(Hit {
                        z,
                        normal: [dx / self.radius, dy / self.radius, dz / self.radius],
                        color: if t < 0.5 { self.ca } else { self.cb },
                    });
                }
            }
            if self.inv_length2 == 0. {
                break;
            }
        }
        if self.cylinder_a > 1e-12 {
            let qx = x - self.a[0];
            let qy = y - self.a[1];
            let k = qx * self.d[0] + qy * self.d[1];
            let b = -2. * k * self.d[2] * self.inv_length2;
            let c = qx * qx + qy * qy - k * k * self.inv_length2 - r2;
            let discriminant = b * b - 4. * self.cylinder_a * c;
            if discriminant >= 0. {
                let root = discriminant.sqrt();
                for sign in [1., -1.] {
                    let t = (-b + sign * root) / (2. * self.cylinder_a);
                    let along = (k + t * self.d[2]) * self.inv_length2;
                    let z = self.a[2] + t;
                    if (0.0..=1.0).contains(&along) && hit.as_ref().is_none_or(|h| z > h.z) {
                        let normal = mul(sub([qx, qy, t], mul(self.d, along)), 1. / self.radius);
                        hit = Some(Hit {
                            z,
                            normal,
                            color: if along < 0.5 { self.ca } else { self.cb },
                        });
                    }
                }
            }
        }
        hit
    }
}
fn lighting(normal: V3, color: Rgb) -> Rgb {
    let light = [-0.3577708764, 0.4472135955, 0.8197560613];
    let diffuse = dot(normal, light).max(0.);
    let half = [-0.187414, 0.234267, 0.95396];
    let specular = dot(normal, half).max(0.).powi(24) * 0.23;
    color.map(|v| ((v as f64 * (0.30 + 0.70 * diffuse) + 255. * specular).clamp(0., 255.)) as u8)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn fused_delocalized_polygons(
        upper_size: usize,
        lower_size: usize,
        shared_nitrogen: bool,
    ) -> (Molecule, Vec<V3>) {
        assert!(upper_size >= 3 && lower_size >= 3);
        let mut points = vec![[-0.5, 0., 0.], [0.5, 0., 0.]];
        let upper_radius = 0.5 / (std::f64::consts::PI / upper_size as f64).sin();
        let upper_apothem = 0.5 / (std::f64::consts::PI / upper_size as f64).tan();
        for index in 2..upper_size {
            let angle = -std::f64::consts::FRAC_PI_2 - std::f64::consts::PI / upper_size as f64
                + std::f64::consts::TAU * index as f64 / upper_size as f64;
            points.push([
                upper_radius * angle.cos(),
                upper_apothem + upper_radius * angle.sin(),
                0.,
            ]);
        }
        let lower_start = points.len();
        let lower_radius = 0.5 / (std::f64::consts::PI / lower_size as f64).sin();
        let lower_apothem = 0.5 / (std::f64::consts::PI / lower_size as f64).tan();
        for index in 2..lower_size {
            let angle = std::f64::consts::FRAC_PI_2 + std::f64::consts::PI / lower_size as f64
                - std::f64::consts::TAU * index as f64 / lower_size as f64;
            points.push([
                lower_radius * angle.cos(),
                -lower_apothem + lower_radius * angle.sin(),
                0.,
            ]);
        }
        let mut molecule = Molecule {
            atoms: points
                .iter()
                .enumerate()
                .map(|(index, &xyz)| Atom {
                    element: if shared_nitrogen && index == 0 {
                        "N".into()
                    } else {
                        "C".into()
                    },
                    xyz,
                    charge: 0,
                    isotope: 0,
                })
                .collect(),
            ..Default::default()
        };
        let upper: Vec<_> = (0..upper_size).collect();
        let lower: Vec<_> = [0, 1]
            .into_iter()
            .chain(lower_start..points.len())
            .collect();
        for ring in [&upper, &lower] {
            for index in 0..ring.len() {
                molecule
                    .bonds
                    .insert(pair(ring[index], ring[(index + 1) % ring.len()]), 4.);
            }
        }
        (molecule, points)
    }

    #[test]
    fn depth_resolves_crossing_capsules_without_draw_order_dependence() {
        let front = Solid {
            a: [-1., 0., 0.5],
            b: [1., 0., 0.5],
            radius: 0.2,
            ca: [230, 10, 10],
            cb: [230, 10, 10],
            dashed: false,
            atoms: None,
        };
        let rear = Solid {
            a: [0., -1., -0.5],
            b: [0., 1., -0.5],
            radius: 0.2,
            ca: [10, 10, 230],
            cb: [10, 10, 230],
            dashed: false,
            atoms: None,
        };
        let camera = Camera {
            rotation: [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]],
            zoom: 35.,
            pan: [0.; 2],
        };
        let a = Scene {
            solids: vec![front.clone(), rear.clone()],
        }
        .render(100, 100, camera, false);
        let b = Scene {
            solids: vec![rear, front],
        }
        .render(100, 100, camera, false);
        assert_eq!(a.rgba, b.rgba);
        let pixel = &a.rgba[(50 * 100 + 50) * 4..][..4];
        assert!(pixel[0] > pixel[2] * 2);
        assert_eq!(a.rgba[3], 0);
    }
    #[test]
    fn capsule_front_surface_is_continuous_and_camera_parallel_is_finite() {
        let s = Solid {
            a: [-1., 0., 0.],
            b: [1., 0., 0.],
            radius: 0.2,
            ca: [255; 3],
            cb: [255; 3],
            dashed: false,
            atoms: None,
        };
        let identity = [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]];
        let p = Projected::new(&s, identity, [50., 50.], 30., 100, 100);
        for x in [-1., -0.5, 0., 0.5, 1.] {
            assert!((p.hit(x, 0.).unwrap().z - 0.2).abs() < 1e-12);
        }
        assert!((p.hit(1.1, 0.).unwrap().z - (0.04_f64 - 0.01).sqrt()).abs() < 1e-10);
        let parallel = Projected::new(&s, rot_y(90.), [50., 50.], 30., 100, 100);
        assert!((parallel.hit(0., 0.).unwrap().z - 1.2).abs() < 1e-10);
    }

    #[test]
    fn depth_test_reports_the_frontmost_molecular_surface() {
        let solid = |z, color| Solid {
            a: [-1., 0., z],
            b: [1., 0., z],
            radius: 0.2,
            ca: color,
            cb: color,
            dashed: false,
            atoms: None,
        };
        let camera = Camera {
            rotation: [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]],
            zoom: 1.,
            pan: [0.; 2],
        };
        let scene = Scene {
            solids: vec![solid(-0.5, [0; 3]), solid(0.5, [255; 3])],
        };
        assert!((scene.depth_test(camera).depth_at(0., 0.).unwrap() - 0.7).abs() < 1e-12);
        assert!(scene.depth_test(camera).depth_at(0., 1.).is_none());
    }

    #[test]
    fn local_bonds_yield_to_their_atom_label_without_disabling_other_depth() {
        let solid = |z, atoms| Solid {
            a: [-1., 0., z],
            b: [1., 0., z],
            radius: 0.2,
            ca: [255; 3],
            cb: [255; 3],
            dashed: false,
            atoms,
        };
        let camera = Camera {
            rotation: [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]],
            zoom: 1.,
            pan: [0.; 2],
        };

        let local_only = Scene {
            solids: vec![solid(0.5, Some((0, 1)))],
        }
        .depth_test(camera);
        assert!(!local_only.occludes_label(0., 0., -1., 0));
        assert!(local_only.occludes_label(0., 0., -1., 2));

        let unrelated_behind_local_but_ahead_of_label = Scene {
            solids: vec![solid(0.8, Some((0, 1))), solid(0.5, Some((2, 3)))],
        }
        .depth_test(camera);
        assert!(unrelated_behind_local_but_ahead_of_label.occludes_label(0., 0., -1., 0));

        let unrelated_behind_label = Scene {
            solids: vec![solid(0.5, Some((0, 1))), solid(-1.5, Some((2, 3)))],
        }
        .depth_test(camera);
        assert!(!unrelated_behind_label.occludes_label(0., 0., -1., 0));
    }

    #[test]
    fn aromatic_dashes_stay_inside_a_five_membered_ring() {
        let points: Vec<_> = (0..5)
            .map(|i| {
                let angle = std::f64::consts::TAU * i as f64 / 5.;
                [angle.cos(), angle.sin(), 0.]
            })
            .collect();
        let mut molecule = Molecule {
            atoms: points
                .iter()
                .map(|&xyz| Atom {
                    element: "C".into(),
                    xyz,
                    charge: 0,
                    isotope: 0,
                })
                .collect(),
            ..Default::default()
        };
        for i in 0..5 {
            molecule.bonds.insert(pair(i, (i + 1) % 5), 4.);
        }
        let scene = Scene::from_molecule(&molecule, &points);
        let dashed: Vec<_> = scene.solids.iter().filter(|solid| solid.dashed).collect();
        assert!(!dashed.is_empty());
        let outer_chord_midpoint = (std::f64::consts::PI / 5.).cos();
        assert!(dashed.iter().all(|solid| {
            let midpoint = mix(solid.a, solid.b, 0.5);
            (midpoint[0] * midpoint[0] + midpoint[1] * midpoint[1]).sqrt() < outer_chord_midpoint
        }));
    }

    #[test]
    fn five_six_and_seven_membered_rings_use_the_same_dash_clearance() {
        for size in [5, 6, 7] {
            let points: Vec<_> = (0..size)
                .map(|index| {
                    let angle = std::f64::consts::TAU * index as f64 / size as f64;
                    [angle.cos(), angle.sin(), 0.]
                })
                .collect();
            let ring: Vec<_> = (0..size).collect();
            let guide = delocalized_dash_guide(&points, &ring, 0, 1, [0., 1., 0.]);
            let parent_midpoint = mix(points[0], points[1], 0.5);
            let guide_midpoint = mix(guide.0, guide.1, 0.5);
            let offset = norm(sub(guide_midpoint, parent_midpoint));
            assert!((offset - DELOCALIZED_CENTERLINE_OFFSET).abs() < 1e-12);
            assert!((offset - BOND_RADIUS - DELOCALIZED_DASH_RADIUS - 0.058).abs() < 1e-12);
        }
    }

    #[test]
    fn fully_delocalized_fused_faces_draw_the_shared_bond_on_both_sides() {
        // These graph families exercise indole-like 5/6, naphthalene- or
        // quinoline-like 6/6, and azulene-like 5/7 fused faces. The test is
        // depiction-only and does not assert chemical aromaticity.
        for (upper, lower, nitrogen) in [(5, 6, true), (6, 6, true), (5, 7, false)] {
            let (molecule, points) = fused_delocalized_polygons(upper, lower, nitrogen);
            let adjacency = molecule.adjacency();
            let rings = delocalized_bond_rings(&molecule, &adjacency, 0, 1, 12);
            let sizes: std::collections::BTreeSet<_> =
                rings.iter().map(|ring| ring.len()).collect();
            assert!(sizes.contains(&upper) && sizes.contains(&lower));

            let guides = delocalized_dash_guides(&points, &rings, 0, 1, [0., 1., 0.]);
            assert_eq!(guides.len(), 2);
            let parent_midpoint = mix(points[0], points[1], 0.5);
            let offsets: Vec<_> = guides
                .iter()
                .map(|guide| sub(mix(guide.0, guide.1, 0.5), parent_midpoint))
                .collect();
            assert!(dot(offsets[0], offsets[1]) < 0.);
            assert!(
                offsets.iter().all(|offset| {
                    (norm(*offset) - DELOCALIZED_CENTERLINE_OFFSET).abs() < 1e-12
                })
            );

            let scene = Scene::from_molecule(&molecule, &points);
            let shared_fragments: Vec<_> = scene
                .solids
                .iter()
                .filter(|solid| solid.dashed && solid.atoms == Some(pair(0, 1)))
                .collect();
            assert!(shared_fragments.len() >= 4);
            assert!(
                shared_fragments
                    .iter()
                    .any(|solid| mix(solid.a, solid.b, 0.5)[1] > 0.)
            );
            assert!(
                shared_fragments
                    .iter()
                    .any(|solid| mix(solid.a, solid.b, 0.5)[1] < 0.)
            );
        }
    }

    #[test]
    fn fused_delocalized_edge_follows_the_majority_delocalized_ring() {
        let mut molecule = Molecule::default();
        molecule.atoms.extend((0..9).map(|_| Atom {
            element: "C".into(),
            xyz: [0.; 3],
            charge: 0,
            isotope: 0,
        }));
        for edge in [(0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 0)] {
            molecule.bonds.insert(pair(edge.0, edge.1), 4.);
        }
        for edge in [(5, 6), (6, 7), (7, 8), (8, 4)] {
            molecule.bonds.insert(pair(edge.0, edge.1), 1.);
        }
        let ring = delocalized_bond_ring(&molecule, &molecule.adjacency(), 4, 5, 12).unwrap();
        assert!(ring.iter().all(|atom| *atom <= 5));
        assert!(ring.contains(&0) && ring.contains(&1) && ring.contains(&2) && ring.contains(&3));
        assert!(!ring.contains(&6) && !ring.contains(&7) && !ring.contains(&8));
    }

    #[test]
    fn fused_aza_ring_dashes_use_local_cycles_with_uniform_spacing() {
        // Redacted regression topology: a six-membered and a five-membered
        // aromatic ring share a C-N edge. Bonds touching the shared nitrogen
        // are intentionally single rather than MDL aromatic type 4.
        let molecule =
            parse_sdf(include_str!("../tests/fixtures/sdf/fused_aza_redacted.sdf")).unwrap();
        let points = molecule.coords();

        let adjacency = molecule.adjacency();
        let five = delocalized_bond_ring(&molecule, &adjacency, 3, 6, 12).unwrap();
        assert_eq!(
            five.iter()
                .copied()
                .collect::<std::collections::BTreeSet<_>>(),
            std::collections::BTreeSet::from([3, 4, 6, 7, 8])
        );

        let scene = Scene::from_molecule(&molecule, &points);
        let dash_offset = |edge: Pair| {
            let fragments: Vec<_> = scene
                .solids
                .iter()
                .filter(|solid| solid.dashed && solid.atoms == Some(pair(edge.0, edge.1)))
                .collect();
            assert!(!fragments.is_empty());
            let dash_midpoint = mul(
                fragments
                    .iter()
                    .fold([0.; 3], |sum, solid| add(sum, mix(solid.a, solid.b, 0.5))),
                1. / fragments.len() as f64,
            );
            let bond_midpoint = mix(points[edge.0], points[edge.1], 0.5);
            let axis = unit(sub(points[edge.1], points[edge.0]));
            let delta = sub(dash_midpoint, bond_midpoint);
            let longitudinal = dot(delta, axis);
            let perpendicular = norm(sub(delta, mul(axis, longitudinal)));
            (longitudinal, perpendicular)
        };

        let mut all_offsets = Vec::new();
        for ring_edges in [
            &[(0, 1), (0, 5), (1, 2), (2, 3)][..],
            &[(3, 6), (6, 7), (7, 8)][..],
        ] {
            let offsets: Vec<_> = ring_edges.iter().map(|&edge| dash_offset(edge)).collect();
            assert!(offsets.iter().all(|(along, _)| along.abs() < 1e-10));
            let minimum = offsets
                .iter()
                .map(|(_, perpendicular)| *perpendicular)
                .reduce(f64::min)
                .unwrap();
            let maximum = offsets
                .iter()
                .map(|(_, perpendicular)| *perpendicular)
                .reduce(f64::max)
                .unwrap();
            assert!(maximum - minimum < 1e-10);
            all_offsets.extend(offsets.into_iter().map(|(_, perpendicular)| perpendicular));
        }
        assert!(
            all_offsets
                .iter()
                .all(|offset| (offset - DELOCALIZED_CENTERLINE_OFFSET).abs() < 1e-10)
        );
    }
}
