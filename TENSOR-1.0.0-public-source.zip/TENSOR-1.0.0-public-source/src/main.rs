#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]
use anyhow::{Context, Result, bail};
use std::{collections::BTreeMap, path::PathBuf};
use tensor::{
    analysis::*, cluster::ClusterSettings, config::*, jobs::*, molecule::*, ui::Workbench,
    verification,
};

const HELP: &str =
    "TENSOR - Theoretical Evaluation of NMR: Structures, Orchestration, and Rendering

Usage:
  tensor                         Open the two-tab desktop application
  tensor --demo                  Open a marked synthetic example
  tensor --setup INPUT... --out DIR [options]
  tensor --analyze INPUT... [--out DIR] [--no-dedup]
  tensor --open-results DIR      Reopen exported viewer results
  tensor --self-test             Run built-in scientific and UI checks
  tensor --render-demo DIR       Save headless renders of both tabs
  tensor --export-demo DIR       Export a labelled synthetic structure in PNG/SVG/PDF
  tensor --export-spectra-demo DIR  Export a synthetic spin-system validation case
  tensor --write-icons DIR       Write the supplied logo as PNG/Windows ICO resources

INPUT may be an SDF/log file or a folder. Add --recursive for subfolders.
Single conformers must use compound_number.sdf filenames.

Shared options:
  --config FILE       Read routes, scalings, and machine profiles from this file
  --out DIR           Output folder (analysis defaults to beside the logs)
  --temperature K     Setup temperature / analysis temperature override
  --recursive         Include subfolders when collecting inputs

Setup options:
  --method KEY        Method key in configuration (default 1)
  --machine KEY       Machine key (default default)
  --tier KEY          Resource tier (default medium)
  --couplings         Add coupling calculation
  --fluorine          Add fluorine shifts
  --nitrogen          Add nitrogen shifts
  --sulfur            Add carbon–sulfur correction jobs
  --halogen           Add carbon–halogen correction jobs
  --cluster MODE      none, shifts, all-nmr, or custom
  --linkage NAME      complete, average, single, weighted, ward, or all
  --tau VALUE         Relative clustering threshold, 0..1
  --selection NAME    lowest_energy, tiered, or medoid
  --dihedral-weight W Nonnegative torsion fingerprint weight
  --keep-split        Keep split SDF intermediates
  --keep-aligned      Keep aligned SDF intermediates
  --keep-clustered    Keep clustering reports and selected/unselected SDFs

Analysis options:
  --no-dedup          Keep all otherwise valid conformers
  --outputs KEYS      Comma-separated export keys, all, or none:
                     chemical_shifts,coupling_constants,conformer_sdf,distances,
                     noe_intensities,noe_multipliers,frequencies,pymol_script,
                     dedup_report,wiberg_report

Submit generated jobs through your usual Gaussian workflow. Scientific processing
and the built-in 3D viewer require no Python.
";

fn config_path(explicit: Option<PathBuf>) -> Result<PathBuf> {
    if let Some(p) = explicit {
        return Ok(p);
    }
    let cwd = std::env::current_dir()?;
    let mut locations = vec![cwd.join(CONFIG_NAME)];
    if let Ok(exe) = std::env::current_exe()
        && let Some(parent) = exe.parent()
    {
        locations.push(parent.join(CONFIG_NAME));
    }
    let root = std::env::var_os("APPDATA")
        .map(PathBuf::from)
        .or_else(|| std::env::var_os("XDG_CONFIG_HOME").map(PathBuf::from))
        .or_else(|| std::env::var_os("HOME").map(|h| PathBuf::from(h).join(".config")))
        .unwrap_or(cwd);
    let user_config = root.join("TENSOR").join(CONFIG_NAME);
    locations.push(user_config.clone());
    if let Some(path) = locations.iter().find(|path| path.is_file()) {
        return Ok(path.clone());
    }
    // Public releases intentionally do not discover or migrate pre-TENSOR
    // application data. A first launch therefore creates clean bundled
    // defaults under %APPDATA%\TENSOR (or the platform config equivalent).
    Ok(user_config)
}

fn run() -> Result<()> {
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    let mut mode = "gui";
    let mut inputs = vec![];
    let mut output = None;
    let mut config_file = None;
    let mut recursive = false;
    let mut demo = false;
    let mut results_folder = None;
    let mut job = JobSettings::default();
    let mut analysis = AnalysisSettings::default();
    let mut clustering = "none".to_owned();
    let mut custom = ClusterSettings::default();
    let mut i = 0;
    while i < args.len() {
        let flag = args[i].to_string_lossy().to_string();
        let mut next = || -> Result<std::ffi::OsString> {
            i += 1;
            args.get(i)
                .cloned()
                .with_context(|| format!("{flag} requires a value"))
        };
        match flag.as_str() {
            "--help" | "-h" => {
                println!("{HELP}");
                return Ok(());
            }
            "--version" | "-V" => {
                println!("{} {}", tensor::TITLE, tensor::VERSION);
                return Ok(());
            }
            "--setup" | "--analyze" | "--analysis" => {
                anyhow::ensure!(mode == "gui", "Choose one operation per invocation");
                mode = if flag == "--setup" {
                    "setup"
                } else {
                    "analyze"
                };
            }
            "--self-test" => {
                return verification::self_test();
            }
            "--render-demo" => {
                return verification::render_demo(&PathBuf::from(next()?));
            }
            "--export-demo" => return verification::export_demo(&PathBuf::from(next()?)),
            "--export-spectra-demo" => {
                return verification::export_spectra_demo(&PathBuf::from(next()?));
            }
            "--write-icons" => {
                return tensor::branding::write_icons(&PathBuf::from(next()?));
            }
            "--demo" => demo = true,
            "--open-results" => results_folder = Some(PathBuf::from(next()?)),
            "--out" | "--output" => output = Some(PathBuf::from(next()?)),
            "--config" => config_file = Some(PathBuf::from(next()?)),
            "--recursive" => recursive = true,
            "--method" => job.method = next()?.to_string_lossy().into(),
            "--machine" => job.machine = next()?.to_string_lossy().into(),
            "--tier" => job.tier = next()?.to_string_lossy().into(),
            "--temperature" => {
                let t: f64 = next()?
                    .to_string_lossy()
                    .parse()
                    .context("Invalid temperature")?;
                anyhow::ensure!(t.is_finite() && t > 0., "Temperature must be above 0 K");
                job.temperature = t;
                analysis.temperature_override = Some(t);
            }
            "--couplings" => job.coupling = true,
            "--fluorine" => job.fluorine = true,
            "--nitrogen" => job.nitrogen = true,
            "--sulfur" => job.sulfur = true,
            "--halogen" => job.halogen = true,
            "--keep-split" => job.keep_split = true,
            "--keep-aligned" => job.keep_aligned = true,
            "--keep-clustered" => job.keep_clustered = true,
            "--cluster" => clustering = next()?.to_string_lossy().into(),
            "--linkage" => custom.linkage = next()?.to_string_lossy().into(),
            "--tau" => {
                custom.tau = next()?
                    .to_string_lossy()
                    .parse()
                    .context("Invalid clustering threshold")?
            }
            "--selection" => custom.selection = next()?.to_string_lossy().into(),
            "--dihedral-weight" => {
                custom.dihedral_weight = next()?
                    .to_string_lossy()
                    .parse()
                    .context("Invalid dihedral weight")?
            }
            "--no-dedup" => analysis.dedup = false,
            "--outputs" => {
                let keys = next()?.to_string_lossy().into_owned();
                analysis.outputs.set_all(keys == "all");
                if keys != "all" && keys != "none" {
                    for key in keys.split(',') {
                        let v = analysis
                            .outputs
                            .0
                            .get_mut(key.trim())
                            .with_context(|| format!("Unknown output key: {key}"))?;
                        *v = true;
                    }
                }
            }
            "--" => {
                inputs.extend(args[i + 1..].iter().map(PathBuf::from));
                break;
            }
            _ if flag.starts_with('-') => bail!("Unknown option: {flag}\nUse --help for usage."),
            _ => inputs.push(PathBuf::from(&args[i])),
        }
        i += 1;
    }
    if mode == "analyze" {
        anyhow::ensure!(
            !inputs.is_empty(),
            "Supply completed Gaussian logs or a folder"
        );
        analysis.output_root = output;
        let mut paths = vec![];
        for p in inputs {
            paths.extend(collect_files(&p, "log", recursive)?);
        }
        paths.sort_by(|a, b| natural_path_cmp(a, b));
        paths.dedup();
        let result = run_analysis(&paths, &analysis, &Progress::default())?;
        for c in &result.compounds {
            println!(
                "{}: {} conformers; {} exports in {}",
                c.name,
                c.conformers.len(),
                c.generated.len(),
                c.directory.display()
            );
        }
        anyhow::ensure!(
            result.errors.is_empty(),
            "Some inputs failed:\n{}",
            result.errors.join("\n")
        );
        anyhow::ensure!(
            !result.compounds.is_empty(),
            "No compounds were successfully analyzed"
        );
        return Ok(());
    }
    let cfg_path = config_path(config_file)?;
    let config = Config::load(&cfg_path)?;
    job.clustering = match clustering.as_str() {
        "none" => None,
        "shifts" => Some(ClusterSettings::shifts()),
        "all-nmr" => Some(ClusterSettings::all_nmr()),
        "custom" => Some(custom),
        _ => bail!("Unknown cluster mode: {clustering}"),
    };
    if mode == "setup" {
        anyhow::ensure!(!inputs.is_empty(), "Supply SDF conformers or a folder");
        let root = output.context("Choose an output folder with --out DIR")?;
        let mut paths = vec![];
        for p in inputs {
            paths.extend(collect_files(&p, "sdf", recursive)?);
        }
        paths.sort_by(|a, b| natural_path_cmp(a, b));
        paths.dedup();
        let (items, errors) = load_inputs(&paths);
        anyhow::ensure!(
            errors.is_empty(),
            "Resolve SDF input errors before generating:\n{}",
            errors.join("\n")
        );
        let settings: BTreeMap<_, _> = items
            .iter()
            .map(|c| (c.compound.clone(), job.clone()))
            .collect();
        let result = run_setup(&items, &settings, &config, &root, &Progress::default())?;
        println!(
            "Generated {} Gaussian jobs in {}",
            result.paths.len(),
            root.join("gjf_files").display()
        );
        return Ok(());
    }
    let direct_workspace = demo || results_folder.is_some() || !inputs.is_empty();
    let mut app = Workbench::new(config, cfg_path);
    app.restore_job(job);
    app.analysis_settings = analysis;
    app.recursive_folders = recursive;
    if let Some(root) = output {
        app.setup_output = root.to_string_lossy().into();
        app.analysis_output = root.to_string_lossy().into();
    }
    if demo {
        verification::load_demo(&mut app)?;
    }
    if let Some(root) = results_folder {
        app.open_results(&root)?;
    }
    if !inputs.is_empty() {
        let setup = inputs[0]
            .extension()
            .is_some_and(|e| e.to_string_lossy().eq_ignore_ascii_case("sdf"));
        if !setup {
            app.tab = tensor::ui::Tab::Analysis;
        }
        app.add_paths(inputs, setup);
    }
    if !direct_workspace {
        app.begin_startup();
    }
    let options = eframe::NativeOptions {
        viewport: eframe::egui::ViewportBuilder::default()
            .with_title(tensor::TITLE)
            .with_icon(app.window_icon.clone())
            .with_inner_size(if direct_workspace {
                [1280., 820.]
            } else {
                [230., 230.]
            })
            .with_min_inner_size(if direct_workspace {
                [760., 520.]
            } else {
                [220., 220.]
            })
            .with_decorations(direct_workspace)
            .with_resizable(direct_workspace)
            .with_maximized(direct_workspace)
            .with_clamp_size_to_monitor_size(true),
        centered: true,
        renderer: eframe::Renderer::Glow,
        ..Default::default()
    };
    eframe::run_native(tensor::TITLE,options,Box::new(|cc| {
        Workbench::style(&cc.egui_ctx); Ok(Box::new(app))
    })).map_err(|e|anyhow::anyhow!("Cannot open the desktop window: {e}\nA running desktop session with an OpenGL-capable driver is required. Use --help for headless commands."))
}
fn main() {
    let command_line = std::env::args_os()
        .skip(1)
        .take_while(|a| a != "--")
        .any(|a| {
            matches!(
                a.to_str(),
                Some(
                    "--setup"
                        | "--analyze"
                        | "--analysis"
                        | "--self-test"
                        | "--render-demo"
                        | "--export-demo"
                        | "--export-spectra-demo"
                        | "--write-icons"
                        | "--help"
                        | "-h"
                        | "--version"
                        | "-V"
                )
            )
        });
    #[cfg(windows)]
    if command_line {
        #[link(name = "kernel32")]
        unsafe extern "system" {
            fn AttachConsole(process_id: u32) -> i32;
        }
        // CLI commands share the invoking terminal; ordinary GUI launch has no console.
        unsafe {
            AttachConsole(u32::MAX);
        }
    }
    if let Err(error) = run() {
        eprintln!("Error: {error:#}");
        if !command_line {
            rfd::MessageDialog::new()
                .set_title("TENSOR")
                .set_description(format!("{error:#}"))
                .set_level(rfd::MessageLevel::Error)
                .show();
        }
        std::process::exit(1);
    }
}
