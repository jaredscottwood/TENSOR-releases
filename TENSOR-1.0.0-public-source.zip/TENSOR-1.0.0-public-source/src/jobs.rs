use crate::{
    cluster::{ClusterSettings, cluster},
    config::*,
    math::*,
    molecule::*,
};
use anyhow::{Context, Result, ensure};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::{Path, PathBuf},
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, Ordering},
        mpsc::Sender,
    },
};

#[derive(Clone, Debug)]
pub struct JobSettings {
    pub method: String,
    pub machine: String,
    pub tier: String,
    pub temperature: f64,
    pub coupling: bool,
    pub fluorine: bool,
    pub nitrogen: bool,
    pub sulfur: bool,
    pub halogen: bool,
    pub keep_split: bool,
    pub keep_aligned: bool,
    pub keep_clustered: bool,
    pub clustering: Option<ClusterSettings>,
}
impl Default for JobSettings {
    fn default() -> Self {
        Self {
            method: "1".into(),
            machine: "default".into(),
            tier: "medium".into(),
            temperature: 298.,
            coupling: false,
            fluorine: false,
            nitrogen: false,
            sulfur: false,
            halogen: false,
            keep_split: false,
            keep_aligned: false,
            keep_clustered: false,
            clustering: None,
        }
    }
}
#[derive(Clone, Default)]
pub struct Progress {
    pub cancel: Arc<AtomicBool>,
    pub sender: Option<Sender<String>>,
    pub transcript: Arc<Mutex<Vec<String>>>,
}
impl Progress {
    pub fn check(&self) -> Result<()> {
        ensure!(!self.cancel.load(Ordering::Relaxed), "Cancelled");
        Ok(())
    }
    pub fn log(&self, msg: impl Into<String>) {
        let msg = msg.into();
        if let Ok(mut lines) = self.transcript.lock() {
            lines.push(msg.clone());
        }
        if let Some(s) = &self.sender {
            let _ = s.send(msg);
        } else {
            println!("{msg}");
        }
    }
    pub fn save_log(&self, path: &Path) -> Result<()> {
        let text = self
            .transcript
            .lock()
            .map_err(|_| anyhow::anyhow!("Run log is unavailable"))?
            .join("\n");
        atomic_write(path, &(text + "\n"))
    }
}
#[derive(Clone, Debug)]
pub struct OutputFile {
    pub path: PathBuf,
    pub contents: String,
}
impl OutputFile {
    pub fn new(path: impl Into<PathBuf>, contents: String) -> Self {
        Self {
            path: path.into(),
            contents,
        }
    }
}
#[derive(Clone, Debug, Default)]
pub struct SetupResult {
    pub paths: Vec<PathBuf>,
    pub selected: Vec<(String, Vec<usize>)>,
    pub overlays: Vec<SetupClusterOverlay>,
}

/// The exact aligned conformers and cluster membership used to generate jobs.
/// Passing this back to the UI avoids repeating alignment and clustering after
/// a successful setup run.
#[derive(Clone, Debug)]
pub struct SetupClusterOverlay {
    pub compound: String,
    pub settings: ClusterSettings,
    pub signature: Vec<(PathBuf, usize)>,
    pub items: Vec<ConformerInput>,
    pub groups: Vec<Vec<usize>>,
}

pub fn atomic_write(path: &Path, text: &str) -> Result<()> {
    atomic_write_bytes(path, text.as_bytes())
}
pub fn atomic_write_bytes(path: &Path, bytes: &[u8]) -> Result<()> {
    let parent = path.parent().context("No parent folder")?;
    std::fs::create_dir_all(parent)?;
    let unique = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)?
        .as_nanos();
    let tmp = parent.join(format!(".nmr-write-{}-{unique}.tmp", std::process::id()));
    let result = (|| -> Result<()> {
        use std::io::Write;
        let mut f = std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&tmp)?;
        f.write_all(bytes)?;
        f.sync_all()?;
        drop(f);
        std::fs::rename(&tmp, path)?;
        Ok(())
    })();
    if result.is_err() {
        let _ = std::fs::remove_file(&tmp);
    }
    result.with_context(|| format!("Cannot write {}", path.display()))
}
fn hash(text: &str) -> u64 {
    text.bytes().fold(14695981039346656037_u64, |h, b| {
        (h ^ b as u64).wrapping_mul(1099511628211)
    })
}
/// Validate all relative paths before any write or cleanup.
fn checked_outputs(files: &[OutputFile]) -> Result<BTreeMap<PathBuf, u64>> {
    let mut wanted = BTreeMap::new();
    for f in files {
        ensure!(
            !f.path.is_absolute()
                && f.path
                    .components()
                    .all(|c| matches!(c, std::path::Component::Normal(_))),
            "Invalid output path"
        );
        ensure!(
            wanted.insert(f.path.clone(), hash(&f.contents)).is_none(),
            "Duplicate output path {}",
            f.path.display()
        );
    }
    Ok(wanted)
}

/// Replace generated files, including pre-existing output from the Python tool.
/// The manifest identifies stale paths; it is no longer an overwrite veto.
pub fn commit_files(
    root: &Path,
    owner: &str,
    files: &[OutputFile],
    p: &Progress,
) -> Result<Vec<PathBuf>> {
    safe_name(owner)?;
    let wanted = checked_outputs(files)?;
    p.check()?;
    let manifest = root.join(format!(".nmr-{owner}-manifest.tsv"));
    let previous = std::fs::read_to_string(&manifest).unwrap_or_default();
    let old: Vec<PathBuf> = previous
        .lines()
        .filter_map(|line| line.split_once('\t'))
        .map(|(_, path)| PathBuf::from(path))
        .filter(|path| {
            !path.is_absolute()
                && path
                    .components()
                    .all(|c| matches!(c, std::path::Component::Normal(_)))
        })
        .collect();
    let mut written = Vec::new();
    for file in files {
        let path = root.join(&file.path);
        atomic_write(&path, &file.contents)?;
        written.push(path);
    }
    for path in old {
        if !wanted.contains_key(&path) && root.join(&path).is_file() {
            std::fs::remove_file(root.join(path))?;
        }
    }
    let text = wanted
        .iter()
        .map(|(path, h)| format!("{h:016x}\t{}\n", path.to_string_lossy().replace('\\', "/")))
        .collect::<String>();
    atomic_write(&manifest, &text)?;
    Ok(written)
}

/// Stage a complete analysis directory, then replace the old directory.
/// A failed calculation or cancelled run cannot clear the previous results.
pub fn replace_result_directory(
    root: &Path,
    files: &[OutputFile],
    inputs: &[PathBuf],
    p: &Progress,
) -> Result<Vec<PathBuf>> {
    checked_outputs(files)?;
    let parent = root.parent().context("Result directory has no parent")?;
    std::fs::create_dir_all(parent)?;
    if root.exists() {
        ensure!(
            root.is_dir() && !std::fs::symlink_metadata(root)?.file_type().is_symlink(),
            "Result destination must be a regular directory: {}",
            root.display()
        );
        let resolved = root.canonicalize()?;
        for input in inputs {
            if let Ok(path) = input.canonicalize() {
                ensure!(
                    !path.starts_with(&resolved),
                    "Result folder contains an input file: {}. Choose a result destination outside the input files.",
                    input.display()
                );
            }
        }
    }
    let id = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)?
        .as_nanos();
    let staging = parent.join(format!(".tensor-stage-{}-{id}", std::process::id()));
    let retired = parent.join(format!(".tensor-retired-{}-{id}", std::process::id()));
    std::fs::create_dir(&staging)?;
    let result = (|| -> Result<Vec<PathBuf>> {
        commit_files(&staging, "analysis", files, p)?;
        p.check()?;
        let replacing = root.exists();
        if replacing {
            p.log(format!(
                "Replacing previous result directory: {}",
                root.display()
            ));
            std::fs::rename(root, &retired).with_context(|| {
                format!(
                    "Cannot replace {}. Close files open in another program and retry.",
                    root.display()
                )
            })?;
        }
        if let Err(error) = std::fs::rename(&staging, root) {
            if replacing {
                std::fs::rename(&retired, root).context(
                    "Could not restore previous results after a failed directory replacement",
                )?;
            }
            return Err(error.into());
        }
        if replacing && let Err(error) = std::fs::remove_dir_all(&retired) {
            // The commit succeeded; a cleanup failure must not discard the
            // new results from the viewer or report the calculation failed.
            p.log(format!(
                "New results were saved, but could not remove the retired directory {}: {error}",
                retired.display()
            ));
        }
        Ok(files.iter().map(|f| root.join(&f.path)).collect())
    })();
    if staging.exists() {
        let _ = std::fs::remove_dir_all(&staging);
    }
    result
}

/// Retire stale setup outputs only for the compound currently being generated.
/// Other compounds sharing gjf_files are independent of this run.
fn retire_stale_setup(root: &Path, compound: &str, files: &[OutputFile]) -> Result<()> {
    let wanted: BTreeSet<_> = files.iter().map(|f| root.join(&f.path)).collect();
    for (folder, ext) in [("gjf_files", "gjf"), ("split_conformers", "sdf")] {
        if let Ok(entries) = std::fs::read_dir(root.join(folder)) {
            for entry in entries {
                let entry = entry?;
                let path = entry.path();
                if !entry.file_type()?.is_file()
                    || !path
                        .extension()
                        .is_some_and(|e| e.to_string_lossy().eq_ignore_ascii_case(ext))
                {
                    continue;
                }
                if let Some((name, _)) = number_name(&path)
                    && (name == compound
                        || name == format!("{compound}-csulfur")
                        || name == format!("{compound}-chalogen"))
                    && !wanted.contains(&path)
                {
                    std::fs::remove_file(path)?;
                }
            }
        }
    }
    for folder in ["aligned_conformers", "clustered_output"] {
        let directory = root.join(folder).join(compound);
        if !directory.exists() {
            continue;
        }
        ensure!(
            !std::fs::symlink_metadata(&directory)?
                .file_type()
                .is_symlink(),
            "Setup result directory must not be a symbolic link"
        );
        fn clean(directory: &Path, wanted: &BTreeSet<PathBuf>) -> Result<()> {
            for entry in std::fs::read_dir(directory)? {
                let entry = entry?;
                let path = entry.path();
                let kind = entry.file_type()?;
                if kind.is_dir() {
                    clean(&path, wanted)?;
                    let _ = std::fs::remove_dir(path);
                } else if !wanted.contains(&path) {
                    std::fs::remove_file(path)?;
                }
            }
            Ok(())
        }
        clean(&directory, &wanted)?;
        let _ = std::fs::remove_dir(directory);
    }
    Ok(())
}

fn check_setup_sources(
    root: &Path,
    inputs: &[ConformerInput],
    compounds: impl Iterator<Item = impl AsRef<str>>,
) -> Result<()> {
    if !root.exists() {
        return Ok(());
    }
    let root = root.canonicalize()?;
    let compounds: BTreeSet<String> = compounds.map(|c| c.as_ref().to_owned()).collect();
    let mut intermediate_directories = Vec::new();
    for name in &compounds {
        for folder in ["aligned_conformers", "clustered_output"] {
            let path = root.join(folder).join(name);
            if path.exists() {
                intermediate_directories.push(path.canonicalize()?);
            }
        }
    }
    let split = root.join("split_conformers");
    let split = if split.exists() {
        split.canonicalize()?
    } else {
        split
    };
    for input in inputs {
        // Embedded examples have in-memory SDF data and illustrative paths.
        // There is no source file to overwrite in that case.
        if !input.source.exists() {
            continue;
        }
        let source = input
            .source
            .canonicalize()
            .with_context(|| format!("Cannot check loaded input {}", input.source.display()))?;
        let in_generated_directory = intermediate_directories
            .iter()
            .any(|dir| source.starts_with(dir));
        let in_split_directory = source.parent() == Some(split.as_path())
            && number_name(&source).is_some_and(|(name, _)| compounds.contains(&name));
        ensure!(
            !in_generated_directory && !in_split_directory,
            "Setup output cleanup would replace or remove loaded input {}. Choose another output folder, or copy the SDF inputs outside this output tree first.",
            input.source.display()
        );
    }
    Ok(())
}

struct TitleSpec<'a> {
    compound: &'a str,
    number: &'a str,
    job: &'a str,
    molecule: &'a Molecule,
    scale: Option<Scaling>,
    special: Option<&'a str>,
    config: &'a Config,
    method: &'a str,
}

fn title(spec: TitleSpec<'_>) -> Result<String> {
    let TitleSpec {
        compound,
        number,
        job,
        molecule,
        scale,
        special,
        config,
        method,
    } = spec;
    let mut text = format!("{compound}_{number}_{job}");
    if job == "opt" {
        let charges: Vec<_> = molecule
            .atoms
            .iter()
            .enumerate()
            .filter(|(_, a)| a.charge != 0)
            .map(|(i, a)| format!("{}:{}", i + 1, a.charge))
            .collect();
        if !charges.is_empty() {
            text += &format!(" [{}]", charges.join("|"));
        }
    } else if job == "carbon" && special == Some("chalogen") {
        let adj = molecule.adjacency();
        let mut rows = vec![];
        for (i, a) in molecule.atoms.iter().enumerate() {
            if a.element != "C" {
                continue;
            }
            let hs: Vec<_> = adj[i]
                .iter()
                .filter_map(|&j| match molecule.atoms[j].element.as_str() {
                    "Cl" => Some((1, "Cl")),
                    "Br" => Some((2, "Br")),
                    "I" => Some((3, "I")),
                    _ => None,
                })
                .collect();
            if let Some((_, halogen)) = hs.iter().max() {
                let scaling_name = match *halogen {
                    "Cl" => "chlorine",
                    "Br" => "bromine",
                    "I" => "iodine",
                    _ => unreachable!(),
                };
                let scaling = config
                    .halogen_scaling(method, halogen, hs.len())?
                    .with_context(|| {
                        format!(
                            "Method {method:?} needs {}_{}_slope and {}_{}_intercept for carbon atom {}",
                            scaling_name,
                            hs.len().clamp(1, 3),
                            scaling_name,
                            hs.len().clamp(1, 3),
                            i + 1
                        )
                    })?;
                rows.push(format!(
                    "{}:s:{},i:{}",
                    i + 1,
                    py_float(scaling.slope),
                    py_float(scaling.intercept)
                ));
            }
        }
        if !rows.is_empty() {
            text += &format!(" hal{{{}}}", rows.join("|"))
        }
    } else if let Some(scaling) = scale {
        text += &format!(
            " s:{} i:{}",
            py_float(scaling.slope),
            py_float(scaling.intercept)
        );
    }
    Ok(text)
}
fn basis_block(m: &Molecule, basis: &str, iodine_block: Option<&str>) -> Result<String> {
    ensure!(
        !basis.is_empty() && !matches!(basis.to_lowercase().as_str(), "gen" | "genecp"),
        "An explicit non-iodine basis is required for a gen route"
    );
    let mut lines = vec![];
    for element in m.elements() {
        if element != "I" {
            lines.push(format!("{element} 0\n{basis}\n****"));
        }
    }
    if m.atoms.iter().any(|a| a.element == "I") {
        let block = iodine_block
            .filter(|block| !block.trim().is_empty())
            .context("The selected method has no usable iodine basis block")?;
        lines.push(block.trim().to_string())
    }
    Ok(lines.join("\n"))
}
pub fn generate_input(
    config: &Config,
    settings: &JobSettings,
    m: &Molecule,
    compound: &str,
    number: &str,
    special: Option<&str>,
    preview: bool,
) -> Result<String> {
    safe_name(compound)?;
    m.validate()?;
    let iodine = m.atoms.iter().any(|a| a.element == "I");
    let machine = config
        .machines
        .get(&settings.machine)
        .context("Unknown machine")?;
    let tier = machine
        .tiers
        .iter()
        .find(|x| x.name == settings.tier)
        .context("Unknown resource tier")?;
    let routes = if let Some(kind) = special {
        config.special_routes(&settings.method, settings.temperature, iodine, kind)?
    } else {
        config.routes(&settings.method, settings.temperature, iodine)?
    };
    let mut job_types = vec!["opt", "carbon"];
    if special.is_none() {
        job_types.push("proton");
        if settings.fluorine {
            job_types.push("fluorine")
        }
        if settings.nitrogen {
            job_types.push("nitrogen")
        }
        if settings.coupling {
            job_types.push("cc")
        }
    }
    let name = if let Some(s) = special {
        format!("{compound}-{s}")
    } else {
        compound.into()
    };
    let vars = Entry::from([
        ("compound".into(), name.clone()),
        ("conformer".into(), number.into()),
    ]);
    let adj = m.adjacency();
    let mut lines = vec![];
    for (index, job) in job_types.iter().enumerate() {
        if index > 0 {
            lines.push("--Link1--".into())
        }
        for template in [&machine.rwf, &machine.chk] {
            if !template.is_empty() {
                // Preview uses literal placeholders after the same substitutions as a real file.
                let header = if preview {
                    template
                        .replace("{compound}", &name)
                        .replace("{conformer}", number)
                } else {
                    render_template(template, &vars)?
                };
                lines.push(header);
            }
        }
        lines.push(format!("%nprocshared={}", tier.cores));
        lines.push(format!("%mem={}", tier.memory));
        let route = routes.get(*job).with_context(|| {
            format!(
                "Selected calculation {job} has no route in method {}",
                settings.method
            )
        })?;
        lines.push(route.clone());
        lines.push(String::new());
        let scaling = if special == Some("csulfur") && *job == "carbon" {
            config.scaling(&settings.method, "sulfur")?
        } else {
            config.scaling(&settings.method, job)?
        };
        let needs_scaling = match special {
            None => matches!(*job, "carbon" | "proton" | "fluorine" | "nitrogen"),
            Some("csulfur") => *job == "carbon",
            Some("chalogen") => false,
            Some(_) => false,
        };
        if needs_scaling {
            ensure!(
                scaling.is_some(),
                "Method {} needs {job}_slope and {job}_intercept before NMR jobs can be generated",
                settings.method
            );
        }
        lines.push(title(TitleSpec {
            compound: &name,
            number,
            job,
            molecule: m,
            scale: scaling,
            special,
            config,
            method: &settings.method,
        })?);
        lines.push(String::new());
        lines.push(format!("{} 1", m.charge()));
        if index == 0 {
            if preview {
                lines.push("{coordinates}".into())
            } else {
                for a in &m.atoms {
                    lines.push(format!(
                        "{} {} {} {}",
                        a.element,
                        py_float(a.xyz[0]),
                        py_float(a.xyz[1]),
                        py_float(a.xyz[2])
                    ));
                }
            }
            lines.push(String::new());
            for (a, neighbors) in adj.iter().enumerate() {
                let mut row = (a + 1).to_string();
                for &b in neighbors {
                    let mdl = m.bonds[&pair(a, b)];
                    ensure!(
                        [1., 1.5, 2., 3., 4.].contains(&mdl),
                        "Unsupported/query SDF bond type {mdl} between atoms {} and {}",
                        a + 1,
                        b + 1
                    );
                    // MDL type 4 is an aromatic flag, not a quadruple bond.
                    let gaussian_order = if mdl == 4. { 1.5 } else { mdl };
                    row += &format!(" {} {gaussian_order:.1}", b + 1);
                }
                lines.push(row);
            }
        }
        lines.push(String::new());
        if iodine || route.to_lowercase().contains("/gen") {
            let basis = config.basis_name(&settings.method, job, special)?;
            lines.push(basis_block(
                m,
                basis,
                if iodine {
                    Some(config.iodine_basis_block(&settings.method)?)
                } else {
                    None
                },
            )?);
            lines.push(String::new());
        }
        if index == 0 {
            lines.push("$NBO BNDIDX $END".into());
            lines.push(String::new());
        }
    }
    Ok(lines.join("\n") + "\n")
}
pub fn preview(
    config: &Config,
    settings: &JobSettings,
    m: &Molecule,
    compound: &str,
) -> Result<String> {
    let mut out = String::new();
    for special in [
        None,
        settings.sulfur.then_some("csulfur"),
        settings.halogen.then_some("chalogen"),
    ]
    .into_iter()
    .enumerate()
    {
        if special.0 > 0 && special.1.is_none() {
            continue;
        }
        let suffix = special.1.map(|s| format!("-{s}")).unwrap_or_default();
        out += &format!("===== {compound}{suffix}_{{conformer}}.gjf =====\n");
        out += &generate_input(
            config,
            settings,
            m,
            compound,
            "{conformer}",
            special.1,
            true,
        )?;
        out.push('\n');
    }
    Ok(out)
}
pub fn run_setup(
    inputs: &[ConformerInput],
    settings: &BTreeMap<String, JobSettings>,
    config: &Config,
    root: &Path,
    progress: &Progress,
) -> Result<SetupResult> {
    let started = std::time::Instant::now();
    progress.log("==================== GAUSSIAN JOB SETUP ====================");
    progress.log(format!(
        "{} input structures; {} selected compounds; output {}",
        inputs.len(),
        settings.len(),
        root.display()
    ));
    let mut result = SetupResult::default();
    let mut groups = BTreeMap::<String, Vec<ConformerInput>>::new();
    for c in inputs {
        if settings.contains_key(&c.compound) {
            groups
                .entry(c.compound.clone())
                .or_default()
                .push(c.clone());
        }
    }
    ensure!(!groups.is_empty(), "No conformers selected");
    // Check every selected compound before committing any of them. SDFs from
    // a previous run can otherwise be mistaken for disposable intermediates.
    check_setup_sources(root, inputs, groups.keys())?;
    for (compound, mut items) in groups {
        progress.check()?;
        let s = &settings[&compound];
        progress.log(format!(
            "{compound}: method {}; machine {}; tier {}; temperature {:.2} K",
            s.method, s.machine, s.tier, s.temperature
        ));
        items.sort_by_key(|x| x.number);
        let mut files = vec![];
        if s.keep_split {
            for c in &items {
                if c.split {
                    files.push(OutputFile::new(
                        format!("split_conformers/{}_{}.sdf", compound, c.number),
                        c.sdf.clone(),
                    ));
                }
            }
        }
        progress.log(format!("{compound}: aligning {} conformers", items.len()));
        align_inputs(&mut items)?;
        if s.keep_aligned {
            for c in &items {
                files.push(OutputFile::new(
                    format!(
                        "aligned_conformers/{compound}/{}_{}.sdf",
                        compound, c.number
                    ),
                    c.sdf.clone(),
                ));
            }
        }
        let (selected, overlay) = if let Some(settings) = &s.clustering {
            progress.log(format!(
                "{compound}: {} linkage, τ {:.2}, {} selection",
                settings.linkage, settings.tau, settings.selection
            ));
            let clustered = cluster(&items, settings, progress)?;
            if s.keep_clustered {
                for (i, c) in items.iter().enumerate() {
                    let dir = if clustered.selected.contains(&i) {
                        "selected_unique"
                    } else {
                        "not_selected"
                    };
                    files.push(OutputFile::new(
                        format!(
                            "clustered_output/{compound}/{dir}/{}_{}.sdf",
                            compound, c.number
                        ),
                        c.sdf.clone(),
                    ));
                }
                files.push(OutputFile::new(
                    format!("clustered_output/{compound}/clustering_report.txt"),
                    clustered.report.clone(),
                ));
            }
            let overlay = SetupClusterOverlay {
                compound: compound.clone(),
                settings: settings.clone(),
                signature: items
                    .iter()
                    .map(|item| (item.source.clone(), item.number))
                    .collect(),
                items: items.clone(),
                groups: clustered.groups.clone(),
            };
            (clustered.selected, Some(overlay))
        } else {
            ((0..items.len()).collect::<BTreeSet<_>>(), None)
        };
        ensure!(!selected.is_empty(), "Clustering retained no structures");
        let numbers: Vec<_> = selected.iter().map(|&i| items[i].number).collect();
        for i in selected {
            progress.check()?;
            let c = &items[i];
            for (enabled, kind) in [
                (true, None),
                (s.sulfur, Some("csulfur")),
                (s.halogen, Some("chalogen")),
            ] {
                if !enabled {
                    continue;
                }
                let name = kind
                    .map(|k| format!("{compound}-{k}"))
                    .unwrap_or(compound.clone());
                let text = generate_input(
                    config,
                    s,
                    &c.molecule,
                    &compound,
                    &c.number.to_string(),
                    kind,
                    false,
                )?;
                files.push(OutputFile::new(
                    format!("gjf_files/{name}_{}.gjf", c.number),
                    text,
                ));
            }
        }
        progress.log(format!(
            "{compound}: writing {} files; replacing previous outputs for this compound",
            files.len()
        ));
        let paths = commit_files(root, &format!("setup-{compound}"), &files, progress)?;
        retire_stale_setup(root, &compound, &files)?;
        result.paths.extend(
            paths
                .into_iter()
                .filter(|p| p.extension().is_some_and(|e| e == "gjf")),
        );
        progress.log(format!(
            "{compound}: {} selected conformers; Gaussian inputs saved.",
            numbers.len()
        ));
        result.selected.push((compound, numbers));
        if let Some(overlay) = overlay {
            result.overlays.push(overlay);
        }
    }
    progress.log(format!(
        "Setup complete: {} Gaussian jobs in {:.2} seconds",
        result.paths.len(),
        started.elapsed().as_secs_f64()
    ));
    let log_path = root.join("tensor-log.txt");
    progress.log(format!("Run log: {}", log_path.display()));
    if let Err(error) = progress.save_log(&log_path) {
        progress.log(format!("Could not save run log: {error:#}"));
    }
    Ok(result)
}

/// Generate each selected compound beside its source conformer file.  A
/// compound assembled from several files must come from one folder so cleanup
/// and regeneration have one unambiguous destination.
pub fn run_setup_beside(
    inputs: &[ConformerInput],
    settings: &BTreeMap<String, JobSettings>,
    config: &Config,
    progress: &Progress,
) -> Result<SetupResult> {
    ensure!(!settings.is_empty(), "No compounds selected");
    let mut by_root = BTreeMap::<PathBuf, BTreeMap<String, JobSettings>>::new();
    for (compound, job) in settings {
        let sources: Vec<_> = inputs
            .iter()
            .filter(|input| &input.compound == compound)
            .map(|input| &input.source)
            .collect();
        ensure!(!sources.is_empty(), "No conformers found for {compound}");
        ensure!(
            sources.iter().all(|path| path.is_file()),
            "{compound}: an in-memory or missing source has no folder. Choose an explicit output folder."
        );
        let mut parents = BTreeSet::new();
        for source in sources {
            parents.insert(
                source
                    .parent()
                    .unwrap_or(Path::new("."))
                    .canonicalize()
                    .with_context(|| {
                        format!("Cannot resolve source folder for {}", source.display())
                    })?,
            );
        }
        ensure!(
            parents.len() == 1,
            "{compound}: conformers span multiple source folders. Choose one explicit output folder."
        );
        by_root
            .entry(parents.into_iter().next().unwrap())
            .or_default()
            .insert(compound.clone(), job.clone());
    }
    let mut combined = SetupResult::default();
    for (root, jobs) in by_root {
        let result = run_setup(inputs, &jobs, config, &root, progress)?;
        combined.paths.extend(result.paths);
        combined.selected.extend(result.selected);
        combined.overlays.extend(result.overlays);
    }
    Ok(combined)
}
