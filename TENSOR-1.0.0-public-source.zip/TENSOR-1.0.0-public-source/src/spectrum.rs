//! Fast-exchange, isotropic spin-1/2 spectra. All frequencies and J values are in Hz.
use crate::{analysis::CompoundResult, math::*, molecule::*, symmetry::chordless_bond_cycles};
use anyhow::{Result, bail, ensure};
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::sync::atomic::{AtomicBool, Ordering};

#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub enum Nucleus {
    H,
    C,
    F,
    N,
}
impl Nucleus {
    pub const ALL: [Self; 4] = [Self::H, Self::C, Self::F, Self::N];
    pub fn index(self) -> usize {
        match self {
            Self::H => 0,
            Self::C => 1,
            Self::F => 2,
            Self::N => 3,
        }
    }
    pub fn label(self) -> &'static str {
        match self {
            Self::H => "¹H",
            Self::C => "¹³C",
            Self::F => "¹⁹F",
            Self::N => "¹⁵N",
        }
    }
    pub fn ascii(self) -> &'static str {
        match self {
            Self::H => "1H",
            Self::C => "13C",
            Self::F => "19F",
            Self::N => "15N",
        }
    }
    pub fn ratio(self) -> f64 {
        match self {
            Self::H => 1.,
            Self::C => 0.25145020,
            Self::F => 0.94094011,
            Self::N => 0.10136767,
        }
    }
    pub fn rare(self) -> bool {
        matches!(self, Self::C | Self::N)
    }
    pub fn from_atom(a: &Atom) -> Option<Self> {
        match (a.element.as_str(), a.isotope) {
            ("H", 0 | 1) => Some(Self::H),
            ("C", 0 | 13) => Some(Self::C),
            ("F", 0 | 19) => Some(Self::F),
            ("N", 0 | 15) => Some(Self::N),
            _ => None,
        }
    }
}
#[derive(Clone, Debug)]
pub struct Spin {
    pub atom: usize,
    pub nucleus: Nucleus,
    pub ppm: f64,
    pub area: f64,
}
#[derive(Clone, Debug)]
pub struct ReferencePeak {
    pub nucleus: Nucleus,
    pub ppm: f64,
    pub area: f64,
    pub label: String,
}
#[derive(Clone, Debug, Default)]
pub struct Input {
    pub name: String,
    pub spins: Vec<Spin>,
    pub calculated: PairValues,
    pub estimated: PairValues,
    pub estimated_aromatic: PairValues,
    pub references: Vec<ReferencePeak>,
    pub rotor_groups: Vec<Vec<usize>>,
    pub notes: Vec<String>,
}
#[derive(Clone, Debug)]
pub struct SpectrumConformer {
    pub number: usize,
    pub population: f64,
    pub molecule: Molecule,
}
#[derive(Clone, Debug)]
pub struct SpectrumLog {
    pub compound: String,
    pub number: usize,
    pub valid: bool,
    pub couplings: PairValues,
    pub solvents: BTreeSet<String>,
}
/// The compact subset of an analysis result needed by the spectrum worker.
/// Large distance, NOE, frequency, export, and report payloads stay in the
/// main workbench instead of being cloned when the window opens.
#[derive(Clone, Debug)]
pub struct SpectrumSource {
    pub name: String,
    pub structure: Molecule,
    pub conformers: Vec<SpectrumConformer>,
    pub shifts: Values,
    pub couplings: PairValues,
    pub logs: Vec<SpectrumLog>,
}
impl SpectrumSource {
    pub fn from_compound(compound: &CompoundResult) -> Self {
        Self {
            name: compound.name.clone(),
            structure: compound.structure.clone(),
            conformers: compound
                .conformers
                .iter()
                .map(|conformer| SpectrumConformer {
                    number: conformer.number,
                    population: conformer.population,
                    molecule: conformer.molecule.clone(),
                })
                .collect(),
            shifts: compound.shifts.clone(),
            couplings: compound.couplings.clone(),
            logs: compound
                .logs
                .iter()
                .map(|log| SpectrumLog {
                    compound: log.compound.clone(),
                    number: log.number,
                    valid: log.valid(),
                    couplings: log.couplings.clone(),
                    solvents: log.solvents.clone(),
                })
                .collect(),
        }
    }
}
fn check(cancel: &AtomicBool) -> Result<()> {
    ensure!(
        !cancel.load(Ordering::Relaxed),
        "Spectrum calculation cancelled"
    );
    Ok(())
}
/// A simplified vicinal H–C(sp³)–C(sp³)–H Karplus curve; not a substituent-corrected model.
pub fn karplus(theta: f64) -> f64 {
    let c = theta.cos();
    7.76 * c * c - 1.10 * c + 1.40
}

fn carbon_response(molecule: &Molecule, atom: usize, adjacency: &[Vec<usize>]) -> f64 {
    let hydrogens = adjacency[atom]
        .iter()
        .filter(|&&neighbor| molecule.atoms[neighbor].element == "H")
        .count();
    match hydrogens {
        0 => 0.45,
        1 => 1.00,
        2 => 1.15,
        _ => 1.30,
    }
}

fn aromatic_ring_distance(
    adjacency: &[Vec<usize>],
    ring: &BTreeSet<usize>,
    start: usize,
    end: usize,
) -> Option<usize> {
    let mut distance = vec![usize::MAX; adjacency.len()];
    distance[start] = 0;
    let mut queue = VecDeque::from([start]);
    while let Some(atom) = queue.pop_front() {
        if atom == end {
            return Some(distance[atom]);
        }
        for &next in &adjacency[atom] {
            if ring.contains(&next) && distance[next] == usize::MAX {
                distance[next] = distance[atom] + 1;
                queue.push_back(next);
            }
        }
    }
    None
}

fn aromatic_hydrogen_couplings(molecule: &Molecule, adjacency: &[Vec<usize>]) -> PairValues {
    // The general symmetry ring inventory intentionally keeps one shortest
    // alternate path per bond. Coupling perception needs every local
    // chordless six-membered face because a shorter fused-ring path must not
    // hide the aromatic ring containing the two observed proton sites.
    let mut local_rings = BTreeSet::new();
    for (a, neighbors) in adjacency.iter().enumerate() {
        for &b in neighbors {
            if a >= b {
                continue;
            }
            for mut ring in chordless_bond_cycles(adjacency, a, b, 8, 4096) {
                ring.sort_unstable();
                local_rings.insert(ring);
            }
        }
    }
    let aromatic_rings: Vec<BTreeSet<usize>> = local_rings
        .into_iter()
        .filter(|ring| {
            ring.len() == 6
                && ring
                    .iter()
                    .all(|&atom| matches!(molecule.atoms[atom].element.as_str(), "C" | "N"))
                && ring.iter().all(|&atom| {
                    adjacency[atom]
                        .iter()
                        .filter(|neighbor| ring.contains(neighbor))
                        .count()
                        == 2
                })
                && molecule
                    .bonds
                    .iter()
                    .filter(|((a, b), order)| ring.contains(a) && ring.contains(b) && **order > 1.3)
                    .count()
                    >= 3
        })
        .map(|ring| ring.into_iter().collect())
        .collect();
    let hydrogens: Vec<_> = molecule
        .atoms
        .iter()
        .enumerate()
        .filter(|(atom, value)| value.element == "H" && adjacency[*atom].len() == 1)
        .filter_map(|(atom, _)| {
            let ring_atom = adjacency[atom][0];
            (molecule.atoms[ring_atom].element == "C").then_some((atom, ring_atom))
        })
        .collect();
    let mut couplings = PairValues::new();
    for (position, &(hydrogen_a, carbon_a)) in hydrogens.iter().enumerate() {
        for &(hydrogen_b, carbon_b) in &hydrogens[position + 1..] {
            let Some(distance) = aromatic_rings
                .iter()
                .filter(|ring| ring.contains(&carbon_a) && ring.contains(&carbon_b))
                .filter_map(|ring| aromatic_ring_distance(adjacency, ring, carbon_a, carbon_b))
                .min()
            else {
                continue;
            };
            let coupling = match distance {
                1 => 7.54,
                2 => 1.37,
                3 => 0.69,
                _ => continue,
            };
            couplings.insert(pair(hydrogen_a, hydrogen_b), coupling);
        }
    }
    couplings
}

fn solvent_references(keyword: &str) -> Option<Vec<ReferencePeak>> {
    let peak = |nucleus, ppm, area, label: &str| ReferencePeak {
        nucleus,
        ppm,
        area,
        label: label.into(),
    };
    let h = |ppm, area, label| peak(Nucleus::H, ppm, area, label);
    let c = |ppm, area, label| peak(Nucleus::C, ppm, area, label);
    Some(match keyword {
        "chloroform" => vec![h(7.26, 0.12, "CHCl₃ residual"), c(77.16, 0.12, "CDCl₃")],
        "dimethylsulfoxide" | "dmso" => {
            vec![h(2.50, 0.12, "DMSO residual"), c(39.52, 0.12, "DMSO-d₆")]
        }
        "acetonitrile" => vec![
            h(1.94, 0.12, "CH₃CN residual"),
            c(1.32, 0.09, "CD₃CN methyl"),
            c(118.26, 0.06, "CD₃CN nitrile"),
        ],
        "water" => vec![h(4.79, 0.12, "H₂O residual")],
        "methanol" => vec![h(3.31, 0.12, "CH₃OH residual"), c(49.00, 0.12, "CD₃OD")],
        "benzene" => vec![h(7.16, 0.12, "C₆H₆ residual"), c(128.06, 0.12, "C₆D₆")],
        "acetone" => vec![
            h(2.05, 0.12, "acetone residual"),
            c(29.84, 0.10, "acetone-d₆ methyl"),
            c(206.26, 0.06, "acetone-d₆ carbonyl"),
        ],
        "tetrahydrofuran" | "thf" => vec![
            h(1.72, 0.08, "THF residual"),
            h(3.58, 0.08, "THF residual"),
            c(25.37, 0.08, "THF-d₈"),
            c(67.57, 0.08, "THF-d₈"),
        ],
        "dichloromethane" => vec![h(5.32, 0.12, "CH₂Cl₂ residual"), c(53.84, 0.12, "CD₂Cl₂")],
        _ => return None,
    })
}
impl Input {
    pub fn from_compound(c: &CompoundResult, cancel: &AtomicBool) -> Result<Self> {
        Self::from_source(&SpectrumSource::from_compound(c), cancel)
    }
    pub fn from_source(c: &SpectrumSource, cancel: &AtomicBool) -> Result<Self> {
        c.structure.validate()?;
        let mut out = Self {
            name: c.name.clone(),
            ..Self::default()
        };
        let adj = c.structure.adjacency();
        for (&atom, &ppm) in &c.shifts {
            ensure!(
                atom < c.structure.atoms.len() && ppm.is_finite(),
                "Invalid predicted shift"
            );
            if let Some(nucleus) = Nucleus::from_atom(&c.structure.atoms[atom]) {
                // Use precisely the combined, two-decimal prediction shown by the viewer/PyMOL labels.
                out.spins.push(Spin {
                    atom,
                    nucleus,
                    ppm: round_decimal(ppm, 2),
                    area: if nucleus == Nucleus::C {
                        carbon_response(&c.structure, atom, &adj)
                    } else {
                        1.
                    },
                });
            }
        }
        ensure!(
            !out.spins.is_empty(),
            "No supported ¹H, ¹³C, ¹⁹F or ¹⁵N shift predictions are available"
        );
        let included: BTreeSet<_> = out.spins.iter().map(|s| s.atom).collect();
        let missing = c
            .structure
            .atoms
            .iter()
            .enumerate()
            .filter(|(i, a)| Nucleus::from_atom(a).is_some() && !included.contains(i))
            .count();
        if missing > 0 {
            out.notes.push(format!("{missing} supported atom(s) lack a shift prediction and are omitted, including their couplings."));
        }
        if c.structure.atoms.iter().any(|a| {
            matches!(a.element.as_str(), "H" | "C" | "N" | "F") && Nucleus::from_atom(a).is_none()
        }) {
            out.notes.push("Explicit unsupported isotopes are omitted; 2H and quadrupolar 14N are not simulated.".into());
        }
        let confs: Vec<_> = c.conformers.iter().filter(|x| x.population > 0.).collect();
        let sum: f64 = confs.iter().map(|x| x.population).sum();
        ensure!(
            c.conformers
                .iter()
                .all(|x| x.population.is_finite() && x.population >= 0.),
            "Invalid conformer populations"
        );
        ensure!(sum.is_finite(), "Invalid population total");
        if c.logs.is_empty() {
            out.calculated = c.couplings.clone();
            if !out.calculated.is_empty() {
                out.notes.push("Reopened J values have already undergone chemical-equivalence averaging; magnetic inequivalence lost in that export cannot be reconstructed. Reanalyze the logs for atom-resolved J values.".into());
            }
        } else if sum > 0. {
            let raw: Vec<_> = confs
                .iter()
                .map(|x| {
                    c.logs
                        .iter()
                        .find(|l| l.compound == c.name && l.number == x.number && l.valid)
                })
                .collect();
            let keys: BTreeSet<_> = raw
                .iter()
                .flatten()
                .flat_map(|l| l.couplings.keys().copied())
                .collect();
            for p in keys {
                check(cancel)?;
                if raw
                    .iter()
                    .all(|l| l.is_some_and(|l| l.couplings.contains_key(&p)))
                {
                    let j = confs
                        .iter()
                        .zip(&raw)
                        .map(|(x, l)| x.population / sum * l.unwrap().couplings[&p])
                        .sum();
                    out.calculated.insert(p, j);
                }
            }
            out.notes.push("Calculated J values are averaged over positively populated conformers before simulation, retaining the raw atom assignments. A pair missing from any contributing conformer is not accepted as a complete calculated average.".into());
        }
        out.calculated
            .retain(|&(a, b), _| a != b && included.contains(&a) && included.contains(&b));
        ensure!(
            out.calculated.values().all(|j| j.is_finite()),
            "Nonfinite calculated coupling"
        );
        let carbon = |i: usize| {
            c.structure.atoms[i].element == "C"
                && adj[i].len() == 4
                && adj[i]
                    .iter()
                    .all(|&j| (c.structure.bonds[&pair(i, j)] - 1.).abs() < 1e-6)
        };
        if sum > 0. {
            for (idx, a) in out
                .spins
                .iter()
                .enumerate()
                .filter(|(_, s)| s.nucleus == Nucleus::H)
            {
                check(cancel)?;
                for b in out
                    .spins
                    .iter()
                    .skip(idx + 1)
                    .filter(|s| s.nucleus == Nucleus::H)
                {
                    let key = pair(a.atom, b.atom);
                    if out.calculated.contains_key(&key)
                        || adj[a.atom].len() != 1
                        || adj[b.atom].len() != 1
                    {
                        continue;
                    }
                    let (x, y) = (adj[a.atom][0], adj[b.atom][0]);
                    if x == y
                        || !carbon(x)
                        || !carbon(y)
                        || !c.structure.bonds.contains_key(&pair(x, y))
                    {
                        continue;
                    }
                    let mut j = 0.;
                    let mut valid = true;
                    for conf in &confs {
                        let p = &conf.molecule.atoms;
                        let (a, b, x, y) = (p[a.atom].xyz, p[b.atom].xyz, p[x].xyz, p[y].xyz);
                        if norm(cross(sub(a, x), sub(y, x))) < 1e-8
                            || norm(cross(sub(b, y), sub(x, y))) < 1e-8
                        {
                            valid = false;
                            break;
                        }
                        j += conf.population / sum * karplus(dihedral(a, x, y, b));
                    }
                    if valid {
                        out.estimated.insert(key, j);
                    }
                }
            }
        } else {
            out.notes.push("No positive conformer populations are available; dihedral estimates cannot be calculated.".into());
        }
        out.estimated_aromatic = aromatic_hydrogen_couplings(&c.structure, &adj);
        out.estimated_aromatic
            .retain(|pair, _| !out.calculated.contains_key(pair));
        for (i, a) in c.structure.atoms.iter().enumerate() {
            if a.element != "C" || adj[i].len() != 4 {
                continue;
            }
            for el in ["H", "F"] {
                let group: Vec<_> = adj[i]
                    .iter()
                    .copied()
                    .filter(|&j| {
                        c.structure.atoms[j].element == el
                            && adj[j].len() == 1
                            && included.contains(&j)
                            && (c.structure.bonds[&pair(i, j)] - 1.).abs() < 1e-6
                    })
                    .collect();
                if group.len() == 3 {
                    out.rotor_groups.push(group);
                }
            }
        }
        let solvent_sets: Vec<_> = c
            .logs
            .iter()
            .filter(|log| log.compound == c.name && log.valid)
            .map(|log| &log.solvents)
            .collect();
        if !solvent_sets.is_empty() && solvent_sets.iter().all(|solvents| solvents.len() == 1) {
            let keyword = solvent_sets[0].iter().next().unwrap();
            if solvent_sets
                .iter()
                .all(|solvents| solvents.iter().next() == Some(keyword))
            {
                if let Some(references) = solvent_references(keyword) {
                    out.references = references;
                    out.notes.push(format!("Conventional residual-solvent markers are available for SCRF solvent={keyword}; these reference positions can vary with conditions."));
                } else {
                    out.notes.push(format!("SCRF solvent={keyword} is not in the residual-solvent marker table; no reference peak is added."));
                }
            } else {
                out.notes.push("Loaded conformers do not agree on one SCRF solvent keyword; no residual-solvent marker is added.".into());
            }
        } else if solvent_sets.iter().any(|solvents| !solvents.is_empty()) {
            out.notes.push("A conformer has missing or multiple SCRF solvent keywords; no residual-solvent marker is added.".into());
        }
        out.notes.push("Unknown couplings are omitted, not measured zeros. Optional estimates cover vicinal H–C(sp³)–C(sp³)–H paths and carbon-bound protons on six-membered aromatic C/N rings; no geminal, exchangeable-proton or missing heteronuclear J values are guessed.".into());
        if out.spins.iter().any(|s| s.nucleus == Nucleus::N) {
            out.notes.push("¹⁵N simulation assumes isotope-appropriate input J values. Gaussian J values are isotope-dependent; this importer does not infer or rescale the isotope used for J. Verify the job isotope settings before interpreting nitrogen splittings.".into());
        }
        Ok(out)
    }
}
#[derive(Clone, Debug, PartialEq)]
pub struct Settings {
    pub proton_mhz: f64,
    pub linewidth_hz: f64,
    pub cutoff_hz: f64,
    pub estimate: bool,
    pub rotor_average: bool,
    pub enriched: bool,
    pub first_order: bool,
    pub residual_solvent: bool,
    pub decouple: [[bool; 4]; 4],
}
impl Default for Settings {
    fn default() -> Self {
        let mut decouple = [[false; 4]; 4];
        decouple[1][0] = true;
        decouple[3][0] = true;
        Self {
            proton_mhz: 600.,
            linewidth_hz: 1.,
            cutoff_hz: 0.1,
            estimate: true,
            rotor_average: true,
            enriched: false,
            first_order: false,
            residual_solvent: true,
            decouple,
        }
    }
}
impl Settings {
    pub fn validate(&self) -> Result<()> {
        ensure!(
            self.proton_mhz.is_finite() && (10.0..=2000.0).contains(&self.proton_mhz),
            "Proton frequency must be 10–2000 MHz"
        );
        ensure!(
            self.linewidth_hz.is_finite() && (0.01..=1000.0).contains(&self.linewidth_hz),
            "Linewidth must be 0.01–1000 Hz"
        );
        ensure!(
            self.cutoff_hz.is_finite() && (0.0..=10000.0).contains(&self.cutoff_hz),
            "J cutoff must be 0–10000 Hz"
        );
        Ok(())
    }
    pub fn description(&self) -> String {
        format!(
            "¹H field {:.3} MHz; Lorentzian FWHM {:.3} Hz; |J| cutoff {:.3} Hz; missing H–H estimates {}; rotor averaging {}; fully enriched {}; force first order {}; residual-solvent markers {}; decouple rows H,C,F,N / columns H,C,F,N: {:?}",
            self.proton_mhz,
            self.linewidth_hz,
            self.cutoff_hz,
            self.estimate,
            self.rotor_average,
            self.enriched,
            self.first_order,
            self.residual_solvent,
            self.decouple
        )
    }
}
#[derive(Clone, Debug)]
pub struct Line {
    pub hz: f64,
    pub area: f64,
}
#[derive(Clone, Debug)]
pub struct Prediction {
    pub nucleus: Nucleus,
    pub atoms: Vec<usize>,
    pub lines: Vec<Line>,
    pub notes: Vec<String>,
    pub references: Vec<ReferencePeak>,
    pub preview_range: [f64; 2],
    pub preview_values: Vec<f64>,
}
#[derive(Clone, Debug)]
pub struct Output {
    pub predictions: Vec<Prediction>,
    pub couplings: PairValues,
    pub estimated: BTreeSet<Pair>,
    pub estimated_aromatic: BTreeSet<Pair>,
    pub notes: Vec<String>,
}

pub fn simulate(input: &Input, s: &Settings, cancel: &AtomicBool) -> Result<Output> {
    s.validate()?;
    check(cancel)?;
    ensure!(
        !input.spins.is_empty() && input.spins.len() <= 2000,
        "Expected 1–2000 predicted spins"
    );
    let mut identities = BTreeSet::new();
    ensure!(
        input.spins.iter().all(|x| identities.insert(x.atom)
            && x.ppm.is_finite()
            && x.ppm.abs() < 1e6
            && x.area.is_finite()
            && x.area > 0.),
        "Invalid or duplicate spin predictions"
    );
    let mut couplings = input.calculated.clone();
    let mut estimated = BTreeSet::new();
    if s.estimate {
        for (&p, &j) in &input.estimated {
            if let std::collections::btree_map::Entry::Vacant(e) = couplings.entry(p) {
                e.insert(j);
                estimated.insert(p);
            }
        }
    }
    let mut estimated_aromatic = BTreeSet::new();
    if s.estimate {
        for (&p, &j) in &input.estimated_aromatic {
            if let std::collections::btree_map::Entry::Vacant(entry) = couplings.entry(p) {
                entry.insert(j);
                estimated.insert(p);
                estimated_aromatic.insert(p);
            }
        }
    }
    ensure!(
        couplings.iter().all(|(&(a, b), j)| a < b
            && identities.contains(&a)
            && identities.contains(&b)
            && j.is_finite()
            && j.abs() < 1e8),
        "Invalid coupling inventory"
    );
    let mut notes = input.notes.clone();
    if s.rotor_average {
        let mut groups: Vec<Vec<usize>> = vec![];
        let mut assigned: BTreeSet<usize> = BTreeSet::new();
        for group in &input.rotor_groups {
            if group.len() != 3
                || group
                    .iter()
                    .any(|i| !identities.contains(i) || assigned.contains(i))
            {
                continue;
            }
            let valid = identities.iter().filter(|i| !group.contains(i)).all(|&i| {
                let n = group
                    .iter()
                    .filter(|&&j| couplings.contains_key(&pair(i, j)))
                    .count();
                let e = group
                    .iter()
                    .filter(|&&j| estimated.contains(&pair(i, j)))
                    .count();
                n == 0 || (n == 3 && (e == 0 || e == 3))
            });
            if valid {
                groups.push(group.clone());
                assigned.extend(group.iter().copied());
            } else {
                notes.push("A methyl/CF₃ group has an incomplete or mixed calculated/estimated J inventory; its couplings were not rotor-averaged.".into());
            }
        }
        let mut mapping: BTreeMap<usize, usize> = identities.iter().map(|&i| (i, i)).collect();
        for group in &groups {
            for &i in group {
                mapping.insert(i, *group.iter().min().unwrap());
            }
        }
        let mut sums: BTreeMap<Pair, (f64, usize)> = BTreeMap::new();
        for (&(a, b), &v) in &couplings {
            let entry = sums.entry(pair(mapping[&a], mapping[&b])).or_default();
            entry.0 += v;
            entry.1 += 1;
        }
        for (&(a, b), v) in &mut couplings {
            let (sum, n) = sums[&pair(mapping[&a], mapping[&b])];
            *v = sum / n as f64;
        }
        notes.push("Fast methyl/CF₃ rotation is assumed for eligible complete coupling inventories. Chemical-equivalence classes are not treated as general magnetic-equivalence classes.".into());
    }
    if !s.enriched {
        notes.push("Natural-abundance mode omits rare-isotope satellites and multiple rare-isotope isotopologues. ¹³C/¹⁵N observation is conditional on that site carrying the observed isotope; other C/N sites are absent from its spin system.".into());
    } else {
        notes.push("Fully enriched mode treats all included C/N sites as spin-½ ¹³C/¹⁵N; intensities are not weighted by natural isotopic abundance.".into());
    }
    let mut predictions = vec![];
    for observed in Nucleus::ALL {
        let targets: Vec<_> = input
            .spins
            .iter()
            .enumerate()
            .filter(|(_, x)| x.nucleus == observed)
            .map(|(i, _)| i)
            .collect();
        if targets.is_empty() {
            continue;
        }
        let mut result = Prediction {
            nucleus: observed,
            atoms: targets.iter().map(|&i| input.spins[i].atom).collect(),
            lines: vec![],
            notes: vec![],
            references: if s.residual_solvent {
                input
                    .references
                    .iter()
                    .filter(|peak| peak.nucleus == observed)
                    .cloned()
                    .collect()
            } else {
                vec![]
            },
            preview_range: [0., 1.],
            preview_values: vec![],
        };
        let batches: Vec<Vec<usize>> = if observed.rare() && !s.enriched {
            targets.iter().map(|&i| vec![i]).collect()
        } else {
            vec![targets.clone()]
        };
        let mut exact = 0;
        let mut approximate = 0;
        for batch in batches {
            check(cancel)?;
            let active: Vec<_> = input
                .spins
                .iter()
                .enumerate()
                .filter(|(i, x)| {
                    (s.enriched || !x.nucleus.rare() || batch.contains(i))
                        && (x.nucleus == observed
                            || !s.decouple[observed.index()][x.nucleus.index()])
                })
                .map(|(i, _)| i)
                .collect();
            let mut edges = vec![vec![]; input.spins.len()];
            for (ii, &i) in active.iter().enumerate() {
                for &j in &active[ii + 1..] {
                    if couplings
                        .get(&pair(input.spins[i].atom, input.spins[j].atom))
                        .is_some_and(|j| j.abs() >= s.cutoff_hz && *j != 0.)
                    {
                        edges[i].push(j);
                        edges[j].push(i);
                    }
                }
            }
            let mut visited = BTreeSet::new();
            for &start in &active {
                if !visited.insert(start) {
                    continue;
                }
                let mut component = vec![start];
                let mut pos = 0;
                while pos < component.len() {
                    let i = component[pos];
                    pos += 1;
                    for &j in &edges[i] {
                        if visited.insert(j) {
                            component.push(j);
                        }
                    }
                }
                if !component.iter().any(|i| batch.contains(i)) {
                    continue;
                }
                component.sort_unstable();
                let spins: Vec<_> = component.iter().map(|&i| input.spins[i].clone()).collect();
                let n = spins.len();
                let mut js = vec![vec![0.; n]; n];
                for i in 0..n {
                    for j in i + 1..n {
                        if let Some(&v) = couplings.get(&pair(spins[i].atom, spins[j].atom))
                            && v.abs() >= s.cutoff_hz
                        {
                            js[i][j] = v;
                            js[j][i] = v;
                        }
                    }
                }
                let mut lines = if n <= 10 && !s.first_order {
                    exact += 1;
                    quantum(&spins, &js, observed, s.proton_mhz, cancel)?
                } else {
                    approximate += 1;
                    let strong = (0..n).any(|i| {
                        (i + 1..n).any(|j| {
                            spins[i].nucleus == spins[j].nucleus
                                && js[i][j] != 0.
                                && (spins[i].ppm - spins[j].ppm).abs()
                                    * s.proton_mhz
                                    * spins[i].nucleus.ratio()
                                    < 10. * js[i][j].abs()
                                && !magnetically_equivalent(i, j, &spins, &js)
                        })
                    });
                    if strong {
                        result.notes.push("First-order approximation includes a system with Δν/|J| < 10; roofing and second-order intensities may be inaccurate. Increase the field, use decoupling, or reduce the connected system for exact treatment.".into());
                    }
                    first_order(&spins, &js, observed, s.proton_mhz, cancel)?
                };
                result.lines.append(&mut lines);
            }
        }
        result
            .lines
            .extend(result.references.iter().map(|reference| Line {
                hz: reference.ppm * s.proton_mhz * observed.ratio(),
                area: reference.area,
            }));
        result.lines = merge_lines(result.lines, 1e-7);
        result.notes.push(format!("{exact} exact component(s); {approximate} first-order component(s). Exact treatment is limited to 10 coupled spins per connected component."));
        result.notes.sort();
        result.notes.dedup();
        result.preview_range = result.range(s);
        result.preview_values = result.curve(s, result.preview_range, 4096);
        predictions.push(result);
    }
    Ok(Output {
        predictions,
        couplings,
        estimated,
        estimated_aromatic,
        notes,
    })
}
fn magnetically_equivalent(i: usize, j: usize, spins: &[Spin], js: &[Vec<f64>]) -> bool {
    spins[i].nucleus == spins[j].nucleus
        && (spins[i].ppm - spins[j].ppm).abs() < 1e-9
        && (0..spins.len())
            .filter(|&k| k != i && k != j)
            .all(|k| (js[i][k] - js[j][k]).abs() < 1e-8)
}
fn first_order(
    spins: &[Spin],
    js: &[Vec<f64>],
    observed: Nucleus,
    field: f64,
    cancel: &AtomicBool,
) -> Result<Vec<Line>> {
    let mut out = vec![];
    for (i, s) in spins
        .iter()
        .enumerate()
        .filter(|(_, s)| s.nucleus == observed)
    {
        let mut lines = vec![Line {
            hz: s.ppm * field * s.nucleus.ratio(),
            area: s.area,
        }];
        for j in 0..spins.len() {
            check(cancel)?;
            if js[i][j] == 0. || magnetically_equivalent(i, j, spins, js) {
                continue;
            }
            ensure!(
                lines.len() <= 131072,
                "Too many first-order transitions; increase the J cutoff or decouple partners"
            );
            lines = merge_lines(
                lines
                    .into_iter()
                    .flat_map(|l| {
                        [
                            Line {
                                hz: l.hz - js[i][j] * 0.5,
                                area: l.area * 0.5,
                            },
                            Line {
                                hz: l.hz + js[i][j] * 0.5,
                                area: l.area * 0.5,
                            },
                        ]
                    })
                    .collect(),
                1e-6,
            );
        }
        out.extend(lines);
    }
    Ok(out)
}
pub fn merge_lines(mut lines: Vec<Line>, tolerance: f64) -> Vec<Line> {
    lines.sort_by(|a, b| a.hz.total_cmp(&b.hz));
    let mut out: Vec<Line> = vec![];
    for l in lines {
        if let Some(prev) = out.last_mut()
            && (l.hz - prev.hz).abs() <= tolerance
        {
            let area = prev.area + l.area;
            prev.hz = (prev.hz * prev.area + l.hz * l.area) / area;
            prev.area = area;
            continue;
        }
        out.push(l);
    }
    out
}
struct Sector {
    states: Vec<usize>,
    index: Vec<usize>,
    energies: Vec<f64>,
    vectors: Vec<f64>,
}
fn quantum(
    spins: &[Spin],
    js: &[Vec<f64>],
    observed: Nucleus,
    field: f64,
    cancel: &AtomicBool,
) -> Result<Vec<Line>> {
    let n = spins.len();
    let size = 1usize << n;
    let mut origins = [0.; 4];
    let mut counts = [0usize; 4];
    for s in spins {
        origins[s.nucleus.index()] += s.ppm * field * s.nucleus.ratio();
        counts[s.nucleus.index()] += 1;
    }
    for i in 0..4 {
        if counts[i] > 0 {
            origins[i] /= counts[i] as f64;
        }
    }
    let w: Vec<_> = spins
        .iter()
        .map(|s| s.ppm * field * s.nucleus.ratio() - origins[s.nucleus.index()])
        .collect();
    let mut sectors = vec![];
    for k in 0..=n {
        check(cancel)?;
        let states: Vec<_> = (0..size).filter(|x| x.count_ones() == k as u32).collect();
        let d = states.len();
        let mut index = vec![usize::MAX; size];
        for (i, &state) in states.iter().enumerate() {
            index[state] = i;
        }
        let mut h = vec![0.; d * d];
        for (row, &state) in states.iter().enumerate() {
            let m: Vec<_> = (0..n)
                .map(|i| if state & (1 << i) == 0 { -0.5 } else { 0.5 })
                .collect();
            let mut e = (0..n).map(|i| w[i] * m[i]).sum::<f64>();
            for i in 0..n {
                for j in i + 1..n {
                    e += js[i][j] * m[i] * m[j];
                    if spins[i].nucleus == spins[j].nucleus && m[i] != m[j] {
                        let col = index[state ^ (1 << i) ^ (1 << j)];
                        h[row * d + col] += js[i][j] * 0.5;
                    }
                }
            }
            h[row * d + row] = e;
        }
        let (energies, vectors) = jacobi(h, d, cancel)?;
        sectors.push(Sector {
            states,
            index,
            energies,
            vectors,
        });
    }
    let mut lines = vec![];
    let normalization = (1usize << (n - 1)) as f64;
    for k in 1..=n {
        let (upper, lower) = (&sectors[k], &sectors[k - 1]);
        let (du, dl) = (upper.states.len(), lower.states.len());
        for u in 0..du {
            check(cancel)?;
            let mut amplitude = vec![0.; dl];
            for (row, &state) in upper.states.iter().enumerate() {
                for (i, s) in spins.iter().enumerate() {
                    if s.nucleus == observed && state & (1 << i) != 0 {
                        amplitude[lower.index[state ^ (1 << i)]] +=
                            s.area.sqrt() * upper.vectors[row * du + u];
                    }
                }
            }
            for l in 0..dl {
                let a = amplitude
                    .iter()
                    .enumerate()
                    .map(|(row, a)| a * lower.vectors[row * dl + l])
                    .sum::<f64>();
                let area = a * a / normalization;
                if area > 1e-10 {
                    lines.push(Line {
                        hz: upper.energies[u] - lower.energies[l] + origins[observed.index()],
                        area,
                    });
                }
            }
        }
    }
    Ok(lines)
}
/// Real symmetric cyclic Jacobi diagonalization. Eigenvectors are matrix columns.
fn jacobi(mut a: Vec<f64>, n: usize, cancel: &AtomicBool) -> Result<(Vec<f64>, Vec<f64>)> {
    let mut v = vec![0.; n * n];
    for i in 0..n {
        v[i * n + i] = 1.;
    }
    for _ in 0..80 {
        check(cancel)?;
        let mut max = 0_f64;
        for p in 0..n {
            for q in p + 1..n {
                let apq = a[p * n + q];
                max = max.max(apq.abs());
                if apq.abs() < 1e-11 {
                    continue;
                }
                let tau = (a[q * n + q] - a[p * n + p]) / (2. * apq);
                let t = if tau >= 0. { 1. } else { -1. } / (tau.abs() + (1. + tau * tau).sqrt());
                let c = 1. / (1. + t * t).sqrt();
                let s = t * c;
                a[p * n + p] -= t * apq;
                a[q * n + q] += t * apq;
                a[p * n + q] = 0.;
                a[q * n + p] = 0.;
                for k in 0..n {
                    if k != p && k != q {
                        let (x, y) = (a[k * n + p], a[k * n + q]);
                        let (x, y) = (c * x - s * y, s * x + c * y);
                        a[k * n + p] = x;
                        a[p * n + k] = x;
                        a[k * n + q] = y;
                        a[q * n + k] = y;
                    }
                    let (x, y) = (v[k * n + p], v[k * n + q]);
                    v[k * n + p] = c * x - s * y;
                    v[k * n + q] = s * x + c * y;
                }
            }
        }
        if max < 1e-10 {
            return Ok(((0..n).map(|i| a[i * n + i]).collect(), v));
        }
    }
    bail!("Spin Hamiltonian did not converge; previous spectra are preserved")
}
impl Prediction {
    pub fn range(&self, s: &Settings) -> [f64; 2] {
        let mhz = s.proton_mhz * self.nucleus.ratio();
        let low = self.lines.first().map(|x| x.hz / mhz).unwrap_or(0.);
        let high = self.lines.last().map(|x| x.hz / mhz).unwrap_or(1.);
        let pad = ((high - low) * 0.08)
            .max(12. * s.linewidth_hz / mhz)
            .max(0.02);
        [low - pad, high + pad]
    }
    /// Bin-integrated Lorentzians retain narrow-line area on a finite-resolution plot.
    pub fn curve(&self, s: &Settings, range: [f64; 2], samples: usize) -> Vec<f64> {
        let mhz = s.proton_mhz * self.nucleus.ratio();
        let lo = range[0] * mhz;
        let dx = (range[1] - range[0]) * mhz / samples.max(1) as f64;
        if !dx.is_finite() || dx <= 0. {
            return vec![0.; samples];
        }
        let gamma = s.linewidth_hz * 0.5;
        let mut y = vec![0.; samples];
        for l in &self.lines {
            let start = (((l.hz - 500. * gamma - lo) / dx).floor() as isize)
                .clamp(0, samples as isize) as usize;
            let end = (((l.hz + 500. * gamma - lo) / dx).ceil() as isize).clamp(0, samples as isize)
                as usize;
            for (i, v) in y.iter_mut().enumerate().take(end).skip(start) {
                let x = lo + i as f64 * dx - l.hz;
                *v += l.area * ((x + dx) / gamma).atan() / std::f64::consts::PI / dx
                    - l.area * (x / gamma).atan() / std::f64::consts::PI / dx;
            }
        }
        y
    }
}
fn escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}

/// Convert Unicode scientific scripts to SVG text spans. This keeps isotope
/// and formula typography intact even in viewers whose fallback font renders
/// Unicode superscript/subscript characters as boxes.
pub fn scripted_svg_text(text: &str) -> String {
    fn script(character: char) -> Option<(&'static str, &'static str)> {
        Some(match character {
            '⁰' => ("super", "0"),
            '¹' => ("super", "1"),
            '²' => ("super", "2"),
            '³' => ("super", "3"),
            '⁴' => ("super", "4"),
            '⁵' => ("super", "5"),
            '⁶' => ("super", "6"),
            '⁷' => ("super", "7"),
            '⁸' => ("super", "8"),
            '⁹' => ("super", "9"),
            '⁺' => ("super", "+"),
            '⁻' => ("super", "−"),
            '₀' => ("sub", "0"),
            '₁' => ("sub", "1"),
            '₂' => ("sub", "2"),
            '₃' => ("sub", "3"),
            '₄' => ("sub", "4"),
            '₅' => ("sub", "5"),
            '₆' => ("sub", "6"),
            '₇' => ("sub", "7"),
            '₈' => ("sub", "8"),
            '₉' => ("sub", "9"),
            '₊' => ("sub", "+"),
            '₋' => ("sub", "−"),
            _ => return None,
        })
    }

    let mut output = String::new();
    let mut active = None;
    for character in text.chars() {
        if let Some((position, replacement)) = script(character) {
            if active != Some(position) {
                if active.is_some() {
                    output.push_str("</tspan>");
                }
                output.push_str(&format!(
                    "<tspan baseline-shift=\"{position}\" font-size=\"70%\">"
                ));
                active = Some(position);
            }
            output.push_str(replacement);
        } else {
            if active.take().is_some() {
                output.push_str("</tspan>");
            }
            output.push_str(&escape(&character.to_string()));
        }
    }
    if active.is_some() {
        output.push_str("</tspan>");
    }
    output
}
pub fn csv(input: &Input, out: &Output, s: &Settings) -> String {
    let mut t = format!(
        "# TENSOR predicted spectra: {}\n# {}\n",
        input.name.replace(['\r', '\n'], " "),
        s.description()
    );
    for n in &out.notes {
        t += &format!("# {}\n", n.replace(['\r', '\n'], " "));
    }
    for p in &out.predictions {
        for n in &p.notes {
            t += &format!("# {}: {n}\n", p.nucleus.ascii());
        }
        for reference in &p.references {
            t += &format!(
                "# {} conventional reference marker: {} at {:.4} ppm\n",
                p.nucleus.ascii(),
                reference.label.replace(['\r', '\n'], " "),
                reference.ppm
            );
        }
    }
    t += "nucleus,frequency_hz,shift_ppm,relative_area\n";
    for p in &out.predictions {
        for l in &p.lines {
            t += &format!(
                "{},{:.10},{:.10},{:.10}\n",
                p.nucleus.ascii(),
                l.hz,
                l.hz / (s.proton_mhz * p.nucleus.ratio()),
                l.area
            );
        }
    }
    t
}
pub fn svg(input: &Input, out: &Output, s: &Settings) -> String {
    let height = 80 + out.predictions.len() * 240;
    let desc = format!(
        "{}; {}; {}",
        s.description(),
        out.notes.join(" "),
        out.predictions
            .iter()
            .flat_map(|p| p.notes.iter())
            .cloned()
            .collect::<Vec<_>>()
            .join(" ")
    );
    let heading = scripted_svg_text(&format!("{} — predicted NMR spectra", input.name));
    let details = scripted_svg_text(&format!(
        "¹H field {:.1} MHz · FWHM {:.2} Hz · model details in SVG description / CSV",
        s.proton_mhz, s.linewidth_hz
    ));
    let mut t = format!(
        "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"1200\" height=\"{height}\" viewBox=\"0 0 1200 {height}\"><desc>{}</desc><rect width=\"100%\" height=\"100%\" fill=\"white\"/><g font-family=\"DejaVu Sans,Arial,sans-serif\" fill=\"#252933\"><text x=\"60\" y=\"32\" font-size=\"22\">{heading}</text><text x=\"60\" y=\"56\" font-size=\"12\">{details}</text>",
        escape(&desc),
    );
    for (row, p) in out.predictions.iter().enumerate() {
        let top = 80. + row as f64 * 240.;
        let base = top + 180.;
        let range = p.preview_range;
        let y = &p.preview_values;
        let max = y.iter().copied().fold(0_f64, f64::max).max(1e-20);
        t += &format!(
            "<text x=\"60\" y=\"{}\" font-size=\"18\">{} · {} atoms</text><path d=\"M 60 {base} H 1140\" fill=\"none\" stroke=\"#777\"/>",
            top + 16.,
            scripted_svg_text(p.nucleus.label()),
            p.atoms.len()
        );
        let path = y
            .iter()
            .enumerate()
            .map(|(i, &v)| {
                format!(
                    "{} {:.2} {:.2}",
                    if i == 0 { "M" } else { "L" },
                    1140. - (i as f64 + 0.5) / y.len() as f64 * 1080.,
                    base - v / max * 140.
                )
            })
            .collect::<Vec<_>>()
            .join(" ");
        t += &format!("<path d=\"{path}\" fill=\"none\" stroke=\"#a52a40\" stroke-width=\"1.2\"/>");
        for reference in &p.references {
            if (range[0]..=range[1]).contains(&reference.ppm) {
                let x = 1140. - (reference.ppm - range[0]) / (range[1] - range[0]) * 1080.;
                t += &format!(
                    "<path d=\"M {x:.2} {} V {base:.2}\" fill=\"none\" stroke=\"#287c8e\"/><text x=\"{x:.2}\" y=\"{}\" text-anchor=\"middle\" font-size=\"10\" fill=\"#1f6677\">{}</text>",
                    top + 24.,
                    top + 20.,
                    scripted_svg_text(&reference.label)
                );
            }
        }
        for tick in 0..=6 {
            let x = 60. + 1080. * tick as f64 / 6.;
            let ppm = range[1] - (range[1] - range[0]) * tick as f64 / 6.;
            t += &format!(
                "<text x=\"{x}\" y=\"{}\" text-anchor=\"middle\" font-size=\"13\">{ppm:.2}</text>",
                base + 23.
            );
        }
        t += &format!(
            "<text x=\"1140\" y=\"{}\" text-anchor=\"end\" font-size=\"12\">δ / ppm</text>",
            base + 44.
        );
    }
    t += "</g></svg>";
    t
}

#[cfg(test)]
mod tests {
    use super::*;

    fn atom(element: &str) -> Atom {
        Atom {
            element: element.into(),
            xyz: [0.; 3],
            charge: 0,
            isotope: 0,
        }
    }

    #[test]
    fn benzene_ring_fallback_covers_ortho_meta_and_para_pairs() {
        let mut molecule = Molecule::default();
        molecule.atoms.extend((0..6).map(|_| atom("C")));
        molecule.atoms.extend((0..6).map(|_| atom("H")));
        for carbon in 0..6 {
            molecule.bonds.insert(pair(carbon, (carbon + 1) % 6), 4.);
            molecule.bonds.insert(pair(carbon, carbon + 6), 1.);
        }
        let couplings = aromatic_hydrogen_couplings(&molecule, &molecule.adjacency());
        assert_eq!(couplings.len(), 15);
        assert_eq!(couplings.values().filter(|&&j| j == 7.54).count(), 6);
        assert_eq!(couplings.values().filter(|&&j| j == 1.37).count(), 6);
        assert_eq!(couplings.values().filter(|&&j| j == 0.69).count(), 3);
    }

    #[test]
    fn kekule_benzene_encoding_keeps_the_same_aromatic_fallback_inventory() {
        let mut molecule = Molecule::default();
        molecule.atoms.extend((0..6).map(|_| atom("C")));
        molecule.atoms.extend((0..6).map(|_| atom("H")));
        for carbon in 0..6 {
            molecule.bonds.insert(
                pair(carbon, (carbon + 1) % 6),
                if carbon % 2 == 0 { 2. } else { 1. },
            );
            molecule.bonds.insert(pair(carbon, carbon + 6), 1.);
        }
        let couplings = aromatic_hydrogen_couplings(&molecule, &molecule.adjacency());
        assert_eq!(couplings.len(), 15);
        assert_eq!(couplings.values().filter(|&&j| j == 7.54).count(), 6);
        assert_eq!(couplings.values().filter(|&&j| j == 1.37).count(), 6);
        assert_eq!(couplings.values().filter(|&&j| j == 0.69).count(), 3);
    }

    #[test]
    fn fused_six_membered_c_n_faces_remain_available_to_coupling_perception() {
        let mut molecule = Molecule::default();
        molecule
            .atoms
            .extend((0..10).map(|index| if index == 4 { atom("N") } else { atom("C") }));
        for (a, b) in [
            (0, 1),
            (1, 2),
            (2, 3),
            (3, 4),
            (4, 5),
            (5, 0),
            (5, 6),
            (6, 7),
            (7, 8),
            (8, 9),
            (9, 4),
        ] {
            molecule.bonds.insert(pair(a, b), 4.);
        }
        for carbon in [0, 1] {
            let hydrogen = molecule.atoms.len();
            molecule.atoms.push(atom("H"));
            molecule.bonds.insert(pair(carbon, hydrogen), 1.);
        }
        let couplings = aromatic_hydrogen_couplings(&molecule, &molecule.adjacency());
        assert_eq!(couplings.get(&pair(10, 11)), Some(&7.54));
    }

    #[test]
    fn fused_aza_ring_fallback_couples_adjacent_aromatic_protons() {
        let molecule =
            parse_sdf(include_str!("../tests/fixtures/sdf/fused_aza_redacted.sdf")).unwrap();

        let couplings = aromatic_hydrogen_couplings(&molecule, &molecule.adjacency());
        assert_eq!(couplings.get(&pair(9, 10)), Some(&7.54));
    }

    #[test]
    fn carbon_response_increases_with_attached_hydrogens() {
        let mut molecule = Molecule::default();
        molecule.atoms.extend((0..4).map(|_| atom("C")));
        for carbon in 1..4 {
            for _ in 0..carbon {
                let hydrogen = molecule.atoms.len();
                molecule.atoms.push(atom("H"));
                molecule.bonds.insert(pair(carbon, hydrogen), 1.);
            }
        }
        let adjacency = molecule.adjacency();
        assert_eq!(carbon_response(&molecule, 0, &adjacency), 0.45);
        assert_eq!(carbon_response(&molecule, 1, &adjacency), 1.00);
        assert_eq!(carbon_response(&molecule, 2, &adjacency), 1.15);
        assert_eq!(carbon_response(&molecule, 3, &adjacency), 1.30);
    }

    #[test]
    fn solvent_reference_table_is_nucleus_specific_and_conservative() {
        let chloroform = solvent_references("chloroform").unwrap();
        assert!(
            chloroform
                .iter()
                .any(|p| p.nucleus == Nucleus::H && p.ppm == 7.26)
        );
        assert!(
            chloroform
                .iter()
                .any(|p| p.nucleus == Nucleus::C && p.ppm == 77.16)
        );
        assert_eq!(solvent_references("water").unwrap().len(), 1);
        assert!(solvent_references("unsupported-solvent").is_none());
    }

    #[test]
    fn svg_scripts_isotopes_and_formula_digits_semantically() {
        let text = scripted_svg_text("¹³C and CDCl₃, charge ⁻1");
        assert!(text.contains("<tspan baseline-shift=\"super\" font-size=\"70%\">13</tspan>C"));
        assert!(text.contains("CDCl<tspan baseline-shift=\"sub\" font-size=\"70%\">3</tspan>"));
        assert!(
            text.contains("charge <tspan baseline-shift=\"super\" font-size=\"70%\">−</tspan>1")
        );
    }
}
