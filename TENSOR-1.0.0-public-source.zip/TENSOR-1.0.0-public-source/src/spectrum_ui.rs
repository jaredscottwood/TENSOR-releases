use crate::{analysis::CompoundResult, spectrum::*};
use eframe::egui::{self, Color32, Pos2, Rect, RichText, Sense, Stroke, Vec2};
use std::{
    collections::BTreeMap,
    path::PathBuf,
    sync::{
        Arc,
        atomic::{AtomicBool, Ordering},
        mpsc::{self, Receiver, TryRecvError},
    },
};

pub(crate) fn spectrum_viewport_builder(
    title: impl Into<String>,
    icon: Arc<egui::IconData>,
) -> egui::ViewportBuilder {
    egui::ViewportBuilder::default()
        .with_title(title)
        .with_icon(icon)
        .with_inner_size([1180., 860.])
        .with_min_inner_size([850., 580.])
        .with_maximized(true)
}

struct Pending {
    result: Receiver<Result<(Arc<Input>, Output), String>>,
    cancel: Arc<AtomicBool>,
    settings: Settings,
}
struct PlotCache {
    range: [f64; 2],
    samples: usize,
    pixels: usize,
    envelope: Vec<(f32, f64)>,
    maximum: f64,
}
#[derive(Default)]
pub struct SpectrumWindow {
    pub open: bool,
    pub settings: Settings,
    applied: Settings,
    input: Option<Arc<Input>>,
    output: Option<Output>,
    worker: Option<Pending>,
    export: Option<Receiver<Result<Option<PathBuf>, String>>>,
    pub(crate) selected: Option<Nucleus>,
    ranges: BTreeMap<Nucleus, [f64; 2]>,
    intensities: BTreeMap<Nucleus, f64>,
    selection_starts: BTreeMap<Nucleus, Option<f32>>,
    cache: BTreeMap<Nucleus, PlotCache>,
    message: String,
}
impl Drop for SpectrumWindow {
    fn drop(&mut self) {
        if let Some(w) = &self.worker {
            w.cancel.store(true, Ordering::Relaxed);
        }
    }
}
impl SpectrumWindow {
    fn release_data(&mut self) {
        self.input = None;
        self.output = None;
        self.cache.clear();
        self.ranges.clear();
        self.intensities.clear();
        self.selection_starts.clear();
        self.selected = None;
    }
    pub fn open_compound(&mut self, c: &CompoundResult, ctx: &egui::Context) {
        self.open = true;
        if self.input.as_ref().is_some_and(|i| i.name == c.name) {
            return;
        }
        let source = SpectrumSource::from_compound(c);
        self.cancel();
        self.input = None;
        self.output = None;
        self.cache.clear();
        self.ranges.clear();
        self.intensities.clear();
        self.selection_starts.clear();
        self.selected = None;
        self.spawn(ctx, move |cancel| {
            Input::from_source(&source, cancel).map(Arc::new)
        });
    }
    fn spawn(
        &mut self,
        ctx: &egui::Context,
        make: impl FnOnce(&AtomicBool) -> anyhow::Result<Arc<Input>> + Send + 'static,
    ) {
        self.cancel();
        let settings = self.settings.clone();
        let thread_settings = settings.clone();
        let cancel = Arc::new(AtomicBool::new(false));
        let task_cancel = cancel.clone();
        let (tx, rx) = mpsc::channel();
        let ctx = ctx.clone();
        std::thread::spawn(move || {
            let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                let input = make(&task_cancel)?;
                let out = simulate(&input, &thread_settings, &task_cancel)?;
                Ok((input, out))
            }));
            let result: Result<_, String> = match result {
                Ok(r) => r.map_err(|e: anyhow::Error| format!("{e:#}")),
                Err(_) => Err("Spectrum calculation stopped unexpectedly".into()),
            };
            let _ = tx.send(result);
            ctx.request_repaint();
        });
        self.worker = Some(Pending {
            result: rx,
            cancel,
            settings,
        });
        self.message = "Calculating spin systems…".into();
    }
    fn cancel(&mut self) {
        if let Some(w) = self.worker.take() {
            w.cancel.store(true, Ordering::Relaxed);
        }
    }
    pub(crate) fn load_prepared(&mut self, input: Input, out: Output, s: Settings) {
        self.cancel();
        self.open = true;
        self.settings = s.clone();
        self.applied = s;
        self.input = Some(Arc::new(input));
        self.output = Some(out);
        self.cache.clear();
        self.ranges.clear();
        self.intensities.clear();
        self.selection_starts.clear();
        self.message = "Predicted spectra ready".into();
    }
    fn poll(&mut self, ctx: &egui::Context) {
        if let Some(w) = &self.worker {
            let result = match w.result.try_recv() {
                Ok(r) => Some(r),
                Err(TryRecvError::Empty) => None,
                Err(TryRecvError::Disconnected) => Some(Err("Spectrum worker disconnected".into())),
            };
            if let Some(result) = result {
                let settings = self.worker.take().unwrap().settings;
                match result {
                    Ok((input, out)) => {
                        self.input = Some(input);
                        self.output = Some(out);
                        self.applied = settings;
                        self.cache.clear();
                        self.ranges.clear();
                        self.intensities.clear();
                        self.selection_starts.clear();
                        self.message = "Predicted spectra ready".into();
                    }
                    Err(e) => self.message = e,
                }
            } else {
                ctx.request_repaint_after(std::time::Duration::from_millis(50));
            }
        }
        if let Some(rx) = &self.export {
            let result = match rx.try_recv() {
                Ok(r) => Some(r),
                Err(TryRecvError::Empty) => None,
                Err(TryRecvError::Disconnected) => {
                    Some(Err("Spectrum export stopped without a result".into()))
                }
            };
            if let Some(result) = result {
                self.export = None;
                self.message = match result {
                    Ok(Some(p)) => format!("Saved {}", p.display()),
                    Ok(None) => "Export cancelled".into(),
                    Err(e) => e,
                };
            } else {
                ctx.request_repaint_after(std::time::Duration::from_millis(80));
            }
        }
    }
    pub fn ui(&mut self, ctx: &egui::Context, icon: Arc<egui::IconData>) {
        self.poll(ctx);
        if !self.open {
            return;
        }
        let mut close = false;
        let title = self
            .input
            .as_ref()
            .map(|i| format!("{} — Predicted NMR spectra", i.name))
            .unwrap_or("Predicted NMR spectra".into());
        ctx.show_viewport_immediate(
            egui::ViewportId::from_hash_of("tensor-spectra"),
            spectrum_viewport_builder(title, icon),
            |ui, _| {
                close = ui.input(|i| i.viewport().close_requested());
                self.content(ui);
            },
        );
        if close {
            self.open = false;
            self.cancel();
            self.release_data();
        }
    }
    pub(crate) fn content(&mut self, ui: &mut egui::Ui) {
        egui::Panel::left("spectrum-settings").exact_size(300.).frame(egui::Frame::new().fill(Color32::from_rgb(38,45,55)).inner_margin(12)).show(ui,|ui|{
            egui::Frame::new().fill(Color32::WHITE).corner_radius(10).inner_margin(14).show(ui,|ui|{
            ui.style_mut().visuals = egui::Visuals::light();
            egui::ScrollArea::vertical().show(ui,|ui|{
                ui.heading("Spectrum settings");ui.add_space(8.);
                egui::Grid::new("spectrum-numbers").num_columns(2).show(ui,|ui|{
                    ui.label("¹H frequency / MHz");ui.add(egui::DragValue::new(&mut self.settings.proton_mhz).range(10.0..=2000.0).speed(10.));ui.end_row();
                    ui.label("FWHM / Hz");ui.add(egui::DragValue::new(&mut self.settings.linewidth_hz).range(0.01..=1000.0).speed(0.1));ui.end_row();
                    ui.label("Minimum |J| / Hz");ui.add(egui::DragValue::new(&mut self.settings.cutoff_hz).range(0.0..=10000.0).speed(0.05));ui.end_row();
                });
                ui.add_space(8.);ui.checkbox(&mut self.settings.estimate,"Estimate missing H–H couplings").on_hover_text("Covers vicinal H–C(sp³)–C(sp³)–H paths and carbon-bound protons on six-membered aromatic C/N rings. Aromatic values are benzene-derived screening estimates; calculated couplings always take precedence.");
                ui.checkbox(&mut self.settings.rotor_average,"Fast methyl / CF₃ rotation");
                ui.checkbox(&mut self.settings.enriched,"Fully ¹³C / ¹⁵N enriched");
                ui.checkbox(&mut self.settings.first_order,"Force first-order approximation");
                ui.checkbox(&mut self.settings.residual_solvent,"Show residual-solvent markers").on_hover_text("Uses the common room-temperature shift only when all loaded logs agree on one supported SCRF solvent keyword.");
                ui.separator();ui.strong("Decouple partner nuclei");
                ui.small("Each row controls the observed spectrum.");
                egui::Grid::new("spectrum-decoupling").show(ui,|ui|{
                    ui.label("Observe");for n in Nucleus::ALL {ui.label(n.label());}ui.end_row();
                    for n in Nucleus::ALL {ui.label(n.label());for partner in Nucleus::ALL {
                        if n==partner {ui.label("—");}else{ui.checkbox(&mut self.settings.decouple[n.index()][partner.index()],"");}
                    }ui.end_row();}
                });
                ui.add_space(10.);
                if ui.add_enabled(self.worker.is_none()&&self.input.is_some(),egui::Button::new("Update spectra").min_size(Vec2::new(230.,32.))).clicked(){let input=self.input.clone().unwrap();self.spawn(ui.ctx(),move|_|Ok(input));}
                if self.worker.is_some() {
                    ui.horizontal(|ui|{ui.spinner();ui.label("Calculating…");if ui.button("Cancel").clicked(){self.cancel();self.message="Calculation cancelled; displayed spectra retained".into();}});
                }
                if self.output.is_some()&&self.applied!=self.settings {ui.colored_label(Color32::from_rgb(153,77,0),"Settings changed. Update to apply them.");}
                ui.separator();ui.strong("Export displayed spectra");
                ui.horizontal_wrapped(|ui|{
                    if ui.add_enabled(self.output.is_some()&&self.export.is_none(),egui::Button::new("Transition CSV…")).clicked(){self.save(false,ui.ctx());}
                    if ui.add_enabled(self.output.is_some()&&self.export.is_none(),egui::Button::new("Spectrum SVG…")).clicked(){self.save(true,ui.ctx());}
                });
                ui.add_space(8.);ui.label(&self.message);
                ui.separator();ui.small("Predicted solution spectra with fast conformational exchange. ¹³C response weighting is qualitative; peak areas are not quantitative experimental response factors.");
                ui.small("Left-drag a region to zoom, right-drag to pan, use the wheel to change vertical intensity, and double-click to reset one plot. Hover near a shift for atom assignments.");
            });
            });
        });
        egui::CentralPanel::default().frame(egui::Frame::new().fill(Color32::from_rgb(46,54,65)).inner_margin(12)).show(ui,|ui|{
            let available_height=ui.available_height();
            egui::Frame::new().fill(Color32::WHITE).corner_radius(10).inner_margin(16).show(ui,|ui|{
            ui.set_min_height((available_height-32.).max(0.));
            ui.style_mut().visuals = egui::Visuals::light();
            let Some(input)=&self.input else{ui.heading("Predicted NMR spectra");ui.label(&self.message);return;};
            ui.heading(&input.name);
            ui.horizontal_wrapped(|ui|{
                ui.selectable_value(&mut self.selected,None,"All nuclei");
                for n in Nucleus::ALL {if input.spins.iter().any(|s|s.nucleus==n){ui.selectable_value(&mut self.selected,Some(n),n.label());}}
                if ui.button("Zoom out to full spectrum").clicked(){self.ranges.clear();self.cache.clear();}
            });
            let Some(out)=&self.output else{return;};
            let height=if self.selected.is_some(){(ui.available_height()-210.).max(270.)}else{235.};
            egui::ScrollArea::vertical()
                .scroll_source(
                    egui::scroll_area::ScrollSource::SCROLL_BAR
                        | egui::scroll_area::ScrollSource::MOUSE_WHEEL,
                )
                .id_salt("spectra-scroll")
                .show(ui,|ui|{
                for p in &out.predictions {
                    if self.selected.is_some_and(|n|n!=p.nucleus){continue;}
                    ui.add_space(7.);ui.label(RichText::new(format!("{} · {} atoms · {:.3} MHz",p.nucleus.label(),p.atoms.len(),self.applied.proton_mhz*p.nucleus.ratio())).strong().size(17.));
                    let range=self.ranges.entry(p.nucleus).or_insert_with(||p.range(&self.applied));
                    let intensity=self.intensities.entry(p.nucleus).or_insert(1.);
                    let selection_start=self.selection_starts.entry(p.nucleus).or_default();
                    plot(ui,input,p,&self.applied,PlotView { range, intensity, selection_start, cache: &mut self.cache },height);
                    for note in &p.notes {ui.small(note);}
                }
                ui.separator();
                egui::CollapsingHeader::new("Data, assumptions, and coupling inventory").show(ui,|ui|{
                    ui.label(self.applied.description());
                    for n in &out.notes{ui.label(n);ui.add_space(5.);}
                    ui.label(format!("{} calculated / {} estimated coupling pairs before decoupling and cutoff",out.couplings.len()-out.estimated.len(),out.estimated.len()));
                    egui::ScrollArea::vertical().max_height(230.).id_salt("coupling-inventory").show(ui,|ui|{
                        egui::Grid::new("spectrum-j-table").striped(true).show(ui,|ui|{
                            ui.strong("Atoms");ui.strong("J / Hz");ui.strong("Source");ui.end_row();
                            for (&p,&j) in &out.couplings{ui.label(format!("{}–{}",p.0+1,p.1+1));ui.label(format!("{j:.3}"));ui.label(if out.estimated_aromatic.contains(&p){"Aromatic estimate"}else if out.estimated.contains(&p){"Vicinal estimate"}else{"Calculated"});ui.end_row();}
                        });
                    });
                    ui.small("Sources: IUPAC chemical-shift conventions (Pure and Applied Chemistry, 2001); generalized vicinal Karplus relationship (Tetrahedron, 1980); benzene ortho/meta/para coupling values (Journal of Molecular Spectroscopy, 1967); and common residual-solvent shifts (Journal of Organic Chemistry, 1997). Full citations and DOI references are listed in SPECTRA.md.");
                    ui.small("The simplified curve used here is 7.76 cos²θ − 1.10 cosθ + 1.40 Hz. It does not include the substituent corrections of the generalized relationship. See SPECTRA.md for the implemented model and its limits.");
                });
            });
            });
        });
    }
    fn save(&mut self, vector: bool, ctx: &egui::Context) {
        let (Some(input), Some(out)) = (&self.input, &self.output) else {
            return;
        };
        let input = input.clone();
        let out = out.clone();
        let settings = self.applied.clone();
        let extension = if vector { "svg" } else { "csv" };
        let name = format!("{}_predicted_spectra.{extension}", input.name);
        let (tx, rx) = mpsc::channel();
        let ctx = ctx.clone();
        self.export = Some(rx);
        std::thread::spawn(move || {
            let result = std::panic::catch_unwind(|| -> anyhow::Result<Option<PathBuf>> {
                let Some(path) = rfd::FileDialog::new()
                    .set_file_name(&name)
                    .add_filter("Spectrum", &[extension])
                    .save_file()
                else {
                    return Ok(None);
                };
                let text = if vector {
                    svg(&input, &out, &settings)
                } else {
                    csv(&input, &out, &settings)
                };
                crate::jobs::atomic_write(&path, &text)?;
                Ok(Some(path))
            });
            let r = match result {
                Ok(r) => r.map_err(|e| format!("{e:#}")),
                Err(_) => Err("Spectrum export stopped unexpectedly".into()),
            };
            let _ = tx.send(r);
            ctx.request_repaint();
        });
    }
}
struct PlotView<'a> {
    range: &'a mut [f64; 2],
    intensity: &'a mut f64,
    selection_start: &'a mut Option<f32>,
    cache: &'a mut BTreeMap<Nucleus, PlotCache>,
}

/// Reduce a dense curve to a min/max envelope for each horizontal bucket.
/// Narrow peaks remain visible while the painter receives O(pixel width)
/// points instead of the full scientific/export sample array every frame.
fn peak_envelope(values: &[f64], pixels: usize) -> Vec<(f32, f64)> {
    if values.is_empty() {
        return vec![];
    }
    let bins = pixels.clamp(64, 2048).min(values.len());
    if values.len() <= bins * 2 {
        return values
            .iter()
            .enumerate()
            .map(|(i, &value)| (i as f32, value))
            .collect();
    }
    let mut out = Vec::with_capacity(bins * 2);
    for bin in 0..bins {
        let start = bin * values.len() / bins;
        let end = ((bin + 1) * values.len() / bins).max(start + 1);
        let mut low = (start, values[start]);
        let mut high = low;
        for (offset, &value) in values[start + 1..end].iter().enumerate() {
            let index = start + 1 + offset;
            if value < low.1 {
                low = (index, value);
            }
            if value > high.1 {
                high = (index, value);
            }
        }
        if low.0 <= high.0 {
            out.push((low.0 as f32, low.1));
            if high.0 != low.0 {
                out.push((high.0 as f32, high.1));
            }
        } else {
            out.push((high.0 as f32, high.1));
            out.push((low.0 as f32, low.1));
        }
    }
    out
}
fn plot(
    ui: &mut egui::Ui,
    input: &Input,
    p: &Prediction,
    s: &Settings,
    view: PlotView<'_>,
    height: f32,
) -> Rect {
    let PlotView {
        range,
        intensity,
        selection_start,
        cache,
    } = view;
    let (rect, response) = ui.allocate_exact_size(
        Vec2::new(ui.available_width(), height),
        Sense::click_and_drag(),
    );
    let r = Rect::from_min_max(
        rect.min + Vec2::new(45., 12.),
        rect.max - Vec2::new(16., 36.),
    );
    if response.double_clicked_by(egui::PointerButton::Primary) {
        *range = p.preview_range;
        *intensity = 1.;
        *selection_start = None;
    }
    if response.dragged_by(egui::PointerButton::Secondary) {
        let delta = ui.input(|i| i.pointer.delta().x);
        let shift = delta as f64 / r.width() as f64 * (range[1] - range[0]);
        range[0] += shift;
        range[1] += shift;
    }
    let pointer_x = ui
        .input(|i| i.pointer.latest_pos())
        .or_else(|| response.interact_pointer_pos())
        .map(|position| position.x.clamp(r.left(), r.right()));
    if response.drag_started_by(egui::PointerButton::Primary) {
        *selection_start = response
            .interact_pointer_pos()
            .or_else(|| ui.input(|i| i.pointer.latest_pos()))
            .map(|position| (position.x - response.drag_delta().x).clamp(r.left(), r.right()));
    }
    let selection = selection_start.as_ref().copied().zip(pointer_x);
    if response.drag_stopped_by(egui::PointerButton::Primary)
        && let Some((a, b)) = selection
        && (a - b).abs() >= 5.
    {
        let ppm =
            |x: f32| range[1] - (x - r.left()) as f64 / r.width() as f64 * (range[1] - range[0]);
        let (pa, pb) = (ppm(a), ppm(b));
        *range = [pa.min(pb), pa.max(pb)];
    }
    if response.drag_stopped_by(egui::PointerButton::Primary)
        || (selection_start.is_some()
            && !ui.input(|i| i.pointer.button_down(egui::PointerButton::Primary)))
    {
        *selection_start = None;
    }
    if response.hovered() {
        let scroll = ui.input(|i| i.smooth_scroll_delta.y);
        if scroll != 0. {
            *intensity = (*intensity * (scroll as f64 * 0.004).exp()).clamp(0.05, 50.);
            // The surrounding spectrum list is evaluated after its contents;
            // consume this plot-local wheel motion before that list can scroll.
            ui.ctx().input_mut(|i| {
                i.smooth_scroll_delta.y = 0.;
            });
        }
    }
    let full = *range == p.preview_range;
    let samples = if full {
        p.preview_values.len()
    } else {
        (r.width() as usize * 2).clamp(512, 4096)
    };
    let pixels = r.width().round().max(1.) as usize;
    if !cache
        .get(&p.nucleus)
        .is_some_and(|c| c.range == *range && c.samples == samples && c.pixels == pixels)
    {
        let values = if full {
            p.preview_values.clone()
        } else {
            p.curve(s, *range, samples)
        };
        let maximum = values.iter().copied().fold(0_f64, f64::max).max(1e-20);
        let envelope = peak_envelope(&values, pixels);
        cache.insert(
            p.nucleus,
            PlotCache {
                range: *range,
                samples,
                pixels,
                envelope,
                maximum,
            },
        );
    }
    let curve = &cache[&p.nucleus];
    let painter = ui.painter_at(rect);
    painter.rect_filled(rect, 4., Color32::WHITE);
    if let Some((a, b)) = selection.filter(|_| response.dragged_by(egui::PointerButton::Primary)) {
        let selected = Rect::from_x_y_ranges(a.min(b)..=a.max(b), r.top()..=r.bottom());
        painter.rect_filled(
            selected,
            0.,
            Color32::from_rgba_unmultiplied(44, 126, 154, 38),
        );
        painter.rect_stroke(
            selected,
            0.,
            Stroke::new(1., Color32::from_rgb(44, 126, 154)),
            egui::StrokeKind::Inside,
        );
    }
    painter.line_segment(
        [Pos2::new(r.left(), r.bottom()), r.max],
        Stroke::new(1., Color32::GRAY),
    );
    let points = curve
        .envelope
        .iter()
        .map(|&(i, v)| {
            Pos2::new(
                r.right() - (i + 0.5) / curve.samples.max(1) as f32 * r.width(),
                r.bottom() - (v / curve.maximum * *intensity).min(1.04) as f32 * r.height() * 0.91,
            )
        })
        .collect();
    painter.add(egui::Shape::line(
        points,
        Stroke::new(1.25, Color32::from_rgb(165, 42, 64)),
    ));
    for tick in 0..=6 {
        let f = tick as f32 / 6.;
        let x = r.left() + f * r.width();
        let ppm = range[1] - (range[1] - range[0]) * f as f64;
        painter.text(
            Pos2::new(x, r.bottom() + 9.),
            egui::Align2::CENTER_TOP,
            format!("{ppm:.2}"),
            egui::FontId::proportional(12.),
            Color32::DARK_GRAY,
        );
    }
    painter.text(
        Pos2::new(r.right(), rect.bottom()),
        egui::Align2::RIGHT_BOTTOM,
        "δ / ppm",
        egui::FontId::proportional(11.),
        Color32::DARK_GRAY,
    );
    painter.text(
        Pos2::new(r.left(), rect.bottom()),
        egui::Align2::LEFT_BOTTOM,
        format!("Intensity ×{intensity:.2}"),
        egui::FontId::proportional(11.),
        Color32::DARK_GRAY,
    );
    for reference in &p.references {
        if (range[0]..=range[1]).contains(&reference.ppm) {
            let x =
                r.right() - ((reference.ppm - range[0]) / (range[1] - range[0])) as f32 * r.width();
            painter.line_segment(
                [Pos2::new(x, r.top() + 16.), Pos2::new(x, r.bottom())],
                Stroke::new(1., Color32::from_rgb(40, 124, 142)),
            );
            painter.text(
                Pos2::new(x, r.top() + 3.),
                egui::Align2::CENTER_TOP,
                &reference.label,
                egui::FontId::proportional(10.),
                Color32::from_rgb(31, 102, 119),
            );
        }
    }
    if let Some(pos) = response.hover_pos() {
        let ppm = range[1] - (pos.x - r.left()) as f64 / r.width() as f64 * (range[1] - range[0]);
        let nearest = input
            .spins
            .iter()
            .filter(|x| x.nucleus == p.nucleus)
            .min_by(|a, b| (a.ppm - ppm).abs().total_cmp(&(b.ppm - ppm).abs()));
        if let Some(reference) = p
            .references
            .iter()
            .min_by(|a, b| (a.ppm - ppm).abs().total_cmp(&(b.ppm - ppm).abs()))
            .filter(|reference| (reference.ppm - ppm).abs() < (range[1] - range[0]) * 0.012)
        {
            response.on_hover_text(format!(
                "Cursor {ppm:.4} ppm\n{} reference marker: {:.2} ppm",
                reference.label, reference.ppm
            ));
        } else if let Some(spin) = nearest {
            let atoms = input
                .spins
                .iter()
                .filter(|x| x.nucleus == p.nucleus && (x.ppm - spin.ppm).abs() < 1e-8)
                .map(|x| (x.atom + 1).to_string())
                .collect::<Vec<_>>()
                .join(", ");
            response.on_hover_text(format!(
                "Cursor {ppm:.4} ppm\nNearest unsplit shift: {:.2} ppm\nAtom(s): {atoms}",
                spin.ppm
            ));
        }
    }
    r
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display_envelope_preserves_narrow_peaks() {
        let mut values = vec![0.; 10_000];
        values[4_321] = 7.5;
        let envelope = peak_envelope(&values, 300);
        assert!(envelope.len() <= 600);
        assert!(
            envelope
                .iter()
                .any(|&(index, value)| index == 4_321. && value == 7.5)
        );
    }

    fn raw_input(events: Vec<egui::Event>, tick: usize) -> egui::RawInput {
        egui::RawInput {
            screen_rect: Some(Rect::from_min_size(Pos2::ZERO, Vec2::new(760., 360.))),
            time: Some(tick as f64 / 60.),
            events,
            ..Default::default()
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn draw_plot(
        ctx: &egui::Context,
        events: Vec<egui::Event>,
        tick: usize,
        input: &Input,
        prediction: &Prediction,
        settings: &Settings,
        range: &mut [f64; 2],
        intensity: &mut f64,
        selection_start: &mut Option<f32>,
        cache: &mut BTreeMap<Nucleus, PlotCache>,
    ) -> (Rect, f32, f32) {
        let mut plot_rect = Rect::NOTHING;
        let mut remaining_scroll = 0.;
        let mut outer_offset = 0.;
        ctx.run_ui(raw_input(events, tick), |ui| {
            let output = egui::ScrollArea::vertical()
                .scroll_source(
                    egui::scroll_area::ScrollSource::SCROLL_BAR
                        | egui::scroll_area::ScrollSource::MOUSE_WHEEL,
                )
                .id_salt("spectrum-interaction-regression")
                .show(ui, |ui| {
                    plot_rect = plot(
                        ui,
                        input,
                        prediction,
                        settings,
                        PlotView {
                            range,
                            intensity,
                            selection_start,
                            cache,
                        },
                        300.,
                    );
                    ui.allocate_space(Vec2::new(1., 600.));
                });
            outer_offset = output.state.offset.y;
            remaining_scroll = ui.input(|i| i.smooth_scroll_delta.y);
        })
        .drop_without_applying_deltas();
        (plot_rect, remaining_scroll, outer_offset)
    }

    #[test]
    fn plot_consumes_intensity_wheel_and_persists_region_drag() {
        let ctx = egui::Context::default();
        let settings = Settings::default();
        let input = Input {
            name: "interaction".into(),
            spins: vec![Spin {
                atom: 0,
                nucleus: Nucleus::H,
                ppm: 5.,
                area: 1.,
            }],
            ..Default::default()
        };
        let prediction = Prediction {
            nucleus: Nucleus::H,
            atoms: vec![0],
            lines: vec![Line {
                hz: 5. * settings.proton_mhz,
                area: 1.,
            }],
            notes: vec![],
            references: vec![],
            preview_range: [0., 10.],
            preview_values: vec![0., 1., 0.],
        };
        let mut range = prediction.preview_range;
        let mut intensity = 1.;
        let mut selection_start = None;
        let mut cache = BTreeMap::new();
        let (rect, _, _) = draw_plot(
            &ctx,
            vec![],
            0,
            &input,
            &prediction,
            &settings,
            &mut range,
            &mut intensity,
            &mut selection_start,
            &mut cache,
        );
        let center = rect.center();
        let (_, remaining, outer_offset) = draw_plot(
            &ctx,
            vec![
                egui::Event::PointerMoved(center),
                egui::Event::MouseWheel {
                    unit: egui::MouseWheelUnit::Point,
                    delta: Vec2::new(0., -80.),
                    phase: egui::TouchPhase::Move,
                    modifiers: Default::default(),
                },
            ],
            1,
            &input,
            &prediction,
            &settings,
            &mut range,
            &mut intensity,
            &mut selection_start,
            &mut cache,
        );
        assert!(intensity < 1.);
        assert_eq!(remaining, 0.);
        assert_eq!(outer_offset, 0.);

        let start = Pos2::new(rect.left() + rect.width() * 0.25, center.y);
        let end = Pos2::new(rect.left() + rect.width() * 0.75, center.y);
        for (tick, events) in [
            vec![
                egui::Event::PointerMoved(start),
                egui::Event::PointerButton {
                    pos: start,
                    button: egui::PointerButton::Primary,
                    pressed: true,
                    modifiers: Default::default(),
                },
            ],
            vec![egui::Event::PointerMoved(end)],
            vec![
                egui::Event::PointerMoved(end),
                egui::Event::PointerButton {
                    pos: end,
                    button: egui::PointerButton::Primary,
                    pressed: false,
                    modifiers: Default::default(),
                },
            ],
        ]
        .into_iter()
        .enumerate()
        {
            let (_, _, outer_offset) = draw_plot(
                &ctx,
                events,
                tick + 2,
                &input,
                &prediction,
                &settings,
                &mut range,
                &mut intensity,
                &mut selection_start,
                &mut cache,
            );
            assert_eq!(outer_offset, 0.);
        }
        assert!(
            range[1] - range[0] < 6.,
            "region drag did not narrow {range:?}"
        );
        assert!(selection_start.is_none());
    }

    #[test]
    fn failed_update_preserves_displayed_parameters() {
        let mut w = SpectrumWindow::default();
        w.settings.proton_mhz = 800.;
        let (tx, rx) = mpsc::channel();
        let cancel = Arc::new(AtomicBool::new(false));
        w.worker = Some(Pending {
            result: rx,
            cancel,
            settings: w.settings.clone(),
        });
        tx.send(Err("Invalid spectrum".into())).unwrap();
        w.poll(&egui::Context::default());
        assert!(w.worker.is_none());
        assert_eq!(w.applied.proton_mhz, 600.);
        assert_eq!(w.settings.proton_mhz, 800.);
        assert_eq!(w.message, "Invalid spectrum");
    }
    #[test]
    fn dropping_window_cancels_its_calculation() {
        let cancel = Arc::new(AtomicBool::new(false));
        let (_tx, rx) = mpsc::channel();
        let mut w = SpectrumWindow::default();
        w.worker = Some(Pending {
            result: rx,
            cancel: cancel.clone(),
            settings: Settings::default(),
        });
        drop(w);
        assert!(cancel.load(Ordering::Relaxed));
    }
}
