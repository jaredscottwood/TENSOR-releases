use crate::{
    analysis::*,
    branding::DEVELOPMENT_CREDIT,
    cluster::{ClusterSettings, cluster},
    config::*,
    gaussian::Frequencies,
    jobs::*,
    molecule::*,
    viewer::{LabelMode, SelectionMeasurement, Viewer},
};
use anyhow::{Context, Result};
use eframe::egui::{self, Color32, RichText, ScrollArea, Vec2};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::{Path, PathBuf},
    sync::{
        Arc,
        atomic::Ordering,
        mpsc::{self, Receiver, TryRecvError},
    },
    time::Instant,
};

const BLUE: Color32 = Color32::from_rgb(31, 91, 145);
const MUTED: Color32 = Color32::from_rgb(91, 107, 126);
const WARN: Color32 = Color32::from_rgb(222, 125, 70);
const DARK_PANEL: Color32 = Color32::from_rgb(38, 45, 55);
const DARK_CENTER: Color32 = Color32::from_rgb(46, 54, 65);
const ON_DARK: Color32 = Color32::from_rgb(222, 229, 237);
pub(crate) const SETUP_VIEWER_MIN_HEIGHT: f32 = 260.;

pub(crate) fn methodology_viewport_builder(
    title: &str,
    icon: Arc<egui::IconData>,
) -> egui::ViewportBuilder {
    egui::ViewportBuilder::default()
        .with_title(title)
        .with_icon(icon)
        .with_inner_size([970., 720.])
        .with_min_inner_size([730., 480.])
        .with_maximized(true)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Tab {
    Setup,
    Analysis,
}
#[derive(Clone, Copy, Debug)]
pub enum Startup {
    Workspace,
    Splash(Option<Instant>),
    Chooser,
}

#[derive(Clone, Copy, Debug)]
enum PickKind {
    Sdf,
    Logs,
    SdfFolder,
    LogsFolder,
    SetupFolder,
    AnalysisFolder,
    ResultsFolder,
}
struct NativePicker {
    kind: PickKind,
    result: Receiver<Result<Option<Vec<PathBuf>>, String>>,
}
fn native_picker(kind: PickKind, directory: PathBuf) -> NativePicker {
    let (sender, result) = mpsc::channel();
    std::thread::spawn(move || {
        let choice=std::panic::catch_unwind(|| {
            let dialog=rfd::FileDialog::new().set_directory(directory);
            match kind {
                PickKind::Sdf => dialog.set_title("TENSOR — choose conformer SDF files").add_filter("SDF structures", &["sdf"]).pick_files(),
                PickKind::Logs => dialog.set_title("TENSOR — choose completed Gaussian logs").add_filter("Gaussian logs", &["log"]).pick_files(),
                _ => dialog.set_title("TENSOR — choose folder").pick_folder().map(|p|vec![p]),
            }
        }).map_err(|_|"The native file dialog could not be opened. You can also drag files or folders into TENSOR.".to_string());
        let _ = sender.send(choice);
    });
    NativePicker { kind, result }
}

enum Completed {
    Loaded(Vec<PathBuf>, Vec<ConformerInput>, Vec<String>),
    LogFiles(Vec<PathBuf>),
    Opened(AnalysisResult),
    Setup(SetupResult),
    Analysis(AnalysisResult),
    ClusterPreview(SetupClusterOverlay),
}
struct Worker {
    progress: Progress,
    logs: Receiver<String>,
    done: Receiver<Result<Completed, String>>,
    started: Instant,
    label: String,
}
fn receive<T>(
    receiver: &Receiver<Result<T, String>>,
    operation: &str,
) -> Option<Result<T, String>> {
    match receiver.try_recv() {
        Ok(result) => Some(result),
        Err(TryRecvError::Empty) => None,
        Err(TryRecvError::Disconnected) => Some(Err(format!(
            "{operation} stopped without returning a result"
        ))),
    }
}
pub struct Workbench {
    pub tab: Tab,
    pub startup: Startup,
    pub window_icon: Arc<egui::IconData>,
    logo: Option<egui::TextureHandle>,
    pub(crate) methodology_page: usize,
    pub(crate) methodology_tab: Tab,
    pub show_export: bool,
    pub figure_options: crate::figure::FigureOptions,
    figure_result: Option<Receiver<Result<Option<PathBuf>, String>>>,
    pub config: Config,
    pub config_path: PathBuf,
    pub setup_files: Vec<PathBuf>,
    pub inputs: Vec<ConformerInput>,
    pub input_errors: Vec<String>,
    pub job: JobSettings,
    pub job_compound: String,
    pub apply_all: bool,
    pub per_compound_jobs: BTreeMap<String, JobSettings>,
    pub setup_output: String,
    pub log_files: Vec<PathBuf>,
    pub analysis_settings: AnalysisSettings,
    pub analysis_output: String,
    pub output_compound: String,
    pub analysis: Option<AnalysisResult>,
    pub viewer: Viewer,
    pub setup_viewer: Viewer,
    pub spectrum: crate::spectrum_ui::SpectrumWindow,
    pub viewer_compound: usize,
    pub viewer_conformer: usize,
    pub demo: bool,
    pub status: String,
    pub status_error: bool,
    pub run_log: Vec<String>,
    pub show_log: bool,
    pub show_methodology: bool,
    pub show_config: bool,
    pub config_text: String,
    pub control_rects: BTreeMap<String, egui::Rect>,
    picker: Option<NativePicker>,
    pub recursive_folders: bool,
    worker: Option<Worker>,
    remove_sdf: BTreeSet<PathBuf>,
    remove_logs: BTreeSet<PathBuf>,
    pub cluster_mode: String,
    pub custom_cluster: ClusterSettings,
    last_setup: Option<SetupResult>,
    viewer_selection: Option<(usize, usize)>,
    cluster_preview: Option<SetupClusterOverlay>,
    setup_cluster: usize,
}
impl Workbench {
    pub fn new(config: Config, config_path: PathBuf) -> Self {
        let config_text =
            std::fs::read_to_string(&config_path).unwrap_or_else(|_| DEFAULT_CONFIG.into());
        let mut job = JobSettings::default();
        if !config.methods.contains_key(&job.method) {
            job.method = config.methods.keys().next().unwrap().clone();
        }
        if !config.machines.contains_key(&job.machine) {
            job.machine = config.machines.keys().next().unwrap().clone();
        }
        if !config.machines[&job.machine]
            .tiers
            .iter()
            .any(|t| t.name == job.tier)
        {
            job.tier = config.machines[&job.machine].tiers[0].name.clone();
        }
        let mut run_log = vec![
            format!("Configuration: {}",config_path.display()),
            format!("{} method(s), {} machine profile(s).",config.methods.len(),config.machines.len()),
            "Ready. Choose Job setup or Analysis & 3D view. All setup calculation and intermediate-output options start unchecked.".into()
        ];
        run_log.extend(config.problems.iter().cloned());
        Self {
            tab: Tab::Setup,
            startup: Startup::Workspace,
            window_icon: Arc::new(crate::branding::icon(128).unwrap_or_default()),
            logo: None,
            methodology_page: 0,
            methodology_tab: Tab::Setup,
            show_export: false,
            figure_options: crate::figure::FigureOptions::default(),
            figure_result: None,
            config,
            config_path,
            setup_files: vec![],
            inputs: vec![],
            input_errors: vec![],
            job,
            job_compound: String::new(),
            apply_all: false,
            per_compound_jobs: BTreeMap::new(),
            setup_output: String::new(),
            log_files: vec![],
            analysis_settings: AnalysisSettings::default(),
            analysis_output: String::new(),
            output_compound: String::new(),
            analysis: None,
            viewer: Viewer::default(),
            setup_viewer: Viewer::default(),
            spectrum: crate::spectrum_ui::SpectrumWindow::default(),
            viewer_compound: 0,
            viewer_conformer: 0,
            demo: false,
            status: "Ready".into(),
            status_error: false,
            run_log,
            show_log: false,
            show_methodology: false,
            show_config: false,
            config_text,
            control_rects: BTreeMap::new(),
            picker: None,
            recursive_folders: false,
            worker: None,
            remove_sdf: BTreeSet::new(),
            remove_logs: BTreeSet::new(),
            cluster_mode: "none".into(),
            custom_cluster: ClusterSettings::default(),
            last_setup: None,
            viewer_selection: None,
            cluster_preview: None,
            setup_cluster: 0,
        }
    }
    pub fn style(ctx: &egui::Context) {
        crate::branding::install_fonts(ctx);
        let mut style = (*ctx.style_of(egui::Theme::Dark)).clone();
        style.visuals = egui::Visuals::dark();
        style.visuals.panel_fill = DARK_PANEL;
        style.visuals.window_fill = DARK_CENTER;
        style.visuals.extreme_bg_color = Color32::from_rgb(28, 34, 42);
        style.visuals.selection.bg_fill = Color32::from_rgb(42, 104, 145);
        style.visuals.selection.stroke = egui::Stroke::new(1., Color32::WHITE);
        style.visuals.widgets.noninteractive.fg_stroke = egui::Stroke::new(1., ON_DARK);
        style.visuals.widgets.inactive.fg_stroke = egui::Stroke::new(1., ON_DARK);
        style.visuals.widgets.active.bg_fill = Color32::from_rgb(49, 105, 139);
        style.visuals.widgets.hovered.bg_fill = Color32::from_rgb(61, 75, 89);
        style.spacing.item_spacing = Vec2::new(8., 7.);
        // Reserve scrollbar space even before the first pointer enters a panel.
        style.spacing.scroll.floating = false;
        style.spacing.scroll.bar_width = 8.;
        style.spacing.button_padding = Vec2::new(10., 6.);
        style
            .text_styles
            .insert(egui::TextStyle::Body, egui::FontId::proportional(14.));
        style
            .text_styles
            .insert(egui::TextStyle::Button, egui::FontId::proportional(14.));
        style
            .text_styles
            .insert(egui::TextStyle::Small, egui::FontId::proportional(12.));
        style
            .text_styles
            .insert(egui::TextStyle::Monospace, egui::FontId::monospace(12.));
        ctx.set_theme(egui::Theme::Dark);
        ctx.set_style_of(egui::Theme::Dark, style);
    }
    fn error(&mut self, e: impl ToString) {
        self.status = e.to_string();
        self.status_error = true;
        self.run_log.push(self.status.clone());
        self.show_log = true;
    }
    fn start(
        &mut self,
        label: &str,
        work: impl FnOnce(Progress) -> anyhow::Result<Completed> + Send + 'static,
    ) {
        if !self.ready_for_work() {
            return;
        }
        let (tx, logs) = mpsc::channel();
        let (done_tx, done) = mpsc::channel();
        let progress = Progress {
            sender: Some(tx),
            ..Default::default()
        };
        let control = progress.clone();
        let label = label.to_string();
        self.run_log.push(format!("\n{label}"));
        self.status = label.clone();
        self.status_error = false;
        self.show_log = true;
        std::thread::spawn(move || {
            let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| work(control)));
            let result = match result {
                Ok(r) => r.map_err(|e| format!("{e:#}")),
                Err(_) => Err(
                    "The worker stopped unexpectedly. Inputs were not changed; see the run log."
                        .into(),
                ),
            };
            let _ = done_tx.send(result);
        });
        self.worker = Some(Worker {
            progress,
            logs,
            done,
            started: Instant::now(),
            label,
        });
    }
    fn poll(&mut self, ctx: &egui::Context) {
        if self.figure_result.is_some() {
            ctx.request_repaint_after(std::time::Duration::from_millis(80));
        }
        let exported = self
            .figure_result
            .as_ref()
            .and_then(|r| receive(r, "Figure export"));
        if let Some(result) = exported {
            self.figure_result = None;
            match result {
                Ok(Some(path)) => {
                    self.status = format!("Figure saved: {}", path.display());
                    self.status_error = false;
                    self.run_log.push(self.status.clone());
                }
                Ok(None) => self.status = "Figure export cancelled".into(),
                Err(error) => self.error(error),
            }
        }
        let choice = self
            .picker
            .as_ref()
            .and_then(|picker| receive(&picker.result, "File selection").map(|r| (picker.kind, r)));
        if self.picker.is_some() {
            ctx.request_repaint_after(std::time::Duration::from_millis(60));
        }
        if let Some((kind, result)) = choice {
            self.picker = None;
            match result {
                Ok(Some(paths)) if !paths.is_empty() => match kind {
                    PickKind::Sdf | PickKind::SdfFolder => self.add_paths(paths, true),
                    PickKind::Logs | PickKind::LogsFolder => self.add_paths(paths, false),
                    PickKind::SetupFolder => {
                        self.setup_output = paths[0].to_string_lossy().into();
                        self.status = "Output folder selected".into();
                    }
                    PickKind::AnalysisFolder => {
                        self.analysis_output = paths[0].to_string_lossy().into();
                        self.status = "Output folder selected".into();
                    }
                    PickKind::ResultsFolder => {
                        let root = paths[0].clone();
                        self.start("Opening saved results", move |p| {
                            p.log(format!("Reading {}", root.display()));
                            Ok(Completed::Opened(read_saved_results(&root)?))
                        });
                    }
                },
                Ok(_) => self.status = "Selection cancelled".into(),
                Err(error) => self.error(error),
            }
        }
        let mut finished = None;
        if let Some(worker) = &self.worker {
            // Receiving completion first guarantees that all final log sends
            // happened before the last drain. No messages are lost at handoff.
            finished = receive(&worker.done, "Worker");
            self.run_log.extend(worker.logs.try_iter());
            ctx.request_repaint_after(std::time::Duration::from_millis(60));
        }
        if let Some(result) = finished {
            self.worker = None;
            match result {
                Ok(Completed::Loaded(paths, inputs, errors)) => {
                    self.setup_files = paths;
                    self.inputs = inputs;
                    self.input_errors = errors;
                    self.status = format!("{} structures loaded", self.inputs.len());
                    if self.job_compound.is_empty()
                        || !self.inputs.iter().any(|c| c.compound == self.job_compound)
                    {
                        let name = self
                            .inputs
                            .first()
                            .map(|c| c.compound.clone())
                            .unwrap_or_default();
                        self.select_job_compound(name);
                    }
                    self.run_log.extend(self.input_errors.iter().cloned());
                    self.status_error = !self.input_errors.is_empty();
                    self.cluster_preview = None;
                    self.setup_cluster = 0;
                    self.setup_viewer.clear();
                }
                Ok(Completed::LogFiles(paths)) => {
                    self.log_files = paths;
                    self.status = format!("{} log files loaded", self.log_files.len());
                    self.status_error = false;
                }
                Ok(Completed::Opened(result)) => {
                    self.accept_results(result);
                    self.status = "Saved results loaded".into();
                }
                Ok(Completed::Setup(result)) => {
                    self.accept_setup_result(result);
                }
                Ok(Completed::Analysis(result)) => {
                    self.status = format!(
                        "{} compounds analyzed{}",
                        result.compounds.len(),
                        if result.errors.is_empty() {
                            ""
                        } else {
                            "; some inputs failed (see run log)"
                        }
                    );
                    self.status_error = !result.errors.is_empty();
                    self.run_log.extend(result.errors.iter().cloned());
                    self.analysis = Some(result);
                    self.spectrum = crate::spectrum_ui::SpectrumWindow::default();
                    self.viewer_compound = 0;
                    self.viewer_conformer = 0;
                    self.viewer_selection = None;
                    self.tab = Tab::Analysis;
                    self.demo = false;
                }
                Ok(Completed::ClusterPreview(preview)) => {
                    self.cluster_preview = Some(preview);
                    self.setup_cluster = 0;
                    self.load_setup_cluster();
                    let clusters = self
                        .cluster_preview
                        .as_ref()
                        .map_or(0, |preview| preview.groups.len());
                    self.status = format!("Cluster overlay ready · {clusters} cluster(s)");
                    self.status_error = false;
                }
                Err(error) => self.error(error),
            }
        }
        if self.run_log.len() > 10_000 {
            self.run_log.drain(..self.run_log.len() - 10_000);
        }
    }
    pub fn add_paths(&mut self, paths: Vec<PathBuf>, setup: bool) {
        if !self.ready_for_work() {
            return;
        }
        let mut candidates = if setup {
            self.setup_files.clone()
        } else {
            self.log_files.clone()
        };
        candidates.extend(paths);
        let recursive = self.recursive_folders;
        self.start(
            if setup {
                "Reading conformer structures"
            } else {
                "Finding Gaussian log files"
            },
            move |p| {
                let extension = if setup { "sdf" } else { "log" };
                let mut files = BTreeSet::new();
                for path in candidates {
                    p.check()?;
                    p.log(format!("Scanning {}", path.display()));
                    files.extend(collect_files(&path, extension, recursive)?);
                }
                let mut files: Vec<_> = files.into_iter().collect();
                files.sort_by(|a, b| natural_path_cmp(a, b));
                p.log(format!("Found {} .{extension} files", files.len()));
                if setup {
                    let (items, errors) = load_inputs(&files);
                    Ok(Completed::Loaded(files, items, errors))
                } else {
                    Ok(Completed::LogFiles(files))
                }
            },
        );
    }
    fn choose(&mut self, kind: PickKind) {
        if !self.ready_for_work() {
            return;
        }
        let base = match kind {
            PickKind::Sdf | PickKind::SdfFolder => self
                .setup_files
                .first()
                .and_then(|p| p.parent())
                .map(Path::to_path_buf),
            PickKind::Logs | PickKind::LogsFolder => self
                .log_files
                .first()
                .and_then(|p| p.parent())
                .map(Path::to_path_buf),
            PickKind::SetupFolder => Some(PathBuf::from(&self.setup_output)),
            PickKind::AnalysisFolder => Some(PathBuf::from(&self.analysis_output)),
            PickKind::ResultsFolder => self
                .log_files
                .first()
                .and_then(|p| p.parent())
                .map(Path::to_path_buf),
        }
        .filter(|p| p.is_dir())
        .unwrap_or_else(|| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));
        self.picker = Some(native_picker(kind, base));
        self.status = "Choose files or a folder in the native system dialog".into();
        self.status_error = false;
    }
    fn job_snapshot(&self) -> JobSettings {
        let mut s = self.job.clone();
        s.clustering = match self.cluster_mode.as_str() {
            "shifts" => Some(ClusterSettings::shifts()),
            "all_nmr" => Some(ClusterSettings::all_nmr()),
            "custom" => Some(self.custom_cluster.clone()),
            _ => None,
        };
        s
    }
    pub fn restore_job(&mut self, job: JobSettings) {
        self.cluster_mode = if let Some(c) = &job.clustering {
            self.custom_cluster = c.clone();
            if c.linkage == "complete"
                && c.tau == 0.4
                && c.selection == "tiered"
                && c.dihedral_weight == 0.5
            {
                "shifts"
            } else if c.linkage == "complete"
                && c.tau == 0.15
                && c.selection == "lowest_energy"
                && c.dihedral_weight == 0.5
            {
                "all_nmr"
            } else {
                "custom"
            }
        } else {
            "none"
        }
        .into();
        self.job = job;
        self.normalize_profile();
    }
    fn ready_for_work(&self) -> bool {
        self.worker.is_none() && self.picker.is_none()
    }
    fn select_job_compound(&mut self, name: String) {
        if name == self.job_compound {
            return;
        }
        if !self.job_compound.is_empty() {
            self.per_compound_jobs
                .insert(self.job_compound.clone(), self.job_snapshot());
        }
        self.job_compound = name;
        self.setup_cluster = 0;
        if let Some(job) = self.per_compound_jobs.get(&self.job_compound).cloned() {
            self.restore_job(job);
        }
    }
    fn cluster_signature(&self, compound: &str) -> Vec<(PathBuf, usize)> {
        let mut signature: Vec<_> = self
            .inputs
            .iter()
            .filter(|input| input.compound == compound)
            .map(|input| (input.source.clone(), input.number))
            .collect();
        signature.sort_by(|a, b| a.1.cmp(&b.1).then_with(|| natural_path_cmp(&a.0, &b.0)));
        signature
    }
    fn accept_setup_result(&mut self, result: SetupResult) {
        let job_count = result.paths.len();
        let automatic = result
            .overlays
            .iter()
            .find(|overlay| {
                overlay.compound == self.job_compound
                    && self
                        .job_snapshot()
                        .clustering
                        .as_ref()
                        .is_some_and(|settings| settings == &overlay.settings)
                    && overlay.signature == self.cluster_signature(&overlay.compound)
            })
            .cloned();
        if let Some(overlay) = automatic {
            let clusters = overlay.groups.len();
            self.cluster_preview = Some(overlay);
            self.setup_cluster = 0;
            self.load_setup_cluster();
            self.status = format!(
                "{job_count} Gaussian input files generated · cluster overlay ready ({clusters})"
            );
        } else {
            self.status = format!("{job_count} Gaussian input files generated");
        }
        self.last_setup = Some(result);
        self.status_error = false;
    }
    fn cluster_preview_current(&self) -> bool {
        let Some(settings) = self.job_snapshot().clustering else {
            return false;
        };
        self.cluster_preview.as_ref().is_some_and(|preview| {
            preview.compound == self.job_compound
                && preview.settings == settings
                && preview.signature == self.cluster_signature(&self.job_compound)
        })
    }
    pub(crate) fn prepare_cluster_preview(&mut self) {
        let Some(settings) = self.job_snapshot().clustering else {
            return;
        };
        let compound = self.job_compound.clone();
        let signature = self.cluster_signature(&compound);
        let mut items: Vec<_> = self
            .inputs
            .iter()
            .filter(|input| input.compound == compound)
            .cloned()
            .collect();
        if items.is_empty() {
            self.error("Choose a loaded compound for the cluster overlay.");
            return;
        }
        let log_was_open = self.show_log;
        self.start("Preparing cluster overlay", move |progress| {
            items.sort_by_key(|input| input.number);
            align_inputs(&mut items)?;
            let groups = cluster(&items, &settings, &progress)?.groups;
            Ok(Completed::ClusterPreview(SetupClusterOverlay {
                compound,
                settings,
                signature,
                items,
                groups,
            }))
        });
        self.show_log = log_was_open;
    }
    fn load_setup_cluster(&mut self) {
        let Some(preview) = &self.cluster_preview else {
            self.setup_viewer.clear();
            return;
        };
        let Some(group) = preview.groups.get(self.setup_cluster) else {
            self.setup_viewer.clear();
            return;
        };
        let molecules: Vec<_> = group
            .iter()
            .filter_map(|&index| preview.items.get(index).map(|item| &item.molecule))
            .collect();
        self.setup_viewer.load_overlay(&molecules);
    }
    fn ensure_setup_cluster_loaded(&mut self) {
        if self.cluster_preview_current() && self.setup_viewer.coordinates.is_empty() {
            self.load_setup_cluster();
        }
    }
    fn generate(&mut self) {
        let items = self.inputs.clone();
        let config = self.config.clone();
        let root =
            (!self.setup_output.trim().is_empty()).then(|| PathBuf::from(self.setup_output.trim()));
        if self
            .input_errors
            .iter()
            .any(|e| e.starts_with("Duplicate compound"))
        {
            self.error("Remove duplicate compound/conformer inputs before generating jobs.");
            return;
        }
        let snapshot = self.job_snapshot();
        let names: BTreeSet<_> = items
            .iter()
            .map(|c| c.compound.clone())
            .filter(|n| self.apply_all || *n == self.job_compound)
            .collect();
        let settings = names.into_iter().map(|n| (n, snapshot.clone())).collect();
        self.start("Generating Gaussian inputs", move |progress| {
            if let Some(root) = root {
                run_setup(&items, &settings, &config, &root, &progress)
            } else {
                run_setup_beside(&items, &settings, &config, &progress)
            }
            .map(Completed::Setup)
        });
    }
    fn analyze(&mut self) {
        let paths = self.log_files.clone();
        let mut settings = self.analysis_settings.clone();
        settings.output_root = if self.analysis_output.trim().is_empty() {
            None
        } else {
            Some(PathBuf::from(self.analysis_output.trim()))
        };
        self.start("Analyzing Gaussian results", move |progress| {
            run_analysis(&paths, &settings, &progress).map(Completed::Analysis)
        });
    }
    pub fn render(&mut self, ui: &mut egui::Ui) {
        let ctx = ui.ctx().clone();
        self.poll(&ctx);
        self.control_rects.clear();
        if self.logo.is_none() {
            self.logo = crate::branding::texture(&ctx).ok();
        }
        if self.startup_ui(ui) {
            return;
        }
        let dropped = ctx.input(|i| {
            i.raw
                .dropped_files
                .iter()
                .map(|f| f.path().to_path_buf())
                .collect::<Vec<_>>()
        });
        if !dropped.is_empty() && self.ready_for_work() {
            self.add_paths(dropped, self.tab == Tab::Setup);
        }
        let app_bar = egui::Panel::top("app_bar").exact_size(44.).show(ui, |ui| {
            ui.add_space(5.);
            ui.horizontal(|ui| {
                let s = ui.selectable_label(
                    self.tab == Tab::Setup,
                    RichText::new("1   Job setup").strong(),
                );
                self.control_rects.insert("setup_tab".into(), s.rect);
                if s.clicked() {
                    self.tab = Tab::Setup;
                }
                let a = ui.selectable_label(
                    self.tab == Tab::Analysis,
                    RichText::new("2   Analysis & 3D view").strong(),
                );
                self.control_rects.insert("analysis_tab".into(), a.rect);
                if a.clicked() {
                    self.tab = Tab::Analysis;
                }

                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    if ui.button("Methodology").clicked() {
                        self.methodology_page = 0;
                        self.methodology_tab = self.tab;
                        self.show_methodology = true;
                    }
                    if ui.button("Configuration").clicked() {
                        self.show_config = true;
                    }
                    if let Some(w) = &self.worker {
                        if ui.button("Cancel").clicked() {
                            w.progress.cancel.store(true, Ordering::Relaxed);
                        }
                        ui.spinner();
                        let worker_status =
                            format!("{} · {:.0}s", w.label, w.started.elapsed().as_secs_f64());
                        ui.add_sized([260., 26.], egui::Label::new(&worker_status).truncate())
                            .on_hover_text(worker_status);
                    } else {
                        ui.add_sized(
                            [260., 26.],
                            egui::Label::new(
                                RichText::new(&self.status).color(if self.status_error {
                                    WARN
                                } else {
                                    ON_DARK
                                }),
                            )
                            .truncate(),
                        )
                        .on_hover_text(&self.status);
                    }

                    ui.separator();
                    let description = if self.tab == Tab::Setup {
                        "Prepare Gaussian NMR calculations from conformer structures"
                    } else {
                        "Analyze calculations, inspect structures, and predict NMR spectra"
                    };
                    let description_response = ui
                        .add_sized(
                            [ui.available_width(), 26.],
                            egui::Label::new(RichText::new(description).color(ON_DARK).size(13.))
                                .truncate(),
                        )
                        .on_hover_text(description);
                    self.control_rects
                        .insert("tab_description".into(), description_response.rect);
                });
            });
        });
        self.control_rects
            .insert("app_bar".into(), app_bar.response.rect);
        egui::Panel::bottom(if self.show_log {
            "run_log_open"
        } else {
            "run_log_closed"
        })
        .resizable(self.show_log)
        .default_size(if self.show_log { 155. } else { 34. })
        .min_size(34.)
        .show(ui, |ui| {
            ui.horizontal(|ui| {
                if ui
                    .selectable_label(
                        self.show_log,
                        if self.show_log {
                            "−  Run log"
                        } else {
                            "+  Run log"
                        },
                    )
                    .clicked()
                {
                    self.show_log = !self.show_log;
                }
                if self.show_log {
                    if ui.small_button("Copy log").clicked() {
                        ui.ctx().copy_text(self.run_log.join("\n"));
                    }
                    if ui.small_button("Clear").clicked() {
                        self.run_log.clear();
                    }
                }
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                    ui.small("Local calculations • Gaussian runs are submitted separately");
                });
            });
            if self.show_log {
                let scroll = ScrollArea::vertical()
                    .auto_shrink([false, false])
                    .scroll_bar_visibility(egui::scroll_area::ScrollBarVisibility::AlwaysVisible)
                    .stick_to_bottom(true)
                    .show(ui, |ui| {
                        ui.set_min_width(ui.available_width());
                        for line in &self.run_log {
                            ui.label(RichText::new(line).monospace().size(12.));
                        }
                    });
                self.control_rects
                    .insert("run_log_scroll".into(), scroll.inner_rect);
            }
        });
        match self.tab {
            Tab::Setup => self.setup_ui(ui),
            Tab::Analysis => self.analysis_ui(ui),
        }
        if self.show_export {
            self.figure_ui(&ctx);
        }
        if self.show_config {
            self.config_ui(&ctx);
        }
        if self.show_methodology {
            self.methodology_ui(&ctx);
        }
        self.spectrum.ui(&ctx, self.window_icon.clone());
    }
    fn setup_ui(&mut self, ui: &mut egui::Ui) {
        let default_panel_width = (ui.available_width() * 0.42).clamp(330., 640.);
        let panel=egui::Panel::right("job_settings").resizable(true).default_size(default_panel_width).size_range(330.0..=820.0).frame(egui::Frame::new().fill(DARK_CENTER).inner_margin(12)).show(ui,|ui|{
          card(ui,|ui|{
            self.control_rects.insert("setup_content".into(),ui.max_rect());
            let height=ui.available_height();
            let parameter_width=(ui.available_width()-130.).clamp(170.,230.);
            ScrollArea::vertical().scroll_bar_visibility(egui::scroll_area::ScrollBarVisibility::AlwaysVisible).id_salt("settings_scroll").max_height((height-185.).max(120.)).show(ui,|ui|{
                section(ui,"Gaussian job settings");
                let names:BTreeSet<_>=self.inputs.iter().map(|c|c.compound.clone()).collect();
                let mut selected_compound=self.job_compound.clone();
                form_row(ui,"Compound",115.,parameter_width,|ui|{
                    ui.add_enabled_ui(!self.apply_all,|ui|{
                        egui::ComboBox::from_id_salt("job_compound").selected_text(if self.job_compound.is_empty(){"No structures loaded"}else{&self.job_compound}).width(parameter_width).show_ui(ui,|ui|{
                            for n in names{ui.selectable_value(&mut selected_compound,n.clone(),n);}
                        }).response
                    }).inner
                });
                self.select_job_compound(selected_compound);
                ui.checkbox(&mut self.apply_all,"Process every loaded compound with these settings");
                if !self.apply_all{
                    ui.small(if self.job_compound.is_empty(){"Choose a compound after loading SDF files.".into()}else{format!("This run processes only {}.",self.job_compound)});
                }
                ui.separator();
                form_row(ui,"Solvent / method",115.,parameter_width,|ui|{
                    egui::ComboBox::from_id_salt("method").width(parameter_width).selected_text(self.config.methods.get(&self.job.method).and_then(|e|e.get("label")).unwrap_or(&self.job.method)).show_ui(ui,|ui|{
                        for (key,entry) in &self.config.methods{ui.selectable_value(&mut self.job.method,key.clone(),entry.get("label").unwrap_or(key));}
                    }).response
                });
                form_row(ui,"Temperature (K)",115.,parameter_width,|ui|ui.add(egui::DragValue::new(&mut self.job.temperature).range(0.01..=10000.).speed(0.1).fixed_decimals(2)));
                form_row(ui,"Machine",115.,parameter_width,|ui|{
                    let before=self.job.machine.clone();
                    let response=egui::ComboBox::from_id_salt("machine").width(parameter_width).selected_text(&self.config.machines[&self.job.machine].label).show_ui(ui,|ui|{
                        for (key,m) in &self.config.machines{ui.selectable_value(&mut self.job.machine,key.clone(),&m.label);}
                    }).response;
                    if before!=self.job.machine{self.job.tier=self.config.machines[&self.job.machine].tiers[0].name.clone();}
                    response
                });
                form_row(ui,"Resources",115.,parameter_width,|ui|{
                    let tiers=&self.config.machines[&self.job.machine].tiers;
                    let text=tiers.iter().find(|t|t.name==self.job.tier).map(|t|format!("{} · {} cores · {}",t.name,t.cores,t.memory)).unwrap_or_default();
                    egui::ComboBox::from_id_salt("tier").width(parameter_width).selected_text(text).show_ui(ui,|ui|{
                        for t in tiers{ui.selectable_value(&mut self.job.tier,t.name.clone(),format!("{} · {} cores · {}",t.name,t.cores,t.memory));}
                    }).response
                });
                section(ui,"Additional calculations");
                let method=&self.job.method;
                let coupling_configured=self.config.supports_job(method,"cc");
                if !coupling_configured{self.job.coupling=false;}
                ui.add_enabled(coupling_configured,egui::Checkbox::new(&mut self.job.coupling,"Coupling constants"))
                    .on_disabled_hover_text("The selected method has no cc_route in the configuration.");
                let selected:Vec<_>=self.inputs.iter().filter(|c|self.apply_all||c.compound==self.job_compound).collect();
                let fluorine_configured=self.config.supports_job(method,"fluorine")&&self.config.supports_scaling(method,"fluorine");
                let nitrogen_configured=self.config.supports_job(method,"nitrogen")&&self.config.supports_scaling(method,"nitrogen");
                let sulfur_configured=self.config.supports_special(method,"csulfur")&&self.config.supports_scaling(method,"sulfur");
                let halogen_configured=self.config.supports_special(method,"chalogen")&&selected.iter().all(|input|halogen_scaling_ready(&self.config,method,&input.molecule));
                for (value,label,required,configured) in [
                    (&mut self.job.fluorine,"Fluorine shifts",vec!["F"],fluorine_configured),
                    (&mut self.job.nitrogen,"Nitrogen shifts",vec!["N"],nitrogen_configured),
                    (&mut self.job.sulfur,"Carbon–sulfur correction",vec!["S"],sulfur_configured),
                    (&mut self.job.halogen,"Carbon–halogen correction",vec!["Cl","Br","I"],halogen_configured)
                ]{
                    let contains_element=!selected.is_empty()&&selected.iter().all(|c|required.iter().any(|e|c.molecule.atoms.iter().any(|a|a.element==*e)));
                    let enabled=contains_element&&configured;
                    if !enabled{*value=false;}
                    let reason=if !configured{"The selected method does not define the required route and scaling constants."}else{"The selected structures do not all contain the required element."};
                    ui.add_enabled(enabled,egui::Checkbox::new(value,label)).on_disabled_hover_text(reason);
                }
                ui.small("Element-specific options apply to every compound in the current run.");
                section(ui,"Output");
                ui.horizontal(|ui|{
                    let width=(ui.available_width()-100.).max(80.);
                    ui.add_sized([width,28.],egui::TextEdit::singleline(&mut self.setup_output).hint_text("Beside the conformer files").desired_width(f32::INFINITY).vertical_align(egui::Align::Center));
                    if ui.button("Choose…").clicked(){self.choose(PickKind::SetupFolder);}
                });
                ui.small("Regeneration replaces this compound’s previous outputs and removes stale files.");
                ui.horizontal_wrapped(|ui|{
                    ui.label("Keep:");
                    ui.checkbox(&mut self.job.keep_split,"Split SDFs");ui.checkbox(&mut self.job.keep_aligned,"Aligned SDFs");ui.checkbox(&mut self.job.keep_clustered,"Clustering output");
                });
            });
            ui.separator();
            ui.horizontal(|ui|{
                ui.strong("Calculation preview");
                if ui.small_button("Copy").clicked()
                    && let Some(c)=self.inputs.iter().find(|c|c.compound==self.job_compound).or(self.inputs.first())
                        && let Ok(text)=preview(&self.config,&self.job_snapshot(),&c.molecule,&c.compound){ui.ctx().copy_text(text);}
            });
            let preview_text=if let Some(c)=self.inputs.iter().find(|c|c.compound==self.job_compound).or(self.inputs.first()){
                preview(&self.config,&self.job_snapshot(),&c.molecule,&c.compound).unwrap_or_else(|e|format!("{e:#}"))
            }else{"Load SDF conformers to preview the Gaussian inputs.\n\nOptimization, frequencies, and C/H NMR are included.\nThe preview and saved files use the same generator.".into()};
            let reserve=50.;
            ScrollArea::both().id_salt("route_preview").max_height((ui.available_height()-reserve).max(70.)).show(ui,|ui|{
                ui.add(egui::Label::new(RichText::new(preview_text).monospace().size(11.5)).wrap_mode(egui::TextWrapMode::Extend).selectable(true));
            });
            ui.add_space(7.);
            let label=if self.apply_all||self.job_compound.is_empty(){"Generate Gaussian inputs".into()}else{format!("Generate inputs · {} only",self.job_compound)};
            let run=ui.add_enabled(self.ready_for_work()&&!self.inputs.is_empty(),egui::Button::new(RichText::new(label).strong().color(Color32::WHITE)).fill(BLUE).min_size(Vec2::new(ui.available_width(),36.)));
            self.control_rects.insert("generate".into(),run.rect);if run.clicked(){self.generate();}
          });
        });
        self.control_rects
            .insert("setup_panel".into(), panel.response.rect);
        egui::CentralPanel::default().frame(egui::Frame::new().fill(DARK_CENTER).inner_margin(12)).show(ui,|ui|{
         card(ui,|ui|{
            let viewport_height=ui.available_height();
            let scroll=ScrollArea::vertical()
                .auto_shrink([false,false])
                .scroll_bar_visibility(egui::scroll_area::ScrollBarVisibility::AlwaysVisible)
                .id_salt("setup_left_scroll")
                .max_height(viewport_height)
                .min_scrolled_height(viewport_height)
                .show(ui,|ui|{
            ui.set_min_width(ui.available_width());
            let content_top=ui.cursor().top();
            section(ui,"Conformer input");
            ui.label("Individual SDFs or a collective conformer ensemble");
            ui.horizontal(|ui|{
                if ui.add_enabled(self.ready_for_work(),egui::Button::new("Add files…")).clicked(){self.choose(PickKind::Sdf);}
                if ui.add_enabled(self.ready_for_work(),egui::Button::new("Add folder…")).clicked(){self.choose(PickKind::SdfFolder);}
                if ui.add_enabled(self.ready_for_work()&&!self.remove_sdf.is_empty(),egui::Button::new("Remove selected")).clicked(){
                    self.setup_files.retain(|p|!self.remove_sdf.contains(p));self.remove_sdf.clear();self.add_paths(vec![],true);
                }
                if ui.add_enabled(self.ready_for_work()&&!self.setup_files.is_empty(),egui::Button::new("Clear")).clicked(){self.setup_files.clear();self.inputs.clear();self.input_errors.clear();self.remove_sdf.clear();self.select_job_compound(String::new());self.cluster_preview=None;self.setup_viewer.clear();}
            });
            ui.checkbox(&mut self.recursive_folders,"Include subfolders when adding a folder");
            let clustering_enabled=self.cluster_mode!="none";
            let file_height=if clustering_enabled{100.}else{(viewport_height-130.).clamp(150.,520.)};
            egui::Frame::group(ui.style()).fill(Color32::WHITE).show(ui,|ui|{
                ui.set_min_width(ui.available_width());
                if self.setup_files.is_empty(){
                    ui.set_min_height(file_height);
                    ui.add_space(18.);ui.colored_label(MUTED,"Drop .sdf files or folders here");ui.small("Single conformers: compound_1.sdf");ui.small("Collective ensembles are split automatically.");
                }else{
                    let row_height=ui.text_style_height(&egui::TextStyle::Body)+4.;
                    ScrollArea::vertical().auto_shrink([false,false]).scroll_bar_visibility(egui::scroll_area::ScrollBarVisibility::AlwaysVisible).id_salt("sdf_files").max_height(file_height).min_scrolled_height(file_height).show_rows(ui,row_height,self.setup_files.len(),|ui,range|{
                        for path in &self.setup_files[range]{
                            let response=ui.selectable_label(self.remove_sdf.contains(path),path.file_name().unwrap_or_default().to_string_lossy()).on_hover_text(path.display().to_string());
                            if response.clicked()&& !self.remove_sdf.insert(path.clone()){self.remove_sdf.remove(path);}
                        }
                    });
                }
            });
            let compounds=self.inputs.iter().map(|c|&c.compound).collect::<BTreeSet<_>>().len();
            ui.label(RichText::new(format!("{} files  ·  {} structures  ·  {compounds} compounds",self.setup_files.len(),self.inputs.len())).strong());
            if !self.input_errors.is_empty(){
                egui::CollapsingHeader::new(format!("{} input issue(s)",self.input_errors.len())).show(ui,|ui|{
                    for error in &self.input_errors{ui.colored_label(WARN,error);}
                });
            }
            ui.small("Conformers are aligned automatically to the lowest-numbered structure.");
            ui.add_space(5.);section(ui,"Conformer clustering");
            ui.horizontal_wrapped(|ui|{
                ui.radio_value(&mut self.cluster_mode,"none".into(),"None · use all");
                ui.radio_value(&mut self.cluster_mode,"shifts".into(),"Chemical shifts · τ 0.40");
                ui.radio_value(&mut self.cluster_mode,"all_nmr".into(),"All NMR · τ 0.15");
                ui.radio_value(&mut self.cluster_mode,"custom".into(),"Custom");
            });
            if self.cluster_mode=="custom"{
                egui::Grid::new("cluster_custom").num_columns(4).show(ui,|ui|{
                    ui.label("Linkage");combo(ui,"linkage",&mut self.custom_cluster.linkage,&["ward","complete","average","single","weighted","all"]);
                    ui.label("τ");ui.add(egui::DragValue::new(&mut self.custom_cluster.tau).range(0.0..=1.0).speed(0.01).fixed_decimals(2));ui.end_row();
                    ui.label("Selection");combo(ui,"selection",&mut self.custom_cluster.selection,&["lowest_energy","tiered","medoid"]);
                    ui.label("Dihedral weight");ui.add(egui::DragValue::new(&mut self.custom_cluster.dihedral_weight).range(0.0..=100.0).speed(0.01));ui.end_row();
                });
            }
            if let Some(result)=&self.last_setup{
                ui.horizontal(|ui|{
                    ui.colored_label(BLUE,format!("{} job files ready to submit",result.paths.len()));
                    if ui.small_button("Open output folder").clicked()&& let Some(p)=result.paths.first().and_then(|p|p.parent()){open_path(p);}
                });
            }
            if self.cluster_mode=="none"{
                if self.cluster_preview.take().is_some(){self.setup_viewer.clear();self.setup_cluster=0;}
                ui.small("Every supplied conformer is retained; a cluster overlay is available when a clustering mode is selected.");
            }else{
                ui.separator();
                ui.horizontal_wrapped(|ui|{
                    let heading=control_cell(ui,132.,|ui|ui.strong("3D cluster overlay"));
                    self.control_rects.insert("cluster_overlay_heading".into(),heading.rect);
                    let names=self.inputs.iter().map(|input|input.compound.clone()).collect::<BTreeSet<_>>();
                    let mut compound=self.job_compound.clone();
                    let compound_control=control_cell(ui,150.,|ui|{
                        egui::ComboBox::from_id_salt("overlay_compound").width(140.).selected_text(if compound.is_empty(){"Choose compound"}else{&compound}).show_ui(ui,|ui|{
                            for name in names{ui.selectable_value(&mut compound,name.clone(),name);}
                        }).response
                    });
                    self.control_rects.insert("cluster_overlay_compound".into(),compound_control.rect);
                    self.select_job_compound(compound);
                    let current=self.cluster_preview_current();
                    // Switching to another compound or temporarily changing a
                    // clustering setting clears the stale scene.  If the user
                    // returns to the exact preview snapshot, restore its first
                    // cluster instead of showing an empty "current" viewer.
                    if current{self.ensure_setup_cluster_loaded();}
                    let label=if current{"Refresh"}else{"Build overlay"};
                    let build=control_cell(ui,112.,|ui|ui.add_enabled(self.ready_for_work()&&!self.job_compound.is_empty(),egui::Button::new(label)));
                    self.control_rects.insert("cluster_overlay_build".into(),build.rect);
                    if build.clicked(){self.prepare_cluster_preview();}
                    if current{
                        let preview=self.cluster_preview.as_ref().unwrap();
                        let mut selected=self.setup_cluster.min(preview.groups.len().saturating_sub(1));
                        let selected_text=preview.groups.get(selected).map(|group|format!("Cluster {} · {} conformers",selected+1,group.len())).unwrap_or_else(||"No clusters".into());
                        let cluster_control=control_cell(ui,210.,|ui|{
                            egui::ComboBox::from_id_salt("overlay_cluster").width(200.).selected_text(selected_text).show_ui(ui,|ui|{
                                for (index,group) in preview.groups.iter().enumerate(){ui.selectable_value(&mut selected,index,format!("Cluster {} · {} conformers",index+1,group.len()));}
                            }).response
                        });
                        self.control_rects.insert("cluster_overlay_cluster".into(),cluster_control.rect);
                        if selected!=self.setup_cluster{self.setup_cluster=selected;self.load_setup_cluster();}
                    }
                });
                if self.cluster_preview_current(){
                    if let Some(preview)=&self.cluster_preview
                        && let Some(group)=preview.groups.get(self.setup_cluster){
                        let members=group.iter().filter_map(|&index|preview.items.get(index).map(|item|item.number.to_string())).collect::<Vec<_>>().join(", ");
                        ui.small(format!("Aligned conformers {members}. Drag to rotate · scroll to zoom · right-drag to pan · double-click to reset."));
                    }
                    let used=ui.cursor().top()-content_top;
                    let size=Vec2::new(ui.available_width(),(viewport_height-used-2.).max(SETUP_VIEWER_MIN_HEIGHT));
                    let viewer=self.setup_viewer.ui(ui,size);
                    self.control_rects.insert("setup_cluster_viewer".into(),viewer.rect);
                }else{
                    self.setup_viewer.clear();
                    ui.small("Build the overlay to align, cluster, and superimpose every conformer in the selected cluster. Rebuild after changing clustering settings or inputs.");
                    self.setup_viewer.empty_message="Build the cluster overlay to display its aligned conformers".into();
                    let used=ui.cursor().top()-content_top;
                    let size=Vec2::new(ui.available_width(),(viewport_height-used-2.).max(SETUP_VIEWER_MIN_HEIGHT));
                    let viewer=self.setup_viewer.ui(ui,size);
                    self.control_rects.insert("setup_cluster_viewer".into(),viewer.rect);
                }
            }
            });
            self.control_rects.insert("setup_scroll_viewport".into(),scroll.inner_rect);
            self.control_rects.insert("setup_scroll_content".into(),egui::Rect::from_min_size(scroll.inner_rect.min,scroll.content_size));
         });
        });
    }
    fn analysis_ui(&mut self, ui: &mut egui::Ui) {
        let default_panel_width = (ui.available_width() * 0.33).clamp(320., 500.);
        let panel=egui::Panel::right("analysis_settings").resizable(true).default_size(default_panel_width).size_range(320.0..=650.0).frame(egui::Frame::new().fill(DARK_CENTER).inner_margin(12)).show(ui,|ui|{
          card(ui,|ui|{
            self.control_rects.insert("analysis_content".into(),ui.max_rect());
            ScrollArea::vertical().scroll_bar_visibility(egui::scroll_area::ScrollBarVisibility::AlwaysVisible).max_height(ui.available_height()-52.).id_salt("analysis_controls").show(ui,|ui|{
                section(ui,"Gaussian output");
                ui.horizontal(|ui|{
                    if ui.add_enabled(self.ready_for_work(),egui::Button::new("Add logs…")).clicked(){self.choose(PickKind::Logs);}
                    if ui.add_enabled(self.ready_for_work(),egui::Button::new("Folder…")).clicked(){self.choose(PickKind::LogsFolder);}
                    if ui.add_enabled(self.ready_for_work(),egui::Button::new("Clear")).clicked(){self.log_files.clear();self.remove_logs.clear();}
                });
                ui.checkbox(&mut self.recursive_folders,"Include subfolders when adding a folder");
                egui::Frame::group(ui.style()).fill(Color32::WHITE).show(ui,|ui|{
                    ui.set_min_width(ui.available_width());
                    if self.log_files.is_empty(){ui.set_min_height(60.);ui.colored_label(MUTED,"Drop completed Gaussian .log files here");}
                    else{
                        let row_height=ui.text_style_height(&egui::TextStyle::Body)+4.;
                        ScrollArea::vertical().auto_shrink([false,false]).scroll_bar_visibility(egui::scroll_area::ScrollBarVisibility::AlwaysVisible).id_salt("log_files").max_height(130.).min_scrolled_height(60.).show_rows(ui,row_height,self.log_files.len(),|ui,range|{
                        for path in &self.log_files[range]{
                            if ui.selectable_label(self.remove_logs.contains(path),path.file_name().unwrap_or_default().to_string_lossy()).on_hover_text(path.display().to_string()).clicked()
                                && !self.remove_logs.insert(path.clone()){self.remove_logs.remove(path);}
                        }
                        });
                    }
                });
                if !self.remove_logs.is_empty() && ui.button("Remove selected logs").clicked(){self.log_files.retain(|p|!self.remove_logs.contains(p));self.remove_logs.clear();}
                let mut names=BTreeMap::<String,usize>::new();let mut unnamed=0;
                for p in &self.log_files{if let Some((n,_))=number_name(p){*names.entry(base_compound(&n).into()).or_default()+=1;}else{unnamed+=1;}}
                ui.label(format!("{} files · {} compounds",self.log_files.len(),names.len()));
                for (name,count) in &names{ui.small(format!("{name}: {count} log file(s)"));}
                if unnamed>0{ui.colored_label(WARN,format!("{unnamed} filename(s) do not match compound_number.log"));}
                section(ui,"Analysis options");
                ui.label(self.analysis_settings.temperature_override.map(|t| format!("Temperature override: {t:.2} K")).unwrap_or_else(|| "Temperature is read from each compound’s logs.".into()));
                ui.checkbox(&mut self.analysis_settings.dedup,"Deduplicate conformers");
                ui.label(RichText::new("Duplicate minima must agree within ΔG 0.20 kcal/mol, symmetry-corrected RMSD 0.10 Å, and maximum atom displacement 0.15 Å. When comparable frequency data are available, frequency RMSD / maximum difference must also be within 2.0 / 3.0 cm^-1.").small().color(MUTED));
                section(ui,"Outputs to produce");
                form_row(ui,"For",36.,220.,|ui|{
                    egui::ComboBox::from_id_salt("output_compound").selected_text(if self.output_compound.is_empty(){"All compounds"}else{&self.output_compound}).show_ui(ui,|ui|{
                        ui.selectable_value(&mut self.output_compound,String::new(),"All compounds");
                        for name in names.keys(){ui.selectable_value(&mut self.output_compound,name.clone(),name);}
                    }).response
                });
                let defaults=self.analysis_settings.outputs.clone();
                let options=if self.output_compound.is_empty(){&mut self.analysis_settings.outputs}else{self.analysis_settings.per_compound.entry(self.output_compound.clone()).or_insert(defaults)};
                ui.horizontal(|ui|{
                    if ui.small_button("All").clicked(){options.set_all(true);}
                    if ui.small_button("None").clicked(){options.set_all(false);}
                });
                for (key,label) in OUTPUT_KEYS {let v=options.0.entry(key.into()).or_default();ui.checkbox(v,label);}
                if !self.output_compound.is_empty() && ui.small_button("Use shared output settings").clicked(){self.analysis_settings.per_compound.remove(&self.output_compound);self.output_compound.clear();}
                ui.small("Export choices do not change the calculations. The viewer remains available for the current run.");
                section(ui,"Save results to");
                ui.horizontal(|ui|{
                    let width=(ui.available_width()-100.).max(80.);
                    ui.add_sized([width,28.],egui::TextEdit::singleline(&mut self.analysis_output).hint_text("Beside the log files").desired_width(f32::INFINITY).vertical_align(egui::Align::Center));
                    if ui.button("Choose…").clicked(){self.choose(PickKind::AnalysisFolder);}
                });
                ui.small("Each compound gets a fresh result folder. Previous contents are replaced.");
            });
            ui.add_space(6.);
            let run=ui.add_enabled(self.ready_for_work()&&!self.log_files.is_empty(),egui::Button::new(RichText::new("Run NMR analysis").strong().color(Color32::WHITE)).fill(BLUE).min_size(Vec2::new(ui.available_width(),36.)));
            self.control_rects.insert("analyze".into(),run.rect);if run.clicked(){self.analyze();}
          });
        });
        self.control_rects
            .insert("analysis_panel".into(), panel.response.rect);
        egui::CentralPanel::default().frame(egui::Frame::new().fill(DARK_CENTER).inner_margin(12)).show(ui,|ui|{
          card(ui,|ui|{
            ui.horizontal(|ui|{
                section(ui,"Structure and predicted shifts");
                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center),|ui|{
                    if ui.small_button("Open results…").clicked(){self.choose(PickKind::ResultsFolder);}
                    let export=ui.add_enabled(!self.viewer.coordinates.is_empty() && self.figure_result.is_none(),egui::Button::new("Export image…").small());
                    self.control_rects.insert("export_image".into(),export.rect);
                    if export.clicked(){self.figure_options.labels=self.viewer.label_mode!=LabelMode::None;self.show_export=true;}
                });
            });
            if let Some(analysis)=&self.analysis{
                if !analysis.compounds.is_empty(){
                    self.viewer_compound=self.viewer_compound.min(analysis.compounds.len()-1);
                    let before=self.viewer_compound;
                    let single_row=ui.available_width()>=735.;
                    egui::Grid::new("analysis_viewer_controls").spacing([8.,2.]).show(ui,|ui|{
                        let compound_control=control_cell(ui,170.,|ui|{
                            egui::ComboBox::from_id_salt("viewer_compound").selected_text(format!("Compound · {}",analysis.compounds[self.viewer_compound].name)).width(160.).show_ui(ui,|ui|{
                                for (idx,c) in analysis.compounds.iter().enumerate(){ui.selectable_value(&mut self.viewer_compound,idx,&c.name);}
                            }).response
                        });
                        self.control_rects.insert("viewer_compound_control".into(),compound_control.rect);
                        if before!=self.viewer_compound{self.viewer_conformer=0;}
                        let compound=&analysis.compounds[self.viewer_compound];
                        self.viewer_conformer=self.viewer_conformer.min(compound.conformers.len().saturating_sub(1));
                        let conformer_control=control_cell(ui,170.,|ui|{
                            egui::ComboBox::from_id_salt("viewer_conformer").selected_text(format!("Conformer {}",compound.conformers[self.viewer_conformer].number)).width(160.).show_ui(ui,|ui|{
                                for (i,c) in compound.conformers.iter().enumerate(){
                                    let text=format!("{}{}",c.number,if i==0 && c.energy.is_some(){" · lowest energy"}else{""});
                                    ui.selectable_value(&mut self.viewer_conformer,i,text);
                                }
                            }).response
                        });
                        self.control_rects.insert("viewer_conformer_control".into(),conformer_control.rect);
                        if !single_row{ui.end_row();}
                        let labels=control_cell(ui,148.,|ui|{
                            egui::ComboBox::from_id_salt("viewer_label_mode")
                                .selected_text(format!("Labels · {}",self.viewer.label_mode.name()))
                                .width(138.)
                                .show_ui(ui,|ui|{
                                    for mode in [LabelMode::Shifts,LabelMode::AtomNumbers,LabelMode::None]{
                                        ui.selectable_value(&mut self.viewer.label_mode,mode,mode.name());
                                    }
                                }).response
                        });
                        self.control_rects.insert("viewer_labels".into(),labels.rect);
                        let reset=control_cell(ui,88.,|ui|{
                            let response=ui.small_button("Reset view");
                            if response.clicked(){self.viewer.reset();}
                            response
                        });
                        self.control_rects.insert("viewer_reset".into(),reset.rect);
                        let spectra = control_cell(ui,112.,|ui|ui.button("NMR spectra…").on_hover_text("Open predicted NMR spectra"));
                        self.control_rects.insert("spectra".into(), spectra.rect);
                        if spectra.clicked() {self.spectrum.open_compound(compound,ui.ctx());}
                        ui.end_row();
                    });
                    let c=&analysis.compounds[self.viewer_compound];let conformer=&c.conformers[self.viewer_conformer];
                    if self.viewer_selection!=Some((self.viewer_compound,self.viewer_conformer)){
                        let labels=c.shifts.iter().map(|(&i,&v)|(i,format!("{v:.2}"))).collect();
                        self.viewer.load(&conformer.molecule,labels);self.viewer_selection=Some((self.viewer_compound,self.viewer_conformer));
                    }
                    let energy=conformer.relative.map(|v|format!("ΔG {v:.3} kcal/mol")).unwrap_or("Gibbs energy unavailable".into());
                    ui.colored_label(MUTED,format!("{} atoms · {} conformers · {} · population {:.2}%",c.structure.atoms.len(),c.conformers.len(),energy,conformer.population*100.));
                }
            }else{
                ui.label("Weighted chemical shifts appear on the optimized geometry after analysis.");
                ui.small("You can also reopen an existing result folder with SDF files and a PyMOL label script.");
            }
            let height=(ui.available_height()-106.).max(160.);
            self.viewer.analysis_ui(ui,Vec2::new(ui.available_width(),height));
            ui.small("Drag to rotate · scroll to zoom · right-drag to pan · middle-click or point + Right Shift to measure · double-click to reset");
            ui.horizontal_wrapped(|ui|{
                ui.colored_label(MUTED,viewer_measurement_text(&self.viewer));
                if !self.viewer.selected_atoms.is_empty() && ui.small_button("Clear selection").clicked(){self.viewer.selected_atoms.clear();}
            });
            ui.small(match self.viewer.label_mode{
                LabelMode::Shifts=>"Gold labels: Boltzmann-weighted shifts after chemical-equivalence averaging (ppm).",
                LabelMode::AtomNumbers=>"Gold labels: one-based atom numbers used by the input, analysis, and exported data.",
                LabelMode::None=>"Labels are hidden; choose shift values or atom numbers from the Labels menu.",
            });
            if let Some(result)=&self.analysis
                && let Some(c)=result.compounds.get(self.viewer_compound){
                    ui.horizontal(|ui|{
                        if ui.add_enabled(c.directory.is_dir(),egui::Button::new("Open result folder").small()).clicked(){open_path(&c.directory);}
                        if ui.small_button("Copy shifts").clicked(){ui.ctx().copy_text(shifts_text(&c.shifts,&c.structure,&c.equivalence,"Weighted Chemical Shifts (ppm):"));}
                        ui.label(if c.logs.is_empty(){"Reopened results · see the saved analysis report for run details".into()}else{format!("{} duplicate minima removed",c.dedup.duplicates.len())});
                    });
                }
          });
        });
    }
    fn config_ui(&mut self, ctx: &egui::Context) {
        let mut open = true;
        egui::Window::new("Methods and machines").open(&mut open).default_size([900.,650.]).show(ctx,|ui|{
          card(ui,|ui|{
            ui.label(self.config_path.display().to_string());
            ui.small("Add [method:NAME], [basis:NAME], and [machine:NAME] sections. Each method keeps functional/basis placeholders, complete routes, special-job settings, C/H/F/N/correction scaling, scaling provenance, and separate sulfur/halogen calculation references together. Multiline basis blocks use triple quotes. Analysis reads the exact scaling serialized into completed Gaussian titles.");
            ScrollArea::both().max_height(510.).show(ui,|ui|{
                ui.add(egui::TextEdit::multiline(&mut self.config_text).code_editor().desired_rows(28).desired_width(1100.));
            });
            ui.horizontal(|ui|{
                if ui.add_enabled(self.ready_for_work(),egui::Button::new("Save and reload")).clicked(){
                    match Config::parse(&self.config_text).and_then(|config|{atomic_write(&self.config_path,&self.config_text)?;Ok(config)}){
                        Ok(config)=>{self.config=config;self.normalize_profile();self.status="Configuration saved".into();self.status_error=false;}
                        Err(e)=>self.error(e)
                    }
                }
                if ui.button("Reload from file").clicked(){
                    match Config::load(&self.config_path){
                        Ok(c)=>{self.config=c;self.config_text=std::fs::read_to_string(&self.config_path).unwrap_or_default();self.normalize_profile();}
                        Err(e)=>self.error(e)
                    }
                }
            });
            for problem in &self.config.problems{ui.colored_label(WARN,problem);}
          });
        });
        self.show_config = open;
    }
    fn normalize_profile(&mut self) {
        if !self.config.methods.contains_key(&self.job.method) {
            self.job.method = self.config.methods.keys().next().unwrap().clone();
        }
        if !self.config.machines.contains_key(&self.job.machine) {
            self.job.machine = self.config.machines.keys().next().unwrap().clone();
        }
        if !self.config.machines[&self.job.machine]
            .tiers
            .iter()
            .any(|t| t.name == self.job.tier)
        {
            self.job.tier = self.config.machines[&self.job.machine].tiers[0]
                .name
                .clone();
        }
    }
    pub fn begin_startup(&mut self) {
        self.startup = Startup::Splash(None);
    }
    fn startup_ui(&mut self, ui: &mut egui::Ui) -> bool {
        let ctx = ui.ctx().clone();
        match self.startup {
            Startup::Workspace => false,
            Startup::Splash(since) => {
                let since = since.unwrap_or_else(Instant::now);
                self.startup = Startup::Splash(Some(since));
                if since.elapsed() >= std::time::Duration::from_millis(1500) {
                    self.startup = Startup::Chooser;
                    ctx.send_viewport_cmd(egui::ViewportCommand::Decorations(true));
                    ctx.send_viewport_cmd(egui::ViewportCommand::Resizable(true));
                    ctx.send_viewport_cmd(egui::ViewportCommand::MinInnerSize(Vec2::new(
                        760., 520.,
                    )));
                    ctx.send_viewport_cmd(egui::ViewportCommand::Maximized(true));
                    ctx.request_repaint();
                }
                egui::CentralPanel::default()
                    .frame(egui::Frame::new().fill(Color32::BLACK).inner_margin(0))
                    .show(ui, |ui| {
                        let rect = ui.max_rect();
                        if let Some(logo) = &self.logo {
                            ui.painter().image(
                                logo.id(),
                                rect,
                                egui::Rect::from_min_max(egui::Pos2::ZERO, egui::Pos2::new(1., 1.)),
                                Color32::WHITE,
                            );
                        }
                    });
                ctx.request_repaint_after(std::time::Duration::from_millis(30));
                true
            }
            Startup::Chooser => {
                egui::CentralPanel::default().frame(egui::Frame::new().fill(DARK_PANEL).inner_margin(28)).show(ui,|ui|{
                    ui.add_space((ui.available_height()*0.08).max(10.));
                    ui.vertical_centered(|ui|{
                        if let Some(logo)=&self.logo{ui.add(egui::Image::new((logo.id(),Vec2::splat(140.))));}
                        ui.add_space(9.);ui.label(RichText::new("TENSOR").size(34.).strong().color(Color32::from_rgb(0,112,126)));
                        ui.label(RichText::new("Prepare Gaussian calculations or explore completed NMR predictions.").color(ON_DARK));
                        let credit=ui.label(RichText::new(DEVELOPMENT_CREDIT).small().color(Color32::from_rgb(166,181,196)));
                        self.control_rects.insert("development_credit".into(),credit.rect);
                        ui.add_space(15.);ui.label(RichText::new("Choose where to begin").size(22.).strong().color(ON_DARK));ui.add_space(12.);
                    });
                    let wide=ui.available_width()>760.;let card_width=if wide{335.}else{ui.available_width().min(420.)};
                    let mut tile=|ui:&mut egui::Ui,tab:Tab,title:&str,body:&str,color:Color32|{
                        ui.allocate_ui_with_layout(Vec2::new(card_width,200.),egui::Layout::top_down(egui::Align::Min),|ui|{
                            egui::Frame::new().fill(Color32::WHITE).stroke(egui::Stroke::new(1.,Color32::from_rgb(206,219,225))).corner_radius(14).inner_margin(22).show(ui,|ui|{
                                ui.style_mut().visuals = egui::Visuals::light();
                                ui.set_width(card_width-44.);
                                let button=ui.add_sized([card_width-44.,74.],egui::Button::new(RichText::new(title).size(21.).strong().color(Color32::WHITE)).fill(color));
                                self.control_rects.insert(if tab==Tab::Setup{"choose_setup"}else{"choose_analysis"}.into(),button.rect);
                                if button.clicked(){self.tab=tab;self.startup=Startup::Workspace;}
                                ui.add_space(10.);ui.label(body);
                            });
                        });
                    };
                    if wide{
                        ui.horizontal(|ui|{
                            ui.add_space(((ui.available_width()-card_width*2.-20.)/2.).max(0.));
                            tile(ui,Tab::Setup,"Job setup","Load conformers, select calculation settings, cluster structures, and prepare Gaussian jobs.",BLUE);
                            ui.add_space(12.);
                            tile(ui,Tab::Analysis,"Analysis & 3D view","Parse completed calculations, inspect predictions, and export molecular figures.",Color32::from_rgb(153,43,59));
                        });
                    }else{
                        tile(ui,Tab::Setup,"Job setup","Prepare Gaussian calculations from conformer structures.",BLUE);
                        tile(ui,Tab::Analysis,"Analysis & 3D view","Process results and view predicted shifts in 3D.",Color32::from_rgb(153,43,59));
                    }
                    ui.add_space(18.);ui.vertical_centered(|ui|{ui.colored_label(ON_DARK,"Use the numbered tabs to switch later; your loaded files and settings stay available.");});
                });
                true
            }
        }
    }
    fn methodology_ui(&mut self, ctx: &egui::Context) {
        if self.methodology_tab != self.tab {
            self.methodology_tab = self.tab;
            self.methodology_page = 0;
        }
        let setup = self.methodology_tab == Tab::Setup;
        let title = if setup {
            "Job setup — Methodology"
        } else {
            "Analysis & 3D view — Methodology"
        };
        let pages = if setup {
            crate::methodology::SETUP
        } else {
            crate::methodology::ANALYSIS
        };
        self.methodology_page = self.methodology_page.min(pages.len() - 1);
        let mut close = false;
        ctx.show_viewport_immediate(
            egui::ViewportId::from_hash_of("tensor-methodology"),
            methodology_viewport_builder(title, self.window_icon.clone()),
            |ui, _| {
                if ui.input(|i| i.viewport().close_requested()) {
                    close = true;
                }
                egui::Panel::left("methodology_sections")
                    .exact_size(208.)
                    .frame(egui::Frame::new().fill(DARK_PANEL).inner_margin(15))
                    .show(ui, |ui| {
                        ui.label(
                            RichText::new("Methodology")
                                .size(20.)
                                .strong()
                                .color(ON_DARK),
                        );
                        ui.label(
                            RichText::new(if setup {
                                "Job setup"
                            } else {
                                "Analysis & 3D view"
                            })
                            .small()
                            .color(ON_DARK),
                        );
                        ui.separator();
                        ScrollArea::vertical().show(ui, |ui| {
                            for (i, (name, _)) in pages.iter().enumerate() {
                                ui.selectable_value(&mut self.methodology_page, i, *name);
                            }
                        });
                    });
                egui::CentralPanel::default()
                    .frame(egui::Frame::new().fill(DARK_CENTER).inner_margin(14))
                    .show(ui, |ui| {
                        card(ui, |ui| {
                            ScrollArea::vertical().show(ui, |ui| {
                                ui.heading(pages[self.methodology_page].0);
                                ui.add_space(12.);
                                for paragraph in pages[self.methodology_page].1.split("\n\n") {
                                    ui.label(paragraph);
                                    ui.add_space(10.);
                                }
                            });
                        });
                    });
            },
        );
        if close {
            self.show_methodology = false;
        }
    }
    fn figure_ui(&mut self, ctx: &egui::Context) {
        let mut open = true;
        let mut save = false;
        if self.viewer.label_mode == LabelMode::None {
            self.figure_options.labels = false;
        }
        egui::Window::new("Export molecular figure").open(&mut open).collapsible(false).default_size([460.,340.]).show(ctx,|ui|{
          card(ui,|ui|{
            ui.label("Export the current orientation, framing, and aspect ratio.");
            ui.horizontal(|ui|{
                ui.label("Format");
                for (format,label) in [(crate::figure::Format::Png,"PNG"),(crate::figure::Format::Svg,"SVG"),(crate::figure::Format::Pdf,"PDF")]{ui.selectable_value(&mut self.figure_options.format,format,label);}
            });
            egui::Grid::new("figure_dimensions").num_columns(2).show(ui,|ui|{
                ui.label("Pixel width");ui.add(egui::DragValue::new(&mut self.figure_options.width).range(128..=6000).speed(50));ui.end_row();
                ui.label("DPI");ui.add(egui::DragValue::new(&mut self.figure_options.dpi).range(72..=1200));ui.end_row();
            });
            ui.checkbox(&mut self.figure_options.transparent,"Transparent background");
            ui.add_enabled(self.viewer.label_mode!=LabelMode::None,egui::Checkbox::new(&mut self.figure_options.labels,format!("Include current {}",self.viewer.label_description())));
            match self.figure_options.dimensions(&self.viewer){
                Ok((w,h))=>{ui.small(format!("{w} × {h} pixels · {:.2} × {:.2} inches at {} DPI",w as f64/self.figure_options.dpi as f64,h as f64/self.figure_options.dpi as f64,self.figure_options.dpi));},
                Err(error)=>{ui.colored_label(WARN,error.to_string());}
            }
            ui.add_space(7.);ui.small("All formats use the same high-resolution depth-tested rendering; SVG and PDF retain physical size and transparency.");
            ui.add_space(12.);
            save=ui.add_enabled(self.figure_result.is_none() && self.figure_options.dimensions(&self.viewer).is_ok(),egui::Button::new("Save image…")).clicked();
          });
        });
        self.show_export = open;
        if save {
            self.show_export = false;
            let viewer = self.viewer.clone();
            let options = self.figure_options.clone();
            let filename = self
                .analysis
                .as_ref()
                .and_then(|a| a.compounds.get(self.viewer_compound))
                .map(|c| {
                    format!(
                        "{}_{}_structure.{}",
                        c.name,
                        c.conformers[self.viewer_conformer].number,
                        options.format.extension()
                    )
                })
                .unwrap_or_else(|| format!("tensor-structure.{}", options.format.extension()));
            let directory = self
                .analysis
                .as_ref()
                .and_then(|a| a.compounds.get(self.viewer_compound))
                .map(|c| c.directory.clone())
                .filter(|p| p.is_dir())
                .unwrap_or_else(|| std::env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));
            let (sender, receiver) = mpsc::channel();
            self.figure_result = Some(receiver);
            self.status = "Choose where to save the molecular figure".into();
            std::thread::spawn(move || {
                let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(
                    || -> Result<Option<PathBuf>> {
                        let path = rfd::FileDialog::new()
                            .set_title("Export TENSOR molecular figure")
                            .set_directory(directory)
                            .set_file_name(filename)
                            .add_filter(
                                options.format.extension().to_uppercase(),
                                &[options.format.extension()],
                            )
                            .save_file();
                        match path {
                            Some(path) => {
                                Ok(Some(crate::figure::export(&viewer, &options, &path)?))
                            }
                            None => Ok(None),
                        }
                    },
                ));
                let result = match outcome {
                    Ok(result) => result.map_err(|e| format!("{e:#}")),
                    Err(_) => Err("Figure export stopped unexpectedly".into()),
                };
                let _ = sender.send(result);
            });
        }
    }
    fn accept_results(&mut self, result: AnalysisResult) {
        self.analysis = Some(result);
        self.spectrum = crate::spectrum_ui::SpectrumWindow::default();
        self.viewer_compound = 0;
        self.viewer_conformer = 0;
        self.viewer_selection = None;
        self.tab = Tab::Analysis;
        self.demo = false;
        self.status_error = false;
    }
    pub fn open_results(&mut self, root: &Path) -> Result<()> {
        self.accept_results(read_saved_results(root)?);
        self.status = "Saved results loaded".into();
        Ok(())
    }
}
impl eframe::App for Workbench {
    fn clear_color(&self, visuals: &egui::Visuals) -> [f32; 4] {
        if matches!(self.startup, Startup::Splash(_)) {
            [0., 0., 0., 1.]
        } else {
            egui::Rgba::from(visuals.panel_fill).to_array()
        }
    }
    fn ui(&mut self, ui: &mut egui::Ui, _: &mut eframe::Frame) {
        self.render(ui);
    }
}
fn section(ui: &mut egui::Ui, title: &str) {
    ui.add_space(3.);
    ui.label(RichText::new(title).strong().size(16.).color(BLUE));
}
fn viewer_measurement_text(viewer: &Viewer) -> String {
    let atoms = viewer.selected_atom_names().join(" → ");
    match viewer.selection_measurement() {
        None => "No atoms selected · middle-click, or point and press Right Shift, on up to four atom centers".into(),
        Some(SelectionMeasurement::Atom(_)) => {
            format!("Selected {atoms} · select another atom for a distance")
        }
        Some(SelectionMeasurement::Distance { angstrom, .. }) => {
            format!("{atoms} · distance {angstrom:.3} Å")
        }
        Some(SelectionMeasurement::Angle { degrees, .. }) => {
            format!("{atoms} · angle {degrees:.2}°")
        }
        Some(SelectionMeasurement::Dihedral { degrees, .. }) => {
            format!("{atoms} · dihedral {degrees:.2}°")
        }
        Some(SelectionMeasurement::NotConnected) => format!(
            "{atoms} · select bonded atoms in sequence to calculate an {}",
            if viewer.selected_atoms.len() == 3 {
                "angle"
            } else {
                "dihedral"
            }
        ),
        Some(SelectionMeasurement::Degenerate) => {
            format!("{atoms} · measurement is undefined for this geometry")
        }
    }
}
fn halogen_scaling_ready(config: &Config, method: &str, molecule: &Molecule) -> bool {
    let adjacency = molecule.adjacency();
    let mut found = false;
    for (atom, neighbors) in molecule.atoms.iter().zip(adjacency) {
        if atom.element != "C" {
            continue;
        }
        let halogens: Vec<_> = neighbors
            .iter()
            .filter_map(
                |&neighbor| match molecule.atoms[neighbor].element.as_str() {
                    "Cl" => Some((1, "Cl")),
                    "Br" => Some((2, "Br")),
                    "I" => Some((3, "I")),
                    _ => None,
                },
            )
            .collect();
        let Some((_, heaviest)) = halogens.iter().max() else {
            continue;
        };
        found = true;
        if !config
            .halogen_scaling(method, heaviest, halogens.len())
            .is_ok_and(|scaling| scaling.is_some())
        {
            return false;
        }
    }
    found
}
fn control_cell<R>(ui: &mut egui::Ui, width: f32, add: impl FnOnce(&mut egui::Ui) -> R) -> R {
    ui.scope(|ui| {
        ui.style_mut().spacing.interact_size.y = 28.;
        ui.allocate_ui_with_layout(
            Vec2::new(width, 30.),
            egui::Layout::left_to_right(egui::Align::Center),
            add,
        )
        .inner
    })
    .inner
}
fn form_row<R>(
    ui: &mut egui::Ui,
    label: &str,
    label_width: f32,
    control_width: f32,
    add: impl FnOnce(&mut egui::Ui) -> R,
) -> R {
    ui.horizontal(|ui| {
        control_cell(ui, label_width, |ui| ui.label(label));
        control_cell(ui, control_width, add)
    })
    .inner
}
fn card<R>(ui: &mut egui::Ui, add: impl FnOnce(&mut egui::Ui) -> R) -> R {
    egui::Frame::new()
        .fill(Color32::WHITE)
        .stroke(egui::Stroke::new(1., Color32::from_rgb(204, 212, 221)))
        .corner_radius(10)
        .inner_margin(14)
        .show(ui, |ui| {
            ui.style_mut().visuals = egui::Visuals::light();
            ui.set_min_width(ui.available_width());
            ui.set_min_height(ui.available_height());
            add(ui)
        })
        .inner
}
fn combo(ui: &mut egui::Ui, id: &str, value: &mut String, options: &[&str]) {
    egui::ComboBox::from_id_salt(id)
        .selected_text(value.as_str())
        .show_ui(ui, |ui| {
            for &v in options {
                ui.selectable_value(value, v.into(), v);
            }
        });
}
fn open_path(path: &Path) {
    #[cfg(target_os = "windows")]
    let _ = std::process::Command::new("explorer").arg(path).spawn();
    #[cfg(target_os = "macos")]
    let _ = std::process::Command::new("open").arg(path).spawn();
    #[cfg(all(unix, not(target_os = "macos")))]
    let _ = std::process::Command::new("xdg-open").arg(path).spawn();
}

fn read_saved_results(root: &Path) -> Result<AnalysisResult> {
    let dirs = if root.join("Conformer SDF Files").is_dir() {
        vec![root.to_path_buf()]
    } else {
        std::fs::read_dir(root)?
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.join("Conformer SDF Files").is_dir())
            .collect::<Vec<_>>()
    };
    let mut compounds = vec![];
    let label_regex = regex::Regex::new(r#"label\s+id\s+(\d+)\s*,\s*'([^']*)'"#)?;
    let energy_regex = regex::Regex::new(r"Total Gibbs Free Energy \(Hartrees\):\s*(\S+)")?;
    let coupling_regex = regex::Regex::new(r"^\s*(\d+)\s*-\s*(\d+)\s*:\s*(\S+)")?;
    for dir in dirs {
        let name = dir
            .file_name()
            .context("Unnamed result folder")?
            .to_string_lossy()
            .to_string();
        let mut shifts = Values::new();
        if let Ok(text) = std::fs::read_to_string(dir.join(format!("{name}_chemical_shifts.pml"))) {
            for c in label_regex.captures_iter(&text) {
                let atom = c[1]
                    .parse::<usize>()
                    .context("Invalid atom number in saved shift labels")?;
                anyhow::ensure!(atom > 0, "Saved shift label atom numbers must start at 1");
                let value = float(&c[2]).context("Invalid value in saved shift labels")?;
                shifts.insert(atom - 1, value);
            }
        }
        let pops = population_file(&dir.join(format!("{name}_boltzmann_populations.txt")))?
            .unwrap_or_default();
        let mut conformers = vec![];
        for path in collect_files(&dir.join("Conformer SDF Files"), "sdf", false)? {
            let text = std::fs::read_to_string(&path)?;
            let molecule = parse_sdf(&text)?;
            let Some((_, number)) = number_name(&path) else {
                continue;
            };
            let energy = energy_regex
                .captures(&text)
                .filter(|c| &c[1] != "N/A")
                .map(|c| float(&c[1]))
                .transpose()?;
            conformers.push(ConformerResult {
                number,
                energy,
                relative: None,
                population: pops.get(&number).copied().unwrap_or(0.),
                molecule,
                shifts: shifts.clone(),
                couplings: PairValues::new(),
                distances: PairValues::new(),
                noe: PairValues::new(),
                frequencies: Frequencies::default(),
            });
        }
        if conformers.is_empty() {
            continue;
        }
        conformers.sort_by(|a, b| {
            a.energy
                .unwrap_or(f64::INFINITY)
                .total_cmp(&b.energy.unwrap_or(f64::INFINITY))
                .then(a.number.cmp(&b.number))
        });
        let min = conformers
            .iter()
            .filter_map(|c| c.energy)
            .fold(f64::INFINITY, f64::min);
        for c in &mut conformers {
            c.relative = c
                .energy
                .map(|e| (e - min) * crate::symmetry::HARTREE_TO_KCAL);
        }
        let structure = conformers[0].molecule.clone();
        anyhow::ensure!(
            shifts.keys().all(|&i| i < structure.atoms.len()),
            "{}: a saved shift label refers to an atom outside the structure",
            dir.display()
        );
        let mut numbers = BTreeSet::new();
        for c in &conformers {
            anyhow::ensure!(
                numbers.insert(c.number),
                "{}: duplicate saved conformer {}",
                dir.display(),
                c.number
            );
            anyhow::ensure!(
                structure.same_topology(&c.molecule),
                "{}: saved conformer {} has incompatible atom identities or connectivity",
                dir.display(),
                c.number
            );
        }
        let mut couplings = PairValues::new();
        let coupling_path = dir.join(format!("{name}_weighted_coupling_constants.txt"));
        if coupling_path.is_file() {
            let text = std::fs::read_to_string(&coupling_path)?;
            for line in text.lines() {
                if let Some(c) = coupling_regex.captures(line) {
                    let a: usize = c[1].parse()?;
                    let b: usize = c[2].parse()?;
                    let value = float(&c[3])?;
                    anyhow::ensure!(
                        a > 0
                            && b > 0
                            && a != b
                            && a <= structure.atoms.len()
                            && b <= structure.atoms.len(),
                        "Invalid atom index in saved J file"
                    );
                    anyhow::ensure!(
                        couplings.insert(pair(a - 1, b - 1), value).is_none(),
                        "Duplicate pair in saved J file"
                    );
                }
            }
        }
        compounds.push(CompoundResult {
            name,
            temperature: 298.,
            structure,
            equivalence: vec![],
            conformers,
            base_shifts: shifts.clone(),
            shifts,
            couplings,
            distances: PairValues::new(),
            noe: PairValues::new(),
            replacements: BTreeMap::new(),
            specials: vec![],
            dedup: crate::symmetry::DedupResult::default(),
            warnings: vec![],
            directory: dir,
            generated: vec![],
            logs: vec![],
        });
    }
    anyhow::ensure!(
        !compounds.is_empty(),
        "No conformer SDF result folders found"
    );
    compounds.sort_by(|a, b| a.name.cmp(&b.name));
    Ok(AnalysisResult {
        compounds,
        errors: vec![],
    })
}

#[cfg(test)]
mod audit_tests {
    use super::*;

    #[test]
    fn pending_file_selection_cannot_lose_to_a_new_worker() {
        let mut app = Workbench::new(Config::default(), PathBuf::from("config.txt"));
        let (_sender, result) = mpsc::channel();
        app.picker = Some(NativePicker {
            kind: PickKind::Sdf,
            result,
        });
        app.start("Should wait for selection", |_| {
            Ok(Completed::LogFiles(vec![]))
        });
        assert!(app.worker.is_none());
        assert!(!app.ready_for_work());
    }

    #[test]
    fn disconnected_operations_report_failure_and_release_busy_state() {
        let mut app = Workbench::new(Config::default(), PathBuf::from("config.txt"));
        let (sender, result) = mpsc::channel();
        app.picker = Some(NativePicker {
            kind: PickKind::Sdf,
            result,
        });
        drop(sender);
        app.poll(&egui::Context::default());
        assert!(app.picker.is_none());
        assert!(app.status_error);
        assert!(app.status.contains("File selection stopped"));

        let (sender, done) = mpsc::channel();
        let (log_sender, logs) = mpsc::channel();
        log_sender.send("Final worker detail".into()).unwrap();
        app.worker = Some(Worker {
            progress: Progress::default(),
            logs,
            done,
            started: Instant::now(),
            label: "test".into(),
        });
        drop(sender);
        app.poll(&egui::Context::default());
        assert!(app.worker.is_none());
        assert!(app.status.contains("Worker stopped"));
        assert!(app.run_log.iter().any(|s| s == "Final worker detail"));
    }

    #[test]
    fn compound_selection_restores_settings_and_normalizes_removed_profiles() {
        let mut app = Workbench::new(Config::default(), PathBuf::from("config.txt"));
        app.select_job_compound("first".into());
        app.job.temperature = 283.;
        app.cluster_mode = "shifts".into();
        app.select_job_compound("second".into());
        app.job.temperature = 310.;
        app.cluster_mode = "none".into();
        app.select_job_compound("first".into());
        assert_eq!(app.job.temperature, 283.);
        assert_eq!(app.cluster_mode, "shifts");
        app.per_compound_jobs.get_mut("second").unwrap().machine = "deleted profile".into();
        app.select_job_compound("second".into());
        assert_eq!(app.job.temperature, 310.);
        assert_eq!(app.cluster_mode, "none");
        assert!(app.config.machines.contains_key(&app.job.machine));
    }

    #[test]
    fn returning_to_a_current_cluster_preview_restores_its_scene() {
        let mut app = Workbench::new(Config::default(), PathBuf::from("config.txt"));
        crate::verification::load_demo(&mut app).unwrap();
        app.tab = Tab::Setup;
        let settings = app.job_snapshot().clustering.unwrap();
        let signature = app.cluster_signature("ethanol");
        let mut items = app.inputs.clone();
        align_inputs(&mut items).unwrap();
        let groups = cluster(&items, &settings, &crate::verification::quiet())
            .unwrap()
            .groups;
        app.cluster_preview = Some(SetupClusterOverlay {
            compound: "ethanol".into(),
            settings,
            signature,
            items,
            groups,
        });

        app.cluster_mode = "custom".into();
        app.setup_viewer.clear();
        app.ensure_setup_cluster_loaded();
        assert!(app.setup_viewer.coordinates.is_empty());

        app.cluster_mode = "shifts".into();
        app.ensure_setup_cluster_loaded();
        assert!(!app.setup_viewer.coordinates.is_empty());
    }

    #[test]
    fn generated_overlay_is_installed_without_a_second_cluster_run() {
        let mut app = Workbench::new(Config::default(), PathBuf::from("config.txt"));
        crate::verification::load_demo(&mut app).unwrap();
        app.tab = Tab::Setup;
        let settings = app.job_snapshot().clustering.unwrap();
        let signature = app.cluster_signature("ethanol");
        let mut items = app.inputs.clone();
        align_inputs(&mut items).unwrap();
        let groups = cluster(&items, &settings, &crate::verification::quiet())
            .unwrap()
            .groups;
        app.accept_setup_result(SetupResult {
            paths: vec![PathBuf::from("gjf_files/ethanol_1.gjf")],
            selected: vec![("ethanol".into(), vec![1])],
            overlays: vec![SetupClusterOverlay {
                compound: "ethanol".into(),
                settings,
                signature,
                items,
                groups,
            }],
        });
        assert!(app.cluster_preview_current());
        assert!(!app.setup_viewer.coordinates.is_empty());
        assert!(app.status.contains("cluster overlay ready"));
    }
}
