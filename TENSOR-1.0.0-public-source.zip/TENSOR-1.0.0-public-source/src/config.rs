use crate::{math::py_float, molecule::float};
use anyhow::{Context, Result, bail, ensure};
use std::{collections::BTreeMap, path::Path, sync::LazyLock};
static OPT_KEYWORD: LazyLock<regex::Regex> =
    LazyLock::new(|| regex::Regex::new(r"(^|[^a-zA-Z0-9=])opt\b").unwrap());
pub const DEFAULT_CONFIG: &str = include_str!("../assets/tensor_config.txt");
pub const CONFIG_NAME: &str = "tensor_config.txt";
pub const JOB_TYPES: [&str; 6] = ["opt", "carbon", "proton", "fluorine", "nitrogen", "cc"];
pub type Entry = BTreeMap<String, String>;
#[derive(Clone, Debug)]
pub struct Tier {
    pub name: String,
    pub cores: usize,
    pub memory: String,
}
#[derive(Clone, Debug)]
pub struct Machine {
    pub name: String,
    pub label: String,
    pub chk: String,
    pub rwf: String,
    pub tiers: Vec<Tier>,
}
#[derive(Clone, Debug)]
pub struct Config {
    pub methods: BTreeMap<String, Entry>,
    pub machines: BTreeMap<String, Machine>,
    pub basis_blocks: BTreeMap<String, String>,
    pub problems: Vec<String>,
}
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Scaling {
    pub slope: f64,
    pub intercept: f64,
}
impl Scaling {
    pub fn new(slope: f64, intercept: f64) -> Self {
        Self { slope, intercept }
    }
    pub fn apply(self, shielding: f64) -> Result<f64> {
        ensure!(
            self.slope.is_finite() && self.slope != 0. && self.intercept.is_finite(),
            "Invalid shielding scaling constants"
        );
        let shift = (shielding - self.intercept) / self.slope;
        ensure!(
            shielding.is_finite() && shift.is_finite(),
            "Nonfinite shielding or scaled chemical shift"
        );
        Ok(shift)
    }
}

type Sections = BTreeMap<(String, String), Entry>;

fn section_header(line: &str) -> Option<(String, String)> {
    let line = line.trim();
    let header = line.strip_prefix('[')?.strip_suffix(']')?;
    let (kind, name) = header.split_once(':')?;
    Some((kind.trim().to_lowercase(), name.trim().to_string()))
}

fn parse_sections(text: &str) -> (Sections, Vec<String>) {
    let lines: Vec<_> = text.lines().collect();
    let mut sections = Sections::new();
    let mut current: Option<(String, String)> = None;
    let mut problems = vec![];
    let mut index = 0;
    while index < lines.len() {
        let raw = lines[index];
        let line = raw.trim();
        if line.is_empty() || line.starts_with(['#', ';']) {
            index += 1;
            continue;
        }
        if line.starts_with('[') && line.ends_with(']') {
            if let Some(header) = section_header(line) {
                sections.entry(header.clone()).or_default();
                current = Some(header);
            } else {
                problems.push(format!(
                    "Line {}: expected [method:NAME], [basis:NAME], or [machine:NAME]",
                    index + 1
                ));
                current = None;
            }
            index += 1;
            continue;
        }
        let Some((key, raw_value)) = line.split_once('=') else {
            problems.push(format!("Line {}: expected key = value", index + 1));
            index += 1;
            continue;
        };
        let Some(section) = current.as_ref() else {
            problems.push(format!("Line {}: value is outside a section", index + 1));
            index += 1;
            continue;
        };
        let key = key.trim().to_lowercase();
        let raw_value = raw_value.trim();
        let value = if raw_value == "\"\"\"" {
            let first_line = index + 2;
            index += 1;
            let mut block = vec![];
            while index < lines.len() && lines[index].trim() != "\"\"\"" {
                block.push(lines[index]);
                index += 1;
            }
            if index == lines.len() {
                problems.push(format!(
                    "Line {first_line}: multiline value for {key} has no closing \"\"\""
                ));
            } else {
                index += 1;
            }
            block.join("\n").trim_matches('\n').to_string()
        } else {
            index += 1;
            raw_value.to_string()
        };
        sections
            .entry(section.clone())
            .or_default()
            .insert(key, value);
    }
    (sections, problems)
}

fn config_value(key: &str, value: &str) -> String {
    if value.contains('\n') {
        format!("{key} = \"\"\"\n{value}\n\"\"\"")
    } else {
        format!("{key} = {value}")
    }
}

/// Add fields introduced after the original configuration format without
/// replacing any value the user already has. Duplicate section headers are
/// accepted, but this writer inserts additions into the existing last section
/// so the resulting file remains straightforward to edit.
fn merge_bundled_fields(text: &str) -> Result<Option<String>> {
    let (current, current_problems) = parse_sections(text);
    if !current_problems.is_empty() {
        return Ok(None);
    }
    let (bundled, bundled_problems) = parse_sections(DEFAULT_CONFIG);
    ensure!(
        bundled_problems.is_empty(),
        "Bundled configuration cannot be used for migration"
    );

    let has_retained_bundled_method = current.keys().any(|(kind, name)| {
        kind == "method" && bundled.contains_key(&("method".into(), name.clone()))
    });
    let mut missing = BTreeMap::<(String, String), Vec<(String, String)>>::new();
    for ((kind, name), defaults) in &bundled {
        let include = match kind.as_str() {
            // Never restore a method the user intentionally removed, but make
            // every retained bundled method complete and visible.
            "method" => current.contains_key(&(kind.clone(), name.clone())),
            // Basis blocks are added when at least one bundled method remains.
            "basis" => has_retained_bundled_method,
            _ => false,
        };
        if !include {
            continue;
        }
        let existing = current.get(&(kind.clone(), name.clone()));
        let additions: Vec<_> = defaults
            .iter()
            .filter(|(key, _)| existing.is_none_or(|entry| !entry.contains_key(*key)))
            .map(|(key, value)| (key.clone(), value.clone()))
            .collect();
        if !additions.is_empty() {
            missing.insert((kind.clone(), name.clone()), additions);
        }
    }
    if missing.is_empty() {
        return Ok(None);
    }

    let lines: Vec<_> = text.lines().collect();
    let mut section_ends = BTreeMap::<(String, String), usize>::new();
    let mut current_section = None;
    let mut multiline = false;
    for (index, raw) in lines.iter().enumerate() {
        let line = raw.trim();
        if multiline {
            if line == "\"\"\"" {
                multiline = false;
            }
            continue;
        }
        if line
            .split_once('=')
            .is_some_and(|(_, value)| value.trim() == "\"\"\"")
        {
            multiline = true;
            continue;
        }
        if let Some(header) = section_header(line)
            && let Some(previous) = current_section.replace(header)
        {
            section_ends.insert(previous, index);
        }
    }
    if let Some(previous) = current_section {
        section_ends.insert(previous, lines.len());
    }

    let mut insertions = BTreeMap::<usize, Vec<String>>::new();
    let mut new_sections = vec![];
    for (section, fields) in missing {
        let rendered: Vec<_> = fields
            .iter()
            .map(|(key, value)| config_value(key, value))
            .collect();
        if let Some(&end) = section_ends.get(&section) {
            let rows = insertions.entry(end).or_default();
            rows.push(format!(
                "# Added by TENSOR to complete this built-in {} definition.",
                section.0
            ));
            rows.extend(rendered);
        } else {
            new_sections.push(format!(
                "[{}:{}]\n{}",
                section.0,
                section.1,
                rendered.join("\n")
            ));
        }
    }

    let mut output = String::new();
    for index in 0..=lines.len() {
        if let Some(rows) = insertions.get(&index) {
            output.push_str(&rows.join("\n"));
            output.push('\n');
        }
        if let Some(line) = lines.get(index) {
            output.push_str(line);
            output.push('\n');
        }
    }
    if !new_sections.is_empty() {
        if !output.ends_with("\n\n") {
            output.push('\n');
        }
        output.push_str("# Added by TENSOR: editable basis blocks used by gen/genecp routes.\n");
        output.push_str(&new_sections.join("\n\n"));
        output.push('\n');
    }
    Ok(Some(output))
}

impl Default for Config {
    fn default() -> Self {
        Self::parse(DEFAULT_CONFIG).expect("Bundled configuration is valid")
    }
}
impl Config {
    pub fn load(path: &Path) -> Result<Self> {
        if !path.exists() {
            if let Some(parent) = path.parent() {
                std::fs::create_dir_all(parent)?;
            }
            std::fs::write(path, DEFAULT_CONFIG)
                .with_context(|| format!("Cannot create {}", path.display()))?;
        }
        let original = std::fs::read_to_string(path)?;
        let mut upgraded = false;
        let text = if let Some(text) = merge_bundled_fields(&original)? {
            let backup = path.with_file_name(format!(
                "{}.pre-{}.bak",
                path.file_name().unwrap_or_default().to_string_lossy(),
                env!("CARGO_PKG_VERSION")
            ));
            if !backup.exists() {
                std::fs::write(&backup, &original)
                    .with_context(|| format!("Cannot back up {}", path.display()))?;
            }
            std::fs::write(path, &text)
                .with_context(|| format!("Cannot update {}", path.display()))?;
            upgraded = true;
            text
        } else {
            original
        };
        let mut config = Self::parse(&text)?;
        if upgraded {
            config.problems.push(format!(
                "Updated missing built-in method/basis fields in {}; the previous file was retained as a .pre-{}.bak backup.",
                path.display(),
                env!("CARGO_PKG_VERSION")
            ));
        }
        Ok(config)
    }
    pub fn parse(text: &str) -> Result<Self> {
        let (sections, problems) = parse_sections(text);
        let mut config = Self {
            methods: BTreeMap::new(),
            machines: BTreeMap::new(),
            basis_blocks: BTreeMap::new(),
            problems,
        };
        for ((kind, name), entry) in sections {
            if kind == "method" {
                let missing: Vec<_> = ["opt_route", "carbon_route", "proton_route"]
                    .iter()
                    .filter(|k| entry.get(**k).is_none_or(|v| v.is_empty()))
                    .copied()
                    .collect();
                if !missing.is_empty() {
                    config.problems.push(format!(
                        "[method:{name}] missing {}; skipped",
                        missing.join(", ")
                    ));
                    continue;
                }
                for job in ["carbon", "proton", "fluorine", "nitrogen", "sulfur"] {
                    let slope = entry
                        .get(&format!("{job}_slope"))
                        .filter(|value| !value.trim().is_empty());
                    let intercept = entry
                        .get(&format!("{job}_intercept"))
                        .filter(|value| !value.trim().is_empty());
                    if slope.is_some() != intercept.is_some() {
                        config.problems.push(format!(
                            "[method:{name}] specify both {job}_slope and {job}_intercept"
                        ));
                    } else if matches!(job, "carbon" | "proton") && slope.is_none() {
                        config.problems.push(format!(
                            "[method:{name}] needs {job}_slope and {job}_intercept for its required {job} job"
                        ));
                    }
                }
                config.methods.insert(name, entry);
            } else if kind == "machine" {
                let mut tiers = vec![];
                for (k, v) in &entry {
                    if let Some(n) = k.strip_prefix("tier.") {
                        if let Some((cores, mem)) = v.split_once(',')
                            && let Ok(cores) = cores.trim().parse::<usize>()
                            && cores > 0
                            && !mem.trim().is_empty()
                        {
                            tiers.push(Tier {
                                name: n.into(),
                                cores,
                                memory: mem.trim().into(),
                            });
                            continue;
                        }
                        config.problems.push(format!(
                            "[machine:{name}] {k}: expected positive cores, memory"
                        ));
                    }
                }
                if tiers.is_empty() {
                    config.problems.push(format!(
                        "[machine:{name}] no usable resource tiers; skipped"
                    ));
                    continue;
                }
                tiers.sort_by_key(|t| t.cores);
                let machine = Machine {
                    name: name.clone(),
                    label: if name == "default" {
                        "Default".into()
                    } else {
                        entry.get("label").cloned().unwrap_or(name.clone())
                    },
                    chk: entry
                        .get("chk")
                        .cloned()
                        .unwrap_or("%chk={compound}_{conformer}.chk".into()),
                    rwf: entry.get("rwf").cloned().unwrap_or_default(),
                    tiers,
                };
                config.machines.insert(name, machine);
            } else if kind == "basis" {
                if let Some(block) = entry.get("block").filter(|value| !value.trim().is_empty()) {
                    config.basis_blocks.insert(name, block.clone());
                } else {
                    config
                        .problems
                        .push(format!("[basis:{name}] has no multiline block; skipped"));
                }
            } else {
                config
                    .problems
                    .push(format!("Unrecognized section [{kind}:{name}]"))
            }
        }
        ensure!(
            !config.methods.is_empty(),
            "Configuration defines no usable methods"
        );
        ensure!(
            !config.machines.is_empty(),
            "Configuration defines no usable machines"
        );
        Ok(config)
    }
    pub fn scaling(&self, method: &str, job: &str) -> Result<Option<Scaling>> {
        let entry = self
            .methods
            .get(method)
            .with_context(|| format!("Method {method:?} not defined"))?;
        let slope = entry
            .get(&format!("{job}_slope"))
            .filter(|value| !value.is_empty());
        let intercept = entry
            .get(&format!("{job}_intercept"))
            .filter(|value| !value.is_empty());
        ensure!(
            slope.is_some() == intercept.is_some(),
            "{method}: specify both {job}_slope and {job}_intercept"
        );
        if let (Some(slope), Some(intercept)) = (slope, intercept) {
            let scaling = Scaling::new(float(slope)?, float(intercept)?);
            scaling.apply(0.)?;
            return Ok(Some(scaling));
        }
        Ok(None)
    }
    /// Scaling for a carbon bearing one, two, or three Cl/Br/I atoms.
    /// Every pair comes from the selected method section. Older built-in
    /// sections are augmented on load so these values remain visible/editable.
    pub fn halogen_scaling(
        &self,
        method: &str,
        element: &str,
        count: usize,
    ) -> Result<Option<Scaling>> {
        let prefix = match element {
            "Cl" => "chlorine",
            "Br" => "bromine",
            "I" => "iodine",
            _ => return Ok(None),
        };
        let count = count.clamp(1, 3);
        let entry = self
            .methods
            .get(method)
            .with_context(|| format!("Method {method:?} not defined"))?;
        let key = format!("{prefix}_{count}");
        let slope = entry
            .get(&format!("{key}_slope"))
            .filter(|value| !value.is_empty());
        let intercept = entry
            .get(&format!("{key}_intercept"))
            .filter(|value| !value.is_empty());
        ensure!(
            slope.is_some() == intercept.is_some(),
            "{method}: specify both {key}_slope and {key}_intercept"
        );
        if let (Some(slope), Some(intercept)) = (slope, intercept) {
            let scaling = Scaling::new(float(slope)?, float(intercept)?);
            scaling.apply(0.)?;
            return Ok(Some(scaling));
        }
        Ok(None)
    }

    fn route_set(
        &self,
        method: &str,
        temperature: f64,
        iodine: bool,
        special: Option<&str>,
    ) -> Result<Entry> {
        ensure!(
            temperature.is_finite() && temperature > 0.,
            "Temperature must be finite and above 0 K"
        );
        let e = self
            .methods
            .get(method)
            .with_context(|| format!("Method {method:?} not defined"))?;
        let (prefix, jobs): (&str, &[&str]) = match special {
            None => ("", &JOB_TYPES),
            Some("csulfur") => ("sulfur_", &["opt", "carbon"]),
            Some("chalogen") => ("halogen_", &["opt", "carbon"]),
            Some(other) => bail!("Unknown special calculation {other:?}"),
        };
        let mut substitutions = e.clone();
        substitutions.retain(|key, _| !key.ends_with("_route"));
        substitutions.insert(
            "temperature".into(),
            format!(" temperature={}", py_float(temperature)),
        );
        for &job in jobs {
            let basis_key = format!("{prefix}{job}_basis");
            substitutions.insert(
                basis_key.clone(),
                if iodine {
                    "gen".into()
                } else {
                    e.get(&basis_key).cloned().unwrap_or_default()
                },
            );
        }
        let mut out = Entry::new();
        for &job in jobs {
            let route_key = format!("{prefix}{job}_route");
            if let Some(route) = e.get(&route_key).filter(|value| !value.is_empty()) {
                let mut r = render_template(route, &substitutions)?;
                ensure!(
                    r.starts_with('#'),
                    "{method}: {job}_route must begin with #"
                );
                ensure!(
                    !r.contains(['\r', '\n']),
                    "Routes must occupy one configuration line"
                );
                if job == "opt" {
                    r = enforce_opt(&r, temperature)
                }
                out.insert(job.into(), r);
            }
        }
        Ok(out)
    }

    pub fn routes(&self, method: &str, temperature: f64, iodine: bool) -> Result<Entry> {
        self.route_set(method, temperature, iodine, None)
    }

    pub fn special_routes(
        &self,
        method: &str,
        temperature: f64,
        iodine: bool,
        special: &str,
    ) -> Result<Entry> {
        self.route_set(method, temperature, iodine, Some(special))
    }

    pub fn basis_name(&self, method: &str, job: &str, special: Option<&str>) -> Result<&str> {
        let prefix = match special {
            None => "",
            Some("csulfur") => "sulfur_",
            Some("chalogen") => "halogen_",
            Some(other) => bail!("Unknown special calculation {other:?}"),
        };
        self.methods
            .get(method)
            .with_context(|| format!("Method {method:?} not defined"))?
            .get(&format!("{prefix}{job}_basis"))
            .map(String::as_str)
            .filter(|value| !value.is_empty())
            .with_context(|| format!("Method {method:?} has no {prefix}{job}_basis"))
    }

    pub fn iodine_basis_block(&self, method: &str) -> Result<&str> {
        let name = self
            .methods
            .get(method)
            .with_context(|| format!("Method {method:?} not defined"))?
            .get("iodine_basis")
            .filter(|name| !name.is_empty())
            .context("Selected method has no iodine_basis entry")?;
        self.basis_blocks
            .get(name)
            .map(String::as_str)
            .with_context(|| format!("Iodine basis block [basis:{name}] is not defined"))
    }

    pub fn supports_job(&self, method: &str, job: &str) -> bool {
        self.methods
            .get(method)
            .and_then(|entry| entry.get(&format!("{job}_route")))
            .is_some_and(|route| !route.is_empty())
    }

    pub fn supports_scaling(&self, method: &str, job: &str) -> bool {
        self.scaling(method, job).is_ok_and(|value| value.is_some())
    }

    pub fn supports_special(&self, method: &str, special: &str) -> bool {
        let prefix = match special {
            "csulfur" => "sulfur",
            "chalogen" => "halogen",
            _ => return false,
        };
        ["opt", "carbon"].iter().all(|job| {
            self.methods
                .get(method)
                .and_then(|entry| entry.get(&format!("{prefix}_{job}_route")))
                .is_some_and(|route| !route.is_empty())
        })
    }
}
pub fn render_template(template: &str, values: &Entry) -> Result<String> {
    let mut out = template.to_string();
    // Repeat to support readable composed values such as a route referencing
    // {proton_keywords}, whose value in turn references {solvent}. The bounded
    // pass count also leaves cycles/self-references for the unresolved check.
    for _ in 0..=values.len() {
        let before = out.clone();
        for (k, v) in values {
            out = out.replace(&format!("{{{k}}}"), v);
        }
        if out == before {
            break;
        }
    }
    // Values such as $USER are intentionally left for the user's submission workflow.
    if out.contains('{') || out.contains('}') {
        bail!("Unresolved placeholder in {out:?}")
    }
    Ok(out)
}
pub fn enforce_opt(route: &str, t: f64) -> String {
    let mut r = route.trim().to_string();
    let lower = r.to_lowercase();
    let opt = OPT_KEYWORD.is_match(&lower);
    for (present, keyword) in [
        (opt, "opt"),
        (lower.contains("freq"), "freq=noraman"),
        (lower.contains("connectivity"), "geom=connectivity"),
        (lower.contains("nboread"), "pop=nboread"),
    ] {
        if !present {
            r.push(' ');
            r += keyword
        }
    }
    if !lower.contains("temperature=") {
        r += &format!(" temperature={}", py_float(t));
    }
    r
}
