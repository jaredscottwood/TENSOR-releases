//! Small, double-precision linear algebra. Horn's quaternion method allows only
//! proper rotations; it cannot erase chirality by reflecting a structure.
use anyhow::{Result, ensure};
pub type V3 = [f64; 3];
pub type M3 = [[f64; 3]; 3];
pub const IDENTITY: M3 = [[1., 0., 0.], [0., 1., 0.], [0., 0., 1.]];
pub fn add(a: V3, b: V3) -> V3 {
    std::array::from_fn(|i| a[i] + b[i])
}
pub fn sub(a: V3, b: V3) -> V3 {
    std::array::from_fn(|i| a[i] - b[i])
}
pub fn mul(a: V3, b: f64) -> V3 {
    a.map(|x| x * b)
}
pub fn dot(a: V3, b: V3) -> f64 {
    a.iter().zip(b).map(|(x, y)| x * y).sum()
}
pub fn norm(a: V3) -> f64 {
    dot(a, a).sqrt()
}
pub fn distance(a: V3, b: V3) -> f64 {
    norm(sub(a, b))
}
pub fn cross(a: V3, b: V3) -> V3 {
    [
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    ]
}
pub fn volume(a: V3, b: V3, c: V3, d: V3) -> f64 {
    dot(sub(b, a), cross(sub(c, a), sub(d, a)))
}
pub fn centroid(p: &[V3]) -> V3 {
    if p.is_empty() {
        return [0.; 3];
    }
    mul(
        p.iter().fold([0.; 3], |a, &b| add(a, b)),
        1. / p.len() as f64,
    )
}
pub fn transpose(a: M3) -> M3 {
    std::array::from_fn(|i| std::array::from_fn(|j| a[j][i]))
}
pub fn transform(r: M3, v: V3) -> V3 {
    r.map(|row| dot(row, v))
}
pub fn matmul(a: M3, b: M3) -> M3 {
    let t = transpose(b);
    a.map(|r| t.map(|c| dot(r, c)))
}
pub fn rot_x(deg: f64) -> M3 {
    let (s, c) = deg.to_radians().sin_cos();
    [[1., 0., 0.], [0., c, -s], [0., s, c]]
}
pub fn rot_y(deg: f64) -> M3 {
    let (s, c) = deg.to_radians().sin_cos();
    [[c, 0., s], [0., 1., 0.], [-s, 0., c]]
}
pub fn determinant(r: M3) -> f64 {
    dot(r[0], cross(r[1], r[2]))
}

/// Symmetric Jacobi eigensolver. Eigenvectors occupy columns.
pub fn eigen<const N: usize>(mut a: [[f64; N]; N]) -> ([f64; N], [[f64; N]; N]) {
    let mut v = std::array::from_fn(|i| std::array::from_fn(|j| if i == j { 1. } else { 0. }));
    for _ in 0..(100 * N * N) {
        let (mut p, mut q, mut off) = (0, 1, 0_f64);
        for (i, row) in a.iter().enumerate() {
            for (j, &value) in row.iter().enumerate().skip(i + 1) {
                if value.abs() > off {
                    (p, q, off) = (i, j, value.abs());
                }
            }
        }
        let scale = (0..N).map(|i| a[i][i].abs()).fold(0_f64, f64::max).max(1.);
        if off <= f64::EPSILON * scale * 0.5 {
            break;
        }
        let tau = (a[q][q] - a[p][p]) / (2. * a[p][q]);
        let t = if tau >= 0. {
            1. / (tau + (1. + tau * tau).sqrt())
        } else {
            -1. / (-tau + (1. + tau * tau).sqrt())
        };
        let c = 1. / (1. + t * t).sqrt();
        let s = t * c;
        let app = a[p][p];
        let aqq = a[q][q];
        let apq = a[p][q];
        a[p][p] = app - t * apq;
        a[q][q] = aqq + t * apq;
        a[p][q] = 0.;
        a[q][p] = 0.;
        for k in 0..N {
            if k != p && k != q {
                let kp = a[k][p];
                let kq = a[k][q];
                a[k][p] = c * kp - s * kq;
                a[p][k] = a[k][p];
                a[k][q] = s * kp + c * kq;
                a[q][k] = a[k][q];
            }
            let vp = v[k][p];
            let vq = v[k][q];
            v[k][p] = c * vp - s * vq;
            v[k][q] = s * vp + c * vq;
        }
    }
    (std::array::from_fn(|i| a[i][i]), v)
}

#[derive(Debug, Clone, Copy)]
pub struct Superposition {
    pub rotation: M3,
    pub reference_center: V3,
    pub target_center: V3,
    pub rmsd: f64,
    pub maximum: f64,
}
impl Superposition {
    pub fn apply(&self, p: V3) -> V3 {
        add(
            transform(self.rotation, sub(p, self.target_center)),
            self.reference_center,
        )
    }
}
pub fn superpose(reference: &[V3], target: &[V3]) -> Result<Superposition> {
    ensure!(
        !reference.is_empty() && reference.len() == target.len(),
        "Superposition requires equal, nonempty coordinate arrays"
    );
    ensure!(
        reference
            .iter()
            .chain(target)
            .flatten()
            .all(|x| x.is_finite()),
        "Nonfinite coordinates"
    );
    let ac = centroid(reference);
    let bc = centroid(target);
    let mut s = [[0.; 3]; 3];
    for (&a, &b) in reference.iter().zip(target) {
        let a = sub(a, ac);
        let b = sub(b, bc);
        for i in 0..3 {
            for j in 0..3 {
                s[i][j] += a[i] * b[j];
            }
        }
    }
    let [[xx, xy, xz], [yx, yy, yz], [zx, zy, zz]] = s;
    let k = [
        [xx + yy + zz, yz - zy, zx - xz, xy - yx],
        [yz - zy, xx - yy - zz, xy + yx, zx + xz],
        [zx - xz, xy + yx, -xx + yy - zz, yz + zy],
        [xy - yx, zx + xz, yz + zy, -xx - yy + zz],
    ];
    let (ev, vec) = eigen(k);
    let best = (0..4).max_by(|&i, &j| ev[i].total_cmp(&ev[j])).unwrap();
    let [w, x, y, z] = std::array::from_fn(|i| vec[i][best]);
    let forward = [
        [
            w * w + x * x - y * y - z * z,
            2. * (x * y - w * z),
            2. * (x * z + w * y),
        ],
        [
            2. * (x * y + w * z),
            w * w - x * x + y * y - z * z,
            2. * (y * z - w * x),
        ],
        [
            2. * (x * z - w * y),
            2. * (y * z + w * x),
            w * w - x * x - y * y + z * z,
        ],
    ];
    let rotation = transpose(forward);
    let mut result = Superposition {
        rotation,
        reference_center: ac,
        target_center: bc,
        rmsd: 0.,
        maximum: 0.,
    };
    let squared: Vec<_> = reference
        .iter()
        .zip(target)
        .map(|(&a, &b)| dot(sub(a, result.apply(b)), sub(a, result.apply(b))))
        .collect();
    result.rmsd = (squared.iter().sum::<f64>() / squared.len() as f64).sqrt();
    result.maximum = squared.into_iter().fold(0_f64, f64::max).sqrt();
    Ok(result)
}
pub fn round_decimal(x: f64, n: usize) -> f64 {
    // Python round(x,n) rounds the actual binary float, not x*10**n.
    format!("{x:.n$}").parse().unwrap_or(x)
}
pub fn py_float(x: f64) -> String {
    let s = x.to_string();
    if s.contains('.') || s.contains('e') || s.contains('E') {
        s
    } else {
        format!("{s}.0")
    }
}
pub fn dihedral(p0: V3, p1: V3, p2: V3, p3: V3) -> f64 {
    let b0 = sub(p0, p1);
    let b1 = sub(p2, p1);
    let b2 = sub(p3, p2);
    let unit = mul(b1, 1. / (norm(b1) + 1e-12));
    let v = sub(b0, mul(unit, dot(b0, unit)));
    let w = sub(b2, mul(unit, dot(b2, unit)));
    dot(cross(unit, v), w).atan2(dot(v, w))
}
pub fn hungarian(cost: &[Vec<f64>]) -> Vec<usize> {
    let n = cost.len();
    if n == 0 {
        return vec![];
    }
    let mut u = vec![0.; n + 1];
    let mut v = u.clone();
    let mut p = vec![0; n + 1];
    let mut way = p.clone();
    for i in 1..=n {
        p[0] = i;
        let mut j0 = 0;
        let mut minv = vec![f64::INFINITY; n + 1];
        let mut used = vec![false; n + 1];
        loop {
            used[j0] = true;
            let i0 = p[j0];
            let (mut delta, mut j1) = (f64::INFINITY, 0);
            for j in 1..=n {
                if !used[j] {
                    let cur = cost[i0 - 1][j - 1] - u[i0] - v[j];
                    if cur < minv[j] {
                        minv[j] = cur;
                        way[j] = j0
                    }
                    if minv[j] < delta {
                        delta = minv[j];
                        j1 = j
                    }
                }
            }
            for j in 0..=n {
                if used[j] {
                    u[p[j]] += delta;
                    v[j] -= delta
                } else {
                    minv[j] -= delta
                }
            }
            j0 = j1;
            if p[j0] == 0 {
                break;
            }
        }
        loop {
            let j1 = way[j0];
            p[j0] = p[j1];
            j0 = j1;
            if j0 == 0 {
                break;
            }
        }
    }
    let mut out = vec![0; n];
    for j in 1..=n {
        out[p[j] - 1] = j - 1
    }
    out
}
