pub mod analysis;
pub mod branding;
pub mod cluster;
pub mod config;
pub mod figure;
pub mod gaussian;
pub mod jobs;
pub mod math;
pub mod methodology;
pub mod molecule;
pub mod render3d;
pub mod symmetry;
pub mod ui;
pub mod verification;
pub mod viewer;

pub const VERSION: &str = env!("CARGO_PKG_VERSION");
pub const TITLE: &str =
    "TENSOR - Theoretical Evaluation of NMR: Structures, Orchestration, and Rendering";

pub mod spectrum;
pub mod spectrum_ui;
