//! The Python distance/dihedral fingerprint and hierarchical selection rules.
//! Nearest-neighbor chains avoid cubic scanning of the entire distance matrix.
use crate::{jobs::Progress, math::*, molecule::*};
use anyhow::{Result, bail, ensure};
use rayon::prelude::*;
use std::collections::{BTreeMap, BTreeSet};
#[derive(Clone, Debug, PartialEq)]
pub struct ClusterSettings {
    pub linkage: String,
    pub tau: f64,
    pub selection: String,
    pub dihedral_weight: f64,
}
impl Default for ClusterSettings {
    fn default() -> Self {
        Self {
            linkage: "complete".into(),
            tau: 0.30,
            selection: "tiered".into(),
            dihedral_weight: 0.5,
        }
    }
}
impl ClusterSettings {
    pub fn shifts() -> Self {
        Self {
            tau: 0.4,
            ..Self::default()
        }
    }
    pub fn all_nmr() -> Self {
        Self {
            tau: 0.15,
            selection: "lowest_energy".into(),
            ..Self::default()
        }
    }
}
#[derive(Clone, Debug)]
pub struct Merge {
    pub left: usize,
    pub right: usize,
    pub height: f64,
    pub count: usize,
}
#[derive(Clone, Debug)]
pub struct ClusterResult {
    pub selected: BTreeSet<usize>,
    pub groups: Vec<Vec<usize>>,
    pub matrix: Vec<Vec<f32>>,
    pub report: String,
}
pub fn fingerprints(items: &[ConformerInput], weight: f64) -> Result<Vec<Vec<f32>>> {
    fingerprints_checked(items, weight, || Ok(()))
}
fn fingerprints_checked(
    items: &[ConformerInput],
    weight: f64,
    check: impl Fn() -> Result<()> + Sync,
) -> Result<Vec<Vec<f32>>> {
    check()?;
    let n = items.len();
    ensure!(n > 0, "No conformers for clustering");
    ensure!(
        weight.is_finite() && weight >= 0.,
        "Dihedral weight must be finite and nonnegative"
    );
    let reference = &items[0].molecule;
    ensure!(
        items.iter().all(|c| reference.same_topology(&c.molecule)),
        "Clustering requires identical atom ordering, elements, charges and connectivity"
    );
    // Check the n² allocation before attempting it.
    let cells = n.checked_mul(n).context_size()?;
    ensure!(
        cells <= 100_000_000,
        "This clustering run needs more than 100 million pairwise cells. Split the ensemble before clustering."
    );
    let adj = reference.adjacency();
    let atoms = &reference.atoms;
    let selected: Vec<_> = (0..atoms.len())
        .filter(|&i| {
            atoms[i].element != "H" || !(adj[i].len() == 1 && atoms[adj[i][0]].element == "C")
        })
        .collect();
    let mut pairs = vec![];
    for (k, &i) in selected.iter().enumerate() {
        for &j in &selected[k + 1..] {
            pairs.push((i, j));
        }
    }
    let mut torsions = vec![];
    for b in 0..atoms.len() {
        if atoms[b].element == "H" {
            continue;
        }
        for &c in &adj[b] {
            if c <= b || atoms[c].element == "H" {
                continue;
            }
            let a = adj[b].iter().find(|&&a| a != c && atoms[a].element != "H");
            let d = adj[c].iter().find(|&&d| d != b && atoms[d].element != "H");
            if let (Some(&a), Some(&d)) = (a, d) {
                torsions.push([a, b, c, d]);
            }
        }
    }
    let features: Vec<(Vec<f64>, Vec<f64>)> = items
        .par_iter()
        .map(|item| -> Result<_> {
            check()?;
            let coords = item.molecule.coords();
            // The source intentionally calculates this block in float32.
            let distances = pairs
                .iter()
                .map(|&(i, j)| {
                    let a = coords[i].map(|x| x as f32);
                    let b = coords[j].map(|x| x as f32);
                    ((a[0] - b[0]).powi(2) + (a[1] - b[1]).powi(2) + (a[2] - b[2]).powi(2)).sqrt()
                        as f64
                })
                .collect();
            let angles: Vec<_> = torsions
                .iter()
                .map(|&[a, b, c, d]| dihedral(coords[a], coords[b], coords[c], coords[d]))
                .collect();
            let dihedrals = angles
                .iter()
                .map(|a| a.sin() as f32 as f64)
                .chain(angles.iter().map(|a| a.cos() as f32 as f64))
                .collect();
            Ok((distances, dihedrals))
        })
        .collect::<Result<_>>()?;
    let (df, hf): (Vec<_>, Vec<_>) = features.into_iter().unzip();
    fn rms(a: &[f64], b: &[f64]) -> f64 {
        if a.is_empty() {
            0.
        } else {
            a.iter()
                .zip(b)
                .map(|(a, b)| (a - b).powi(2))
                .sum::<f64>()
                .sqrt()
                / (a.len() as f64).sqrt()
        }
    }
    // Only the strict upper triangle is used. Storing each distance/torsion
    // pair once halves temporary f64 matrix storage without changing precision.
    let rows: Vec<_> = (0..n)
        .into_par_iter()
        .map(|i| -> Result<_> {
            check()?;
            let mut row = Vec::with_capacity(n - i - 1);
            let (mut dmax, mut hmax) = (0_f64, 0_f64);
            for j in i + 1..n {
                let d = rms(&df[i], &df[j]);
                let h = rms(&hf[i], &hf[j]);
                dmax = dmax.max(d);
                hmax = hmax.max(h);
                row.push((d, h));
            }
            Ok((row, dmax, hmax))
        })
        .collect::<Result<_>>()?;
    let (mut dmax, mut hmax) = (0_f64, 0_f64);
    let mut pairwise = Vec::with_capacity(n);
    for (row, row_dmax, row_hmax) in rows {
        pairwise.push(row);
        dmax = dmax.max(row_dmax);
        hmax = hmax.max(row_hmax);
    }
    let use_dih = !torsions.is_empty() && hmax > 1e-12 && weight > 0.;
    if dmax <= 1e-12 {
        dmax = 1.
    }
    let alpha = if use_dih { weight / (1. + weight) } else { 0. };
    let mut out = vec![vec![0_f32; n]; n];
    out.par_iter_mut()
        .enumerate()
        .try_for_each(|(i, row)| -> Result<()> {
            check()?;
            for (j, value) in row.iter_mut().enumerate() {
                if i == j {
                    continue;
                }
                let (d, h) = if i < j {
                    pairwise[i][j - i - 1]
                } else {
                    pairwise[j][i - j - 1]
                };
                let d = d / dmax;
                let v = if use_dih {
                    ((1. - alpha) * d * d + alpha * (h / hmax).powi(2)).sqrt()
                } else {
                    d
                };
                *value = v as f32;
            }
            Ok(())
        })?;
    Ok(out)
}
trait SizeResult<T> {
    fn context_size(self) -> Result<T>;
}
impl<T> SizeResult<T> for Option<T> {
    fn context_size(self) -> Result<T> {
        self.ok_or_else(|| anyhow::anyhow!("Ensemble size overflow"))
    }
}

pub fn linkage(matrix: &[Vec<f32>], method: &str, progress: &Progress) -> Result<Vec<Merge>> {
    ensure!(
        matches!(
            method,
            "single" | "complete" | "average" | "weighted" | "ward"
        ),
        "Unknown linkage {method}"
    );
    let n = matrix.len();
    if n < 2 {
        return Ok(vec![]);
    }
    ensure!(
        matrix.iter().all(|r| r.len() == n),
        "Distance matrix is not square"
    );
    let mut d: Vec<Vec<f64>> = matrix
        .iter()
        .map(|r| r.iter().map(|&x| x as f64).collect())
        .collect();
    let mut sizes = vec![1usize; n];
    let mut labels: Vec<_> = (0..n).collect();
    let mut chain: Vec<usize> = vec![];
    let mut merges = vec![];
    for step in 0..n - 1 {
        progress.check()?;
        if chain.is_empty() {
            chain.push((0..n).find(|&i| sizes[i] > 0).unwrap());
        }
        let (x, y);
        loop {
            let current = *chain.last().unwrap();
            let mut nearest = if chain.len() > 1 {
                chain[chain.len() - 2]
            } else {
                usize::MAX
            };
            let mut best = if nearest != usize::MAX {
                d[current][nearest]
            } else {
                f64::INFINITY
            };
            for (j, &size) in sizes.iter().enumerate() {
                if size > 0 && j != current && d[current][j] < best {
                    best = d[current][j];
                    nearest = j;
                }
            }
            ensure!(
                nearest != usize::MAX && best.is_finite(),
                "Invalid pairwise distances"
            );
            if chain.len() > 1 && nearest == chain[chain.len() - 2] {
                x = current.min(nearest);
                y = current.max(nearest);
                chain.pop();
                chain.pop();
                break;
            }
            chain.push(nearest);
            ensure!(
                chain.len() <= n + 1,
                "Nearest-neighbor chain did not converge"
            );
        }
        let nx = sizes[x] as f64;
        let ny = sizes[y] as f64;
        let xy = d[x][y];
        merges.push(Merge {
            left: labels[x].min(labels[y]),
            right: labels[x].max(labels[y]),
            height: xy,
            count: sizes[x] + sizes[y],
        });
        for i in 0..n {
            if i == x || i == y || sizes[i] == 0 {
                continue;
            }
            let (a, b) = (d[i][x], d[i][y]);
            let ni = sizes[i] as f64;
            let value = match method {
                "single" => a.min(b),
                "complete" => a.max(b),
                "average" => (nx * a + ny * b) / (nx + ny),
                "weighted" => (a + b) * 0.5,
                "ward" => (((ni + nx) * a * a + (ni + ny) * b * b - ni * xy * xy) / (ni + nx + ny))
                    .max(0.)
                    .sqrt(),
                _ => unreachable!(),
            };
            d[y][i] = value;
            d[i][y] = value;
        }
        sizes[y] += sizes[x];
        sizes[x] = 0;
        labels[y] = n + step;
    }
    Ok(merges)
}
pub fn cut(merges: &[Merge], n: usize, tau: f64) -> Vec<Vec<usize>> {
    if n == 0 {
        return vec![];
    }
    if n == 1 || tau >= 1. {
        return vec![(0..n).collect()];
    }
    if tau <= 0. {
        return (0..n).map(|i| vec![i]).collect();
    }
    let max = merges.iter().map(|m| m.height).fold(0_f64, f64::max);
    let threshold = tau * if max > 0. { max } else { 1. };
    fn leaves(node: usize, n: usize, z: &[Merge], out: &mut Vec<usize>) {
        if node < n {
            out.push(node)
        } else {
            leaves(z[node - n].left, n, z, out);
            leaves(z[node - n].right, n, z, out);
        }
    }
    fn visit(node: usize, n: usize, z: &[Merge], t: f64, out: &mut Vec<Vec<usize>>) {
        if node < n {
            out.push(vec![node])
        } else {
            let m = &z[node - n];
            if m.height <= t {
                let mut group = vec![];
                leaves(node, n, z, &mut group);
                group.sort();
                out.push(group)
            } else {
                visit(m.left, n, z, t, out);
                visit(m.right, n, z, t, out)
            }
        }
    }
    let mut out = vec![];
    visit(2 * n - 2, n, merges, threshold, &mut out);
    out.sort_by_key(|g| g[0]);
    out
}
pub fn cluster(
    items: &[ConformerInput],
    settings: &ClusterSettings,
    progress: &Progress,
) -> Result<ClusterResult> {
    ensure!(
        settings.tau.is_finite() && (0.0..=1.0).contains(&settings.tau),
        "τ must lie between 0 and 1"
    );
    ensure!(
        matches!(
            settings.selection.as_str(),
            "lowest_energy" | "tiered" | "medoid"
        ),
        "Unknown cluster selection mode"
    );
    let matrix = fingerprints_checked(items, settings.dihedral_weight, || progress.check())?;
    progress.check()?;
    let method = if settings.linkage == "all" {
        "average"
    } else {
        &settings.linkage
    };
    let merges = linkage(&matrix, method, progress)?;
    let groups = cut(&merges, items.len(), settings.tau);
    let mut selected = BTreeSet::new();
    let mut report = format!(
        "Conformer clustering\nLinkage: {method}\nTAU: {:.6}\nDihedral weight: {:.6}\nSelection: {}\nInput: {} conformers\nClusters: {}\n\nThe lowest conformer number is used as the source energy ranking.\n\n",
        settings.tau,
        settings.dihedral_weight,
        settings.selection,
        items.len(),
        groups.len()
    );
    if settings.linkage == "all" {
        for m in ["ward", "complete", "average", "single"] {
            let z = linkage(&matrix, m, progress)?;
            report += &format!(
                "{m}: {} clusters at the chosen TAU\n",
                cut(&z, items.len(), settings.tau).len()
            );
        }
        report.push('\n');
    }
    for (idx, g) in groups.iter().enumerate() {
        // NumPy sum/mean of the source float32 matrix are deliberately retained.
        let sums: BTreeMap<_, _> = g
            .iter()
            .map(|&i| (i, g.iter().map(|&j| matrix[i][j]).sum::<f32>()))
            .collect();
        let medoid = *g
            .iter()
            .min_by(|&&a, &&b| sums[&a].total_cmp(&sums[&b]).then(a.cmp(&b)))
            .unwrap();
        let mut values = vec![];
        for (k, &i) in g.iter().enumerate() {
            for &j in &g[k + 1..] {
                values.push(matrix[i][j]);
            }
        }
        let spread = if values.is_empty() {
            0_f32
        } else {
            values.iter().sum::<f32>() / values.len() as f32
        };
        let lowest = *g.iter().min_by_key(|&&i| items[i].number).unwrap();
        let mut kept = vec![];
        match settings.selection.as_str() {
            "medoid" => kept.push(medoid),
            "lowest_energy" => kept.push(lowest),
            "tiered" => {
                kept.push(lowest);
                if spread as f64 >= 0.12 && medoid != lowest {
                    kept.push(medoid)
                }
                if spread as f64 >= 0.18
                    && let Some(&outlier) =
                        g.iter().filter(|i| !kept.contains(i)).max_by(|&&a, &&b| {
                            matrix[a][medoid]
                                .total_cmp(&matrix[b][medoid])
                                .then(b.cmp(&a))
                        })
                {
                    kept.push(outlier);
                }
            }
            _ => bail!("Unknown selection"),
        }
        selected.extend(kept.iter().copied());
        report += &format!(
            "Cluster {}: members {:?}; medoid {}; mean pairwise spread {:.6}; selected {:?}\n",
            idx + 1,
            g.iter().map(|&i| items[i].number).collect::<Vec<_>>(),
            items[medoid].number,
            spread,
            kept.iter().map(|&i| items[i].number).collect::<Vec<_>>()
        );
    }
    report += &format!(
        "\n{} selected; {} set aside.\n",
        selected.len(),
        items.len() - selected.len()
    );
    Ok(ClusterResult {
        selected,
        groups,
        matrix,
        report,
    })
}
