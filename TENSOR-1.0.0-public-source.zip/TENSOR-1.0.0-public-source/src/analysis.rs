use crate::{
    gaussian::*,
    jobs::{OutputFile, Progress, replace_result_directory},
    math::*,
    molecule::*,
    symmetry::*,
};
use anyhow::{Context, Result, ensure};
use rayon::prelude::*;
use std::{
    collections::{BTreeMap, BTreeSet},
    path::{Path, PathBuf},
};

pub const OUTPUT_KEYS: [(&str, &str); 10] = [
    ("chemical_shifts", "Chemical shifts (unweighted + weighted)"),
    ("coupling_constants", "Coupling constants (if applicable)"),
    ("conformer_sdf", "Conformer SDF files"),
    ("distances", "Atomic distances"),
    ("noe_intensities", "NOE intensities"),
    ("noe_multipliers", "NOE equivalence multipliers"),
    ("frequencies", "Vibrational frequency listings"),
    ("pymol_script", "PyMOL labelling script"),
    ("dedup_report", "Deduplication report"),
    ("wiberg_report", "Wiberg bond index report"),
];
#[derive(Clone, Debug)]
pub struct Outputs(pub BTreeMap<String, bool>);
impl Default for Outputs {
    fn default() -> Self {
        Self(
            OUTPUT_KEYS
                .iter()
                .map(|(k, _)| (k.to_string(), true))
                .collect(),
        )
    }
}
impl Outputs {
    pub fn enabled(&self, key: &str) -> bool {
        self.0.get(key).copied().unwrap_or(false)
    }
    pub fn set_all(&mut self, value: bool) {
        for v in self.0.values_mut() {
            *v = value;
        }
    }
}
#[derive(Clone, Debug)]
pub struct AnalysisSettings {
    pub dedup: bool,
    pub temperature_override: Option<f64>,
    pub outputs: Outputs,
    pub per_compound: BTreeMap<String, Outputs>,
    pub output_root: Option<PathBuf>,
}
impl Default for AnalysisSettings {
    fn default() -> Self {
        Self {
            dedup: true,
            temperature_override: None,
            outputs: Outputs::default(),
            per_compound: BTreeMap::new(),
            output_root: None,
        }
    }
}
#[derive(Clone, Debug)]
pub struct ConformerResult {
    pub number: usize,
    pub energy: Option<f64>,
    pub relative: Option<f64>,
    pub population: f64,
    pub molecule: Molecule,
    pub shifts: Values,
    pub couplings: PairValues,
    pub distances: PairValues,
    pub noe: PairValues,
    pub frequencies: Frequencies,
}
#[derive(Clone, Debug)]
pub struct SpecialResult {
    pub kind: String,
    pub weighted: Values,
    pub shifts: BTreeMap<usize, Values>,
    pub populations: BTreeMap<usize, f64>,
    pub logs: Vec<GaussianLog>,
}
#[derive(Clone, Debug)]
pub struct CompoundResult {
    pub name: String,
    pub temperature: f64,
    pub structure: Molecule,
    pub equivalence: Vec<Vec<usize>>,
    pub conformers: Vec<ConformerResult>,
    pub base_shifts: Values,
    pub shifts: Values,
    pub couplings: PairValues,
    pub distances: PairValues,
    pub noe: PairValues,
    pub replacements: BTreeMap<usize, String>,
    pub specials: Vec<SpecialResult>,
    pub dedup: DedupResult,
    pub warnings: Vec<String>,
    pub directory: PathBuf,
    pub generated: Vec<PathBuf>,
    pub logs: Vec<GaussianLog>,
}
#[derive(Clone, Debug, Default)]
pub struct AnalysisResult {
    pub compounds: Vec<CompoundResult>,
    pub errors: Vec<String>,
}

pub fn base_compound(name: &str) -> &str {
    name.strip_suffix("-csulfur")
        .or_else(|| name.strip_suffix("-chalogen"))
        .unwrap_or(name)
}
pub fn populations(energies: &[f64], temperature: f64) -> Result<Vec<f64>> {
    ensure!(
        !energies.is_empty() && energies.iter().all(|x| x.is_finite()),
        "Missing or nonfinite Gibbs energies"
    );
    ensure!(
        temperature.is_finite() && temperature > 0.,
        "Temperature must be above 0 K"
    );
    let min = energies.iter().copied().fold(f64::INFINITY, f64::min);
    let factors: Vec<_> = energies
        .iter()
        .map(|e| (-((e - min) * HARTREE_TO_KCAL) / (R * temperature)).exp())
        .collect();
    let total = factors.iter().sum::<f64>();
    ensure!(
        total.is_finite() && total > 0.,
        "Invalid Boltzmann partition function"
    );
    Ok(factors.into_iter().map(|f| f / total).collect())
}
pub fn population_file(path: &Path) -> Result<Option<BTreeMap<usize, f64>>> {
    if !path.exists() {
        return Ok(None);
    }
    let text = std::fs::read_to_string(path)?;
    let re = regex::Regex::new(r"(?i)^Conformer\s+(\d+)\s*:\s*([-+0-9.eEdD]+)\s*%")?;
    let mut out = BTreeMap::new();
    for line in text.lines() {
        if let Some(c) = re.captures(line.trim()) {
            let n: usize = c[1].parse()?;
            let pop = float(&c[2])? / 100.;
            ensure!(pop >= 0., "Negative manual population");
            ensure!(
                out.insert(n, pop).is_none(),
                "Repeated conformer {n} in manual population file"
            );
        }
    }
    ensure!(
        !out.is_empty(),
        "{} contains no valid 'Conformer N: P%' rows",
        path.display()
    );
    let total: f64 = out.values().sum();
    ensure!(
        total.is_finite() && total > 0.,
        "Manual populations have a nonfinite or zero total"
    );
    for v in out.values_mut() {
        *v /= total
    }
    Ok(Some(out))
}
#[derive(Clone, Copy, Debug)]
pub struct Circle {
    pub center: V3,
    pub radius: f64,
    pub normal: V3,
}
pub fn circle(coords: &[V3], atoms: &[usize]) -> Circle {
    let [p1, p2, p3] = [coords[atoms[0]], coords[atoms[1]], coords[atoms[2]]];
    let normal = cross(sub(p2, p1), sub(p3, p1));
    let n = norm(normal);
    let center = mul(add(add(p1, p2), p3), 1. / 3.);
    if n == 0. {
        return Circle {
            center,
            radius: distance(p1, center),
            normal: [0., 0., 1.],
        };
    }
    Circle {
        center,
        radius: (distance(p1, center) + distance(p2, center) + distance(p3, center)) / 3.,
        normal: mul(normal, 1. / n),
    }
}
pub fn point_circle(point: V3, c: Circle) -> f64 {
    let to = sub(point, c.center);
    let dotp = dot(to, c.normal);
    let projection = sub(to, mul(c.normal, dotp));
    let length = norm(projection);
    if length < 1e-10 {
        (dotp * dotp + c.radius * c.radius).sqrt()
    } else {
        distance(point, add(c.center, mul(projection, c.radius / length)))
    }
}
fn basis(n: V3) -> (V3, V3) {
    let v = if n[0].abs() > 0.001 {
        [-n[1], n[0], 0.]
    } else {
        [0., -n[2], n[1]]
    };
    let u = mul(v, 1. / norm(v));
    (u, cross(n, u))
}
pub fn circle_distance(a: Circle, b: Circle) -> f64 {
    let vector = sub(b.center, a.center);
    let center_distance = norm(vector);
    if center_distance == 0. {
        return (a.radius - b.radius).abs();
    }
    if (dot(a.normal, b.normal).abs() - 1.).abs() < 1e-6 {
        let proj = dot(vector, a.normal);
        if proj.abs() < 1e-6 {
            return (center_distance - a.radius - b.radius).max(0.);
        }
        let plane = (center_distance * center_distance - proj * proj)
            .max(0.)
            .sqrt();
        return ((plane - a.radius - b.radius).max(0.).powi(2) + proj * proj).sqrt();
    }
    let mut min = f64::INFINITY;
    for (first, second) in [(a, b), (b, a)] {
        let (x, y) = basis(first.normal);
        for i in 0..36 {
            let angle = std::f64::consts::TAU * i as f64 / 36.;
            let point = add(
                first.center,
                mul(add(mul(x, angle.cos()), mul(y, angle.sin())), first.radius),
            );
            min = min.min(point_circle(point, second));
        }
    }
    min
}
pub fn methyl_distances(m: &Molecule) -> PairValues {
    let coords = m.coords();
    let adj = m.adjacency();
    let n = coords.len();
    let mut out = PairValues::new();
    for i in 0..n {
        for j in i + 1..n {
            out.insert((i, j), distance(coords[i], coords[j]));
        }
    }
    let mut groups = vec![];
    for (i, a) in m.atoms.iter().enumerate() {
        if a.element == "C" && adj[i].len() == 4 {
            let atoms: Vec<_> = adj[i]
                .iter()
                .copied()
                .filter(|&j| matches!(m.atoms[j].element.as_str(), "H" | "F"))
                .collect();
            if atoms.len() == 3 {
                groups.push((circle(&coords, &atoms), atoms));
            }
        }
    }
    let methyl_atoms: BTreeSet<_> = groups.iter().flat_map(|(_, g)| g.iter().copied()).collect();
    for (i, (a, ga)) in groups.iter().enumerate() {
        for (b, gb) in &groups[i + 1..] {
            let d = circle_distance(*a, *b);
            for &u in ga {
                for &v in gb {
                    out.insert(pair(u, v), d);
                }
            }
        }
    }
    for (i, &coordinate) in coords.iter().enumerate().take(n) {
        if !methyl_atoms.contains(&i) {
            for (c, g) in &groups {
                let d = point_circle(coordinate, *c);
                for &atom in g {
                    out.insert(pair(i, atom), d);
                }
            }
        }
    }
    // Distances within the same methyl/CF₃ group remain the actual atom distances.
    out
}
pub fn noe_intensities(distances: &PairValues) -> PairValues {
    distances
        .iter()
        .filter(|(_, r)| **r > 0.)
        .map(|(&p, &r)| (p, 1. / r.powi(6)))
        .collect()
}
pub fn group_sizes(groups: &[Vec<usize>], atoms: usize) -> Vec<usize> {
    let mut out = vec![1; atoms];
    for g in groups {
        for &i in g {
            out[i] = g.len();
        }
    }
    out
}
pub fn noe_multiplier(a: usize, b: usize) -> f64 {
    ((a.max(1) * b.max(1)) as f64).powf(-1. / 6.)
}
fn weighted_values<'a>(values: impl Iterator<Item = (f64, &'a Values)>) -> Values {
    let mut out = Values::new();
    for (pop, values) in values.filter(|(pop, _)| *pop > 0.) {
        for (&i, &v) in values {
            *out.entry(i).or_default() += pop * v;
        }
    }
    out
}
fn weighted_pairs<I: IntoIterator<Item = (Pair, f64)>>(
    values: impl Iterator<Item = (f64, I)>,
) -> PairValues {
    let mut out = PairValues::new();
    for (pop, values) in values.filter(|(pop, _)| *pop > 0.) {
        for (i, v) in values {
            *out.entry(i).or_default() += pop * v;
        }
    }
    out
}
fn scale_shifts(log: &GaussianLog, groups: &[Vec<usize>]) -> Result<Values> {
    let mut shifts = Values::new();
    // Check raw observations before equivalence averaging, which intentionally
    // expands a group average to every member and must not hide a missing atom.
    for (i, atom) in log.molecule.atoms.iter().enumerate() {
        let kind = match atom.element.as_str() {
            "C" => "carbon",
            "H" => "proton",
            "F" => "fluorine",
            "N" => "nitrogen",
            _ => continue,
        };
        if matches!(kind, "carbon" | "proton") || log.shieldings.contains_key(kind) {
            ensure!(
                log.shieldings
                    .get(kind)
                    .is_some_and(|values| values.contains_key(&i)),
                "{}: raw {} shielding is missing for atom {}",
                log.path.display(),
                atom.element,
                i + 1
            );
        }
    }
    for (kind, values) in &log.shieldings {
        let scale=log.scaling.get(kind).with_context(||format!("{}: missing {kind} scaling in the calculation title; include explicit s:<slope> i:<intercept>. Method-key and built-in table fallbacks are disabled.",log.path.display()))?;
        let scaled = values
            .iter()
            .map(|(&i, &v)| Ok((i, scale.apply(v)?)))
            .collect::<Result<Values>>()?;
        shifts.extend(average_shifts(&scaled, groups));
    }
    for (i, a) in log.molecule.atoms.iter().enumerate() {
        if matches!(a.element.as_str(), "C" | "H") {
            ensure!(
                shifts.contains_key(&i),
                "{}: {} shielding is missing for atom {}",
                log.path.display(),
                a.element,
                i + 1
            );
        }
    }
    ensure!(
        !shifts.is_empty(),
        "No chemical shifts in {}",
        log.path.display()
    );
    Ok(shifts)
}
#[derive(Clone, Copy)]
struct SpecialAnalysisContext<'a> {
    name: &'a str,
    logs: &'a [GaussianLog],
    structure: &'a Molecule,
    groups: &'a [Vec<usize>],
    removed: &'a BTreeSet<usize>,
    temperature: f64,
    input_directory: &'a Path,
    progress: &'a Progress,
}

fn special_analysis(
    kind: &str,
    context: &SpecialAnalysisContext<'_>,
) -> Result<Option<SpecialResult>> {
    let SpecialAnalysisContext {
        name,
        logs,
        structure,
        groups,
        removed,
        temperature,
        input_directory,
        progress: p,
    } = *context;
    let key = format!("{name}-{kind}");
    let present = logs.iter().filter(|l| l.compound == key).count();
    if present == 0 {
        p.log(format!(
            "{name}: no {kind} correction calculations supplied"
        ));
        return Ok(None);
    }
    p.log(format!(
        "{name}: processing {present} {kind} logs; title scaling only"
    ));
    for log in logs.iter().filter(|l| l.compound == key) {
        if removed.contains(&log.number) {
            p.log(format!(
                "{key}: excluding conformer {} (duplicate standard minimum)",
                log.number
            ));
        } else if !log.valid() {
            p.log(format!(
                "{key}: excluding conformer {} ({})",
                log.number,
                log.exclusions.join("; ")
            ));
        }
    }
    let adj = structure.adjacency();
    let mut selected = vec![];
    let mut per = BTreeMap::new();
    for log in logs
        .iter()
        .filter(|l| l.compound == key && l.valid() && !removed.contains(&l.number))
    {
        p.check()?;
        if log.energy.is_none() {
            continue;
        }
        ensure!(
            structure.same_topology(&log.molecule),
            "{}: special calculation atom identities or connectivity differ from the standard calculation",
            log.path.display()
        );
        let Some(carbon) = log.shieldings.get("carbon") else {
            continue;
        };
        for (i, atom) in structure.atoms.iter().enumerate() {
            if atom.element == "C" {
                ensure!(
                    carbon.contains_key(&i),
                    "{}: raw carbon shielding is missing for atom {}",
                    log.path.display(),
                    i + 1
                );
            }
        }
        p.log(format!(
            "{key}: conformer {} — converting carbon shieldings with explicit title factors",
            log.number
        ));
        let mut shifts = Values::new();
        for (&i, &shielding) in carbon {
            ensure!(
                i < structure.atoms.len(),
                "Special calculation has incompatible atom count"
            );
            let hs: Vec<_> = adj[i]
                .iter()
                .filter_map(|&n| match structure.atoms[n].element.as_str() {
                    "Cl" => Some((1, "Cl")),
                    "Br" => Some((2, "Br")),
                    "I" => Some((3, "I")),
                    _ => None,
                })
                .collect();
            let s = if kind == "csulfur"
                && hs.is_empty()
                && adj[i].iter().any(|&n| structure.atoms[n].element == "S")
            {
                Some(*log.scaling.get("carbon").with_context(|| format!(
                    "{}: missing sulfur-carbon title scaling; include explicit s:<slope> i:<intercept>. No method-key or average fallback is used.", log.path.display()
                ))?)
            } else if kind == "chalogen" {
                if hs.is_empty() {
                    None
                } else {
                    Some(*log.halogen_scaling.get(&i).or_else(|| log.scaling.get("carbon")).with_context(|| format!(
                        "{}: missing halogen-carbon title scaling for atom {}; include its hal{{...}} entry or an explicit carbon s:<slope> i:<intercept>. No table fallback is used.", log.path.display(), i+1
                    ))?)
                }
            } else {
                None
            };
            if let Some(sc) = s {
                shifts.insert(i, sc.apply(shielding)?);
            }
        }
        if !shifts.is_empty() {
            per.insert(log.number, average_shifts(&shifts, groups));
            selected.push(log.clone());
        }
    }
    if selected.is_empty() {
        return Ok(None);
    }
    let manual = population_file(&input_directory.join(format!("{key}_boltzmann.txt")))?;
    p.log(format!(
        "{key}: weighting {} retained correction conformers using {}",
        selected.len(),
        if manual.is_some() {
            "manual populations"
        } else {
            "their Gibbs energies"
        }
    ));
    let mut weights = if let Some(manual) = manual {
        selected
            .iter()
            .map(|l| manual.get(&l.number).copied().unwrap_or(0.))
            .collect::<Vec<_>>()
    } else {
        populations(
            &selected
                .iter()
                .map(|l| l.energy.unwrap())
                .collect::<Vec<_>>(),
            temperature,
        )?
    };
    let total = weights.iter().sum::<f64>();
    ensure!(total > 0., "No positive populations for {key}");
    for w in &mut weights {
        *w /= total
    }
    let populations: BTreeMap<_, _> = selected
        .iter()
        .zip(weights)
        .map(|(l, p)| (l.number, p))
        .collect();
    let expected: BTreeSet<_> = per
        .values()
        .flat_map(|values| values.keys().copied())
        .collect();
    for (&number, values) in &per {
        if populations[&number] > 0. {
            ensure!(
                values.keys().copied().collect::<BTreeSet<_>>() == expected,
                "{key}: correction atom inventory differs in populated conformer {number}"
            );
        }
    }
    let weighted = weighted_values(per.iter().map(|(&n, s)| (populations[&n], s)));
    Ok(Some(SpecialResult {
        kind: kind.into(),
        weighted,
        shifts: per,
        populations,
        logs: selected,
    }))
}
pub fn analyze_compound(
    name: &str,
    logs: Vec<GaussianLog>,
    settings: &AnalysisSettings,
    input_directory: &Path,
    p: &Progress,
) -> Result<CompoundResult> {
    let mut warnings = vec![];
    let mut valid: Vec<_> = logs
        .iter()
        .filter(|l| l.compound == name && l.valid())
        .collect();
    valid.sort_by_key(|l| l.number);
    for log in &logs {
        for note in &log.warnings {
            warnings.push(format!(
                "{}: {note}",
                log.path.file_name().unwrap_or_default().to_string_lossy()
            ));
        }
        if !log.valid() {
            warnings.push(format!(
                "{} excluded: {}",
                log.path.file_name().unwrap_or_default().to_string_lossy(),
                log.exclusions.join("; ")
            ));
        }
    }
    ensure!(
        !valid.is_empty(),
        "{name}: no valid completed standard calculations"
    );
    p.log(format!(
        "{name}: {} completed standard conformers accepted",
        valid.len()
    ));
    p.log(format!(
        "{name}: extracting final geometries and checking connectivity / Wiberg bond orders"
    ));
    let structure = valid[0].molecule.clone();
    for log in &valid {
        ensure!(
            structure.same_topology(&log.molecule),
            "{name}: atom identities or connectivity differ in {}",
            log.path.display()
        );
    }
    let temperature = settings
        .temperature_override
        .unwrap_or(valid[0].temperature);
    ensure!(
        temperature.is_finite() && temperature > 0.,
        "Invalid ensemble temperature"
    );
    if valid
        .iter()
        .any(|l| (l.temperature - valid[0].temperature).abs() > 0.01)
    {
        warnings.push(format!(
            "Temperature differs between logs; weighting uses {temperature} K."
        ));
    }
    for l in valid
        .iter()
        .skip(1)
        .step_by((valid.len().saturating_sub(1) / 4).max(1))
        .take(4)
    {
        for (&pair, &order) in &structure.bonds {
            if l.molecule.bonds.get(&pair) != Some(&order) {
                warnings.push(format!("Conformer {}: Wiberg order differs for bond {}–{}; using the lowest-energy accepted conformer's order.",l.number,pair.0+1,pair.1+1));
            }
        }
    }
    p.log(format!(
        "{name}: temperature {temperature:.2} K; {} atoms, {} bonds",
        structure.atoms.len(),
        structure.bonds.len()
    ));
    p.log(format!("{name}: determining chemical equivalence"));
    let eq = equivalence(&structure, p)?;
    if eq.exhausted {
        warnings.push("Chemical equivalence search reached its node budget; unresolved atoms remain separate.".into());
    }
    if !eq.unverifiable.is_empty() {
        warnings.push(format!(
            "Conservative equivalence treatment around hypervalent/cumulated centers: atoms {:?}",
            eq.unverifiable.iter().map(|i| i + 1).collect::<Vec<_>>()
        ));
    }
    let inputs: Vec<_> = valid
        .iter()
        .map(|l| DedupInput {
            number: l.number,
            energy: l.energy,
            coordinates: l.molecule.coords(),
            frequencies: l.frequencies.values.clone(),
        })
        .collect();
    p.log(format!(
        "{name}: checking {} conformers for duplicate minima",
        valid.len()
    ));
    let dedup = deduplicate(&structure, &inputs, settings.dedup, p)?;
    p.log(format!(
        "{name}: duplicate check complete — {} removed, {} retained",
        dedup.duplicates.len(),
        dedup.survivors.len()
    ));
    valid.retain(|l| dedup.survivors.contains(&l.number));
    let manual = population_file(&input_directory.join(format!("{name}_boltzmann.txt")))?;
    p.log(format!(
        "{name}: {}",
        if manual.is_some() {
            "reading and normalizing manual populations after exclusions"
        } else {
            "calculating Boltzmann populations from Gibbs energies"
        }
    ));
    let contributing: Vec<_> = valid
        .iter()
        .copied()
        .filter(|l| {
            if let Some(manual) = &manual {
                manual.contains_key(&l.number)
            } else {
                l.energy.is_some()
            }
        })
        .collect();
    ensure!(
        !contributing.is_empty(),
        "{name}: no Gibbs energies or matching manual populations"
    );
    let weights = if let Some(manual) = &manual {
        let w: Vec<_> = contributing.iter().map(|l| manual[&l.number]).collect();
        let total = w.iter().sum::<f64>();
        ensure!(
            total > 0.,
            "No positive manual populations remain after exclusions/deduplication"
        );
        w.into_iter().map(|w| w / total).collect::<Vec<_>>()
    } else {
        populations(
            &contributing
                .iter()
                .map(|l| l.energy.unwrap())
                .collect::<Vec<_>>(),
            temperature,
        )?
    };
    if contributing.len() != valid.len() {
        warnings.push(
            "Conformers without Gibbs energies / manual populations were excluded from weighting."
                .into(),
        );
    }
    let minimum = contributing
        .iter()
        .filter_map(|l| l.energy)
        .fold(f64::INFINITY, f64::min);
    p.log(format!("{name}: converting title-scaled shieldings, averaging equivalent atoms / J values, and calculating distances / NOEs"));
    let mut conformers: Vec<ConformerResult> = contributing.par_iter().zip(weights.par_iter()).map(|(log,&population)| -> Result<ConformerResult> {
        p.check()?;
        let shifts = scale_shifts(log, &eq.groups)?;
        let mut molecule = structure.clone();
        for (a, b) in molecule.atoms.iter_mut().zip(&log.molecule.atoms) {
            a.xyz = b.xyz.map(|x| round_decimal(x, 6));
        }
        let distances = methyl_distances(&molecule);
        let noe = noe_intensities(&distances);
        p.log(format!("{name}: conformer {} — shifts, couplings, methyl/CF₃ distances and 1/r⁶ values complete (population {:.3}%)",log.number,population*100.));
        Ok(ConformerResult {
            number: log.number,
            energy: log.energy,
            relative: log.energy.map(|e| (e - minimum) * HARTREE_TO_KCAL),
            population,
            molecule,
            shifts,
            couplings: average_couplings(&log.couplings, &eq.groups, structure.atoms.len()),
            distances,
            noe,
            frequencies: log.frequencies.clone(),
        })
    }).collect::<Result<Vec<_>>>()?;
    // A missing NMR section must never silently contribute a zero to an average.
    let expected = conformers
        .iter()
        .find(|c| c.population > 0.)
        .context("No positive populations")?
        .shifts
        .keys()
        .copied()
        .collect::<BTreeSet<_>>();
    for c in conformers.iter().filter(|c| c.population > 0.) {
        ensure!(
            c.shifts.keys().copied().collect::<BTreeSet<_>>() == expected,
            "{name}: populated conformers contain different NMR nuclei/atom inventories (conformer {})",
            c.number
        );
    }
    for kind in ["carbon", "proton", "fluorine", "nitrogen"] {
        let mut reference = None;
        for (log, _) in contributing.iter().zip(&weights).filter(|(_, w)| **w > 0.) {
            if let Some(sc) = log.scaling.get(kind) {
                if let Some(previous) = reference {
                    ensure!(
                        previous == *sc,
                        "{name}: {kind} scaling constants differ between conformers"
                    );
                } else {
                    reference = Some(*sc);
                }
            }
        }
    }
    p.log(format!(
        "{name}: population-weighting chemical shifts and coupling matrices"
    ));
    let base_shifts = weighted_values(conformers.iter().map(|c| (c.population, &c.shifts)));
    let mut shifts = base_shifts.clone();
    let coupling_keys: BTreeSet<_> = conformers
        .iter()
        .filter(|c| c.population > 0.)
        .flat_map(|c| c.couplings.keys().copied())
        .collect();
    let compatible = conformers
        .iter()
        .filter(|c| c.population > 0.)
        .all(|c| c.couplings.keys().copied().collect::<BTreeSet<_>>() == coupling_keys);
    let couplings = if compatible {
        weighted_pairs(
            conformers
                .iter()
                .map(|c| (c.population, c.couplings.iter().map(|(&p, &v)| (p, v)))),
        )
    } else {
        warnings.push("Weighted couplings were omitted because populated conformers have incomplete or different coupling matrices; available unweighted matrices are retained.".into());
        PairValues::new()
    };
    // Apply the documented per-conformer rounding in memory so output
    // switches cannot affect another result.
    p.log(format!("{name}: population-weighting distances after 0.01 A rounding and NOE intensities after three-decimal scientific-notation rounding"));
    let distances = weighted_pairs(conformers.iter().map(|c| {
        (
            c.population,
            c.distances.iter().map(|(&p, &d)| (p, round_decimal(d, 2))),
        )
    }));
    let noe = weighted_pairs(conformers.iter().map(|c| {
        (
            c.population,
            c.noe
                .iter()
                .map(|(&p, &v)| (p, format!("{v:.3e}").parse().unwrap_or(v))),
        )
    }));
    let removed = dedup.duplicates.iter().map(|d| d.number).collect();
    let mut specials = vec![];
    let mut replacements = BTreeMap::new();
    let special_context = SpecialAnalysisContext {
        name,
        logs: &logs,
        structure: &structure,
        groups: &eq.groups,
        removed: &removed,
        temperature,
        input_directory,
        progress: p,
    };
    for kind in ["csulfur", "chalogen"] {
        if let Some(s) = special_analysis(kind, &special_context)? {
            for (&i, &v) in &s.weighted {
                shifts.insert(i, round_decimal(v, 3));
                replacements.insert(i, kind.into());
            }
            specials.push(s);
        }
    }
    p.log(format!(
        "{name}: combining standard and special-carbon weighted labels for the 3D viewer"
    ));
    // The viewer opens the lowest-energy surviving conformer.
    conformers.sort_by(|a, b| {
        a.energy
            .unwrap_or(f64::INFINITY)
            .total_cmp(&b.energy.unwrap_or(f64::INFINITY))
            .then(a.number.cmp(&b.number))
    });
    let root = settings.output_root.as_deref().unwrap_or(input_directory);
    Ok(CompoundResult {
        name: name.into(),
        temperature,
        structure,
        equivalence: eq.groups,
        conformers,
        base_shifts,
        shifts,
        couplings,
        distances,
        noe,
        replacements,
        specials,
        dedup,
        warnings,
        directory: root.join(name),
        generated: vec![],
        logs,
    })
}

pub fn shifts_text(shifts: &Values, m: &Molecule, groups: &[Vec<usize>], title: &str) -> String {
    let mut rows = BTreeMap::<usize, String>::new();
    let mut processed = BTreeSet::new();
    for g in groups {
        let present: Vec<_> = g
            .iter()
            .copied()
            .filter(|i| shifts.contains_key(i))
            .collect();
        if present.len() > 1 {
            let list = present
                .iter()
                .map(|i| (i + 1).to_string())
                .collect::<Vec<_>>()
                .join(", ");
            let i = present[0];
            rows.insert(
                i,
                format!("Atoms {list} ({}): {:.3}\n", m.atoms[i].element, shifts[&i]),
            );
            processed.extend(present);
        }
    }
    for (&i, &v) in shifts {
        if !processed.contains(&i) {
            rows.insert(
                i,
                format!("Atom {} ({}): {v:.3}\n", i + 1, m.atoms[i].element),
            );
        }
    }
    format!("{title}\n{}", rows.into_values().collect::<String>())
}
pub fn pair_text(values: &PairValues, title: &str, noe: bool) -> String {
    let mut out = format!("{title}\n");
    if noe {
        out.push('\n')
    }
    let mut grouped = BTreeMap::<usize, Vec<String>>::new();
    for (&(i, j), &v) in values {
        let value = if noe {
            let raw = format!("{v:.3e}");
            if let Some((sig, exp)) = raw.split_once('e') {
                let n = exp.parse::<i32>().unwrap_or(0);
                format!("{sig}e{n:+03}")
            } else {
                raw
            }
        } else {
            format!("{v:.2}")
        };
        let width = if noe { 22 } else { 18 };
        grouped.entry(i).or_default().push(format!(
            "{:<width$}",
            format!("{} - {}: {value}", i + 1, j + 1)
        ));
    }
    let width = if noe { 4 } else { 5 };
    for rows in grouped.values() {
        for chunk in rows.chunks(width) {
            out += &chunk.join("");
            out.push('\n');
        }
        out.push('\n');
    }
    out
}
fn multiplier_text(values: &PairValues, m: &Molecule, groups: &[Vec<usize>]) -> String {
    let sizes = group_sizes(groups, m.atoms.len());
    let mut out="NOE Equivalence Multipliers\n==============================================================================\nAdditive r^-6 NOE physics: N equivalent spins at distance r contribute N*r^-6 to the\nintegrated cross peak, so the apparent distance is r*(Na*Nb)^(-1/6), shorter than the\ntrue per-atom distance. Multiply an apparent (measured) distance by 1/factor to recover\nthe per-atom distance. Only pairs with a factor other than 1 are listed.\n\n  Atom i  Atom j   Ni   Nj    factor     r (A)  apparent (A)\n------------------------------------------------------------------------------\n".to_string();
    let mut written = 0;
    for (&(i, j), &d) in values {
        let factor = noe_multiplier(sizes[i], sizes[j]);
        if (factor - 1.).abs() < 1e-12 {
            continue;
        }
        out += &format!(
            "{:>8}{:>8}{:>5}{:>5}{factor:>10.4}{d:>10.4}{:>14.4}\n",
            i + 1,
            j + 1,
            sizes[i],
            sizes[j],
            d * factor
        );
        written += 1;
    }
    if written == 0 {
        out += "  (no equivalent-atom pairs in this structure)\n";
    }
    out
}
fn frequency_text(log_name: &str, f: &Frequencies) -> String {
    let mut out = format!(
        "File: {log_name}\nNumber of significant imaginary frequencies: {}\n\n",
        f.values.iter().filter(|&&v| v < -12.).count()
    );
    for (title, values) in [
        ("Frequencies (cm^-1):", &f.values),
        ("Reduced masses (amu):", &f.masses),
        ("Force constants (mDyne/A):", &f.forces),
        ("IR Intensities (KM/Mole):", &f.intensities),
    ] {
        out += &format!("{title}\n");
        for chunk in values.chunks(5) {
            out += &chunk
                .iter()
                .map(|v| format!("{:<10}", format!("{v:.4}")))
                .collect::<Vec<_>>()
                .join(" ");
            out.push('\n');
        }
        out.push('\n');
    }
    out
}
fn pymol_text(c: &CompoundResult) -> String {
    let first = c.conformers[0].number;
    let filename = format!("Conformer SDF Files/{}_{}.sdf", c.name, first)
        .replace('\\', "\\\\")
        .replace('"', "\\\"");
    let mut out = format!(
        "load \"{filename}\"\nhide everything\nshow sticks\n\n# Weighted, chemically equivalent shifts\n"
    );
    for (&i, &v) in &c.shifts {
        out += &format!("label id {}, '{v:.2}'", i + 1);
        if let Some(kind) = c.replacements.get(&i) {
            out += &format!(" # Replaced by {kind} results");
        }
        out.push('\n');
    }
    out += "\nbg_color black\nset stick_radius, 0.15\nset_color dark_grey, [0.5, 0.5, 0.5]\nset_color bright_grey, [0.8, 0.8, 0.8]\nset_color deep_blue, [0.0, 0.0, 0.8]\nset_color deep_red, [0.8, 0.0, 0.0]\nset_color light_pink, [1.0, 0.75, 0.8]\ncolor dark_grey, elem C\ncolor bright_grey, elem H\ncolor deep_blue, elem N\ncolor deep_red, elem O\ncolor light_pink, elem F\nset label_font_id, 5\nset label_size, 15\nset_color deep_gold, [1.0, 0.8, 0.0]\nset label_color, deep_gold\nset antialias_shader, 2\nset line_smooth, 1\nset specular, 1.0\nset use_shaders, 0\nset stick_use_shader, 1\nset render_as_cylinders, 1\nset line_as_cylinders, 1\nset stick_as_cylinders, 1\nset dot_as_spheres, 1\nset depth_cue, 0\nshow sticks, all\n";
    out
}
pub fn output_files(c: &CompoundResult, options: &Outputs) -> Vec<OutputFile> {
    let mut files = vec![];
    let n = &c.name;
    let mut put = |path: String, text: String| files.push(OutputFile::new(path, text));
    let mut pop = "Boltzmann Populations:\n".to_string();
    let mut energy = "Raw Energies (Hartrees):\n".to_string();
    let mut confs: Vec<_> = c.conformers.iter().collect();
    confs.sort_by_key(|c| c.number);
    for conformer in &confs {
        pop += &format!(
            "Conformer {}: {:.2}%\n",
            conformer.number,
            conformer.population * 100.
        );
        energy += &format!(
            "Conformer {}: {}\n",
            conformer.number,
            conformer
                .energy
                .map(|v| format!("{v:.10}"))
                .unwrap_or("N/A".into())
        );
    }
    put(format!("{n}_boltzmann_populations.txt"), pop);
    put(format!("{n}_raw_energies.txt"), energy);
    let mut summary = format!(
        "TENSOR\nCompound: {n}\nTemperature: {:.4} K\nRetained conformers: {}\nDuplicate minima removed: {}\n\n",
        c.temperature,
        c.conformers.len(),
        c.dedup.duplicates.len()
    );
    for note in &c.warnings {
        summary += &format!("NOTE: {note}\n")
    }
    summary += "\nShift scaling: delta = (shielding - intercept) / slope.\nEach per-conformer distance is rounded to 0.01 A before population weighting.\nEach per-conformer relative 1/r⁶ NOE value is rounded to three decimal places in scientific notation before population weighting. Terminal methyl and CF₃ groups use the documented rotation-circle distance surrogate.\n";
    put(format!("{n}_analysis_report.txt"), summary);
    if options.enabled("chemical_shifts") {
        put(
            format!("{n}_weighted_shifts.txt"),
            shifts_text(
                &c.base_shifts,
                &c.structure,
                &c.equivalence,
                "Weighted Chemical Shifts (ppm):",
            ),
        );
        if !c.specials.is_empty() {
            put(
                format!("{n}_combined_weighted_shifts.txt"),
                shifts_text(
                    &c.shifts,
                    &c.structure,
                    &c.equivalence,
                    "Weighted Chemical Shifts Including Special Carbon Corrections (ppm):",
                ),
            );
        }
    }
    if options.enabled("coupling_constants") && !c.couplings.is_empty() {
        put(
            format!("{n}_weighted_coupling_constants.txt"),
            pair_text(&c.couplings, "Weighted Coupling Constants (Hz):", false),
        );
    }
    if options.enabled("distances") {
        put(
            format!("{n}_weighted_distances.txt"),
            pair_text(
                &c.distances,
                "Weighted Atomic Distances (Angstroms):",
                false,
            ),
        );
    }
    if options.enabled("noe_intensities") {
        put(
            format!("{n}_weighted_noe_intensities.txt"),
            pair_text(&c.noe, "Weighted NOE Intensities (1/r^6 values):", true),
        );
    }
    if options.enabled("noe_multipliers") {
        put(
            format!("{n}_weighted_noe_equivalence_multipliers.txt"),
            multiplier_text(&c.distances, &c.structure, &c.equivalence),
        );
    }
    if options.enabled("pymol_script") {
        put(format!("{n}_chemical_shifts.pml"), pymol_text(c));
    }
    if options.enabled("dedup_report") {
        put(
            format!("{n}_conformer_deduplication.txt"),
            c.dedup.report.clone(),
        );
    }
    for x in &confs {
        let number = x.number;
        if options.enabled("chemical_shifts") {
            put(
                format!("Unweighted NMR Data/{n}_conformer_{number}_shifts.txt"),
                shifts_text(
                    &x.shifts,
                    &c.structure,
                    &c.equivalence,
                    "Unweighted Chemical Shifts (ppm):",
                ),
            );
        }
        if options.enabled("coupling_constants") && !x.couplings.is_empty() {
            put(
                format!("Unweighted NMR Data/{n}_conformer_{number}_coupling_constants.txt"),
                pair_text(&x.couplings, "Unweighted Coupling Constants (Hz):", false),
            );
        }
        if options.enabled("conformer_sdf") {
            put(
                format!("Conformer SDF Files/{n}_{number}.sdf"),
                v3000(&x.molecule, n, number, x.energy),
            );
        }
        if options.enabled("distances") {
            put(
                format!("Unweighted Atomic Distances/{n}_{number}_distances.txt"),
                pair_text(
                    &x.distances,
                    "Unweighted Atomic Distances (Angstroms):",
                    false,
                ),
            );
        }
        if options.enabled("noe_intensities") {
            put(
                format!("Unweighted NOE Intensities/{n}_{number}_noe_intensities.txt"),
                pair_text(&x.noe, "Unweighted NOE Intensities (1/r^6 values):", true),
            );
        }
        if options.enabled("noe_multipliers") {
            put(
                format!("Unweighted Atomic Distances/{n}_{number}_noe_equivalence_multipliers.txt"),
                multiplier_text(&x.distances, &c.structure, &c.equivalence),
            );
        }
    }
    for special in &c.specials {
        let kind = &special.kind;
        if options.enabled("chemical_shifts") {
            put(
                format!("{n}_{kind}_weighted_shifts.txt"),
                shifts_text(
                    &special.weighted,
                    &c.structure,
                    &[] as &[Vec<usize>],
                    &format!("Weighted ({kind}) Carbon Shifts (ppm):"),
                ),
            );
            for (&number, s) in &special.shifts {
                put(
                    format!("Unweighted NMR Data/{n}_{kind}_conformer_{number}_shifts.txt"),
                    shifts_text(
                        s,
                        &c.structure,
                        &[],
                        &format!("Unweighted ({kind}) Carbon Shifts (ppm):"),
                    ),
                );
            }
        }
        let mut pop = "Boltzmann Populations:\n".to_string();
        for (&number, &v) in &special.populations {
            pop += &format!("Conformer {number}: {:.2}%\n", v * 100.);
        }
        put(format!("{n}_{kind}_boltzmann_populations.txt"), pop);
    }
    for log in &c.logs {
        if options.enabled("frequencies") {
            put(
                format!(
                    "Frequencies/{}_{}_frequencies.txt",
                    log.compound, log.number
                ),
                frequency_text(
                    &log.path.file_name().unwrap_or_default().to_string_lossy(),
                    &log.frequencies,
                ),
            );
        }
        if options.enabled("wiberg_report") && log.compound == c.name {
            let mut text = format!(
                "Wiberg Bond Index Report: {n}, conformer {}\nClassification boundaries: below 0.35 no bond; <=1.30 single; <=1.60 delocalized/aromatic; <=2.40 double; >2.40 triple.\nExisting connectivity edges below 0.35 remain single. Conservative terminal carbonyl and comparable two-oxygen delocalization rules may override the discrete depiction; raw WBI values remain unchanged.\nTopology overrides in this conformer: {}\n\nAtom pair\tRaw WBI\tDisplayed bond order\n",
                log.number, log.topology_adjusted
            );
            for (&(a, b), &order) in &log.molecule.bonds {
                let w = log
                    .wiberg
                    .get(&(a, b))
                    .map(|v| format!("{v:.4}"))
                    .unwrap_or("missing".into());
                let displayed = if order.fract().abs() < 1e-8 {
                    format!("{order:.0}")
                } else {
                    format!("{order:.1}")
                };
                text += &format!("{} - {}\t{w}\t{displayed}\n", a + 1, b + 1);
            }
            put(
                format!("Wiberg Bond Indices/{n}_{}_wiberg.txt", log.number),
                text,
            );
        }
    }
    files
}
pub fn run_analysis(
    paths: &[PathBuf],
    settings: &AnalysisSettings,
    p: &Progress,
) -> Result<AnalysisResult> {
    ensure!(!paths.is_empty(), "No Gaussian log files selected");
    let started = std::time::Instant::now();
    p.log("==================== RUNNING NMR ANALYSIS ====================");
    p.log(format!(
        "Input selection: {} files; deduplication {}",
        paths.len(),
        if settings.dedup { "on" } else { "off" }
    ));
    p.log(match settings.temperature_override {
        Some(t) => format!("Temperature override: {t:.2} K"),
        None => "Temperature: read from each compound's logs".into(),
    });
    p.log(format!(
        "Results: {}",
        settings
            .output_root
            .as_deref()
            .map(|p| p.display().to_string())
            .unwrap_or_else(|| "beside each compound's logs".into())
    ));
    let log_roots: BTreeSet<PathBuf> = if let Some(root) = &settings.output_root {
        [root.clone()].into_iter().collect()
    } else {
        paths
            .iter()
            .filter_map(|p| p.parent().map(Path::to_path_buf))
            .collect()
    };
    let mut all_paths: BTreeSet<_> = paths.iter().cloned().collect();
    // Companion jobs belong to the same explicitly loaded conformer.
    for path in paths {
        if let Some((name, num)) = number_name(path)
            && base_compound(&name) == name
        {
            for kind in ["csulfur", "chalogen"] {
                let candidate = path.with_file_name(format!("{name}-{kind}_{num}.log"));
                if candidate.exists() {
                    all_paths.insert(candidate);
                }
            }
        }
    }
    let mut grouped = BTreeMap::<String, Vec<GaussianLog>>::new();
    let mut directories = BTreeMap::<String, PathBuf>::new();
    let mut identities = BTreeSet::new();
    let mut result = AnalysisResult::default();
    let paths: Vec<_> = all_paths.into_iter().collect();
    let workers = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1)
        .min(8)
        .min(paths.len())
        .max(1);
    p.log(format!(
        "Reading {} Gaussian logs using {workers} worker(s)",
        paths.len()
    ));
    let pool = rayon::ThreadPoolBuilder::new()
        .num_threads(workers)
        .build()?;
    let parsed: Vec<_> = pool.install(|| {
        paths
            .par_iter()
            .enumerate()
            .map(|(index,path)| {
                p.log(format!("[file {}/{}] Reading {}",index+1,paths.len(),path.file_name().unwrap_or_default().to_string_lossy()));
                let log=p.check().and_then(|_|parse_log(path));
                if let Ok(log)=&log {
                    p.log(format!("{}: {} atoms, {} bonds ({} Wiberg order changes; {} topology overrides), {} frequencies, {} J entries; {}",path.file_name().unwrap_or_default().to_string_lossy(),log.molecule.atoms.len(),log.molecule.bonds.len(),log.wiberg_adjusted,log.topology_adjusted,log.frequencies.values.len(),log.couplings.len(),if log.valid(){"completed".into()}else{format!("EXCLUDED: {}",log.exclusions.join("; "))}));
                    let mut factors=log.scaling.iter().filter(|(kind,_)|log.shieldings.contains_key(*kind)).map(|(kind,s)|format!("{kind} s={} i={}",s.slope,s.intercept)).collect::<Vec<_>>();
                    factors.extend(log.halogen_scaling.iter().map(|(i,s)|format!("halogen C{} s={} i={}",i+1,s.slope,s.intercept)));
                    p.log(format!("{}: title scaling: {}",path.file_name().unwrap_or_default().to_string_lossy(),if factors.is_empty(){"MISSING".into()}else{factors.join("; ")}));
                }
                (path.clone(),log)
            })
            .collect()
    });
    for (path, parsed_log) in parsed {
        p.check()?;
        match parsed_log {
            Ok(log) => {
                let name = base_compound(&log.compound).to_string();
                let dir = path
                    .parent()
                    .context("No input parent folder")?
                    .to_path_buf();
                ensure!(
                    directories.get(&name).is_none_or(|d| d == &dir),
                    "Logs for {name} span different directories; load one ensemble directory at a time"
                );
                ensure!(
                    identities.insert((log.compound.clone(), log.number)),
                    "Duplicate log identity {}_{}",
                    log.compound,
                    log.number
                );
                directories.insert(name.clone(), dir);
                grouped.entry(name).or_default().push(log);
            }
            Err(e) => {
                let msg = format!("{}: {e:#}", path.display());
                p.log(&msg);
                result.errors.push(msg);
            }
        }
    }
    let count = grouped.len();
    p.log(format!("Found {count} selected compound(s)"));
    for (index, (name, logs)) in grouped.into_iter().enumerate() {
        p.log(format!(
            "\n[compound {}/{}] Processing {name}",
            index + 1,
            count
        ));
        p.check()?;
        let outcome = (|| -> Result<CompoundResult> {
            let mut c =
                pool.install(|| analyze_compound(&name, logs, settings, &directories[&name], p))?;
            let outputs = settings
                .per_compound
                .get(&name)
                .unwrap_or(&settings.outputs);
            let files = output_files(&c, outputs);
            for (key, label) in OUTPUT_KEYS {
                if outputs.enabled(key) {
                    p.log(format!("{name}: preparing {label}"));
                }
            }
            p.log(format!("{name}: committing {} output files", files.len()));
            // Failed parses and other selected compounds are inputs too.
            c.generated = replace_result_directory(&c.directory, &files, &paths, p)?;
            for message in &c.warnings {
                p.log(format!("{name}: {message}"));
            }
            p.log(format!(
                "{name}: {} conformers, {} duplicate minima removed; {} files saved.",
                c.conformers.len(),
                c.dedup.duplicates.len(),
                c.generated.len()
            ));
            Ok(c)
        })();
        match outcome {
            Ok(c) => result.compounds.push(c),
            Err(e) => {
                p.check()?;
                let msg = format!("{name}: {e:#}");
                p.log(&msg);
                result.errors.push(msg);
            }
        }
    }
    p.log(format!("==================== ANALYSIS FINISHED ====================\n{} compounds; {} retained conformers; {} reported errors; {:.2} seconds",result.compounds.len(),result.compounds.iter().map(|c|c.conformers.len()).sum::<usize>(),result.errors.len(),started.elapsed().as_secs_f64()));
    for root in log_roots {
        let path = root.join("tensor-log.txt");
        p.log(format!("Run log: {}", path.display()));
        if let Err(error) = p.save_log(&path) {
            p.log(format!("Could not save run log: {error:#}"));
        }
    }
    ensure!(
        !result.compounds.is_empty(),
        "No compounds completed.\n{}",
        result.errors.join("\n")
    );
    Ok(result)
}
