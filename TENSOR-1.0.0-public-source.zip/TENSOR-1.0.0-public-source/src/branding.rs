use anyhow::{Context, Result, ensure};
use eframe::egui;
use std::io::Cursor;

pub const SYMBOL_FONT: &[u8] = include_bytes!("../assets/DejaVuSans.ttf");
pub const LABEL_FONT: &[u8] = include_bytes!("../assets/DejaVuSans-Bold.ttf");
pub const LOGO: &[u8] = include_bytes!("../assets/tensor-logo.png");
pub const DEVELOPMENT_CREDIT: &str = "Developed by Jared Wood and OpenAI GPT-5.6 Sol";

pub fn install_fonts(ctx: &egui::Context) {
    let mut definitions = egui::FontDefinitions::default();
    definitions.font_data.insert(
        "tensor_bold".into(),
        egui::FontData::from_static(LABEL_FONT).into(),
    );
    definitions.families.insert(
        egui::FontFamily::Name("tensor_labels".into()),
        vec!["tensor_bold".into()],
    );
    definitions.font_data.insert(
        "tensor_symbols".into(),
        egui::FontData::from_static(SYMBOL_FONT).into(),
    );
    for family in [egui::FontFamily::Proportional, egui::FontFamily::Monospace] {
        definitions
            .families
            .entry(family)
            .or_default()
            .push("tensor_symbols".into());
    }
    ctx.set_fonts(definitions);
}
pub fn original() -> Result<(usize, usize, Vec<u8>)> {
    let mut decoder = png::Decoder::new(Cursor::new(LOGO));
    decoder.set_transformations(png::Transformations::EXPAND | png::Transformations::STRIP_16);
    let mut reader = decoder.read_info()?;
    let mut bytes = vec![
        0;
        reader
            .output_buffer_size()
            .context("Logo size unavailable")?
    ];
    let info = reader.next_frame(&mut bytes)?;
    bytes.truncate(info.buffer_size());
    let rgba = match info.color_type {
        png::ColorType::Rgba => bytes,
        png::ColorType::Rgb => bytes
            .chunks_exact(3)
            .flat_map(|c| [c[0], c[1], c[2], 255])
            .collect(),
        _ => anyhow::bail!("Logo must decode to RGB or RGBA"),
    };
    Ok((info.width as usize, info.height as usize, rgba))
}
fn mask_corners(rgba: &mut [u8], width: usize, height: usize, fraction: f64) {
    let radius = width.min(height) as f64 * fraction;
    for y in 0..height {
        for x in 0..width {
            let dx = (radius - (x as f64 + 0.5).min(width as f64 - x as f64 - 0.5)).max(0.);
            let dy = (radius - (y as f64 + 0.5).min(height as f64 - y as f64 - 0.5)).max(0.);
            let coverage = (radius - (dx * dx + dy * dy).sqrt() + 0.5).clamp(0., 1.);
            let alpha = &mut rgba[(y * width + x) * 4 + 3];
            *alpha = (*alpha as f64 * coverage).round() as u8;
        }
    }
}
pub fn rounded() -> Result<(usize, usize, Vec<u8>)> {
    let (width, height, mut rgba) = original()?;
    mask_corners(&mut rgba, width, height, 0.055);
    Ok((width, height, rgba))
}
/// Adapt the supplied logo for OS icons; rounding is a corner mask at display size.
pub fn icon(size: usize) -> Result<egui::IconData> {
    ensure!((16..=512).contains(&size), "Invalid icon size");
    let (width, height, source) = original()?;
    let mut rgba = vec![0u8; size * size * 4];
    for y in 0..size {
        for x in 0..size {
            let sx =
                ((x as f64 + 0.5) * width as f64 / size as f64 - 0.5).clamp(0., (width - 1) as f64);
            let sy = ((y as f64 + 0.5) * height as f64 / size as f64 - 0.5)
                .clamp(0., (height - 1) as f64);
            let x0 = sx.floor() as usize;
            let y0 = sy.floor() as usize;
            let x1 = (x0 + 1).min(width - 1);
            let y1 = (y0 + 1).min(height - 1);
            let tx = sx - x0 as f64;
            let ty = sy - y0 as f64;
            for c in 0..4 {
                let top = source[(y0 * width + x0) * 4 + c] as f64 * (1. - tx)
                    + source[(y0 * width + x1) * 4 + c] as f64 * tx;
                let bottom = source[(y1 * width + x0) * 4 + c] as f64 * (1. - tx)
                    + source[(y1 * width + x1) * 4 + c] as f64 * tx;
                rgba[(y * size + x) * 4 + c] = (top * (1. - ty) + bottom * ty).round() as u8;
            }
        }
    }
    mask_corners(&mut rgba, size, size, 0.18);
    Ok(egui::IconData {
        rgba,
        width: size as u32,
        height: size as u32,
    })
}
pub fn texture(ctx: &egui::Context) -> Result<egui::TextureHandle> {
    let (width, height, rgba) = rounded()?;
    Ok(ctx.load_texture(
        "tensor-logo",
        egui::ColorImage::from_rgba_unmultiplied([width, height], &rgba),
        // The source is intentionally much larger than the splash.  Trilinear
        // mipmap filtering preserves detail when Windows maps the 230 logical
        // point viewport to different per-monitor DPI scales.
        egui::TextureOptions::LINEAR.with_mipmap_mode(Some(egui::TextureFilter::Linear)),
    ))
}
pub fn write_icons(directory: &std::path::Path) -> Result<()> {
    std::fs::create_dir_all(directory)?;
    let mut frames = vec![];
    for size in [16, 32, 48, 64, 128, 256] {
        let icon = icon(size)?;
        let mut bytes = vec![];
        let mut encoder = png::Encoder::new(&mut bytes, size as u32, size as u32);
        encoder.set_color(png::ColorType::Rgba);
        encoder.set_depth(png::BitDepth::Eight);
        encoder.write_header()?.write_image_data(&icon.rgba)?;
        if size == 256 {
            std::fs::write(directory.join("tensor-icon.png"), &bytes)?;
        }
        frames.push((size, bytes));
    }
    let mut ico = vec![0, 0, 1, 0, frames.len() as u8, 0];
    let mut offset = (6 + 16 * frames.len()) as u32;
    for (size, bytes) in &frames {
        ico.extend([*size as u8, *size as u8, 0, 0]);
        ico.extend(1u16.to_le_bytes());
        ico.extend(32u16.to_le_bytes());
        ico.extend((bytes.len() as u32).to_le_bytes());
        ico.extend(offset.to_le_bytes());
        offset += bytes.len() as u32;
    }
    for (_, bytes) in frames {
        ico.extend(bytes);
    }
    std::fs::write(directory.join("tensor.ico"), ico)?;
    Ok(())
}
