//! Reproducible scientific checks, an embedded synthetic example, and headless
//! rendering of the actual egui interface. No Python is needed at runtime.
use crate::{
    analysis::*,
    cluster,
    config::*,
    gaussian::*,
    jobs::*,
    math::*,
    molecule::*,
    symmetry,
    ui::{Tab, Workbench},
    viewer::Viewer,
};
use anyhow::{Context, Result, ensure};
use eframe::egui::{self, Pos2, Rect, Vec2};
use std::{
    collections::HashMap,
    path::{Path, PathBuf},
};

pub const ETHANOL_LOGS: [&str; 3] = [
    include_str!("../tests/fixtures/logs/ethanol_1.log"),
    include_str!("../tests/fixtures/logs/ethanol_2.log"),
    include_str!("../tests/fixtures/logs/ethanol_3.log"),
];
pub fn ethanol_logs() -> Result<Vec<GaussianLog>> {
    ETHANOL_LOGS
        .iter()
        .enumerate()
        .map(|(i, t)| {
            parse_log_text(
                t,
                &PathBuf::from(format!("ethanol_{}.log", i + 1)),
                "ethanol",
                i + 1,
            )
        })
        .collect()
}
pub fn quiet() -> Progress {
    let (sender, _) = std::sync::mpsc::channel();
    Progress {
        sender: Some(sender),
        ..Default::default()
    }
}
pub fn load_demo(app: &mut Workbench) -> Result<()> {
    let c = analyze_compound(
        "ethanol",
        ethanol_logs()?,
        &AnalysisSettings::default(),
        Path::new("/synthetic-example-no-population-files"),
        &quiet(),
    )?;
    for (n, text) in [
        include_str!("../tests/fixtures/sdf/ethanol_1.sdf"),
        include_str!("../tests/fixtures/sdf/ethanol_2.sdf"),
        include_str!("../tests/fixtures/sdf/ethanol_3.sdf"),
    ]
    .into_iter()
    .enumerate()
    {
        let source = PathBuf::from(format!("synthetic-example/ethanol_{}.sdf", n + 1));
        app.setup_files.push(source.clone());
        app.inputs.push(ConformerInput {
            compound: "ethanol".into(),
            number: n + 1,
            source,
            molecule: parse_sdf(text)?,
            sdf: text.into(),
            split: false,
        });
    }
    // Paths are illustrative only; the demo is already processed in memory.
    app.log_files.clear();
    app.job_compound = "ethanol".into();
    app.job.coupling = true;
    app.cluster_mode = "shifts".into();
    // The demo structures are embedded rather than backed by real files, so
    // they cannot use the normal "beside conformer files" destination.
    if app.setup_output.trim().is_empty() {
        app.setup_output = std::env::current_dir()
            .unwrap_or_else(|_| PathBuf::from("."))
            .to_string_lossy()
            .into_owned();
    }
    app.analysis = Some(AnalysisResult {
        compounds: vec![c],
        errors: vec![],
    });
    app.demo = true;
    app.tab = Tab::Analysis;
    app.status = "Synthetic example loaded · no Gaussian calculation was run".into();
    app.run_log.push("Synthetic ethanol: 3 supplied conformers, 1 duplicate removed. These illustrative values are not experimental or computed NMR results.".into());
    Ok(())
}
fn close(a: f64, b: f64, tol: f64) -> Result<()> {
    ensure!(
        (a - b).abs() <= tol,
        "Expected {b:.14}, got {a:.14} (tolerance {tol})"
    );
    Ok(())
}
fn math_checks() -> Result<()> {
    let a = vec![
        [0., 0., 0.],
        [1.1, 0., 0.],
        [0., 1.3, 0.],
        [0., 0., 1.7],
        [0.4, 0.5, -0.2],
    ];
    let rot = matmul(rot_x(37.), rot_y(-61.));
    let b: Vec<_> = a
        .iter()
        .map(|&v| add(transform(rot, v), [3., -7., 2.]))
        .collect();
    let s = superpose(&a, &b)?;
    close(s.rmsd, 0., 1e-10)?;
    close(determinant(s.rotation), 1., 1e-12)?;
    let mirror: Vec<_> = a.iter().map(|p| [-p[0], p[1], p[2]]).collect();
    ensure!(
        superpose(&a, &mirror)?.rmsd > 0.2,
        "Reflection was accepted as a proper rotation"
    );
    let weights = populations(&[-155., -154.999], 298.)?;
    close(weights.iter().sum(), 1., 1e-14)?;
    ensure!(
        weights[0] > weights[1],
        "Higher energy received greater population"
    );
    ensure!(
        populations(&[-1.], 0.).is_err(),
        "Invalid temperature accepted"
    );
    close(round_decimal(2.675, 2), 2.67, 1e-15)?;
    ensure!(
        hungarian(&[vec![8., 1., 5.], vec![2., 7., 6.], vec![9., 4., 0.]]) == vec![1, 0, 2],
        "Wrong minimum-cost assignment"
    );
    Ok(())
}
fn equivalence_checks() -> Result<()> {
    let molecules = [
        (
            "ethanol",
            include_str!("../tests/fixtures/sdf/ethanol_1.sdf"),
        ),
        (
            "benzene",
            include_str!("../tests/fixtures/sdf/benzene_1.sdf"),
        ),
    ];
    for line in include_str!("../tests/fixtures/golden_equivalence.tsv").lines() {
        let (name, expected) = line
            .split_once('\t')
            .context("Malformed golden equivalence")?;
        let text = molecules.iter().find(|(n, _)| *n == name).unwrap().1;
        let m = parse_sdf(text)?;
        let actual = symmetry::equivalence(&m, &quiet())?;
        let mut expected: Vec<Vec<usize>> = expected
            .split(';')
            .filter(|s| !s.is_empty())
            .map(|g| {
                g.split(',')
                    .map(|i| i.parse::<usize>().unwrap() - 1)
                    .collect()
            })
            .collect();
        let mut got = actual.groups;
        expected.sort();
        got.sort();
        ensure!(
            got == expected,
            "{name} equivalence differs from Python: {got:?} vs {expected:?}"
        );
        let reparsed = parse_sdf(&v3000(&m, name, 1, None))?;
        ensure!(m.same_topology(&reparsed), "SDF topology round-trip failed");
    }
    let mut m = parse_sdf(molecules[0].1)?;
    m.atoms[3].isotope = 2;
    let groups = symmetry::equivalence(&m, &quiet())?.groups;
    ensure!(
        !groups.iter().any(|g| g.contains(&3)),
        "Isotopically distinct atom was merged"
    );
    Ok(())
}
fn cluster_checks() -> Result<()> {
    let files: [&str; 16] = [
        include_str!("../tests/fixtures/cluster/chain_1.sdf"),
        include_str!("../tests/fixtures/cluster/chain_2.sdf"),
        include_str!("../tests/fixtures/cluster/chain_3.sdf"),
        include_str!("../tests/fixtures/cluster/chain_4.sdf"),
        include_str!("../tests/fixtures/cluster/chain_5.sdf"),
        include_str!("../tests/fixtures/cluster/chain_6.sdf"),
        include_str!("../tests/fixtures/cluster/chain_7.sdf"),
        include_str!("../tests/fixtures/cluster/chain_8.sdf"),
        include_str!("../tests/fixtures/cluster/chain_9.sdf"),
        include_str!("../tests/fixtures/cluster/chain_10.sdf"),
        include_str!("../tests/fixtures/cluster/chain_11.sdf"),
        include_str!("../tests/fixtures/cluster/chain_12.sdf"),
        include_str!("../tests/fixtures/cluster/chain_13.sdf"),
        include_str!("../tests/fixtures/cluster/chain_14.sdf"),
        include_str!("../tests/fixtures/cluster/chain_15.sdf"),
        include_str!("../tests/fixtures/cluster/chain_16.sdf"),
    ];
    let items: Vec<_> = files
        .iter()
        .enumerate()
        .map(|(n, t)| {
            Ok(ConformerInput {
                compound: "chain".into(),
                number: n + 1,
                source: PathBuf::new(),
                molecule: parse_sdf(t)?,
                sdf: t.to_string(),
                split: false,
            })
        })
        .collect::<Result<_>>()?;
    let actual = cluster::fingerprints(&items, 0.5)?;
    for (i, line) in include_str!("../tests/fixtures/golden_cluster_matrix.tsv")
        .lines()
        .enumerate()
    {
        for (j, field) in line.split('\t').enumerate() {
            close(actual[i][j] as f64, field.parse()?, 1.2e-7)?;
        }
    }
    for line in include_str!("../tests/fixtures/golden_clusters.tsv").lines() {
        let parts: Vec<_> = line.split('\t').collect();
        let tree = cluster::linkage(&actual, parts[0], &quiet())?;
        let groups = cluster::cut(&tree, items.len(), parts[1].parse()?);
        let expected: Vec<Vec<usize>> = parts[2]
            .split(';')
            .map(|g| {
                g.split(',')
                    .map(|v| v.parse::<usize>().unwrap() - 1)
                    .collect()
            })
            .collect();
        ensure!(
            groups == expected,
            "{} τ{} clusters differ: {:?} vs {:?}",
            parts[0],
            parts[1],
            groups,
            expected
        );
    }
    Ok(())
}
fn viewer_checks() -> Result<()> {
    let m = parse_sdf(include_str!("../tests/fixtures/viewer_scene.sdf"))?;
    let mut viewer = Viewer::default();
    viewer.load(
        &m,
        [(0, "128.40".into()), (6, "7.26".into()), (13, "O".into())].into(),
    );
    viewer.last_rect = Some(Rect::from_min_size(Pos2::ZERO, Vec2::new(600., 420.)));
    viewer.fit(600., 420.);
    let geometry = viewer.scene.clone();
    let before = viewer.render_snapshot(300, 210, true);
    ensure!(
        before.rgba.chunks_exact(4).any(|p| p[3] > 0),
        "Viewer did not draw a molecular solid"
    );
    ensure!(
        before.rgba[3] == 0,
        "Molecular render background is not transparent"
    );
    viewer.rotation = matmul(rot_y(67.), viewer.rotation);
    viewer.pan = [7., -11.];
    let rotated = viewer.render_snapshot(300, 210, true);
    ensure!(
        before.rgba != rotated.rgba,
        "Camera did not change the image"
    );
    ensure!(
        *viewer.scene == *geometry,
        "Camera movement changed the fixed molecular geometry"
    );
    let dashed: Vec<_> = viewer.scene.solids.iter().filter(|p| p.dashed).collect();
    ensure!(
        !dashed.is_empty() && dashed.len() <= 24,
        "Unexpected aromatic dash density"
    );
    viewer.label_mode = crate::viewer::LabelMode::None;
    ensure!(
        viewer.render_snapshot(300, 210, true).rgba == rotated.rgba,
        "Label toggle changed the molecular solid"
    );
    ensure!(
        viewer.label_positions(600., 420.).is_empty(),
        "Hidden label mode still produced labels"
    );
    viewer.label_mode = crate::viewer::LabelMode::AtomNumbers;
    let numbered = viewer.label_positions(600., 420.);
    ensure!(
        numbered.len() == m.atoms.len()
            && numbered.iter().any(|label| label.text == "1")
            && numbered
                .iter()
                .any(|label| label.text == m.atoms.len().to_string()),
        "Atom-number label inventory changed"
    );
    viewer.label_mode = crate::viewer::LabelMode::Shifts;
    ensure!(
        viewer.label_positions(600., 420.).len() == 3,
        "Shift label inventory changed"
    );
    Ok(())
}

fn analysis_checks() -> Result<()> {
    let logs = ethanol_logs()?;
    ensure!(
        logs.iter().all(|l| l.exclusions.is_empty()),
        "Fixture parser exclusions: {:?}",
        logs.iter().map(|l| &l.exclusions).collect::<Vec<_>>()
    );
    ensure!(
        logs[0].molecule.atoms.len() == 9 && logs[0].molecule.bonds.len() == 8,
        "Incorrect reconstructed molecule"
    );
    ensure!(
        logs[0].frequencies.values.len() == 21,
        "Incomplete frequency parse"
    );
    ensure!(
        logs[0].couplings.len() == 36,
        "Incomplete blocked coupling parse"
    );
    let settings = AnalysisSettings::default();
    let result = analyze_compound(
        "ethanol",
        logs.clone(),
        &settings,
        Path::new("/synthetic-example-no-population-files"),
        &quiet(),
    )?;
    ensure!(
        result
            .conformers
            .iter()
            .map(|c| c.number)
            .collect::<Vec<_>>()
            == vec![1, 3],
        "Wrong dedup survivors"
    );
    ensure!(
        result.dedup.duplicates.len() == 1 && result.dedup.duplicates[0].number == 2,
        "Expected rotated duplicate 2"
    );
    close(result.shifts[&3], result.shifts[&4], 1e-14)?;
    close(result.shifts[&4], result.shifts[&5], 1e-14)?;
    close(
        result.conformers.iter().map(|c| c.population).sum(),
        1.,
        1e-14,
    )?;
    let mut none = settings.clone();
    none.outputs.set_all(false);
    let without = analyze_compound(
        "ethanol",
        logs.clone(),
        &none,
        Path::new("/synthetic-example-no-population-files"),
        &quiet(),
    )?;
    ensure!(
        result.shifts == without.shifts && !without.conformers.is_empty(),
        "Export toggles affected calculations/viewer"
    );
    let mut broken = logs.clone();
    broken[2].shieldings.remove("proton");
    ensure!(
        analyze_compound(
            "ethanol",
            broken,
            &settings,
            Path::new("/synthetic-example-no-population-files"),
            &quiet()
        )
        .is_err(),
        "Missing populated proton block silently accepted"
    );
    let negative = ETHANOL_LOGS[0].replacen("100.0000", "-30.0000", 1);
    ensure!(
        !parse_log_text(&negative, Path::new("ethanol_1.log"), "ethanol", 1)?
            .exclusions
            .is_empty(),
        "Imaginary frequency accepted"
    );
    let incomplete = ETHANOL_LOGS[0].rsplit_once("Normal termination").unwrap().0;
    ensure!(
        !parse_log_text(incomplete, Path::new("ethanol_1.log"), "ethanol", 1)?
            .exclusions
            .is_empty(),
        "Incomplete final Link1 accepted"
    );
    Ok(())
}
fn job_checks() -> Result<()> {
    let cfg = Config::parse(DEFAULT_CONFIG)?;
    let aromatic = parse_sdf(include_str!("../tests/fixtures/sdf/benzene_1.sdf"))?;
    let benzene = generate_input(
        &cfg,
        &JobSettings::default(),
        &aromatic,
        "benzene",
        "1",
        None,
        false,
    )?;
    ensure!(
        benzene.lines().any(|line| line == "1 2 1.5 6 1.5 7 1.0"),
        "SDF aromatic flag was not converted to Gaussian bond order"
    );
    let m = parse_sdf(include_str!("../tests/fixtures/sdf/multinuc_1.sdf"))?;
    for method in ["1", "2", "3", "4", "5"] {
        let job = JobSettings {
            method: method.into(),
            coupling: true,
            fluorine: true,
            nitrogen: true,
            ..Default::default()
        };
        let s = generate_input(&cfg, &job, &m, "multinuc", "1", None, false)?;
        ensure!(
            s.matches("--Link1--").count() == 5,
            "Missing optional Link1 calculation"
        );
        ensure!(
            s.contains("$NBO BNDIDX $END")
                && s.lines()
                    .any(|line| line.split_whitespace().collect::<Vec<_>>() == vec!["I", "0"]),
            "Missing iodine basis or NBO input"
        );
        ensure!(
            s.contains("geom=connectivity") && s.contains("nboread") && s.contains("freq"),
            "Required optimization keyword absent"
        );
        ensure!(!s.contains('\r'), "Not Unix newlines");
        let template = generate_input(&cfg, &job, &m, "multinuc", "1", None, true)?;
        let coordinate_rows = m
            .atoms
            .iter()
            .map(|a| {
                format!(
                    "{} {} {} {}",
                    a.element,
                    py_float(a.xyz[0]),
                    py_float(a.xyz[1]),
                    py_float(a.xyz[2])
                )
            })
            .collect::<Vec<_>>()
            .join("\n");
        ensure!(
            template.replace("{coordinates}", &coordinate_rows) == s,
            "Preview and generator diverged"
        );
    }
    let job = JobSettings {
        halogen: true,
        sulfur: true,
        ..Default::default()
    };
    let hal = generate_input(&cfg, &job, &m, "multinuc", "1", Some("chalogen"), false)?;
    ensure!(
        hal.contains("hal{1:s:-1.02,i:177.1|2:s:-1.07,i:207.3}"),
        "Wrong element-specific carbon scaling title"
    );
    let sul = generate_input(&cfg, &job, &m, "multinuc", "1", Some("csulfur"), false)?;
    ensure!(
        sul.contains("s:-0.9124 i:193.639"),
        "Wrong sulfur scaling title"
    );
    Ok(())
}

fn raw_input(size: [f32; 2], events: Vec<egui::Event>, tick: usize) -> egui::RawInput {
    egui::RawInput {
        screen_rect: Some(Rect::from_min_size(Pos2::ZERO, Vec2::from(size))),
        time: Some(tick as f64 / 60.),
        events,
        ..Default::default()
    }
}
fn ui_checks() -> Result<()> {
    let ctx = egui::Context::default();
    Workbench::style(&ctx);
    let mut app = Workbench::new(
        Config::parse(DEFAULT_CONFIG)?,
        PathBuf::from("tensor_config.txt"),
    );
    load_demo(&mut app)?;
    app.tab = Tab::Setup;
    let mut tick = 0;
    for _ in 0..3 {
        ctx.run_ui(raw_input([1280., 880.], vec![], tick), |ui| app.render(ui))
            .drop_without_applying_deltas();
        tick += 1;
    }
    let app_bar = app.control_rects["app_bar"];
    let initial_panel = app.control_rects["setup_panel"];
    ensure!(
        app.control_rects.contains_key("cluster_overlay_build"),
        "Clustering did not expose the setup overlay controls"
    );
    ensure!(
        (app_bar.height() - 44.).abs() < 0.01,
        "Top bar height changed: {app_bar:?}"
    );
    ensure!(
        (initial_panel.top() - app_bar.bottom()).abs() < 0.01 && initial_panel.height() > 795.,
        "Setup content did not receive the height reclaimed by the one-row top bar"
    );
    ensure!(
        app.control_rects["setup_content"].left() - initial_panel.left() >= 13.,
        "Setup panel has no inner padding"
    );
    ensure!(
        initial_panel.width() >= 500.,
        "Setup settings panel did not retain a useful responsive width: {initial_panel:?}"
    );
    let setup_control_y = app.control_rects["cluster_overlay_compound"].center().y;
    let build_rect = app.control_rects["cluster_overlay_build"];
    ensure!(
        (build_rect.center().y - setup_control_y).abs() <= 0.5
            && (app.control_rects["cluster_overlay_heading"].center().y - setup_control_y).abs()
                <= 0.5,
        "Setup overlay controls are not vertically aligned: heading {:?}, compound {:?}, build {:?}",
        app.control_rects["cluster_overlay_heading"],
        app.control_rects["cluster_overlay_compound"],
        build_rect
    );
    ctx.run_ui(
        raw_input(
            [1280., 880.],
            vec![egui::Event::PointerMoved(initial_panel.center())],
            tick,
        ),
        |ui| app.render(ui),
    )
    .drop_without_applying_deltas();
    tick += 1;
    ensure!(
        app.control_rects["setup_panel"] == initial_panel,
        "Setup panel moved on first pointer entry: {initial_panel:?} -> {:?}",
        app.control_rects["setup_panel"]
    );
    let location = app.control_rects["analysis_tab"].center();
    for pressed in [true, false] {
        ctx.run_ui(
            raw_input(
                [1280., 880.],
                vec![
                    egui::Event::PointerMoved(location),
                    egui::Event::PointerButton {
                        pos: location,
                        button: egui::PointerButton::Primary,
                        pressed,
                        modifiers: Default::default(),
                    },
                ],
                tick,
            ),
            |ui| app.render(ui),
        )
        .drop_without_applying_deltas();
        tick += 1;
    }
    ensure!(app.tab == Tab::Analysis, "Analysis tab click failed");
    ctx.run_ui(raw_input([1280., 880.], vec![], tick), |ui| app.render(ui))
        .drop_without_applying_deltas();
    tick += 1;
    ensure!(
        app.control_rects["tab_description"].width() > 400.,
        "Analysis description did not receive the header's available width: {:?}",
        app.control_rects["tab_description"]
    );
    ensure!(
        app.viewer.molecule.atoms.len() == 9 && app.viewer.last_rect.is_some(),
        "Viewer did not load the selected result"
    );
    ensure!(
        crate::ui::methodology_viewport_builder("Methodology", app.window_icon.clone()).maximized
            == Some(true),
        "Methodology viewport did not request a maximized initial window"
    );
    ensure!(
        crate::spectrum_ui::spectrum_viewport_builder("Predicted spectra", app.window_icon.clone())
            .maximized
            == Some(true),
        "Predicted spectra viewport did not request a maximized initial window"
    );
    let initial_panel = app.control_rects["analysis_panel"];
    ensure!(
        (initial_panel.top() - app.control_rects["app_bar"].bottom()).abs() < 0.01
            && initial_panel.height() > 795.,
        "Analysis content did not receive the height reclaimed by the one-row top bar"
    );
    ensure!(
        app.control_rects["analysis_content"].left() - initial_panel.left() >= 13.,
        "Analysis panel has no inner padding"
    );
    ensure!(
        (400.0..=440.0).contains(&initial_panel.width()) && initial_panel.left() >= 840.,
        "Analysis settings panel did not use the narrower viewer-first default: {initial_panel:?}"
    );
    let analysis_control_y = app.control_rects["viewer_compound_control"].center().y;
    for name in [
        "viewer_conformer_control",
        "viewer_labels",
        "viewer_reset",
        "spectra",
    ] {
        ensure!(
            (app.control_rects[name].center().y - analysis_control_y).abs() <= 6.,
            "Analysis viewer control {name} is not vertically aligned: label {:?}, control {:?}",
            app.control_rects["viewer_compound_control"],
            app.control_rects[name]
        );
    }
    let mut renders = app.viewer.frames_rendered;
    for label_mode in [
        crate::viewer::LabelMode::None,
        crate::viewer::LabelMode::AtomNumbers,
        crate::viewer::LabelMode::Shifts,
    ] {
        app.viewer.label_mode = label_mode;
        ctx.run_ui(
            raw_input(
                [1280., 880.],
                vec![egui::Event::PointerMoved(initial_panel.center())],
                tick,
            ),
            |ui| app.render(ui),
        )
        .drop_without_applying_deltas();
        tick += 1;
        ensure!(
            app.control_rects["analysis_panel"] == initial_panel,
            "Analysis panel moved on pointer entry: {initial_panel:?} -> {:?}",
            app.control_rects["analysis_panel"]
        );
        ensure!(
            app.viewer.frames_rendered > renders,
            "Label toggle did not recompose the cached molecular frame"
        );
        renders = app.viewer.frames_rendered;
    }
    let pick = app
        .viewer
        .atom_screen_position(0, app.viewer.last_rect.unwrap())
        .context("Analysis viewer did not project atom 1")?;
    for pressed in [true, false] {
        ctx.run_ui(
            raw_input(
                [1280., 880.],
                vec![
                    egui::Event::PointerMoved(pick),
                    egui::Event::PointerButton {
                        pos: pick,
                        button: egui::PointerButton::Middle,
                        pressed,
                        modifiers: Default::default(),
                    },
                ],
                tick,
            ),
            |ui| app.render(ui),
        )
        .drop_without_applying_deltas();
        tick += 1;
    }
    ensure!(
        app.viewer.selected_atoms == vec![0],
        "Middle-click did not select the nearest analysis-viewer atom"
    );
    let shift_pick = app
        .viewer
        .atom_screen_position(1, app.viewer.last_rect.unwrap())
        .context("Analysis viewer did not project atom 2")?;
    for (key, expected) in [
        (egui::Key::ShiftLeft, vec![0]),
        (egui::Key::ShiftRight, vec![0, 1]),
    ] {
        for pressed in [true, false] {
            let modifiers = egui::Modifiers {
                shift: pressed,
                ..Default::default()
            };
            ctx.run_ui(
                raw_input(
                    [1280., 880.],
                    vec![
                        egui::Event::PointerMoved(shift_pick),
                        egui::Event::Key {
                            key,
                            physical_key: Some(key),
                            pressed,
                            repeat: false,
                            modifiers,
                        },
                    ],
                    tick,
                ),
                |ui| app.render(ui),
            )
            .drop_without_applying_deltas();
            tick += 1;
        }
        ensure!(
            app.viewer.selected_atoms == expected,
            "Only Right Shift should select the pointed-to atom: key {key:?}, selection {:?}",
            app.viewer.selected_atoms
        );
    }
    let center = app.viewer.last_rect.unwrap().center();
    let rotation = app.viewer.rotation;
    for (phase, (pos, pressed)) in [
        (center, true),
        (center + Vec2::new(40., 20.), true),
        (center + Vec2::new(40., 20.), false),
    ]
    .into_iter()
    .enumerate()
    {
        let mut events = vec![egui::Event::PointerMoved(pos)];
        if phase != 1 {
            events.push(egui::Event::PointerButton {
                pos,
                button: egui::PointerButton::Primary,
                pressed,
                modifiers: Default::default(),
            });
        }
        ctx.run_ui(raw_input([1280., 880.], events, tick), |ui| app.render(ui))
            .drop_without_applying_deltas();
        tick += 1;
    }
    ensure!(
        app.viewer.rotation != rotation,
        "Viewer drag did not rotate molecule"
    );
    let pan = app.viewer.pan;
    for (phase, pos) in [
        center,
        center + Vec2::new(25., -12.),
        center + Vec2::new(25., -12.),
    ]
    .into_iter()
    .enumerate()
    {
        let mut events = vec![egui::Event::PointerMoved(pos)];
        if phase != 1 {
            events.push(egui::Event::PointerButton {
                pos,
                button: egui::PointerButton::Secondary,
                pressed: phase == 0,
                modifiers: Default::default(),
            });
        }
        ctx.run_ui(raw_input([1280., 880.], events, tick), |ui| app.render(ui))
            .drop_without_applying_deltas();
        tick += 1;
    }
    ensure!(app.viewer.pan != pan, "Right-drag did not pan the viewer");
    let zoom = app.viewer.zoom;
    ctx.run_ui(
        raw_input(
            [1280., 880.],
            vec![
                egui::Event::PointerMoved(center),
                egui::Event::MouseWheel {
                    unit: egui::MouseWheelUnit::Point,
                    delta: Vec2::new(0., 60.),
                    phase: egui::TouchPhase::Move,
                    modifiers: Default::default(),
                },
            ],
            tick,
        ),
        |ui| app.render(ui),
    )
    .drop_without_applying_deltas();
    tick += 1;
    ensure!(app.viewer.zoom > zoom, "Scroll did not zoom the viewer");
    // Separate this gesture from the earlier tab click in egui's click history.
    tick += 60;
    for pressed in [true, false, true, false] {
        ctx.run_ui(
            raw_input(
                [1280., 880.],
                vec![
                    egui::Event::PointerMoved(center),
                    egui::Event::PointerButton {
                        pos: center,
                        button: egui::PointerButton::Primary,
                        pressed,
                        modifiers: Default::default(),
                    },
                ],
                tick,
            ),
            |ui| app.render(ui),
        )
        .drop_without_applying_deltas();
        tick += 1;
    }
    ensure!(
        app.viewer.rotation == rotation,
        "Double-click did not reset the view"
    );
    app.show_log = true;
    for _ in 0..3 {
        ctx.run_ui(raw_input([960., 680.], vec![], tick), |ui| app.render(ui))
            .drop_without_applying_deltas();
        tick += 1;
    }
    ensure!(
        app.control_rects["analyze"].bottom() <= 680.,
        "Analysis action was clipped at minimum window size"
    );
    ensure!(
        app.control_rects["spectra"].right() < app.control_rects["analysis_panel"].left()
            && app.control_rects["viewer_labels"].top()
                > app.control_rects["viewer_compound_control"].bottom(),
        "Narrow analysis controls did not wrap before the settings pane: spectra {:?}, labels {:?}, compound {:?}, pane {:?}",
        app.control_rects["spectra"],
        app.control_rects["viewer_labels"],
        app.control_rects["viewer_compound_control"],
        app.control_rects["analysis_panel"]
    );
    ensure!(
        app.control_rects["run_log_scroll"].right()
            >= app.control_rects["analysis_panel"].right() - 24.,
        "Run-log scrollbar did not reach the far-right edge of the application: log {:?}, panel {:?}",
        app.control_rects["run_log_scroll"],
        app.control_rects["analysis_panel"]
    );
    ensure!(app.job.coupling, "Tab switching lost setup options");
    app.begin_startup();
    ctx.run_ui(raw_input([230., 230.], vec![], tick), |ui| app.render(ui))
        .drop_without_applying_deltas();
    tick += 1;
    ensure!(
        matches!(app.startup, crate::ui::Startup::Splash(Some(_))),
        "Splash was skipped"
    );
    app.startup = crate::ui::Startup::Splash(Some(
        std::time::Instant::now() - std::time::Duration::from_millis(1600),
    ));
    let transition = ctx.run_ui(raw_input([230., 230.], vec![], tick), |ui| app.render(ui));
    let requested_maximize = transition.viewport_output.values().any(|viewport| {
        viewport
            .commands
            .iter()
            .any(|command| matches!(command, egui::ViewportCommand::Maximized(true)))
    });
    transition.drop_without_applying_deltas();
    tick += 1;
    ensure!(
        matches!(app.startup, crate::ui::Startup::Chooser),
        "Splash did not advance to workspace chooser"
    );
    ensure!(
        requested_maximize,
        "Splash transition did not request a maximized workspace"
    );
    for _ in 0..3 {
        ctx.run_ui(raw_input([960., 680.], vec![], tick), |ui| app.render(ui))
            .drop_without_applying_deltas();
        tick += 1;
    }
    for name in ["choose_setup", "choose_analysis", "development_credit"] {
        let rect = app.control_rects[name];
        ensure!(
            rect.left() >= 0. && rect.right() <= 960. && rect.bottom() <= 680.,
            "Workspace choice {name} is clipped: {rect:?}"
        );
    }
    let choice = app.control_rects["choose_setup"].center();
    for pressed in [true, false] {
        ctx.run_ui(
            raw_input(
                [960., 680.],
                vec![
                    egui::Event::PointerMoved(choice),
                    egui::Event::PointerButton {
                        pos: choice,
                        button: egui::PointerButton::Primary,
                        pressed,
                        modifiers: Default::default(),
                    },
                ],
                tick,
            ),
            |ui| app.render(ui),
        )
        .drop_without_applying_deltas();
        tick += 1;
    }
    ensure!(
        matches!(app.startup, crate::ui::Startup::Workspace)
            && app.tab == Tab::Setup
            && app.inputs.len() == 3
            && app.job.coupling,
        "Workspace choice failed or cleared session state"
    );

    // A maximized display with 300% UI scaling exposes a much smaller logical
    // viewport. With the log open, the complete left card must scroll while
    // preserving a useful cluster viewer instead of shrinking it to a sliver.
    let scaled_ctx = egui::Context::default();
    Workbench::style(&scaled_ctx);
    let mut scaled = Workbench::new(
        Config::parse(DEFAULT_CONFIG)?,
        PathBuf::from("tensor_config.txt"),
    );
    load_demo(&mut scaled)?;
    scaled.tab = Tab::Setup;
    scaled.show_log = true;
    for frame in 0..3 {
        scaled_ctx
            .run_ui(raw_input([760., 520.], vec![], frame), |ui| {
                scaled.render(ui)
            })
            .drop_without_applying_deltas();
    }
    ensure!(
        scaled.control_rects["setup_panel"].width() <= 420.
            && scaled.control_rects["setup_scroll_viewport"].width() >= 300.,
        "High-DPI responsive split did not preserve both panes: settings {:?}, conformers {:?}",
        scaled.control_rects["setup_panel"],
        scaled.control_rects["setup_scroll_viewport"]
    );
    ensure!(
        scaled.control_rects["setup_scroll_content"].height()
            > scaled.control_rects["setup_scroll_viewport"].height() + 100.,
        "High-DPI conformer card did not become vertically scrollable"
    );
    ensure!(
        scaled.control_rects["setup_cluster_viewer"].height()
            >= crate::ui::SETUP_VIEWER_MIN_HEIGHT - 0.1,
        "High-DPI cluster viewer fell below its minimum usable height"
    );
    Ok(())
}
pub fn self_test() -> Result<()> {
    type Check = (&'static str, fn() -> Result<()>);
    let checks: [Check; 7] = [
        (
            "Proper rotations, populations, decimal rounding, assignment",
            math_checks,
        ),
        (
            "Python chemical equivalence and SDF round trips",
            equivalence_checks,
        ),
        (
            "Python/SciPy fingerprints and 25 linkage cuts",
            cluster_checks,
        ),
        (
            "Fixed 3D geometry, sparse aromatic dashes, transparent depth rendering",
            viewer_checks,
        ),
        (
            "Gaussian parsing, deduplication, weighting, missing-data rejection",
            analysis_checks,
        ),
        (
            "All built-in methods, optional jobs, iodine, preview parity",
            job_checks,
        ),
        (
            "Two-tab interface, state retention, camera controls, small window",
            ui_checks,
        ),
    ];
    let mut failed = vec![];
    for (name, run) in checks {
        match std::panic::catch_unwind(run) {
            Ok(Ok(())) => println!("PASS {name}"),
            Ok(Err(e)) => {
                println!("FAIL {name}: {e:#}");
                failed.push(name)
            }
            Err(_) => {
                println!("FAIL {name}: panic");
                failed.push(name)
            }
        }
    }
    ensure!(failed.is_empty(), "{} check group(s) failed", failed.len());
    println!(
        "All 7 built-in check groups passed. Fixtures are synthetic, not Gaussian calculations."
    );
    Ok(())
}

// A minimal CPU triangle rasterizer for reproducible QA of the actual egui output.
// This is never used by the desktop renderer, which uses eframe's OpenGL backend.
#[derive(Default)]
struct Rasterizer {
    textures: HashMap<egui::TextureId, egui::ColorImage>,
}
impl Rasterizer {
    fn texture_deltas(&mut self, delta: &mut egui::TexturesDelta) {
        for (id, changes) in delta.set.drain() {
            for change in changes {
                let egui::ImageData::Color(image) = change.image;
                if let Some([x, y]) = change.pos {
                    if let Some(target) = self.textures.get_mut(&id) {
                        for j in 0..image.size[1] {
                            for i in 0..image.size[0] {
                                target.pixels[(y + j) * target.size[0] + x + i] =
                                    image.pixels[j * image.size[0] + i];
                            }
                        }
                    }
                } else {
                    self.textures.insert(id, (*image).clone());
                }
            }
        }
    }
    fn paint(
        &mut self,
        ctx: &egui::Context,
        mut output: egui::FullOutput,
        size: [usize; 2],
    ) -> Vec<u8> {
        self.texture_deltas(&mut output.textures_delta);
        let primitives =
            ctx.tessellate(std::mem::take(&mut output.shapes), output.pixels_per_point);
        let [w, h] = size;
        let mut pixels = vec![[245_f32, 247., 250., 255.]; w * h];
        for p in primitives {
            let egui::epaint::Primitive::Mesh(mesh) = p.primitive else {
                continue;
            };
            let Some(tex) = self.textures.get(&mesh.texture_id) else {
                continue;
            };
            for indices in mesh.indices.chunks_exact(3) {
                let vs = [
                    mesh.vertices[indices[0] as usize],
                    mesh.vertices[indices[1] as usize],
                    mesh.vertices[indices[2] as usize],
                ];
                let edge = |a: Pos2, b: Pos2, c: Pos2| {
                    (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
                };
                let area = edge(vs[0].pos, vs[1].pos, vs[2].pos);
                if area.abs() < 1e-8 {
                    continue;
                }
                let xmin = vs
                    .iter()
                    .map(|v| v.pos.x)
                    .fold(f32::INFINITY, f32::min)
                    .max(p.clip_rect.min.x)
                    .floor()
                    .max(0.) as usize;
                let xmax = vs
                    .iter()
                    .map(|v| v.pos.x)
                    .fold(f32::NEG_INFINITY, f32::max)
                    .min(p.clip_rect.max.x)
                    .ceil()
                    .min(w as f32) as usize;
                let ymin = vs
                    .iter()
                    .map(|v| v.pos.y)
                    .fold(f32::INFINITY, f32::min)
                    .max(p.clip_rect.min.y)
                    .floor()
                    .max(0.) as usize;
                let ymax = vs
                    .iter()
                    .map(|v| v.pos.y)
                    .fold(f32::NEG_INFINITY, f32::max)
                    .min(p.clip_rect.max.y)
                    .ceil()
                    .min(h as f32) as usize;
                for y in ymin..ymax {
                    for x in xmin..xmax {
                        let point = Pos2::new(x as f32 + 0.5, y as f32 + 0.5);
                        if !p.clip_rect.contains(point) {
                            continue;
                        }
                        let b = [
                            edge(vs[1].pos, vs[2].pos, point) / area,
                            edge(vs[2].pos, vs[0].pos, point) / area,
                            edge(vs[0].pos, vs[1].pos, point) / area,
                        ];
                        if b.iter().any(|v| *v < -1e-6) {
                            continue;
                        }
                        let u = vs.iter().zip(b).map(|(v, b)| v.uv.x * b).sum::<f32>()
                            * tex.size[0] as f32
                            - 0.5;
                        let v = vs.iter().zip(b).map(|(v, b)| v.uv.y * b).sum::<f32>()
                            * tex.size[1] as f32
                            - 0.5;
                        let sx = u.floor();
                        let sy = v.floor();
                        let (fx, fy) = (u - sx, v - sy);
                        let mut color = [0.; 4];
                        for (dx, dy, weight) in [
                            (0., 0., (1. - fx) * (1. - fy)),
                            (1., 0., fx * (1. - fy)),
                            (0., 1., (1. - fx) * fy),
                            (1., 1., fx * fy),
                        ] {
                            let ix = (sx + dx).clamp(0., tex.size[0] as f32 - 1.) as usize;
                            let iy = (sy + dy).clamp(0., tex.size[1] as f32 - 1.) as usize;
                            for (k, c) in tex.pixels[iy * tex.size[0] + ix]
                                .to_array()
                                .iter()
                                .enumerate()
                            {
                                color[k] += *c as f32 * weight;
                            }
                        }
                        for (k, channel) in color.iter_mut().enumerate() {
                            *channel *= vs
                                .iter()
                                .zip(b)
                                .map(|(v, b)| v.color.to_array()[k] as f32 * b)
                                .sum::<f32>()
                                / 255.;
                        }
                        let dest = &mut pixels[y * w + x];
                        let alpha = color[3] / 255.;
                        for k in 0..3 {
                            dest[k] = color[k] + dest[k] * (1. - alpha);
                        }
                        dest[3] = 255.;
                    }
                }
            }
        }
        for id in output.textures_delta.free.drain() {
            self.textures.remove(&id);
        }
        output.textures_delta.clear();
        pixels
            .into_iter()
            .flat_map(|p| p.map(|v| v.round().clamp(0., 255.) as u8))
            .collect()
    }
}
pub fn render_demo(root: &Path) -> Result<()> {
    std::fs::create_dir_all(root)?;
    for (name, tab, size, custom) in [
        ("job-setup", Tab::Setup, [1280, 880], false),
        ("job-setup-cluster", Tab::Setup, [1280, 880], false),
        ("job-setup-defaults", Tab::Setup, [1280, 880], false),
        ("analysis-viewer", Tab::Analysis, [1280, 880], false),
        ("analysis-atom-numbers", Tab::Analysis, [1280, 880], false),
        ("analysis-measurement", Tab::Analysis, [1280, 880], false),
        ("job-setup-small", Tab::Setup, [960, 680], true),
        ("job-setup-high-dpi", Tab::Setup, [760, 520], false),
        ("analysis-small", Tab::Analysis, [960, 680], false),
        ("startup-chooser", Tab::Setup, [1280, 820], false),
        ("splash", Tab::Setup, [230, 230], false),
        ("methodology-setup", Tab::Setup, [1280, 880], false),
        ("methodology-analysis", Tab::Analysis, [1280, 880], false),
        ("figure-export", Tab::Analysis, [1280, 880], false),
        ("methodology-populations", Tab::Analysis, [1280, 880], false),
        ("spectra-overview", Tab::Analysis, [1180, 1440], false),
        ("spectra-proton", Tab::Analysis, [1180, 880], false),
    ] {
        let ctx = egui::Context::default();
        Workbench::style(&ctx);
        let mut app = Workbench::new(
            Config::parse(DEFAULT_CONFIG)?,
            PathBuf::from("tensor_config.txt"),
        );
        if name != "job-setup-defaults" {
            load_demo(&mut app)?;
        }
        app.tab = tab;
        if name == "startup-chooser" {
            app.startup = crate::ui::Startup::Chooser;
        }
        if name.starts_with("methodology-") {
            app.show_methodology = true;
            app.methodology_tab = tab;
            if name == "methodology-populations" {
                app.methodology_page = crate::methodology::ANALYSIS
                    .iter()
                    .position(|p| p.0 == "Populations and corrections")
                    .unwrap();
            }
        }
        if name.starts_with("spectra-") {
            let (input, settings) = spectrum_case();
            let output = crate::spectrum::simulate(
                &input,
                &settings,
                &std::sync::atomic::AtomicBool::new(false),
            )?;
            app.spectrum.load_prepared(input, output, settings);
            if name == "spectra-proton" {
                app.spectrum.selected = Some(crate::spectrum::Nucleus::H);
            }
        }
        if name == "figure-export" {
            app.show_export = true;
        }
        if custom {
            app.cluster_mode = "custom".into();
        }
        if name == "job-setup-high-dpi" {
            app.show_log = true;
        }
        if name.starts_with("job-setup") {
            app.setup_output.clear();
        }
        let mut raster = Rasterizer::default();
        let mut pixels = vec![];
        let mut tick = 0;
        if name == "job-setup-cluster" {
            app.prepare_cluster_preview();
            for _ in 0..200 {
                let output = ctx.run_ui(
                    raw_input([size[0] as f32, size[1] as f32], vec![], tick),
                    |ui| app.render(ui),
                );
                // Preserve font and viewer texture deltas produced while the
                // background cluster worker finishes.  Discarding these deltas
                // leaves the later CPU-rasterized frame with no texture atlas.
                pixels = raster.paint(&ctx, output, size);
                tick += 1;
                if app.status.starts_with("Cluster overlay ready") {
                    break;
                }
                std::thread::sleep(std::time::Duration::from_millis(5));
            }
            ensure!(
                app.status.starts_with("Cluster overlay ready"),
                "Cluster overlay did not finish for the headless capture"
            );
        }
        for frame in 0..4 {
            if frame > 0 && name == "analysis-atom-numbers" {
                app.viewer.label_mode = crate::viewer::LabelMode::AtomNumbers;
            }
            if frame > 0 && name == "analysis-measurement" {
                // H4–C1–C2–O3 is a connected four-atom sequence in the
                // embedded ethanol fixture and gives a visible dihedral readout.
                app.viewer.selected_atoms = vec![3, 0, 1, 2];
            }
            if name == "splash" {
                app.startup = crate::ui::Startup::Splash(Some(std::time::Instant::now()));
            }
            let output = ctx.run_ui(
                raw_input([size[0] as f32, size[1] as f32], vec![], tick + frame * 10),
                |ui| {
                    if name.starts_with("spectra-") {
                        app.spectrum.content(ui)
                    } else {
                        app.render(ui)
                    }
                },
            );
            pixels = raster.paint(&ctx, output, size);
        }
        let path = root.join(format!("{name}.png"));
        let file = std::fs::File::create(&path)?;
        let mut encoder = png::Encoder::new(
            std::io::BufWriter::new(file),
            size[0] as u32,
            size[1] as u32,
        );
        encoder.set_color(png::ColorType::Rgba);
        encoder.set_depth(png::BitDepth::Eight);
        let mut writer = encoder.write_header()?;
        writer.write_image_data(&pixels)?;
        writer.finish()?;
        println!("Rendered {}", path.display());
        println!("Controls: {:?}", app.control_rects);
    }
    Ok(())
}

pub fn export_demo(root: &Path) -> Result<()> {
    std::fs::create_dir_all(root)?;
    let molecule = parse_sdf(include_str!("../tests/fixtures/viewer_scene.sdf"))?;
    let mut viewer = Viewer::default();
    let labels = molecule
        .atoms
        .iter()
        .enumerate()
        .filter_map(|(i, a)| match a.element.as_str() {
            "H" => Some((i, "7.26".into())),
            "C" => Some((i, "128.40".into())),
            _ => None,
        })
        .collect();
    viewer.load(&molecule, labels);
    viewer.last_rect = Some(Rect::from_min_size(Pos2::ZERO, Vec2::new(800., 600.)));
    viewer.fit(800., 600.);
    for format in [
        crate::figure::Format::Png,
        crate::figure::Format::Svg,
        crate::figure::Format::Pdf,
    ] {
        for labels in [true, false] {
            let options = crate::figure::FigureOptions {
                format,
                labels,
                ..Default::default()
            };
            let path = root.join(format!(
                "synthetic-structure-{}.{}",
                if labels { "labels" } else { "unlabelled" },
                format.extension()
            ));
            let saved = crate::figure::export(&viewer, &options, &path)?;
            println!("Exported {}", saved.display());
        }
    }
    Ok(())
}

pub fn spectrum_case() -> (crate::spectrum::Input, crate::spectrum::Settings) {
    use crate::spectrum::*;
    let spins = [
        (Nucleus::H, 5.),
        (Nucleus::H, 5.05),
        (Nucleus::H, 1.2),
        (Nucleus::C, 70.),
        (Nucleus::F, -120.),
        (Nucleus::F, -120.09),
        (Nucleus::N, -45.),
    ]
    .into_iter()
    .enumerate()
    .map(|(atom, (nucleus, ppm))| Spin {
        atom,
        nucleus,
        ppm,
        area: 1.,
    })
    .collect();
    let calculated = [
        ((0, 1), -14.),
        ((0, 2), 7.),
        ((1, 2), 5.5),
        ((0, 4), 20.),
        ((1, 4), 11.),
        ((1, 5), 8.),
        ((4, 5), 180.),
        ((2, 3), 135.),
        ((0, 3), 5.),
        ((3, 6), 11.),
        ((1, 6), -4.),
        ((5, 6), 23.),
    ]
    .into_iter()
    .collect();
    let input=Input{name:"Synthetic seven-spin validation example".into(),spins,calculated,notes:vec!["Fabricated spin parameters for testing, not a Gaussian result or real molecular assignment.".into()],..Input::default()};
    let settings = Settings {
        proton_mhz: 400.,
        enriched: true,
        decouple: [[false; 4]; 4],
        ..Settings::default()
    };
    (input, settings)
}
pub fn export_spectra_demo(root: &Path) -> Result<()> {
    use crate::spectrum::*;
    std::fs::create_dir_all(root)?;
    let (input, settings) = spectrum_case();
    let output = simulate(
        &input,
        &settings,
        &std::sync::atomic::AtomicBool::new(false),
    )?;
    std::fs::write(
        root.join("transitions.csv"),
        csv(&input, &output, &settings),
    )?;
    std::fs::write(
        root.join("predicted-spectra.svg"),
        svg(&input, &output, &settings),
    )?;
    let mut spins = "atom,nucleus,ppm,mhz\n".to_string();
    for s in &input.spins {
        spins += &format!(
            "{},{},{},{}\n",
            s.atom + 1,
            s.nucleus.ascii(),
            s.ppm,
            settings.proton_mhz * s.nucleus.ratio()
        );
    }
    std::fs::write(root.join("spins.csv"), spins)?;
    let mut couplings = "atom1,atom2,j_hz\n".to_string();
    for (&(a, b), &j) in &input.calculated {
        couplings += &format!("{},{},{j}\n", a + 1, b + 1);
    }
    std::fs::write(root.join("couplings.csv"), couplings)?;
    for p in &output.predictions {
        println!(
            "{}: {} transitions, total relative area {:.8}",
            p.nucleus.ascii(),
            p.lines.len(),
            p.lines.iter().map(|l| l.area).sum::<f64>()
        );
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn mathematics() {
        math_checks().unwrap()
    }
    #[test]
    fn python_equivalence() {
        equivalence_checks().unwrap()
    }
    #[test]
    fn python_clustering() {
        cluster_checks().unwrap()
    }
    #[test]
    fn molecular_viewer() {
        viewer_checks().unwrap()
    }
    #[test]
    fn analysis_pipeline() {
        analysis_checks().unwrap()
    }
    #[test]
    fn gaussian_jobs() {
        job_checks().unwrap()
    }
    #[test]
    fn interface_interaction() {
        ui_checks().unwrap()
    }
}
