# TENSOR 1.0.0-public — validation record

Validation date: 2026-09-11. Toolchain: Rust 1.95.0. Dependency versions are pinned by `Cargo.lock`.

| Check | Result |
|---|---|
| Formatting | `cargo fmt --all -- --check` passed |
| Static analysis | `cargo clippy --locked --all-targets -- -D warnings` passed |
| Debug Rust tests | 90 passed, 0 failed: 36 library tests, 19 audit regressions, 19 integration regressions, and 16 spectrum regressions |
| Optimized Rust tests | The same 90 tests passed under `--release` |
| Built-in application checks | 7/7 passed: mathematics, equivalence/SDF, clustering, molecular rendering, analysis, Gaussian jobs, and interface interaction |
| Python-reference export parity | 2,065 numeric records across 44 files matched at exported precision |
| Independent spin Hamiltonian | Full seven-spin NumPy solver agreed for ¹H, ¹³C, ¹⁹F, and ¹⁵N |
| Setup smoke test | Six structures in three compounds produced five selected Gaussian inputs, three setup manifests, and `tensor-log.txt` |
| Figure exports | Labelled and unlabelled transparent PNG, SVG, and PDF generated successfully |
| Interface captures | 17 real egui views regenerated and inspected, including atom-number and four-atom measurement views, the 760 × 520 high-DPI/log-open setup case, both minimum layouts, setup overlay, spectra, methodologies, splash, and startup choice |
| Windows source compatibility | `cargo check --locked --all-targets --target x86_64-pc-windows-msvc` passed |
| Release identity | The optimized executable reports TENSOR 1.0.0-public |

## Focused public-release checks

- Ordinary five-, six-, and seven-membered local faces use a fixed 0.220 model-unit bond-centerline-to-dash-centerline offset. With the 0.115 main-bond and 0.047 dash radii, that gives the same 0.058 model-unit visible surface clearance across those ring sizes.
- A bond shared by two fully delocalized chordless local faces receives two geometrically distinct dash guides, one into each face. Regression families cover 5/6 C/N, 6/6 C/N, and 5/7 fused systems. A partially delocalized neighboring face still produces only one guide.
- The supplied redacted fused C/N topology remains a minimized regression fixture. Cycle selection rejects chorded composite perimeters, chooses the appropriate local chordless faces, maintains symmetric longitudinal insets, and keeps the fixed transverse clearance. A 65%-of-local-inward-distance cap protects unusually narrow or distorted geometry.
- Coupling perception uses the bounded chordless-cycle enumerator rather than a one-shortest-ring inventory. Both aromatic MDL-order and alternating Kekulé benzene encodings produce the expected benzene-derived fallback inventory; a fused six-membered C/N face retains its adjacent proton pair. Calculated Gaussian couplings continue to take precedence.
- A clean first-run regression places an invalid legacy `nmr_workbench` configuration beside a fake roaming root, launches the application setup path, and verifies that TENSOR ignores it and creates the bundled defaults at `%APPDATA%/TENSOR/tensor_config.txt`. The legacy file remains untouched.
- Public distribution builders overwrite their packaged `tensor_config.txt` from `assets/tensor_config.txt`, so a private/test-build configuration cannot be carried into the public package accidentally.
- Every built-in method exposes separate Pierens sulfur-correction and Giesen/Zumbulyadis halogen-correction provenance fields. Complete C/H/F/N/S and Cl/Br/I scaling factors, routes, bases, keywords, and the iodine block remain configurable and are serialized into generated jobs for later log-based analysis.
- The setup cluster viewer retains a 260-point minimum logical height inside its vertically scrollable card, including the high-DPI/log-open layout.
- Interface-event coverage requires middle-click and Right Shift to select through the same projected nearest-atom picker, verifies that Left Shift does not select, and confirms the narrower analysis pane gives the structure viewer additional laptop-width space. The opening development credit must remain inside the chooser viewport.
- Configuration migration backups use the running package version (`.pre-1.0.0-public.bak` for this release), and audit checks reject stale hard-coded current-version text.
- Formatting, strict Clippy analysis, direct-dependency usage, panic/bounds review, and source scans found no actionable deprecated production API or unused direct dependency.

## Retained development-line checks

- Viewer regressions require mutually exclusive shift, one-based atom-number, and hidden label inventories. Figure SVG metadata identifies whether exported labels are chemical shifts or atom numbers.
- Picking regressions use projected coordinates to require nearest-screen selection, frontmost resolution for exact projection ties, second-click removal, and a hard four-atom cap. Loading another structure clears the selection.
- Measurement regressions require a 1.000 Å distance, a 90.00° connected angle, finite signed connected dihedrals, and an explicit disconnected-sequence state. The real analysis UI delivers both middle-button and Right Shift selections while rejecting Left Shift; the setup viewer continues to use its non-selecting entry point.
- Auxiliary viewport builders require maximized initial state. The analysis toolbar uses one row at normal width and two rows before it can overflow at the minimum logical window width.
- Configuration regressions change standard and special functionals, bases, keywords, scaling constants, and the named iodine block, then require those exact edits in generated Gaussian input. All five shipped methods retain complete C/H/F/N/S and Cl/Br/I factor inventories.
- A migration regression loads a deliberately incomplete older built-in method, verifies that only missing shipped fields and the multiline iodine section are added, confirms existing labels/routes/factors are preserved, checks the one-time backup byte-for-byte, and confirms a second load is idempotent.
- Job-generation checks require every requested C/H/F/N title factor, sulfur scaling, and carbon-specific halogen factor. Optional UI controls also require the selected method's route/factor capability.
- UI checks require sub-pixel-equal centers for the cluster-overlay label, dropdown, and button; a maximized viewport command after the splash; responsive side panes; centered destination hints; and a vertically scrollable setup card whose viewer remains at least 260 points high in a 760 × 520 logical viewport with the Run log open.
- Fused-ring dash placement, full-resolution interaction rendering, automatic setup-overlay handoff, semantic spectrum SVG, full-width log, natural numeric file ordering, and plot-local wheel/drag handling remain under regression coverage.
- Identity checks cover `tensor`, `tensor_config.txt`, `tensor-log.txt`, TENSOR-only active UI naming, the 1.0.0-public CLI/resource metadata, retained Windows GUI subsystem, and maximized default workspace and auxiliary windows.

## Independent spectrum comparison

| Nucleus | Merged transitions | Maximum frequency error | Maximum relative-area error |
|---|---:|---:|---:|
| ¹H | 288 | 9.69×10⁻¹¹ Hz | 4.98×10⁻¹¹ |
| ¹³C | 146 | 1.25×10⁻¹⁰ Hz | 4.99×10⁻¹¹ |
| ¹⁹F | 176 | 1.16×10⁻¹⁰ Hz | 4.99×10⁻¹¹ |
| ¹⁵N | 142 | 7.53×10⁻¹¹ Hz | 4.94×10⁻¹¹ |

The synthetic system has integrated model areas 3, 1, 2, and 1 respectively. Numerical agreement validates the implemented Hamiltonian and transition calculation for this case; it does not validate DFT shifts, estimated J values, isotope choices, solvent markers, conformer populations, or agreement with an experimental spectrum.

## Reproduction

```sh
cargo fmt --all -- --check
cargo clippy --locked --all-targets -- -D warnings
cargo test --locked --all-targets
cargo test --locked --release --all-targets
cargo build --locked --release
./target/release/tensor --version
./target/release/tensor --self-test
python3 tools/compare_reference.py target/release/tensor
./target/release/tensor --export-spectra-demo validation/public-1.0.0/spectrum-case
python3 tools/check_spin_hamiltonian.py validation/public-1.0.0/spectrum-case
./target/release/tensor --config assets/tensor_config.txt --setup examples/sdf --out validation/public-1.0.0/setup-smoke --cluster shifts
./target/release/tensor --export-demo figure-examples
./target/release/tensor --render-demo screenshots
cargo check --locked --all-targets --target x86_64-pc-windows-msvc
```

`compare_reference.py` uses only Python's standard library. `check_spin_hamiltonian.py` uses NumPy. Neither Python nor NumPy is required by TENSOR itself.

## Platform and scientific limits

The validation executable was Linux x86-64. A native Windows build requires the MSVC Rust target, Visual Studio C++ build tools, and a Windows SDK so `rc.exe` can embed the icon/version resource. The source-level Windows check cannot substitute for linking and launching the native executable on Windows. `windows_subsystem = "windows"` remains compiled into normal Windows release builds, including `cargo build --release`, so the GUI does not request a companion console window.

Chordless ring searches are deliberately bounded: individual cycles are limited to 12 atoms and each queried bond returns at most 4,096 paths. These limits avoid unbounded work on pathological graphs while covering the local organic ring systems targeted by the renderer and aromatic-coupling fallback.

The spectrum model has a ten-spin exact-component limit, secular heteronuclear treatment, optional simplified vicinal and aromatic proton estimates, and labelled first-order fallback. It omits quadrupolar nuclei, explicit isotope satellites, exchange/relaxation dynamics, pulse sequences, and quantitative response modelling. Conventional residual-solvent positions vary with experimental conditions.

The topology override is a conservative depiction rule for existing C–O connectivity, not a general bond-perception or formal-charge engine. It deliberately leaves nonterminal and structurally ambiguous cases under the raw Wiberg threshold classification. Validate representative real Gaussian ensembles and experimental references before research use.
