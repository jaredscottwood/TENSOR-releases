SYNTHETIC SOFTWARE TEST DATA — NO GAUSSIAN CALCULATION WAS RUN

ethanol: three conformers, of which the second is a rotated duplicate of the
first and the third has a different OH orientation.

multinuc: a deliberately constructed test molecule containing C/H/F/N/S/Cl/I.
It exercises all optional calculation types and separate carbon corrections.
Its shifts, couplings, energies and frequencies are invented test values.

Load sdf/ files in Job setup. Load logs/ files in Analysis. Use a separate output
folder so that you can easily remove the generated examples later.
