#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
cargo build --locked --release
cargo test --locked --release
artifact_bin="${CARGO_TARGET_DIR:-target}/release/tensor"
"$artifact_bin" --self-test
artifact_dir=dist/TENSOR-1.0.0-public-linux
mkdir -p "$artifact_dir"
cp "$artifact_bin" "$artifact_dir/"
# The public test distribution starts from the shipped TENSOR defaults and
# never imports a private/test-build configuration.
cp assets/tensor_config.txt "$artifact_dir/tensor_config.txt"
cp README.md CHANGES.md AUDIT.md VALIDATION.md SPECTRA.md THIRD_PARTY_NOTICES.md "$artifact_dir/"
cp -R third-party-licenses "$artifact_dir/"
chmod +x "$artifact_dir/tensor"
printf 'Built %s\n' "$artifact_dir/tensor"
