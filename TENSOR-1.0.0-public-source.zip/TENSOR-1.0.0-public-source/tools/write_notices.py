#!/usr/bin/env python3
"""Collect notices for the resolved Linux/Windows dependency trees from Cargo's cache."""
from pathlib import Path
import os,re,shutil,subprocess,tomllib
ROOT=Path(__file__).resolve().parents[1]
CARGO=os.environ.get('CARGO','cargo')
CACHE=Path(os.environ.get('CARGO_HOME',str(Path.home()/'.cargo')))/'registry'/'src'
root_package=tomllib.loads((ROOT/'Cargo.toml').read_text())['package']['name']
packages=set()
for target in ['x86_64-unknown-linux-gnu','x86_64-pc-windows-msvc']:
 result=subprocess.run([CARGO,'tree','--offline','--locked','--target',target,'--prefix','none','--format','{p}'],cwd=ROOT,check=True,capture_output=True,text=True)
 for line in result.stdout.splitlines():
  m=re.match(r'^(\S+) v(\S+)',line)
  if m and m[1]!=root_package:packages.add((m[1],m[2]))
folder=ROOT/'third-party-licenses';folder.mkdir(exist_ok=True)
rows=[]
for name,version in sorted(packages):
 matches=list(CACHE.glob(f'*/{name}-{version}/Cargo.toml'))
 if len(matches)!=1:raise RuntimeError(f'Missing/ambiguous cached manifest: {name} {version}')
 manifest=matches[0];data=tomllib.loads(manifest.read_text())['package'];root=manifest.parent
 license=data.get('license','See bundled license file').replace('|','\\|')
 repository=data.get('repository',f'https://crates.io/crates/{name}/{version}')
 rows.append(f'| {name} | {version} | {license} | [upstream]({repository}) |')
 found=[]
 for path in root.rglob('*'):
  if not path.is_file():continue
  lower=path.name.lower()
  if not any(term in lower for term in ['license','copying','copyright','notice','ofl.txt','ufl.txt']):continue
  if path.suffix in ['.rs','.toml','.yml','.yaml','.json']:continue
  relative=path.relative_to(root);dest=folder/f'{name}-{version}'/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest);found.append(relative)
 if not found:print(f'No standalone license file in Cargo package: {name} {version} ({license})')
text='''# Third-party notices

TENSOR uses the following Cargo packages in its resolved Linux and Windows
builds. Licenses and notices present in their published source packages are
copied into `third-party-licenses/`, including embedded font notices. Package
source and additional attribution are available from the linked upstreams.
The Rust standard library copyright and license information is also included.
System libraries and Gaussian are not redistributed in these archives.

The supplied Python reference is Jared Wood’s original work and retains its
original attribution; this inventory does not assign a new license to it.
The TENSOR logo was supplied by the user for this application. The source
archive retains its original JPEG bytes and a lossless PNG normalization.
The separate bold label font is DejaVu Sans Bold, with its license in
`third-party-licenses/DejaVuSans/` (and `assets/DejaVuSans-LICENSE.txt`).

| Package | Version | Declared license | Source |
|---|---|---|---|
'''+ '\n'.join(rows)+'\n'
(ROOT/'THIRD_PARTY_NOTICES.md').write_text(text)
print(f'Collected notices for {len(packages)} resolved Cargo packages.')
