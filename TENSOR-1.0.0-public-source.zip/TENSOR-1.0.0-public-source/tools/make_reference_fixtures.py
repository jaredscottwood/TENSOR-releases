#!/usr/bin/env python3
"""Create synthetic (not computed) fixtures and golden results using the original Python.
Requires numpy and scipy; never required by the Rust application.
"""
import contextlib, importlib.machinery, importlib.util, math, os, shutil, sys, types
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
F = ROOT / 'tests' / 'fixtures'
loader = importlib.machinery.SourceFileLoader('nmr_reference', str(ROOT/'reference/nmr_workbench.pyw'))
spec = importlib.util.spec_from_loader(loader.name, loader)
p = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = p
loader.exec_module(p)
F.mkdir(parents=True, exist_ok=True)
(F/'logs').mkdir(exist_ok=True)
(F/'sdf').mkdir(exist_ok=True)

def sdf(name, elements, coords, bonds):
    lines = [name, 'Synthetic regression fixture — not a computed structure', '', '  0  0  0     0  0            999 V3000', 'M  V30 BEGIN CTAB',f'M  V30 COUNTS {len(elements)} {len(bonds)} 0 0 0','M  V30 BEGIN ATOM']
    lines += [f'M  V30 {i} {e} {x:.6f} {y:.6f} {z:.6f} 0' for i,(e,(x,y,z)) in enumerate(zip(elements,coords),1)]
    lines += ['M  V30 END ATOM','M  V30 BEGIN BOND']
    lines += [f'M  V30 {i} {4 if o==1.5 else int(o)} {a} {b}' for i,((a,b),o) in enumerate(sorted(bonds.items()),1)]
    return '\n'.join(lines+['M  V30 END BOND','M  V30 END CTAB','M  END','$$$$',''])

def gaussian(name, number, elements, coords, bonds, energy, offset=0., freq_offset=0., special=None):
    # Deliberately conventional Gaussian formatting, including normally terminated Link1 jobs.
    coords=np.asarray(coords).round(6)
    zs={'H':1,'C':6,'N':7,'O':8,'F':9,'S':16,'Cl':17,'Br':35,'I':53}
    lines=[' Entering Gaussian System',' Synthetic data for software regression — no calculation was run.',f' {name}_{number}_opt','', ' Charge = 0 Multiplicity = 1']
    lines += [f' {e} {x:.6f} {y:.6f} {z:.6f}' for e,(x,y,z) in zip(elements,coords)]
    lines += ['', '                           Initial Parameters','                           (Angstroms and Degrees)',' --------------------------',' ! Name  Definition              Value          Derivative Info. !',' ! ---------------------------------------------------------- !']
    lines += [f' ! R{i} R({a},{b}) {np.linalg.norm(coords[a-1]-coords[b-1]):.4f} estimate D2E/DX2 !' for i,(a,b) in enumerate(sorted(bonds),1)]
    lines += [' --------------------------',' Standard orientation:',' ---------------------------------------------------------------------',' Center     Atomic      Atomic             Coordinates (Angstroms)',' Number     Number       Type             X           Y           Z',' ---------------------------------------------------------------------']
    lines += [f' {i:6} {zs[e]:10} {0:10} {x:15.6f} {y:11.6f} {z:11.6f}' for i,(e,(x,y,z)) in enumerate(zip(elements,coords),1)]
    lines += [' ---------------------------------------------------------------------', ' Temperature   298.000 Kelvin.  Pressure 1.00000 Atm.',f' Sum of electronic and thermal Free Energies= {energy:.10f}']
    nmodes=3*len(elements)-6
    for j in range(0,nmodes,3):
        v=[100.+80.*k+freq_offset for k in range(j,min(j+3,nmodes))]
        lines += [' Frequencies --   '+' '.join(f'{x:.4f}' for x in v),' Red. masses --   '+' '.join('1.1000' for _ in v),' Frc consts  --   '+' '.join('0.8000' for _ in v),' IR Inten    --   '+' '.join('3.0000' for _ in v)]
    lines += [' Wiberg bond index matrix in the NAO basis:','']
    for start in range(1,len(elements)+1,5):
        columns=range(start,min(start+5,len(elements)+1))
        lines += [' Atom '+' '.join(f'{c:9}' for c in columns),' ---------------------------------------']
        for i,e in enumerate(elements,1):
            vals=[]
            for j in columns:
                o=bonds.get((min(i,j),max(i,j)),bonds.get((max(i,j),min(i,j)),0))
                vals.append(0. if i==j else {1.:.98,1.5:1.45,2.:1.95,3.:2.85,4.:1.45}.get(o,.001))
            lines.append(f' {i:3}. {e:2} '+' '.join(f'{v:9.4f}' for v in vals))
        lines.append('')
    lines += [' Wiberg bond index, Totals by atom:',' Normal termination of Gaussian 16','']
    kinds=['carbon'] if special else ['carbon','proton','fluorine','nitrogen']
    for kind in kinds:
        e={'carbon':'C','proton':'H','fluorine':'F','nitrogen':'N'}[kind]
        if e not in elements: continue
        sc={'carbon':(-1.0065,196.0386),'proton':(-1.0311,32.2654),'fluorine':(-.924,207.78),'nitrogen':(-.9776,253.23)}[kind]
        if special=='csulfur':sc=(-.9124,193.639)
        title=f'{name}_{number}_{kind} s:{sc[0]} i:{sc[1]}'
        if special=='chalogen': title=f'{name}_{number}_carbon hal{{1:s:-1.02,i:177.1|2:s:-1.07,i:207.3}}'
        lines += [' '+title,'']
        for i,element in enumerate(elements,1):
            if element!=e: continue
            delta=({1:18.3,2:58.6}.get(i,45.+i) if e=='C' else {'H':1.+i*.21,'F':-123.4,'N':41.2}[e])+offset
            pair=sc
            if special=='csulfur':delta=61.2+offset
            if special=='chalogen':pair={1:(-1.02,177.1),2:(-1.07,207.3)}.get(i,(-1.,190.));delta=28.4+i+offset
            shielding=delta*pair[0]+pair[1]
            lines.append(f' {i:4}  {e:<2} Isotropic = {shielding:13.6f}   Anisotropy = 10.0000')
        lines += [' End of Minotr F.D. properties file',' Normal termination of Gaussian 16','']
    if not special:
        lines += [f' {name}_{number}_cc','', ' Total nuclear spin-spin coupling J (Hz):']
        for start in range(1,len(elements)+1,5):
            cols=list(range(start,min(start+5,len(elements)+1)))
            lines.append(' '.join(f'{c:13}' for c in cols))
            for i in range(start,len(elements)+1):
                vals=[0. if i==j else (i+j)*.37+offset for j in cols if j<=i]
                lines.append(f'{i:5} '+ ' '.join(f'{v:.6E}'.replace('E','D') for v in vals))
        lines += [' End of Minotr F.D. properties file',' Normal termination of Gaussian 16','']
    return '\n'.join(lines)

with open(F/'golden_equivalence.tsv','w') as eq:
    for name in ['ethanol','benzene']:
        elements,coords,bonds=p._self_test_molecule(name)
        (F/'sdf'/f'{name}_1.sdf').write_text(sdf(name,elements,coords,bonds))
        groups=p.equiv_equivalent_groups_from_graph(elements,coords,bonds)
        eq.write(name+'\t'+';'.join(','.join(map(str,g['atoms'])) for g in groups.values())+'\n')

el,xyz,bonds=p._self_test_molecule('ethanol')
xyz=np.array(xyz,dtype=float)
angle=.73
rot=np.array([[math.cos(angle),-math.sin(angle),0],[math.sin(angle),math.cos(angle),0],[0,0,1]])
rotated=xyz@rot.T+[1.2,-4.1,.7]
third=xyz.copy();axis=(xyz[2]-xyz[1]);axis/=np.linalg.norm(axis);v=xyz[8]-xyz[2];a=1.4
third[8]=xyz[2]+v*math.cos(a)+np.cross(axis,v)*math.sin(a)+axis*np.dot(axis,v)*(1-math.cos(a))
for n,coords,energy,offset,fo in [(1,xyz,-155.,0.,0.),(2,rotated,-154.999998,2.,.25),(3,third,-154.999,.4,5.)]:
    (F/'logs'/f'ethanol_{n}.log').write_text(gaussian('ethanol',n,el,coords,bonds,energy,offset,fo))
    (F/'sdf'/f'ethanol_{n}.sdf').write_text(sdf(f'ethanol_{n}',el,coords,bonds))

# Exercise every optional NMR route and independently weighted carbon corrections.
el=['C','C','C','F','I','Cl','N','S','H','H','H','H','H','H']
xyz=np.array([(0,0,0),(1.5,0,0),(2,1.4,0),(-.5,1.2,.2),(-.7,-.6,1.6),(2.1,-1.3,-.7),(1.8,-.2,1.4),(3.7,1.7,.2),(-.5,-.5,-.9),(1.4,2.1,.7),(1.8,1.8,-1),(2.6,.1,1.8),(1.2,-.2,2.1),(4,2.7,.6)])
bonds={pair:1. for pair in [(1,2),(1,4),(1,5),(1,9),(2,3),(2,6),(2,7),(3,8),(3,10),(3,11),(7,12),(7,13),(8,14)]}
for n in [1,2]:
    coords=xyz.copy();coords[13,2]+=.25*(n-1)
    (F/'sdf'/f'multinuc_{n}.sdf').write_text(sdf(f'multinuc_{n}',el,coords,bonds))
    for kind,base,gap in [(None,-700.,.0007),('csulfur',-650.,.0002),('chalogen',-620.,.0005)]:
        name='multinuc'+('-'+kind if kind else '')
        (F/'logs'/f'{name}_{n}.log').write_text(gaussian(name,n,el,coords,bonds,base+gap*(n-1),.6*(n-1),5.*(n-1),kind))

# Fingerprints and linkage outputs from scipy, at several thresholds.
cluster_dir=F/'cluster';cluster_dir.mkdir(exist_ok=True)
items=[]
for n,angle in enumerate([0,9,24,52,68,89,114,136,159,179,199,227,253,275,303,336],1):
    a=math.radians(angle);coords=[(0,1.4,0),(0,0,0),(1.5,0,0),(2.2,1.2*math.cos(a),1.2*math.sin(a))]
    path=cluster_dir/f'chain_{n}.sdf';path.write_text(sdf(f'chain_{n}',['C']*4,coords,{(1,2):1.,(2,3):1.,(3,4):1.}))
    atoms,c,conn,_=p.cluster_parse_sdf(str(path));dih=np.asarray(p.extract_dihedral_topology(atoms,conn),dtype=np.int32).reshape(-1,4)-1
    items+=p.parse_conformer_chunk([(n,str(path),dih)])
items,_=p.build_distance_arrays(items)
mat,_=p.build_combined_distance_matrix(items,.5)
np.savetxt(F/'golden_cluster_matrix.tsv',mat,delimiter='\t',fmt='%.10g')
with open(F/'golden_clusters.tsv','w') as out:
    for method in p.SUPPORTED_LINKAGES:
        z,_=p.run_linkage(mat,method)
        for tau in [0.,.15,.4,.7,1.]:
            labels=p.labels_at_tau(z,len(items),tau)
            groups=sorted([sorted(np.flatnonzero(labels==l)+1) for l in set(labels)],key=lambda g:g[0])
            out.write(f'{method}\t{tau}\t'+ ';'.join(','.join(map(str,g)) for g in groups)+'\n')

# Scene primitives use the actual reference implementation without constructing Tk.
elements,coords,bonds=p._self_test_molecule('benzene')
# Add a double bond, triple bond, and isolated ion so every primitive branch is used.
elements+=['C','O','C','N','Na'];coords+= [(4,0,0),(5.2,0,0),(4,2,0),(5.2,2,0),(5,-2,1)]
bonds.update({(13,14):2.,(15,16):3.})
bonds={tuple(sorted(k)):4. if o==1.5 else o for k,o in bonds.items()}
(F/'viewer_scene.sdf').write_text(sdf('viewer_scene',elements,coords,bonds))
coords=np.array(coords).round(6)
view=types.SimpleNamespace(coordinates=np.array(coords)-np.mean(coords,axis=0),rotation=p.StructureViewer._rotation_y(-30)@p.StructureViewer._rotation_x(20),pan=(7.,-11.),zoom=28.,elements=elements,bonds=sorted(bonds),bond_orders=bonds,show_labels=True,labels={1:'128.40',7:'7.26',14:'O'})
aromatic=[bond for bond,o in bonds.items() if o==4]
view.bond_rings={pair:p.StructureViewer.find_ring_members(aromatic,*pair) for pair in aromatic}
scene=p.StructureViewer.build_scene(view,600,420)
with open(F/'golden_scene.tsv','w') as out:
    for primitive in scene:
        values=list(primitive)
        if values[0]=='line':values[-1]='dash' if values[-1] else 'solid'
        out.write('\t'.join(str(v) for v in values)+'\n')

# Keep the Python output in a separate directory. Never run the reference on user data:
# run_ngp_analysis deletes its own existing compound output folders.
ref=F/'python_results';ref.mkdir(exist_ok=True)
for path in (F/'logs').glob('*.log'):shutil.copy2(path,ref/path.name)
p.RUNNING_UNDER_GUI=True
p.AUTO_DETECT_PROCESSORS=False;p.NUM_PROCESSORS_FALLBACK=1
p.NGP_OUTPUT_SWITCHES={key:True for key in p.NGP_OUTPUT_SWITCHES}
p.WORKBENCH_METHODS,p.WORKBENCH_MACHINES,p.WORKBENCH_CONFIG_PROBLEMS=p.load_workbench_config(str(ROOT/'assets/tensor_config.txt'))
old=Path.cwd()
try:
    os.chdir(ref)
    with open(F/'python_reference_run.txt','w') as out,contextlib.redirect_stdout(out),contextlib.redirect_stderr(out):p.run_ngp_analysis()
finally:os.chdir(old)
for path in ref.glob('*.log'):path.unlink()
print(f'Golden fixtures and Python outputs generated in {F}')
