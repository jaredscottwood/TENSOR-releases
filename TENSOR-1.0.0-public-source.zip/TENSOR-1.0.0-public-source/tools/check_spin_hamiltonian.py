#!/usr/bin/env python3
"""Independent NumPy full-Hilbert-space check of the Rust sector-based solver.
Run tensor --export-spectra-demo DIR first, then this script DIR. Requires NumPy.
The input is a fabricated fully enriched seven-spin system with no decoupling.
"""
import csv
import sys
from pathlib import Path
import numpy as np

root = Path(sys.argv[1])
spins = list(csv.DictReader((root / 'spins.csv').open()))
js = list(csv.DictReader((root / 'couplings.csv').open()))
records = list(csv.DictReader(line for line in (root / 'transitions.csv').open() if not line.startswith('#')))
n = len(spins)
assert n <= 10, 'This independent check uses the complete Hilbert space.'
identity = np.eye(2, dtype=complex)
ix = np.array([[0, .5], [.5, 0]], dtype=complex)
iy = np.array([[0, -.5j], [.5j, 0]], dtype=complex)
iz = np.diag([.5, -.5]).astype(complex)
lower = ix - 1j * iy

def operator(atom, matrix):
    value = np.array([[1]], dtype=complex)
    for i in range(n):
        value = np.kron(value, matrix if i == atom else identity)
    return value

x, y, z = ([operator(i, axis) for i in range(n)] for axis in (ix, iy, iz))
hamiltonian = sum(float(s['ppm']) * float(s['mhz']) * z[i] for i, s in enumerate(spins))
for row in js:
    a, b, j = int(row['atom1'])-1, int(row['atom2'])-1, float(row['j_hz'])
    hamiltonian += j * (z[a] @ z[b])
    if spins[a]['nucleus'] == spins[b]['nucleus']:
        hamiltonian += j * (x[a] @ x[b] + y[a] @ y[b])
assert np.max(np.abs(hamiltonian - hamiltonian.T.conj())) < 1e-10
energies, vectors = np.linalg.eigh(hamiltonian)

def merged(lines):
    out = []
    for frequency, area in sorted(lines):
        if out and abs(frequency-out[-1][0]) <= 1e-6:
            old_frequency, old_area = out[-1]
            out[-1] = ((frequency*area + old_frequency*old_area)/(area+old_area), area+old_area)
        else:
            out.append((frequency, area))
    return np.asarray(out)

for nucleus in ('1H', '13C', '19F', '15N'):
    targets = [i for i, s in enumerate(spins) if s['nucleus'] == nucleus]
    if not targets:
        continue
    detection = sum(operator(i, lower) for i in targets)
    matrix = vectors.conj().T @ detection @ vectors
    intensities = abs(matrix)**2 / 2**(n-1)
    rows, cols = np.where(intensities > 1e-10)
    expected = merged((energies[b]-energies[a], intensities[a, b]) for a, b in zip(rows, cols))
    actual = merged((float(r['frequency_hz']), float(r['relative_area'])) for r in records if r['nucleus'] == nucleus)
    assert expected.shape == actual.shape, (nucleus, expected.shape, actual.shape)
    frequency_error = np.max(abs(expected[:, 0]-actual[:, 0]))
    area_error = np.max(abs(expected[:, 1]-actual[:, 1]))
    assert frequency_error < 1e-6, (nucleus, frequency_error)
    assert area_error < 1e-7, (nucleus, area_error)
    assert abs(actual[:, 1].sum()-len(targets)) < 1e-6
    print(f'PASS {nucleus}: {len(actual)} merged transitions; maximum frequency error {frequency_error:.3g} Hz; maximum relative-area error {area_error:.3g}')
print('PASS: independent full-space eigensolver agrees with the Rust sector solver for every observed nucleus.')
