#!/usr/bin/env python3
# NMR Gaussian Workbench | Version 1.0.0
# A single-window interface over the two halves of the NMR DFT workflow:
#   Tab 1  Job setup    -- conformer SDFs in, Gaussian input files out (splitting, clustering, input generation)
#   Tab 2  Analysis     -- Gaussian LOG files in, NMR predictions out (the full NGP pipeline, outputs selectable)
#
# Conformational searching happens before this tool; nothing here generates conformers.
#
# ------------------------------------------------------------------------------------------------------------
# HOW THIS FILE IS PUT TOGETHER
# ------------------------------------------------------------------------------------------------------------
# Four previously separate scripts are embedded below, each under its own section banner, with their logic
# unchanged apart from the renames noted in each banner. Those renames exist only because the scripts were
# written independently and reused a handful of names for different things -- most importantly parse_sdf, which
# means something genuinely different in the job-setup and clustering code. Everything else is as it was, so a
# result produced through this window is the same result those scripts produce from the command line.
#
# ------------------------------------------------------------------------------------------------------------
# OPTIONAL DEPENDENCIES
# ------------------------------------------------------------------------------------------------------------
# numpy is required (the analysis half cannot run without it). SciPy is required only for clustering; when it is
# absent that one section of Tab 1 disables itself with an explanation and everything else continues to work,
# because hierarchical linkage over thousands of conformers has no practical pure-Python substitute and silently
# degrading to a worse algorithm would be a poor trade for a scientific result.

import os
import re
import sys
import math
import glob
import time
import csv
import shutil
import tempfile
import random
import queue
import threading
import itertools
import traceback
from collections import defaultdict, deque, OrderedDict
from io import StringIO
from multiprocessing import Pool, cpu_count, current_process, freeze_support

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    np = None
    NUMPY_AVAILABLE = False

try:
    from scipy.cluster.hierarchy import linkage, fcluster, cophenet
    from scipy.spatial.distance import squareform, pdist
    SCIPY_AVAILABLE = True
except ImportError:
    linkage = fcluster = cophenet = squareform = pdist = None
    SCIPY_AVAILABLE = False




# ================================================================================================================
# EMBEDDED: multi-structure SDF splitting (from sms.py)
# ================================================================================================================
# Renamed: fix_sdf_header -> sms_fix_sdf_header. Only the record-splitting and header-repair logic is carried
# over; the command-line driver around it is replaced by the interface.


# Small Molecule Split: Provide a *_confs.sdf file from a finished xsampler search or a *.sdf_Conf.sdf file from Spartan, then run the script. 
# Automatically splits all conformers into individual files.
# Cross-platform compatible (Windows/Linux/macOS) - Python 2.7+ and 3.x


COUNTS_LINE_SEARCH_DEPTH = 12  # The counts line is line 4 of a well-formed record; a generous window still finds it in a malformed one without risking a false match against body text further down

def sms_fix_sdf_header(sdf_entry):
    """
    Fix an SDF record's header to the required 4-line format.

    Both connection-table versions are handled. The counts line is line 4 of the header and ends with the
    version tag -- "V2000" for the fixed-width format, "V3000" for the tagged format -- and everything this
    function does (counting how many header lines precede it and padding to exactly three) depends only on
    finding that line, not on which format follows it. So the same repair applies to both, and the V3000 body
    below the counts line is passed through untouched.

    The search is limited to the first few lines because a record's header is always at the top; scanning the
    whole record risks matching a data field whose value happens to end in a version tag.
    """
    lines = sdf_entry.split('\n')

    counts_index = -1
    for i, line in enumerate(lines[:COUNTS_LINE_SEARCH_DEPTH]):
        stripped = line.strip().upper()
        if stripped.endswith('V2000') or stripped.endswith('V3000'):
            counts_index = i
            break

    if counts_index == -1:
        print("Warning: no V2000 or V3000 counts line found in conformer; header left unchanged")
        return sdf_entry
    v2000_index = counts_index
    
    # Extract the part before V2000 line and after V2000 line
    header_lines = lines[:v2000_index]
    v2000_line = lines[v2000_index]
    remaining_lines = lines[v2000_index + 1:]
    
    # Ensure we have exactly 3 lines before the V2000 line
    fixed_header = []
    
    # Process existing header lines, filtering out empty ones at the start
    non_empty_headers = []
    for line in header_lines:
        if line.strip() or non_empty_headers:  # Keep line if it's non-empty OR we already have content
            non_empty_headers.append(line)
    
    # Now build the proper 4-line header
    if len(non_empty_headers) == 0:
        # No header content at all
        fixed_header = [
            "sdf-fill line",
            "                    3D", 
            " Generated by conformer splitter",
            v2000_line
        ]
    elif len(non_empty_headers) == 1:
        # Only one line (likely the 3D line)
        fixed_header = [
            "sdf-fill line",
            non_empty_headers[0],
            " Generated by conformer splitter", 
            v2000_line
        ]
    elif len(non_empty_headers) == 2:
        # Two lines (likely 3D and program line)
        fixed_header = [
            "sdf-fill line",
            non_empty_headers[0],
            non_empty_headers[1],
            v2000_line
        ]
    elif len(non_empty_headers) >= 3:
        # Three or more lines - take the last 3 before V2000
        fixed_header = non_empty_headers[-3:] + [v2000_line]
    
    # Reconstruct the SDF entry
    result_lines = fixed_header + remaining_lines
    return '\n'.join(result_lines)






def sms_split_sdf_entries(content):
    """
    Split multi-structure SDF text into individual records, repairing each one's header.

    Wraps the embedded splitting logic so the GUI can work from file content it already has in memory rather than
    going back to disk, and so each extracted record gets the same header repair the original script applies --
    a record pulled out of a concatenated file frequently has a blank or reused title line, which downstream
    parsers read as the compound name.
    """
    entries = []
    for block in content.split('$$$$'):
        if block.strip():
            entries.append(sms_fix_sdf_header(block.strip() + '\n$$$$\n'))
    return entries



# ================================================================================================================
# EMBEDDED: conformer clustering (from cluster.py)
# ================================================================================================================
# Renamed to avoid collisions with the analysis half: parse_sdf -> cluster_parse_sdf, and the module-level
# tunables TAU / LINKAGE_METHOD / SELECTION_MODE / DIHEDRAL_WEIGHT gain a CLUSTER_ prefix so the GUI can set
# them per run without shadowing anything else. This script's own command-line entry point and its interactive
# prompts are not carried over -- the interface supplies those settings -- and neither are its job-time
# estimation tables, which predicted queue durations for a workflow this program does not manage.


# Conformer Cluster Organiser
# Run in the same directory as folders containing conformer SDFs
# Copies conformers into per-cluster subdirectories  -- deletes nothing.
# Cross-platform compatible (Windows/Linux/macOS) - Python 3.x
# Version 7.0   -- Clusters on a COMBINED fingerprint of (a) selected
#                interatomic distances (global shape) and (b) heavy-atom
#                dihedral angles encoded as (sin, cos) pairs (local torsional
#                state). The two blocks are normalised and blended by a single
#                representation constant, then turned into one pairwise distance
#                matrix using vectorised SciPy pdist (fast, no Python pair loops).
#                FOUR linkage methods (ward / complete / average / single,
#                + optional weighted) are driven by ONE tuning knob, CLUSTER_TAU (the
#                cut height as a fraction of each method's maximum merge height,
#                so it means the same thing for every method and every compound).
#                SDF reading handles V2000 and V3000.


# ===============================================================================================
# CONFIGURATION PARAMETERS
# ===============================================================================================

# == OUTPUT ===================================================================


# ===========================================================================
#  THE ONE TUNING KNOB
# ===========================================================================
# CLUSTER_TAU is the single value to optimise. It is the fraction of the dendrogram's
# maximum merge height at which the tree is cut, and it means the SAME thing
# for all four linkage methods and for every compound, regardless of the
# absolute distance scale:
#
#     CLUSTER_TAU -> 0.0   no reduction      (every conformer is its own cluster)
#     CLUSTER_TAU -> 1.0   maximum reduction (all conformers collapse to one cluster)
#
# Raising CLUSTER_TAU monotonically keeps fewer conformers, so it is a clean, physically
# interpretable reduction lever. Sweep it (e.g. 0.15, 0.25, 0.35, 0.45) and keep
# the largest value that still preserves the structural diversity you need.
CLUSTER_TAU = 0.30

# Linkage used for the conformers actually written to disk:
#   'ward' | 'complete' | 'average' | 'single' | 'weighted' | 'all'
# 'all' compares every method in COMPARE_METHODS and, for the on-disk output,
# uses 'average' (a robust default). Pick a single method here to force it.
CLUSTER_LINKAGE_METHOD = 'all'

# How structures are picked from each cluster for the all_dft_conformers folder:
#   'lowest_energy' : ONLY the lowest-energy member of each cluster
#                     (lowest conformer number = lowest energy), nothing else.
#   'medoid'        : ONLY the medoid (geometric centre) of each cluster.
#   'tiered'        : lowest-energy primary, medoid secondary, most-different
#                     conformer tertiary, with how many are kept decided by the
#                     intra-cluster spread (DFT_INTRA_TIGHT / DFT_INTRA_MEDIUM).
# NOTE: CLUSTER_TAU, CLUSTER_LINKAGE_METHOD and CLUSTER_SELECTION_MODE below are the *defaults*. When the
# script runs it asks you to choose a preset or enter manual values, and those
# choices override these three settings for the run.
CLUSTER_SELECTION_MODE = 'tiered'

# Methods always included in the comparison tables / plots.
# (centroid/median are deliberately excluded: their dendrograms can contain
#  inversions, which makes a single height-based cut ill-defined. 'weighted'
#  (WPGMA) is monotone and may be added here if you want a fifth method.)
COMPARE_METHODS = ('ward', 'complete', 'average', 'single')

# == REPRESENTATION CONSTANTS  -- set once, not tuning knobs ===================

# How much the DIHEDRAL block counts relative to the DISTANCE block when the
# two are blended into one metric. Each block is first normalised to a common
# scale, so this weight is applied to genuinely comparable quantities:
#
#     CLUSTER_DIHEDRAL_WEIGHT = 0.0   pure interatomic distances (global shape only)
#     CLUSTER_DIHEDRAL_WEIGHT = 1.0   50/50 distance / dihedral
#     CLUSTER_DIHEDRAL_WEIGHT = 2.0   ~67% dihedral
#
# Distances capture global shape; dihedrals capture local torsional state
# (including ring puckering/flips). A modest dihedral contribution usually
# sharpens clustering. Treated as a fixed representation choice; CLUSTER_TAU remains
# the single tuning knob.
CLUSTER_DIHEDRAL_WEIGHT = 0.5

# Dihedral selection: only torsions whose two central atoms are heavy atoms AND
# that have a heavy substituent on each side are used. This captures backbone
# and ring torsions while ignoring uninformative terminal rotations (e.g. methyl
# spinning) and X-H rotations. Set False to also allow hydrogen substituents to
# define a torsion when no heavy substituent is available on a side.
DIHEDRAL_HEAVY_ONLY = True

# Write a PNG of the geometry method-comparison reduction curve (needs
# matplotlib; skipped silently if unavailable). The CSV is always written.
WRITE_PLOTS = True

# == DFT STRUCTURE SELECTION ==================================================

# Directory name for DFT-ready structures (written alongside clustered_output).
CLUSTER_SIMPLE_OUTPUT = True   # Reduce the clustering output to the only two things that matter downstream:
                               # which conformers passed as unique and which did not. The per-cluster
                               # directories, medoid duplicates and diagnostic CSVs the algorithm writes along
                               # the way are removed afterwards rather than suppressed, so the clustering itself
                               # runs exactly as validated and only the leftovers are cleared.
CLUSTER_SELECTED_DIR = "selected_unique"      # Conformers carried forward to DFT
CLUSTER_REJECTED_DIR = "not_selected"         # Conformers clustering set aside

CLUSTER_DFT_DIR = "all_dft_conformers"

# Directory name for conformers NOT selected for DFT submission.
CLUSTER_LOW_PRIORITY_DIR = "low_priority_conformers"

# Intra-cluster distance thresholds governing how many structures per cluster
# are selected for DFT submission. These apply ONLY when CLUSTER_SELECTION_MODE ==
# 'tiered' (the 'lowest_energy' and 'medoid' modes always keep exactly one
# structure per cluster).
#
# Tier logic for 'tiered' (evaluated in order):
#   intra < DFT_INTRA_TIGHT   -> lowest-energy only     (cluster is homogeneous)
#   intra < DFT_INTRA_MEDIUM  -> lowest-energy + medoid  (moderate spread)
#   intra >= DFT_INTRA_MEDIUM -> lowest-energy + medoid + most-different
#                                                       (broad/heterogeneous)
#
# "Lowest-energy" = member with the smallest conformer number, since conformers
#   are sorted numerically by energy (lower number = lower energy). This is the
#   primary, most-populated geometry within the cluster.
# "Medoid" = geometric centre of the cluster (secondary).
# "Most-different" = member furthest from the medoid  -- the outlier geometry in
#   a broad cluster (tertiary).
#
# Suggested starting values based on the combined matrix scale [0, 1]:
DFT_INTRA_TIGHT  = 0.12   # below this: medoid only
DFT_INTRA_MEDIUM = 0.18   # below this: medoid + 1 extra; above: medoid + 2

# == PARALLELISATION ==========================================================


# ===============================================================================================

# ===============================================================================
# SYSTEM DETECTION
# ===============================================================================



# ===============================================================================
# SDF PARSING
# ===============================================================================

def cluster_parse_sdf(file_path):
    """Parse an SDF/MOL file (V2000 or V3000).

    Returns (atoms, coordinates, connectivity, bond_orders):
      atoms        : list of element symbols, in file order (0-based list)
      coordinates  : list of (x, y, z) float tuples, same order as atoms
      connectivity : {atom_index (1-based): [neighbour_index, ...]}
      bond_orders  : {(a, b) sorted 1-based tuple: bond_order int}

    Adapted from NGIG connectivity parser so that connectivity is read
    together with coordinates and is available for dihedral extraction.
    """
    with open(file_path, 'r') as fh:
        lines = fh.readlines()

    atoms = []
    coordinates = []
    connectivity = {}
    bond_orders = {}

    is_v3000 = any("V3000" in ln for ln in lines)

    if is_v3000:
        reading_atoms = False
        reading_bonds = False
        for raw in lines:
            line = raw.strip()
            if "BEGIN ATOM" in line:
                reading_atoms = True
                continue
            if "END ATOM" in line:
                reading_atoms = False
                continue
            if "BEGIN BOND" in line:
                reading_bonds = True
                continue
            if "END BOND" in line:
                reading_bonds = False
                continue

            if reading_atoms and line.startswith("M  V30"):
                parts = line.split()
                if len(parts) >= 7 and parts[1] == "V30":
                    try:
                        atom_index = int(parts[2])
                        element = parts[3]
                        x, y, z = map(float, parts[4:7])
                    except ValueError:
                        continue
                    atoms.append(element)
                    coordinates.append((x, y, z))
                    connectivity[atom_index] = []

            if reading_bonds and line.startswith("M  V30"):
                parts = line.split()
                if len(parts) >= 6 and parts[1] == "V30":
                    try:
                        bond_order = int(parts[3])
                        a1 = int(parts[4])
                        a2 = int(parts[5])
                    except ValueError:
                        continue
                    if a1 in connectivity:
                        connectivity[a1].append(a2)
                    if a2 in connectivity:
                        connectivity[a2].append(a1)
                    bond_orders[tuple(sorted((a1, a2)))] = bond_order

    else:
        coord_start = None
        for i, line in enumerate(lines):
            if "V2000" in line:
                coord_start = i + 1
                break
        if coord_start is None:
            raise ValueError("V2000/V3000 line not found in: {}".format(
                file_path))

        counts_line = lines[coord_start - 1]
        num_atoms = int(counts_line[0:3].strip())

        for i in range(coord_start, coord_start + num_atoms):
            parts = lines[i].split()
            if len(parts) >= 4:
                coordinates.append((float(parts[0]),
                                    float(parts[1]),
                                    float(parts[2])))
                atoms.append(parts[3])
                connectivity[len(coordinates)] = []
            else:
                raise ValueError("Unexpected coordinate line: {}".format(
                    lines[i].strip()))

        for i in range(coord_start + num_atoms, len(lines)):
            line = lines[i].rstrip()
            if line.strip() == "M  END":
                break
            if line.startswith("M  CHG"):
                continue
            try:
                if len(line) >= 9:
                    a1 = int(line[0:3].strip())
                    a2 = int(line[3:6].strip())
                    bo = int(line[6:9].strip())
                    if a1 in connectivity and a2 in connectivity:
                        connectivity[a1].append(a2)
                        connectivity[a2].append(a1)
                        bond_orders[tuple(sorted((a1, a2)))] = bo
            except (ValueError, IndexError):
                continue

    # Ensure every atom index has a connectivity entry.
    for idx in range(1, len(atoms) + 1):
        connectivity.setdefault(idx, [])

    return atoms, coordinates, connectivity, bond_orders


def calculate_selective_distances(atoms, coordinates, connectivity):
    included_indices = []
    included_coords  = []
    excluded_ch      = 0
    included_non_ch  = 0
    for i, atom in enumerate(atoms):
        idx = i + 1
        if atom != 'H':
            included_indices.append(idx)
            included_coords.append(coordinates[i])
        else:
            if idx in connectivity and len(connectivity[idx]) == 1:
                bonded_to   = connectivity[idx][0]
                bonded_atom = atoms[bonded_to - 1]
                if bonded_atom == 'C':
                    excluded_ch += 1
                else:
                    included_indices.append(idx)
                    included_coords.append(coordinates[i])
                    included_non_ch += 1
            else:
                included_indices.append(idx)
                included_coords.append(coordinates[i])
    n = len(included_coords)
    if n < 2:
        return {}, excluded_ch, included_non_ch
    coords = np.array(included_coords, dtype=np.float32)
    diff   = coords[:, np.newaxis, :] - coords[np.newaxis, :, :]
    dmat   = np.sqrt(np.sum(diff ** 2, axis=2))
    distances = {}
    for i in range(n):
        for j in range(i + 1, n):
            pair = tuple(sorted([included_indices[i], included_indices[j]]))
            distances[pair] = float(dmat[i, j])
    return distances, excluded_ch, included_non_ch


# ===============================================================================
# DIHEDRAL EXTRACTION
# ===============================================================================

def extract_dihedral_topology(atoms, connectivity, heavy_only=True):
    """Deterministic list of dihedral atom quadruples (a, b, c, d), 1-based,
    one per central bond b-c that is informative for conformational state.

    A bond b-c qualifies when both b and c are heavy atoms (not H) and each
    side has at least one substituent (a on b, d on c) other than the bond
    partner. With heavy_only=True a heavy substituent is required on each side,
    which selects backbone and ring torsions while ignoring terminal rotations
    (methyl spinning) and X-H rotations; otherwise an H substituent is used as
    a fallback when no heavy one exists. Neighbours are chosen by lowest index
    so the SAME four atoms define a given torsion in every conformer of the
    molecule (connectivity is shared across conformers).
    """
    def is_h(idx):
        return atoms[idx - 1] == 'H'

    dihedrals = []
    for b in sorted(connectivity):
        if is_h(b):
            continue
        for c in sorted(connectivity[b]):
            if c <= b or is_h(c):
                continue
            heavy_a = [x for x in sorted(connectivity[b])
                       if x != c and not is_h(x)]
            heavy_d = [x for x in sorted(connectivity[c])
                       if x != b and not is_h(x)]
            if heavy_only:
                if not heavy_a or not heavy_d:
                    continue
                a, d = heavy_a[0], heavy_d[0]
            else:
                any_a = [x for x in sorted(connectivity[b]) if x != c]
                any_d = [x for x in sorted(connectivity[c]) if x != b]
                if not any_a or not any_d:
                    continue
                a = heavy_a[0] if heavy_a else any_a[0]
                d = heavy_d[0] if heavy_d else any_d[0]
            dihedrals.append((a, b, c, d))
    return dihedrals


def dihedral_fingerprint(coords, dih_idx):
    """Vectorised dihedral angles for one conformer, encoded as (sin, cos).

    coords : (n_atoms, 3) float array (0-based atom order)
    dih_idx: (m, 4) int array of 0-based atom indices (a, b, c, d)
    Returns (sin_vec, cos_vec), each length m. Periodicity is handled by the
    sin/cos encoding, so Euclidean distance between two conformers' vectors is
    a proper chord distance on the torsion torus (+180 deg == -180 deg).
    """
    m = len(dih_idx)
    if m == 0:
        return (np.zeros(0, dtype=np.float64),
                np.zeros(0, dtype=np.float64))
    p0 = coords[dih_idx[:, 0]]
    p1 = coords[dih_idx[:, 1]]
    p2 = coords[dih_idx[:, 2]]
    p3 = coords[dih_idx[:, 3]]
    b0 = p0 - p1
    b1 = p2 - p1
    b2 = p3 - p2
    b1n = b1 / (np.linalg.norm(b1, axis=1, keepdims=True) + 1e-12)
    v = b0 - np.sum(b0 * b1n, axis=1, keepdims=True) * b1n
    w = b2 - np.sum(b2 * b1n, axis=1, keepdims=True) * b1n
    x = np.sum(v * w, axis=1)
    y = np.sum(np.cross(b1n, v) * w, axis=1)
    ang = np.arctan2(y, x)
    return np.sin(ang).astype(np.float64), np.cos(ang).astype(np.float64)


# ===============================================================================
# PARALLEL PARSING WORKER
# ===============================================================================

def parse_conformer_chunk(chunk_data):
    """
    chunk_data: list of (conformer_num, sdf_file, dih_idx) tuples.
    dih_idx is the precomputed (m, 4) array of 0-based dihedral atom indices,
    shared by every conformer of the molecule (derived once from topology).
    """
    results = []
    for conformer_num, sdf_file, dih_idx in chunk_data:
        try:
            atoms, coords, connectivity, _ = cluster_parse_sdf(sdf_file)
            distances, excl, incl = calculate_selective_distances(
                atoms, coords, connectivity)
            coords_arr = np.asarray(coords, dtype=np.float64)
            dih_sin, dih_cos = dihedral_fingerprint(coords_arr, dih_idx)

            results.append({
                'num':                     conformer_num,
                'file':                    sdf_file,
                'distances':               distances,
                'dih_sin':                 dih_sin.astype(np.float32),
                'dih_cos':                 dih_cos.astype(np.float32),
                'coords':                  coords_arr.astype(np.float32),
                'total_atoms':             len(atoms),
                'excluded_ch_protons':     excl,
                'included_non_ch_protons': incl,
                'num_distances':           len(distances),
                'num_dihedrals':           len(dih_sin),
            })
        except Exception as e:
            print("  Conformer {}: ERROR - {}".format(conformer_num, e))
    return results


# ===============================================================================
# FEATURE FINGERPRINT  ->  COMBINED PAIRWISE DISTANCE MATRIX
# ===============================================================================

def build_distance_arrays(conformer_data):
    """Align each conformer's selected-distance dict into a fixed-order vector.

    Only atom pairs present in EVERY conformer are kept (intersection), so the
    resulting matrix has no missing entries and can go straight into a fast
    vectorised distance computation. For conformers of one molecule the pair
    set is identical, so nothing is lost.
    """
    pair_sets = [set(c['distances'].keys()) for c in conformer_data]
    common = set.intersection(*pair_sets) if pair_sets else set()
    sorted_pairs = sorted(common)
    for c in conformer_data:
        d = c['distances']
        c['dist_array'] = np.array([d[p] for p in sorted_pairs],
                                   dtype=np.float64)
    return conformer_data, sorted_pairs


def _block_pairwise(features, n):
    """Condensed pairwise Euclidean distances for an (n, p) feature block,
    scaled by 1/sqrt(p) so the result is an RMS-per-feature distance. Returns a
    length n*(n-1)/2 vector, or zeros if the block has no columns."""
    if features.ndim != 2 or features.shape[1] == 0:
        return np.zeros(n * (n - 1) // 2, dtype=np.float64)
    d = pdist(np.ascontiguousarray(features, dtype=np.float64), metric='euclidean')
    return d / np.sqrt(features.shape[1])


def build_combined_distance_matrix(conformer_data, dihedral_weight):
    """Blend the distance and dihedral fingerprints into ONE pairwise distance
    matrix, computed with vectorised SciPy pdist (no Python pair loops).

    Steps:
      1. distance block  D : (n, p_d) selected interatomic distances
         dihedral block  H : (n, 2*p_h) stacked [sin..., cos...]
      2. condensed RMS-per-feature distances for each block (fast C loop)
      3. normalise each block's distances to [0, 1] by their own max, so the
         weight is applied to comparable scales (same idea as the old metric,
         and it makes a single CLUSTER_DIHEDRAL_WEIGHT behave consistently across
         molecules of different size/scale)
      4. quadrature blend:
             alpha = w / (1 + w)
             combined = sqrt((1-alpha)*d_dist^2 + alpha*d_dih^2)

    Returns (combined_matrix (n x n float32), info dict).
    """
    n = len(conformer_data)

    D = np.vstack([c['dist_array'] for c in conformer_data])         if conformer_data else np.zeros((0, 0))
    p_d = D.shape[1] if D.ndim == 2 else 0

    p_h = len(conformer_data[0]['dih_sin']) if n else 0
    if p_h > 0:
        H = np.vstack([np.concatenate([c['dih_sin'], c['dih_cos']])
                       for c in conformer_data]).astype(np.float64)
    else:
        H = np.zeros((n, 0), dtype=np.float64)

    d_dist = _block_pairwise(D, n)
    d_dih  = _block_pairwise(H, n)

    dist_max = float(np.max(d_dist)) if d_dist.size else 0.0
    dih_max  = float(np.max(d_dih))  if d_dih.size  else 0.0

    use_dih = (p_h > 0 and dih_max > 1e-12 and dihedral_weight > 0.0)
    if dist_max <= 1e-12:
        dist_max = 1.0

    if use_dih:
        alpha = dihedral_weight / (1.0 + dihedral_weight)
        dn = d_dist / dist_max
        hn = d_dih / dih_max
        combined = np.sqrt((1.0 - alpha) * dn * dn + alpha * hn * hn)
    else:
        alpha = 0.0
        combined = d_dist / dist_max

    mat = squareform(combined).astype(np.float32)
    info = {
        'p_dist':     p_d,
        'p_dihedral': p_h,
        'alpha':      alpha,
        'used_dihedral': use_dih,
        'd_dist_raw': d_dist,
        'd_dih_raw':  d_dih,
    }
    return mat, info

# ===============================================================================
# LINKAGE + OPTIMAL CUT
# ===============================================================================

# Linkage methods that are well-defined under a single height-based cut.
# (centroid/median omitted: their dendrograms can invert.)
SUPPORTED_LINKAGES = ('ward', 'complete', 'average', 'single', 'weighted')


def run_linkage(dist_matrix, method='ward'):
    """Build a SciPy linkage matrix Z for the given method from a precomputed
    square distance matrix. Returns (Z, condensed).

    complete / average / single / weighted are exact on any precomputed
    distance matrix. 'ward' is computed on the same precomputed distances to
    match the originally validated behaviour; strictly, Ward assumes Euclidean
    inputs, so its heights are a (well-behaved) heuristic on a precomputed
    matrix. centroid/median are excluded on purpose: their dendrograms can
    contain inversions, which makes a single height-based cut ill-defined.
    """
    if method not in SUPPORTED_LINKAGES:
        raise ValueError("Unsupported linkage method: {}".format(method))
    condensed = squareform(dist_matrix.astype(np.float64))
    Z = linkage(condensed, method=method)
    return Z, condensed


def max_merge_height(Z):
    """Largest merge height in a linkage matrix (always > 0)."""
    if Z is None or len(Z) == 0:
        return 1.0
    h = float(np.max(Z[:, 2]))
    return h if h > 0.0 else 1.0


def labels_at_tau(Z, n, tau):
    """Flat clusters from cutting Z at height tau * max_merge_height.

    tau has the SAME meaning for every method and every compound:
        tau -> 0.0  => all singletons (no reduction)
        tau -> 1.0  => one cluster   (maximum reduction)
    Raising tau monotonically keeps fewer conformers.
    """
    if n <= 1:
        return np.zeros(max(n, 1), dtype=int)
    tau = float(tau)
    if tau <= 0.0:
        return np.arange(n)
    if tau >= 1.0:
        return np.zeros(n, dtype=int)
    t_abs = tau * max_merge_height(Z)
    return fcluster(Z, t=t_abs, criterion='distance')


def labels_at_k(Z, n, k):
    """Flat clusters with at most k clusters via the maxclust criterion."""
    if k >= n:
        return np.arange(n)
    if k <= 1:
        return np.zeros(n, dtype=int)
    return fcluster(Z, k, criterion='maxclust')




def cophenetic_correlation(Z, condensed):
    """Cophenetic correlation coefficient: how faithfully the dendrogram
    preserves the original pairwise distances (1.0 = perfect). A model-free
    way to compare how well each linkage method fits this data set."""
    try:
        ccc, _ = cophenet(Z, condensed)
        if np.isnan(ccc):
            return 0.0
        return float(ccc)
    except Exception:
        return 0.0




def reduction_curve(Z, n, dist_matrix, ks=None):
    """For each k, the geometry-only normalised intra-cluster spread.
    Returns (ks, spreads). Lets methods be compared even without shift data:
    a lower spread at a given k means tighter clusters."""
    if ks is None:
        ks = _default_k_grid(n)
    spreads = []
    for k in ks:
        labels = labels_at_k(Z, n, k)
        spreads.append(_within_cluster_spread(labels, dist_matrix))
    return ks, spreads


def _default_k_grid(n):
    """Shared grid of cluster counts to evaluate. Full 1..n for small
    molecules; sub-sampled above 150 conformers to stay responsive."""
    if n <= 150:
        return list(range(1, n + 1))
    return sorted(set([1] + list(range(2, n + 1, max(1, n // 100))) + [n]))


# ===============================================================================
# PLOTTING (optional)
# ===============================================================================

def _maybe_plot(path, plot_fn):
    """Run plot_fn(ax) and save to path if matplotlib is available; skip
    silently otherwise. Returns True on success."""
    if not WRITE_PLOTS or CLUSTER_SIMPLE_OUTPUT:
        return False
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except Exception:
        return False
    try:
        fig, ax = plt.subplots(figsize=(7.0, 4.5))
        plot_fn(ax)
        fig.tight_layout()
        fig.savefig(path, dpi=130)
        plt.close(fig)
        return True
    except Exception:
        return False


# ===============================================================================
# METHOD COMPARISON (geometry)
# ===============================================================================

class _SkipDiagnosticWrite(Exception):
    """Raised internally to skip a diagnostic file write without leaving the function that computes real results."""


def analyze_methods(compound_base, compound_out, conformer_data,
                    combined_mat, n):
    """Compare the linkage methods on the combined distance+dihedral matrix.

    For each method: cophenetic correlation (dendrogram fidelity), the cluster
    count at the current CLUSTER_TAU, the normalised intra-cluster spread at CLUSTER_TAU, and a
    full reduction curve (spread vs k). Writes method_comparison.csv (+ optional
    PNG) and prints a readable table.

    Returns (output_method, output_tau, diag); diag keeps the shape the log
    writer expects.
    """
    methods = [m for m in COMPARE_METHODS if m in SUPPORTED_LINKAGES]
    if not methods:
        methods = ['average']

    Zs, ccc = {}, {}
    for m in methods:
        Zm, cond = run_linkage(combined_mat, m)
        Zs[m] = Zm
        ccc[m] = cophenetic_correlation(Zm, cond)

    k_at_tau = {m: len(np.unique(labels_at_tau(Zs[m], n, CLUSTER_TAU)))
                for m in methods}

    ks = _default_k_grid(n)
    curves = {}
    spread_at_tau = {}
    for m in methods:
        _, curves[m] = reduction_curve(Zs[m], n, combined_mat, ks)
        spread_at_tau[m] = _within_cluster_spread(
            labels_at_tau(Zs[m], n, CLUSTER_TAU), combined_mat)

    # The comparison table, CSV and plot are diagnostics about how the partition was reached. They are skipped
    # in simple-output mode, but the function must still run to the end: everything below produces the linkage
    # method, tau and diagnostics the caller unpacks, so returning early here silently breaks clustering.
    if not CLUSTER_SIMPLE_OUTPUT:
        print("\n  -- Method comparison (combined distance + dihedral) --------")
        print("  {:<10}  {:>8}  {:>11}  {:>12}".format(
            "method", "k@CLUSTER_TAU", "cophenetic", "intra@CLUSTER_TAU"))
        for m in methods:
            print("  {:<10}  {:>8d}  {:>11.4f}  {:>12.4f}".format(
                m, k_at_tau[m], ccc[m], spread_at_tau[m]))
        print("  CLUSTER_TAU={:.3f}.  cophenetic near 1.0 = dendrogram preserves "
              "distances; lower intra@CLUSTER_TAU = tighter clusters.".format(CLUSTER_TAU))

    comp_csv = os.path.join(compound_out, "method_comparison.csv")
    try:
        if CLUSTER_SIMPLE_OUTPUT:
            raise _SkipDiagnosticWrite()
        with open(comp_csv, 'w', newline='', encoding='utf-8') as fh:
            w = csv.writer(fh)
            w.writerow(["method", "cophenetic_cc", "k_at_TAU",
                        "intra_spread_at_TAU", "CLUSTER_TAU"])
            for m in methods:
                w.writerow([m, "{:.6f}".format(ccc[m]), k_at_tau[m],
                            "{:.6f}".format(spread_at_tau[m]),
                            "{:.4f}".format(CLUSTER_TAU)])
            w.writerow([])
            w.writerow(["reduction_curve: normalised intra-cluster spread "
                        "vs number of clusters k"])
            w.writerow(["k"] + list(methods))
            for j, k in enumerate(ks):
                w.writerow([k] + ["{:.6f}".format(curves[m][j])
                                  for m in methods])
        print("  Wrote {}".format(comp_csv))
    except _SkipDiagnosticWrite:
        pass
    except (IOError, OSError) as e:
        print("  WARNING: could not write {}: {}".format(comp_csv, e))

    def _plot_curve(ax):
        for m in methods:
            ax.plot(ks, curves[m], marker='o', ms=3, label=m)
        ax.set_xlabel("number of clusters (k)")
        ax.set_ylabel("normalised intra-cluster spread")
        ax.set_title("{}: reduction curve".format(compound_base))
        ax.legend()
        ax.grid(True, alpha=0.3)
    _maybe_plot(os.path.join(compound_out, "method_comparison.png"),
                _plot_curve)

    if CLUSTER_LINKAGE_METHOD != 'all' and CLUSTER_LINKAGE_METHOD in SUPPORTED_LINKAGES:
        output_method = CLUSTER_LINKAGE_METHOD
    else:
        output_method = 'average'
    output_tau = CLUSTER_TAU

    Z_out, _ = run_linkage(combined_mat, output_method)
    ks_out, spreads_out = reduction_curve(Z_out, n, combined_mat, ks)
    chosen_k = len(np.unique(labels_at_tau(Z_out, n, output_tau)))
    diag = {
        'k_values':      list(ks_out),
        'spreads':       list(spreads_out),
        'comp_scores':   list(spreads_out),
        'merge_costs':   Z_out[:, 2].tolist(),
        'composite_k':   chosen_k,
        'accel_k':       chosen_k,
        'min_k':         int(min(ks_out)) if ks_out else 1,
        'max_k':         int(max(ks_out)) if ks_out else n,
        'output_method': output_method,
        'output_tau':    output_tau,
        'cophenetic':    ccc,
    }
    return output_method, output_tau, diag






def _within_cluster_spread(labels, dist_matrix):
    n = len(labels)
    upper = dist_matrix[np.triu_indices(n, k=1)]
    global_std = float(np.std(upper))
    if global_std == 0.0:
        global_std = 1.0
    intra_vals = []
    for cid in np.unique(labels):
        members = np.where(labels == cid)[0]
        if len(members) < 2:
            intra_vals.append(0.0)
            continue
        sub = dist_matrix[np.ix_(members, members)]
        intra_vals.append(float(np.mean(sub[np.triu_indices(len(members), k=1)])))
    return float(np.mean(intra_vals)) / global_std if intra_vals else 0.0


# ===============================================================================
# MEDOID
# ===============================================================================

def _print_matrix_stats(label, arr, unit=""):
    unit_str = "  ({})".format(unit) if unit else ""
    print("  {:<30}: min={:.3f}  mean={:.3f}  max={:.3f}  std={:.3f}{}".format(
        label,
        float(np.min(arr)), float(np.mean(arr)),
        float(np.max(arr)), float(np.std(arr)),
        unit_str))


def find_medoid(member_indices, dist_matrix):
    if len(member_indices) == 1:
        return member_indices[0]
    sub  = dist_matrix[np.ix_(member_indices, member_indices)]
    sums = sub.sum(axis=1)
    return member_indices[int(np.argmin(sums))]


# ===============================================================================
# MEDOID COLLECTION
# ===============================================================================



# ===============================================================================
# DFT STRUCTURE COLLECTION
# ===============================================================================

def _locate_medoid_file(cluster_dir, medoid_num):
    """Best-effort path to a cluster's medoid SDF (used only as a fallback for
    single-conformer clusters that carry no per-member distance info)."""
    for fname in os.listdir(cluster_dir):
        if '_medoid' in fname and fname.endswith('.sdf'):
            return os.path.join(cluster_dir, fname)
    pattern = '_{}.sdf'.format(medoid_num)
    for fname in os.listdir(cluster_dir):
        if fname.endswith(pattern):
            return os.path.join(cluster_dir, fname)
    return None


def _dft_copy_member(member, dft_dir, selected_nums):
    """Copy one member tuple (conformer_num, src_file, dist_to_medoid) into
    dft_dir under its original name, unless that conformer was already taken
    for this cluster. Returns True on a successful copy."""
    if member is None or member[0] in selected_nums:
        return False
    name = os.path.basename(member[1]).replace('_medoid', '')
    try:
        shutil.copy2(member[1], os.path.join(dft_dir, name))
        selected_nums.append(member[0])
        return True
    except (IOError, OSError) as e:
        print("  DFT WARNING: Could not copy {}: {}".format(member[1], e))
        return False


def collect_dft_structures(all_compound_args, all_results, all_cluster_members,
                           output_root):
    """
    For each compound, select structures for DFT submission and copy them into
    a flat directory: <output_root>/<compound_base>/all_dft_conformers/

    Which structures are kept from each cluster depends on CLUSTER_SELECTION_MODE:
      'lowest_energy' : the lowest-energy member only (smallest conformer
                        number = lowest energy).
      'medoid'        : the medoid only (geometric centre).
      'tiered'        : lowest-energy primary, then by intra-cluster spread:
                          intra < DFT_INTRA_TIGHT   -> lowest-energy only
                          intra < DFT_INTRA_MEDIUM  -> + medoid
                          intra >= DFT_INTRA_MEDIUM -> + most-different
                                                       (furthest from medoid)

    Files retain their original names: {compound_name}_{conformer_number}.sdf
    Deletes nothing. Existing all_dft_conformers folder is cleared and rebuilt.
    """
    for (compound_name, _, _), result, cluster_members_map in zip(
            all_compound_args, all_results, all_cluster_members):
        if not result:
            continue

        compound_base = compound_base_name(compound_name)
        dft_dir = os.path.join(output_root, compound_base, "all_dft_conformers")

        if os.path.isdir(dft_dir):
            shutil.rmtree(dft_dir)
        os.makedirs(dft_dir)

        copied  = 0
        skipped = 0
        tier_counts = {1: 0, 2: 0, 3: 0}  # structures per tier (tiered mode)

        for rank, info in sorted(result.items()):
            intra       = info['intra_rmsd']
            cluster_dir = info['dir']
            medoid_num  = info['medoid_num']
            members_info = cluster_members_map.get(rank, [])
            # members_info: list of (conformer_num, src_file, dist_to_medoid)
            selected_nums = []

            # Fallback: clusters with no recorded member info (whole-compound
            # single-conformer case) -- just copy the one medoid file.
            if not members_info:
                src = _locate_medoid_file(cluster_dir, medoid_num)
                if src is not None:
                    try:
                        name = os.path.basename(src).replace('_medoid', '')
                        shutil.copy2(src, os.path.join(dft_dir, name))
                        copied += 1
                        tier_counts[1] += 1
                    except (IOError, OSError) as e:
                        print("  DFT WARNING: {}".format(e))
                        skipped += 1
                else:
                    print("  DFT WARNING: Cannot find structure for "
                          "cluster_{:04d}  -- skipping".format(rank))
                    skipped += 1
                continue

            medoid_member = next(
                (m for m in members_info if m[0] == medoid_num), None)
            lowest_member = min(members_info, key=lambda m: m[0])

            # ---- MEDOID ONLY -------------------------------------------------
            if CLUSTER_SELECTION_MODE == 'medoid':
                if _dft_copy_member(medoid_member, dft_dir, selected_nums):
                    copied += 1
                    tier_counts[1] += 1
                else:
                    skipped += 1
                continue

            # ---- LOWEST-ENERGY ONLY -----------------------------------------
            if CLUSTER_SELECTION_MODE == 'lowest_energy':
                if _dft_copy_member(lowest_member, dft_dir, selected_nums):
                    copied += 1
                    tier_counts[1] += 1
                else:
                    skipped += 1
                continue

            # ---- TIERED ------------------------------------------------------
            # (lowest-energy primary, medoid secondary, most-different tertiary)
            if intra < DFT_INTRA_TIGHT:
                tier = 1
            elif intra < DFT_INTRA_MEDIUM:
                tier = 2
            else:
                tier = 3

            # Primary: lowest-energy member.
            if _dft_copy_member(lowest_member, dft_dir, selected_nums):
                copied += 1
                tier_counts[tier] += 1

            # Secondary: medoid (if distinct from the primary).
            if tier >= 2:
                if _dft_copy_member(medoid_member, dft_dir, selected_nums):
                    copied += 1
                    tier_counts[tier] += 1

            # Tertiary: most-different member (furthest from medoid), if a
            # distinct one remains.
            if tier >= 3:
                remaining = [m for m in members_info
                             if m[0] not in selected_nums]
                if remaining:
                    outlier = max(remaining, key=lambda m: m[2])
                    if _dft_copy_member(outlier, dft_dir, selected_nums):
                        copied += 1
                        tier_counts[tier] += 1

        # ---- Per-compound summary -------------------------------------------
        if CLUSTER_SELECTION_MODE == 'tiered':
            n_tight  = sum(1 for r, i in result.items()
                           if i['intra_rmsd'] < DFT_INTRA_TIGHT)
            n_medium = sum(1 for r, i in result.items()
                           if DFT_INTRA_TIGHT <= i['intra_rmsd']
                           < DFT_INTRA_MEDIUM)
            n_broad  = sum(1 for r, i in result.items()
                           if i['intra_rmsd'] >= DFT_INTRA_MEDIUM)
            print("  {}: {} DFT structures from {} clusters "
                  "({} skipped)  [tiered]".format(
                      compound_base, copied, len(result), skipped))
            print("    Tier breakdown  -- "
                  "tight (<{:.2f}): {} | medium (<{:.2f}): {} | "
                  "broad: {} clusters".format(
                      DFT_INTRA_TIGHT, n_tight,
                      DFT_INTRA_MEDIUM, n_medium, n_broad))
        else:
            print("  {}: {} DFT structures from {} clusters "
                  "({} skipped)  [{}]".format(
                      compound_base, copied, len(result), skipped,
                      SELECTION_LABELS.get(CLUSTER_SELECTION_MODE, CLUSTER_SELECTION_MODE)))


# ===============================================================================
# LOW-PRIORITY STRUCTURE COLLECTION
# ===============================================================================

def collect_low_priority_structures(all_compound_args, all_results,
                                    all_cluster_members, output_root):
    """
    For each compound, copy every conformer that was NOT selected for
    all_dft_conformers into a flat directory:
        <output_root>/<compound_base>/low_priority_conformers/

    A conformer is low-priority if its source file does not appear in the
    all_dft_conformers folder for that compound.

    Deletes nothing.  Existing low_priority_conformers folder is cleared
    and rebuilt each run.
    """
    for (compound_name, conformer_files, _), result, cluster_members_map in zip(
            all_compound_args, all_results, all_cluster_members):
        if not result:
            continue

        compound_base = compound_base_name(compound_name)

        dft_dir = os.path.join(output_root, compound_base, "all_dft_conformers")
        lp_dir  = os.path.join(output_root, compound_base, CLUSTER_LOW_PRIORITY_DIR)

        # == Collect the basenames already written to all_dft_conformers ======
        dft_basenames = set()
        if os.path.isdir(dft_dir):
            for fname in os.listdir(dft_dir):
                if fname.endswith('.sdf'):
                    dft_basenames.add(fname)

        # == Rebuild low_priority_conformers ===================================
        if os.path.isdir(lp_dir):
            shutil.rmtree(lp_dir)
        os.makedirs(lp_dir)

        copied  = 0
        skipped = 0

        for _conf_num, src_path in conformer_files:
            basename = os.path.basename(src_path)
            if basename in dft_basenames:
                continue  # already going to DFT  -- skip

            dst = os.path.join(lp_dir, basename)
            try:
                shutil.copy2(src_path, dst)
                copied += 1
            except (IOError, OSError) as e:
                print("  LP WARNING: Could not copy {}: {}".format(src_path, e))
                skipped += 1

        total_confs = len(conformer_files)
        n_dft       = len(dft_basenames)
        print("  {}: {}/{} conformers -> low_priority_conformers/ "
              "({} skipped)".format(
                  compound_base, copied, total_confs - n_dft, skipped))



# ===============================================================================
# MAIN COMPOUND ORGANISER
# ===============================================================================

def cluster_organise_conformers_into_clusters(compound_name, conformer_files,
                                      output_root, pool=None):
    original_count = len(conformer_files)
    print("\n" + "=" * 70)
    print("Compound   : {}".format(compound_name))
    print("Conformers : {}  |  Dihedral weight: {}".format(
        original_count, CLUSTER_DIHEDRAL_WEIGHT))
    print("=" * 70)

    if original_count == 0:
        print("  No conformers found, skipping.")
        return {}

    compound_base = compound_base_name(compound_name)

    compound_out = os.path.join(output_root, compound_base)

    if original_count == 1:
        print("  Only 1 conformer  -- placing in cluster_0001.")
        cluster_dir = os.path.join(compound_out, "cluster_0001")
        os.makedirs(cluster_dir, exist_ok=True)
        shutil.copy2(conformer_files[0][1], cluster_dir)
        return {1: {'dir': cluster_dir,
                    'members': [conformer_files[0][1]],
                    'size': 1,
                    'medoid_num': conformer_files[0][0],
                    'intra_rmsd': 0.0}}

    # == Step 1: Topology  -- select dihedrals once from the first conformer ====
    print("  [1/6] Reading topology + selecting dihedrals...")
    t0 = time.time()

    first_atoms, first_coords, first_conn, _ = cluster_parse_sdf(conformer_files[0][1])
    dihedrals = extract_dihedral_topology(
        first_atoms, first_conn, DIHEDRAL_HEAVY_ONLY)
    if dihedrals:
        dih_idx = np.array(dihedrals, dtype=np.int64) - 1   # 0-based
    else:
        dih_idx = np.zeros((0, 4), dtype=np.int64)

    print("  Done in {:.2f}s".format(time.time() - t0))
    print("    Atoms in molecule            : {}".format(len(first_atoms)))
    print("    Dihedrals selected           : {}{}".format(
        len(dihedrals),
        "" if dihedrals else "  (none -> distance-only clustering)"))
    for i, (a, b, c, d) in enumerate(dihedrals[:12]):
        print("      tor {:2d}: {}-{}-{}-{}  ({}-{}-{}-{})".format(
            i + 1, a, b, c, d,
            first_atoms[a - 1], first_atoms[b - 1],
            first_atoms[c - 1], first_atoms[d - 1]))
    if len(dihedrals) > 12:
        print("      ... (+{} more)".format(len(dihedrals) - 12))

    # == Step 2: Parse all conformers =========================================
    print("  [2/6] Parsing conformers...")

    n_workers  = pool._processes if pool else 1
    chunk_size = max(1, original_count // n_workers)
    chunks = [
        [(num, path, dih_idx)
         for num, path in conformer_files[i:i + chunk_size]]
        for i in range(0, original_count, chunk_size)
    ]

    if pool and len(chunks) > 1:
        chunk_results = pool.map(parse_conformer_chunk, chunks)
    else:
        chunk_results = [parse_conformer_chunk(ch) for ch in chunks]

    conformer_data = []
    for chunk in chunk_results:
        conformer_data.extend(chunk)
    conformer_data.sort(key=lambda x: x['num'])

    parsed_count = len(conformer_data)
    if parsed_count == 0:
        print("  ERROR: No conformers parsed successfully.")
        return {}

    avg = lambda key: sum(c[key] for c in conformer_data) // parsed_count
    print("  Parsed {} / {} conformers".format(parsed_count, original_count))
    print("    Avg atoms per conformer      : {}".format(avg('total_atoms')))
    print("    Avg C-H protons excluded     : {}".format(avg('excluded_ch_protons')))
    print("    Avg non-C-H protons kept     : {}".format(avg('included_non_ch_protons')))
    print("    Avg distance pairs           : {}".format(avg('num_distances')))
    print("    Dihedral angles per conformer: {}".format(avg('num_dihedrals')))

    if parsed_count == 1:
        print("  Only 1 conformer parsed  -- placing in cluster_0001.")
        cluster_dir = os.path.join(compound_out, "cluster_0001")
        os.makedirs(cluster_dir, exist_ok=True)
        shutil.copy2(conformer_data[0]['file'], cluster_dir)
        return {1: {'dir': cluster_dir,
                    'members': [conformer_data[0]['file']],
                    'size': 1,
                    'medoid_num': conformer_data[0]['num'],
                    'intra_rmsd': 0.0}}

    # == Step 3: Align distance arrays =========================================
    print("  [3/6] Aligning distance vectors...")
    conformer_data, sorted_pairs = build_distance_arrays(conformer_data)
    print("  Common distance pairs: {}".format(len(sorted_pairs)))

    # == Step 4: Build combined distance+dihedral matrix (vectorised) ==========
    n       = len(conformer_data)
    n_pairs = n * (n - 1) // 2
    print("  [4/6] Building combined distance matrix "
          "({} conformer pairs)...".format(n_pairs))
    t0 = time.time()

    combined_mat, cinfo = build_combined_distance_matrix(
        conformer_data, CLUSTER_DIHEDRAL_WEIGHT)

    print("  Done in {:.2f}s".format(time.time() - t0))
    print("    Distance features            : {}".format(cinfo['p_dist']))
    print("    Dihedral angles              : {}".format(cinfo['p_dihedral']))
    if cinfo['used_dihedral']:
        print("    Blend: alpha={:.3f} "
              "(distance {:.0f}%, dihedral {:.0f}%)".format(
                  cinfo['alpha'],
                  (1 - cinfo['alpha']) * 100, cinfo['alpha'] * 100))
    else:
        print("    Blend: distance-only "
              "(no usable dihedral variation or weight=0)")

    c_upper = combined_mat[np.triu_indices(n, k=1)]
    _print_matrix_stats("Combined matrix", c_upper)

    # == Step 5: Linkage (4 methods) + ONE-KNOB CLUSTER_TAU cut ========================
    print("  [5/6] Linkage methods + CLUSTER_TAU cut (CLUSTER_TAU = {:.3f})...".format(CLUSTER_TAU))
    os.makedirs(compound_out, exist_ok=True)
    t0 = time.time()
    output_method, output_tau, diag = analyze_methods(
        compound_base, compound_out, conformer_data, combined_mat, n)
    print("  Analysis complete in {:.1f}s".format(time.time() - t0))

    Z, _    = run_linkage(combined_mat, output_method)
    labels  = labels_at_tau(Z, n, output_tau)
    chosen_k = len(np.unique(labels))
    print("  Output clustering: method='{}', CLUSTER_TAU={:.3f}  ->  {} clusters".format(
        output_method, output_tau, chosen_k))

    # == Step 6: Copy files into cluster directories ===========================
    print("  [6/6] Copying conformers into cluster directories...")

    cluster_ids = np.unique(labels)
    clusters    = [list(np.where(labels == cid)[0]) for cid in cluster_ids]
    cluster_ids = list(range(len(clusters)))

    os.makedirs(compound_out, exist_ok=True)

    cluster_map   = {}
    total_copied  = 0
    total_skipped = 0

    for rank, (cid, members) in enumerate(zip(cluster_ids, clusters), start=1):
        dir_name    = "cluster_{:04d}".format(rank)
        cluster_dir = os.path.join(compound_out, dir_name)
        os.makedirs(cluster_dir, exist_ok=True)

        medoid_idx = find_medoid(members, combined_mat)
        medoid_num = conformer_data[medoid_idx]['num']

        if len(members) >= 2:
            sub   = combined_mat[np.ix_(members, members)]
            intra = float(np.mean(sub[np.triu_indices(len(members), k=1)]))
        else:
            intra = 0.0

        member_files = []
        for gi in members:
            src = conformer_data[gi]['file']
            dst = os.path.join(cluster_dir, os.path.basename(src))
            try:
                shutil.copy2(src, dst)
                member_files.append(src)
                total_copied += 1
                if conformer_data[gi]['num'] == medoid_num and not CLUSTER_SIMPLE_OUTPUT:
                    stem, ext  = os.path.splitext(os.path.basename(src))
                    medoid_dst = os.path.join(
                        cluster_dir, "{}_medoid{}".format(stem, ext))
                    shutil.copy2(src, medoid_dst)
            except (IOError, OSError) as e:
                print("  WARNING: Could not copy {}: {}".format(src, e))
                total_skipped += 1

        # == Build per-member distance data for DFT selection =================
        # Each entry: (conformer_num, src_file, dist_to_medoid)
        # conformer_num is the energy rank  -- lower number = lower energy.
        members_dist_info = []
        for gi in members:
            dist_to_medoid = float(combined_mat[gi, medoid_idx])
            members_dist_info.append((
                conformer_data[gi]['num'],
                conformer_data[gi]['file'],
                dist_to_medoid,
            ))

        cluster_map[rank] = {
            'dir':         cluster_dir,
            'members':     member_files,
            'size':        len(members),
            'medoid_num':  medoid_num,
            'intra_rmsd':  intra,
            'members_dist_info': members_dist_info,
        }

        print("    cluster_{:04d}: {:4d} {}  "
              "intra={:.4f}  medoid={}".format(
                  rank, len(members),
                  "conformer " if len(members) == 1 else "conformers",
                  intra, medoid_num))

    print("\n  Copied {} files into {} cluster directories "
          "({} skipped).".format(total_copied, len(clusters), total_skipped))

    # == Write log =============================================================
    # Skipped in simple-output mode. It is a diagnostic record of how the partition was reached, and the
    # simplifier would delete it immediately afterwards -- writing it only to remove it wastes the work and
    # prints a path the user will never find.
    if CLUSTER_SIMPLE_OUTPUT:
        return cluster_map
    log_path = os.path.join(compound_out, "clustering_log.txt")
    print("  Writing log to {}".format(log_path))

    with open(log_path, 'w', encoding='utf-8') as lf:
        lf.write("Conformer Cluster Organiser Log  v7.0\n")
        lf.write("Compound            : {}\n".format(compound_name))
        lf.write("Linkage method      : {}\n".format(
            diag.get('output_method', '?') if diag else '?'))
        lf.write("Cut height (CLUSTER_TAU)    : {:.4f}  "
                 "(fraction of max merge height)\n".format(
                     diag.get('output_tau', CLUSTER_TAU) if diag else CLUSTER_TAU))
        lf.write("Dihedral weight     : {}  (alpha={:.3f}, {})\n".format(
            CLUSTER_DIHEDRAL_WEIGHT, cinfo['alpha'],
            "distance+dihedral" if cinfo['used_dihedral'] else "distance-only"))
        lf.write("=" * 60 + "\n")
        lf.write("Conformers input    : {}\n".format(n))
        lf.write("Clusters formed     : {}\n".format(len(clusters)))
        lf.write("Clusters at CLUSTER_TAU     : {}\n".format(chosen_k))
        lf.write("Distance features   : {}\n".format(cinfo['p_dist']))
        lf.write("Dihedral angles     : {}\n".format(cinfo['p_dihedral']))
        lf.write("Files copied        : {}\n".format(total_copied))
        lf.write("Nothing deleted     : all source files are intact\n")
        lf.write("\n")
        lf.write("Dihedrals used (a-b-c-d, 1-based):\n")
        for i, (a, b, c, d) in enumerate(dihedrals):
            lf.write("  tor {:3d}: {}-{}-{}-{}  ({}-{}-{}-{})\n".format(
                i + 1, a, b, c, d,
                first_atoms[a - 1], first_atoms[b - 1],
                first_atoms[c - 1], first_atoms[d - 1]))
        lf.write("\n")
        lf.write("Combined matrix stats:\n")
        lf.write("  min={:.4f}  mean={:.4f}  max={:.4f}  std={:.4f}\n".format(
            float(np.min(c_upper)), float(np.mean(c_upper)),
            float(np.max(c_upper)), float(np.std(c_upper))))
        lf.write("\n")

        lf.write("Per-cluster summary:\n")
        lf.write("-" * 60 + "\n")
        lf.write("{:<14}  {:>6}  {:>12}  {:>10}\n".format(
            "Directory", "Size", "Intra_dist", "Medoid_#"))
        lf.write("-" * 60 + "\n")
        for rank, info in sorted(cluster_map.items()):
            lf.write("{:<14}  {:>6}  {:>12.4f}  {:>10}\n".format(
                "cluster_{:04d}".format(rank),
                info['size'], info['intra_rmsd'], info['medoid_num']))

        lf.write("\n")
        lf.write("Full conformer assignments:\n")
        lf.write("-" * 60 + "\n")
        lf.write("{:<12}  {:<14}  {:<10}  {}\n".format(
            "Conf_num", "Cluster_dir", "Is_medoid", "Source_file"))
        lf.write("-" * 60 + "\n")
        for rank, (cid, members) in enumerate(
                zip(cluster_ids, clusters), start=1):
            medoid_idx = find_medoid(members, combined_mat)
            medoid_num = conformer_data[medoid_idx]['num']
            for gi in sorted(members,
                              key=lambda x: conformer_data[x]['num']):
                c         = conformer_data[gi]
                is_medoid = "YES" if c['num'] == medoid_num else ""
                lf.write("{:<12}  {:<14}  {:<10}  {}\n".format(
                    c['num'], "cluster_{:04d}".format(rank),
                    is_medoid, os.path.basename(c['file'])))

        lf.write("\n")
        if diag is not None:
            lf.write("Geometry reduction curve "
                     "(k={}-{}, output method '{}'):\n".format(
                         diag['min_k'], diag['max_k'],
                         diag.get('output_method', '?')))
            lf.write("{:>6}  {:>16}\n".format("k", "norm_spread"))
            for kv, sp in zip(diag['k_values'], diag['spreads']):
                marker = " *" if kv == chosen_k else ""
                lf.write("{:>6}  {:>16.6f}{}\n".format(kv, sp, marker))
            lf.write("\n")

        lf.write("Merge cost sequence:\n")
        for step, cost in enumerate(diag['merge_costs']):
            lf.write("  merge {:4d}: {:.6f}\n".format(step + 1, cost))
        lf.write("\nEnd of log\n")

    return cluster_map




# ===============================================================================
# UTILITIES + MAIN
# ===============================================================================

def compound_base_name(compound_name):
    """Strip leading 'subdir/' prefix from a compound name."""
    return compound_name.split('/', 1)[1] if '/' in compound_name else compound_name










# Human-readable labels for the selection modes.
SELECTION_LABELS = {
    'lowest_energy': 'lowest-energy structure only',
    'medoid':        'medoid only',
    'tiered':        'tiered (lowest-energy + medoid + most-different)',
}








CLUSTER_DIHEDRAL_WEIGHT_DEFAULT = CLUSTER_DIHEDRAL_WEIGHT

def cluster_collect_selected_files(cluster_root, compound_name):
    """
    Gather the conformer files the clustering step chose to carry forward.

    The clustering code organises its output into per-compound directories on disk rather than returning a list,
    so this reads that result back. Only the DFT selection directory is collected: the low-priority directory
    holds the structures clustering deliberately set aside, and pulling those back in would undo the reduction
    that was the point of running it.
    """
    selected = []
    for base in (CLUSTER_DFT_DIR,):
        directory = os.path.join(cluster_root, compound_name, base)
        if not os.path.isdir(directory):
            directory = os.path.join(cluster_root, base)
        if os.path.isdir(directory):
            for name in sorted(os.listdir(directory)):
                if name.lower().endswith('.sdf'):
                    selected.append(os.path.join(directory, name))
    return selected



# ================================================================================================================
# EMBEDDED: Gaussian input generation (from ngig2, version 3.0.4)
# ================================================================================================================
# Renamed: parse_sdf -> ngig_parse_sdf, plus explicit ngig_ prefixes on the entry points the interface calls.
# The coupling-constant route carries no solvent keyword, and its stray parenthesis -- which would have produced
# an unbalanced Gaussian route line -- is fixed. The command-line driver and its interactive prompts are not
# carried over.


#!/usr/bin/env python3
# NMR Gaussian Input Generator Script Generation 2 | Version 3.0.4 | Run this script in the same directory as SDF files obtained from xsampler or Spartan with the "{compound name}_{conformer number}.sdf" naming scheme.


# Basis set dictionary for standard (non-csulfur/non-chalogen) calculations
BASIS_SETS = {
    '1': { # chloroform
        'opt': "6-311g(d,p)",
        'carbon': "def2svp",
        'proton': "6-311++g(2d,p)",
        'fluorine': "aug-cc-pvdz",
        'nitrogen': "cc-pvdz",
        'cc': "6-31g(d)"
    },
    '2': { # dmso
        'opt': "6-311g(d,p)",
        'carbon': "def2svp",
        'proton': "6-311++g(2d,p)",
        'fluorine': "aug-cc-pvdz",
        'nitrogen': "cc-pvdz",
        'cc': "6-31g(d)"
    },
    '3': { # methanol
        'opt': "6-31+g(d,p)",
        'carbon': "6-311+g(2d,p)",
        'proton': "aug-cc-pvdz",
        'fluorine': "aug-cc-pvdz",
        'nitrogen': "cc-pvdz",
        'cc': "6-31g(d)"
    },
    '4': { # acetonitrile
        'opt': "6-311g(d,p)",
        'carbon': "def2svp",
        'proton': "6-311++g(2d,p)",
        'fluorine': "aug-cc-pvdz",
        'nitrogen': "cc-pvdz",
        'cc': "6-31g(d)"
    },
    '5': { # water
        'opt': "6-31+g(d,p)",
        'carbon': "aug-cc-pvdz",
        'proton': "aug-cc-pvdz",
        'fluorine': "aug-cc-pvdz",
        'nitrogen': "cc-pvdz",
        'cc': "6-31g(d)"
    }
}

# Basis sets for csulfur calculations (intended for C directly bound to S)
CSULFUR_BASIS = {
    'opt': "6-31+g(d,p)",
    'carbon': "6-31g(d)"
}

# Basis sets for chalogen calculations (intended for C directly bound to Cl, Br, or I)
CHALOGEN_BASIS = {
    'opt': "midix",
    'carbon': "midix"
}

# Define basis set for iodine when normal basis sets cannot handle it
IODINE_MIDIX_BASIS = """
I     0
S    3   1.00
  14351.186                  0.061003
   2173.0741                 0.366640
    477.87205                0.691131
S    3   1.00
    648.1887                -0.112851
    140.3064                 0.083228
     45.69880                0.969752
S    3   1.00
     56.69469               -0.273697
     27.48875                0.046500
      8.209096               1.091576
S    3   1.00
      8.191679              -0.450828
      3.244596               0.463209
      1.300489               0.838636
S    2   1.00
      1.451380              -0.665852
      0.328103               1.328584
S    1   1.00
      0.115076               1.00000
P    3   1.00
    648.1887                 0.154114
    140.3064                 0.619462
     45.69880                0.383758
P    3   1.00
     56.69469               -0.152322
     27.48875                0.543769
      8.209096               0.656168
P    3   1.00
      8.191679               0.011870
      3.244596               0.526525
      1.300489               0.526608
P    2   1.00
      1.451380               0.027541
      0.3281030              0.985137
P    1   1.00
      0.115076               1.00000
D    3   1.00
    128.09026                0.115864
     35.982378               0.482049
     11.551116               0.589445
D    3   1.00
      6.146152               0.268182
      2.220937               0.580061
      0.809912               0.326226
D    1   1.00
      0.40                   1.0
****
"""

# =============================================================================
# ELECTRON / ATOMIC NUMBER DATABASE  (H=1 through I=53)
# =============================================================================


# =============================================================================
# TIME ESTIMATION
# =============================================================================

# Power function pairs (coefficient, exponent) per job type.
# Two groups for variable job types: methods 1/2/4 vs methods 3/5.
# Static job types apply regardless of method number.




# Power function pairs for csulfur and chalogen extra passes.
# Each table maps job type to [(coeff1, exp1), (coeff2, exp2)].
# Leave empty to skip time estimation for that calculation type.
# Example entry when ready: 'opt': [(2e-05, 2.9845), (2e-06, 3.6399)]








def dos2unix(file_path):
    """
    Convert Windows line endings (CRLF) to Unix line endings (LF) in a file.
    
    Args:
        file_path (str): Path to the file to convert
    
    Returns:
        bool: True if conversion was performed, False if no conversion needed
    """
    try:
        # Read the file in binary mode to preserve exact content
        with open(file_path, 'rb') as f:
            content = f.read()
        
        # Check if file contains Windows line endings
        if b'\r\n' in content:
            # Replace CRLF with LF
            unix_content = content.replace(b'\r\n', b'\n')
            
            # Write back the converted content
            with open(file_path, 'wb') as f:
                f.write(unix_content)
            
            return True  # Conversion performed
        
        return False  # No conversion needed
    
    except Exception as e:
        print(f"Warning: Could not convert {file_path} to Unix format: {e}")
        return False

def ngig_convert_gjf_files_to_unix(gjf_paths):
    """Convert a list of .gjf file paths to Unix line endings."""
    if not gjf_paths:
        return

    converted_count = 0
    for gjf_file in gjf_paths:
        if dos2unix(gjf_file):
            converted_count += 1

    if converted_count > 0:
        print(f"Converted {converted_count} out of {len(gjf_paths)} .gjf files to Unix format.")

# SDF extraction functions
def ngig_parse_sdf(file_path, verbose=False):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    coordinates = []
    connectivity = {}
    per_atom_charges = {}  # key: atom number (int), value: charge (int)
    heavy_atoms = set()  # Track S, Cl, Br, I presence

    # Detect SDF format
    is_v3000 = any("V3000" in line for line in lines)
    
    if is_v3000:
        # V3000 format parsing
        reading_atoms = False
        reading_bonds = False

        for line in lines:
            line = line.strip()

            # Detect coordinate section
            if "BEGIN ATOM" in line:
                reading_atoms = True
                continue
            elif "END ATOM" in line:
                reading_atoms = False
                continue

            # Detect connectivity section
            if "BEGIN BOND" in line:
                reading_bonds = True
                continue
            elif "END BOND" in line:
                reading_bonds = False
                continue

            # Parse atom coordinates
            if reading_atoms and line.startswith("M  V30"):
                parts = line.split()

                if len(parts) >= 7:  # Ensure enough columns exist
                    if parts[1] != "V30":  # Ensure correct format
                        if verbose:
                            print(f"Skipping malformed line: {line}")
                        continue

                    try:
                        atom_index = int(parts[2])  # Atom index
                        element = parts[3]  # Element symbol
                        x, y, z = map(float, parts[4:7])  # Extract coordinates
                        
                        # Set heavy atoms that yield relativistic effects
                        if element in {"S", "Cl", "Br", "I"}:
                            heavy_atoms.add(element)
                        
                        # Search for "CHG=<integer>" in the line
                        charge_match = re.search(r"CHG=(-?\d+)", line)
                        atom_charge = int(charge_match.group(1)) if charge_match else 0
                        
                        # Store per-atom charge
                        if atom_charge != 0:
                            per_atom_charges[atom_index] = atom_charge
                            if verbose:
                                print(f"Detected atomic charge on {element} (Atom {atom_index}): {atom_charge}")
                        
                        coordinates.append(f"{element} {x} {y} {z}")
                        connectivity[atom_index] = []  # Initialize connectivity list

                    except ValueError as e:
                        if verbose:
                            print(f"Error parsing atom line: {line} ({e})")
                        continue  # Skip malformed lines

            # Parse bond connectivity
            if reading_bonds and line.startswith("M  V30"):
                parts = line.split()  # Explicitly split by spaces

                if len(parts) >= 6:  # Ensure enough columns exist
                    if parts[1] != "V30":  # Ensure correct format
                        if verbose:
                            print(f"Skipping malformed bond line: {line}")
                        continue

                    try:
                        bond_order = int(parts[3])  # Bond order
                        atom1 = int(parts[4])  # First atom index
                        atom2 = int(parts[5])  # Second atom index

                        if atom1 in connectivity:
                            connectivity[atom1].append(f"{atom2} {bond_order:.1f}")
                        if atom2 in connectivity:
                            connectivity[atom2].append(f"{atom1} {bond_order:.1f}")

                    except ValueError as e:
                        if verbose:
                            print(f"Error parsing bond line: {line} ({e})")
                        continue  # Skip malformed lines

    else:
        # V2000 format parsing (existing logic)
        # Find the start of the coordinates section after the V2000 line
        coord_start = None
        for i, line in enumerate(lines):
            if "V2000" in line:
                coord_start = i + 1
                break

        if coord_start is None:
            raise ValueError("V2000 line not found in the SDF file.")

        # Read atom count from the counts line (the V2000 line itself, one line before coord_start)
        counts_line = lines[coord_start - 1]
        num_atoms_v2000 = int(counts_line[0:3].strip())

        # Extract coordinates using the exact atom count from the counts line
        for i in range(coord_start, coord_start + num_atoms_v2000):
            line = lines[i].strip()
            parts = line.split()
            if len(parts) >= 4:
                x = float(parts[0])
                y = float(parts[1])
                z = float(parts[2])
                element = parts[3]

                # Set heavy atoms that yield relativistic effects
                if element in {"S", "Cl", "Br", "I"}:
                    heavy_atoms.add(element)

                coordinates.append(f"{element} {x} {y} {z}")
                connectivity[len(coordinates)] = []  # Initialize connectivity for this atom

            else:
                raise ValueError(f"Unexpected format in coordinates line: {line}")

        connectivity_start = coord_start + num_atoms_v2000

        # Extract connectivity and per-atom charges
        for i in range(connectivity_start, len(lines)):
            line = lines[i].rstrip()
            if line.startswith("M  CHG"):
                parts = line.split()
                num_charges = int(parts[2])
                for j in range(num_charges):
                    atom_num = int(parts[3 + 2 * j])
                    charge_value = int(parts[4 + 2 * j])
                    per_atom_charges[atom_num] = charge_value
                continue  # Skip connectivity parsing for this line
            elif line.strip() == "M  END":
                break

            # Parse connectivity data using fixed-width fields
            try:
                atom1 = int(line[0:3].strip())  # First 3 characters: Atom 1
                atom2 = int(line[3:6].strip())  # Second 3 characters: Atom 2
                bond_order = int(line[6:9].strip())  # Third 3 characters: Bond type

                if atom1 in connectivity:
                    connectivity[atom1].append(f"{atom2} {bond_order:.1f}")
                else:
                    if verbose:
                        print(f"Skipping bond: atom {atom1} not found in connectivity keys (line: {line})")
                    continue

                if atom2 in connectivity:
                    connectivity[atom2].append(f"{atom1} {bond_order:.1f}")
                else:
                    if verbose:
                        print(f"Skipping reverse bond: atom {atom2} not found in connectivity keys (line: {line})")
                    continue

            except ValueError as e:
                if verbose:
                    print(f"Error parsing connectivity line: {line} ({e})")
                continue

    if verbose:
        total_charge = sum(per_atom_charges.values())
        print(f"Total molecular charge detected: {total_charge}")

    return coordinates, connectivity, per_atom_charges, heavy_atoms

def serialize_connectivity_and_charge(connectivity, per_atom_charges):
    """
    Serialize per-atom charge information for the job title.

    Charges only: [atom1:charge1|atom2:charge2|...] for atoms with a non-zero formal charge.

    The bond-order block this used to carry ({atom1-atom2-order|...} for every bond of order other than 1) is
    gone. Those orders came from the input SDF, which records what the drawing program believed rather than what
    the converged wavefunction says, and for a large molecule the block grew long enough to threaten Gaussian's
    title-line handling. Opt/freq jobs now request pop=nboread with $NBO BNDIDX $END, and the analysis half reads
    true bond orders from the resulting Wiberg bond index matrix instead. Charges stay here because they are an
    input specification, not something the calculation determines.
    """
    # Serialize charges: only include atoms with non-zero charge
    charge_items = [f"{atom}:{charge}" for atom, charge in sorted(per_atom_charges.items()) if charge != 0]
    # Nothing is emitted for a neutral molecule. An empty bracket pair appeared on every neutral compound and
    # carried no information; the analysis half already treats an absent block as "no charged atoms".
    if not charge_items:
        return ""

    # Charges only. The bond-order block that used to follow is gone entirely -- orders now come from the
    # Wiberg matrix in the log, so an empty pair of braces would carry no information either.
    return "[" + "|".join(charge_items) + "]"

def parse_halogen_scaling_from_title(text):
    """
    Read per-atom halogen scaling out of a chalogen job title.

    The block is {atom:s:slope,i:intercept|...}, written when the job was created. Reading it means each
    carbon is scaled by the constants that actually applied to it, rather than by re-deriving its halogen
    count and consulting a table that may have changed since the job ran.

    Returns {atom_number: (slope, intercept)}.
    """
    factors = {}
    block = re.search(r'hal\{([^}]*)\}', text or '')
    if not block:
        return factors
    # Matched as a whole rather than split on ':' -- the slope carries its own sign and the entry embeds two
    # further ':' separators, so splitting produces the wrong fields
    for atom, slope, intercept in re.findall(
            r'(\d+):s:([-+]?[0-9]*\.?[0-9]+),i:([-+]?[0-9]*\.?[0-9]+)', block.group(1)):
        try:
            factors[int(atom)] = (float(slope), float(intercept))
        except ValueError:
            continue
    return factors


def serialize_halogen_scaling(connectivity, coordinate_lines):
    """
    Per-atom halogen scaling factors for a chalogen job title, as {atom:s:slope,i:intercept|...}.

    A single slope and intercept cannot describe this job: the constants depend on which halogen a carbon
    carries and how many, so one molecule can need several different pairs at once -- a carbon bearing two
    chlorines and another bearing one iodine take different values. Recording them per atom, the same way
    formal charges are recorded, lets the analysis read exactly the factors that applied to each carbon
    instead of re-deriving them from a table that may since have changed.

    Only carbons actually bonded to a halogen appear. Returns an empty string when none are.
    """
    # The coordinate lines are per atom and in atom order ("C  x y z"), so the element for atom N is the
    # first token of line N-1. all_elements elsewhere is a SET for the gen basis block and cannot be indexed.
    atom_types = [line.split()[0] for line in (coordinate_lines or []) if line.split()]
    if not atom_types:
        return ""

    entries = []
    for atom in sorted(connectivity or {}):
        if atom > len(atom_types) or atom_types[atom - 1] != 'C':
            continue
        halogens = []
        for bond in connectivity[atom]:
            neighbour = int(str(bond).split()[0])
            if 1 <= neighbour <= len(atom_types) and atom_types[neighbour - 1] in ('Cl', 'Br', 'I'):
                halogens.append(atom_types[neighbour - 1])
        if not halogens:
            continue
        # The heaviest halogen governs, matching how the analysis selects a table row
        heaviest = max(halogens, key=lambda symbol: ('Cl', 'Br', 'I').index(symbol))
        count = min(len(halogens), 3)
        table = HALOGEN_SCALING.get(heaviest, {}).get(count)
        if table:
            entries.append(f"{atom}:s:{table['slope']},i:{table['intercept']}")
    # Labelled with its own prefix rather than sharing the bare {...} that the old bond-order block used.
    # Two meanings for one delimiter in one file is a trap for anyone who knows only one of them.
    return "hal{" + "|".join(entries) + "}" if entries else ""


def generate_job_title(compound_name, conformer_number, method_key, job_type, method_params, connectivity, per_atom_charges):
    """
    Generate the job title line.
    - Always append serialized connectivity and per-atom charge info for 'opt' job type.
    - Do NOT append scaling factors on 'opt' line.
    - For other job types, append the scaling factors that will be used for that job.
    """
    # The method number is deliberately absent. It existed so the analysis could look the method up in a
    # scaling table; now that every scaled job carries its own factors in its own title, the number identifies
    # nothing the analysis still needs, and the job type alone says which atoms a section describes.
    base_title = f"{compound_name}_{conformer_number}_{job_type}"

    if job_type == 'opt':
        # Append serialized connectivity and charges always for 'opt'
        serialized_info = serialize_connectivity_and_charge(connectivity, per_atom_charges)
        if serialized_info:
            base_title += " " + serialized_info

    else:
        # Scaling factors travel in the title for EVERY method, not only the custom one. The analysis half then
        # reads them from the job it is analysing rather than looking the method up in a table of its own --
        # so a method defined in the configuration file, or one whose constants were edited after the jobs were
        # submitted, still scales correctly, because the factors actually used are recorded in the file that
        # used them.
        # A chalogen job is a carbon NMR job by type, so it would otherwise resolve to the parent method's
        # carbon factors. Its constants are per atom instead -- they depend on each carbon's halogen and
        # halogen count -- so they are serialized from the structure rather than emitted as one pair.
        if compound_name.endswith('-chalogen') and job_type == 'carbon':
            halogen_block = serialize_halogen_scaling(
                connectivity, (method_params or {}).get('_coordinate_lines') or [])
            if halogen_block:
                base_title += " " + halogen_block
        else:
            slope, intercept = resolve_scaling_factors(method_key, job_type, method_params)
            if slope is not None and intercept is not None:
                base_title += f" s:{slope} i:{intercept}"

    return base_title


def resolve_scaling_factors(method_key, job_type, method_params=None):
    """
    The slope and intercept for one NMR job type, wherever they are defined.

    Every scaled job type carries its factors in its own title, so the analysis reads what was actually used
    rather than consulting a table that may have changed since. Fluorine and nitrogen use element-specific
    constants that do not vary by method, but recording them keeps the design uniform and means editing them
    later cannot silently re-scale old logs.

    Coupling constants are not scaled, so 'cc' returns nothing. Chalogen is handled separately: its factors
    depend on each carbon's halogen and halogen count, so a single pair cannot describe the job (see
    serialize_halogen_scaling).

    Order for carbon and proton: the method's own parameters (a custom method, or a configuration entry naming
    them), then the built-in table.

    Returns (slope, intercept), either None when nothing applies.
    """
    if job_type == 'fluorine':
        return FLUORINE_SCALING['slope'], FLUORINE_SCALING['intercept']
    if job_type == 'nitrogen':
        return NITROGEN_SCALING['slope'], NITROGEN_SCALING['intercept']
    if job_type == 'csulfur':
        # Its own sulfur constants, not the parent method's carbon ones -- those describe a different
        # calculation entirely and were being inherited by mistake
        entry = SULFUR_SCALING_BY_METHOD.get(method_key) or SULFUR_SCALING_BY_METHOD.get('6')
        return entry['slope'], entry['intercept']
    if job_type not in ('carbon', 'proton'):
        return None, None

    if method_params:
        slope = method_params.get(f'{job_type}_slope')
        intercept = method_params.get(f'{job_type}_intercept')
        if slope not in (None, '') and intercept not in (None, ''):
            return slope, intercept

    entry = WORKBENCH_METHODS.get(method_key) or {}
    slope = entry.get(f'{job_type}_slope')
    intercept = entry.get(f'{job_type}_intercept')
    if slope and intercept:
        return slope, intercept

    table = scaling_factors.get(method_key)
    if table and job_type in table:
        return table[job_type]['slope'], table[job_type]['intercept']
    return None, None

def config_basis_source(method_key):
    """
    A configuration method's basis sets in the {job_type: basis_name} shape the gen block builder expects.

    The configuration file names these opt_basis, carbon_basis and so on, which reads naturally beside the
    matching route lines, while the gen block builder indexes by bare job type. Translating here means neither
    side needs to know the other's naming, and it gives everything that needs a method's basis sets one
    function to call instead of each reaching into the hard-coded table and failing on anything absent from it.

    Returns None for a method the configuration does not define, so callers can fall back.
    """
    entry = WORKBENCH_METHODS.get(method_key)
    if not entry:
        return None
    mapping = {}
    for job_type in ('opt', 'carbon', 'proton', 'fluorine', 'nitrogen', 'cc'):
        value = entry.get(job_type + '_basis')
        if value:
            mapping[job_type] = value
    return mapping or None


def resolve_basis_source(method_key, method_params=None):
    """
    The basis sets for a method, wherever that method is defined.

    Order: the configuration file, then a method-6 basis source carried on its own parameters, then the
    built-in table. Indexing BASIS_SETS directly is what made a configuration-defined method crash the moment
    a gen basis was required -- an iodine-containing compound, or a route already asking for /gen -- because
    such a method has no entry in that table at all.
    """
    from_config = config_basis_source(method_key)
    if from_config:
        return from_config
    if method_params and method_params.get('basis_source'):
        return method_params['basis_source']
    return BASIS_SETS.get(method_key)


def build_basis_set_block(all_elements, method_key, job_type, basis_source=None):

    basis_dict = basis_source if basis_source else resolve_basis_source(method_key)
    if not basis_dict or job_type not in basis_dict:
        # A method with no basis entry for this job type cannot produce a gen block. Reporting it beats
        # raising, which would abort an entire run over one job type on one compound.
        print("  Warning: no " + repr(job_type) + " basis set defined for method " + repr(method_key)
              + "; gen block omitted for this job.")
        return ""
    
    block_lines = []  
    added = set()
    for element in sorted(all_elements):
        if element == "I":
            continue
        if element not in added:
            block_lines.append(f"{element} 0")
            block_lines.append(basis_dict[job_type])  # One basis set applied to all elements  -- intentional for Gaussian gen blocks
            block_lines.append("****")
            added.add(element)

    if "I" in all_elements:
        block_lines.append(IODINE_MIDIX_BASIS.strip())

    return "\n".join(block_lines)

# Method parameter definitions
def get_method_parameters(method_key, include_cc, include_fluorine, include_nitrogen, temperature=None, contains_iodine=False):
    solvents = {
        '1': "chloroform",
        '2': "dmso",
        '3': "methanol",
        '4': "acetonitrile",
        '5': "water"
    }

    temp_keyword = f" temperature={temperature}" if temperature else ""

    # Configuration-driven methods take precedence, and this check must come BEFORE anything that indexes the
    # hard-coded BASIS_SETS table -- a method key added to the configuration file has no entry there, so
    # reaching that lookup first raises KeyError for exactly the user-defined methods this feature exists to
    # support. Every method is defined in that file; there is no interactive method.
    if method_key in WORKBENCH_METHODS:
        return build_method_from_config(method_key, include_cc, include_fluorine, include_nitrogen,
                                        temperature, contains_iodine)


    # Every method now lives in the configuration file, so reaching here means the requested key is not
    # defined anywhere. Saying so beats a KeyError from the legacy table, which only covers the five methods
    # that happened to be built in.
    if method_key not in BASIS_SETS:
        print(f"  No method '{method_key}' is defined. Add a [method:{method_key}] section to "
              f"{CONFIG_FILENAME}, or pick one of: {', '.join(sorted(WORKBENCH_METHODS)) or 'none available'}.")
        return None

    opt_basis = "gen" if contains_iodine else BASIS_SETS[method_key]['opt']
    carbon_basis = "gen" if contains_iodine else BASIS_SETS[method_key]['carbon']
    proton_basis = "gen" if contains_iodine else BASIS_SETS[method_key]['proton']
    fluorine_basis = "gen" if contains_iodine else BASIS_SETS[method_key]['fluorine']
    nitrogen_basis = "gen" if contains_iodine else BASIS_SETS[method_key]['nitrogen']
    cc_basis = "gen" if contains_iodine else BASIS_SETS[method_key]['cc']

    # Predefined methods for various solvents (1 to 5)
    methods = {
        '1': {
            'opt': f"# opt freq=noraman{temp_keyword} b3lyp/{opt_basis} scrf=(iefpcm,solvent=chloroform) geom=connectivity pop=nboread empiricaldispersion=gd3",
            'carbon': f"# nmr=giao wb97xd/{carbon_basis} scrf=(iefpcm,solvent=chloroform) geom=check guess=read",
            'proton': f"# nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=chloroform) geom=check guess=read"
        },
        '2': {
            'opt': f"# opt freq=noraman{temp_keyword} b3lyp/{opt_basis} scrf=(iefpcm,solvent=dmso) geom=connectivity pop=nboread empiricaldispersion=gd3",
            'carbon': f"# nmr=giao wb97xd/{carbon_basis} scrf=(iefpcm,solvent=dmso) geom=check guess=read",
            'proton': f"# nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=dmso) geom=check guess=read"
        },
        '3': {
            'opt': f"# opt freq=noraman{temp_keyword} b3lyp/{opt_basis} geom=connectivity pop=nboread",
            'carbon': f"# nmr=giao mpw1pw91/{carbon_basis} scrf=(iefpcm,solvent=methanol) geom=check guess=read",
            'proton': f"# nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=methanol) geom=check guess=read"
        },
        '4': {
            'opt': f"# opt freq=noraman{temp_keyword} b3lyp/{opt_basis} scrf=(iefpcm,solvent=acetonitrile) geom=connectivity pop=nboread empiricaldispersion=gd3",
            'carbon': f"# nmr=giao wb97xd/{carbon_basis} scrf=(iefpcm,solvent=acetonitrile) geom=check guess=read",
            'proton': f"# nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=acetonitrile) geom=check guess=read"
        },
        '5': {
            'opt': f"# opt freq=noraman{temp_keyword} b3lyp/{opt_basis} geom=connectivity pop=nboread",
            'carbon': f"# nmr=giao blyp/{carbon_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=water) geom=check guess=read",
            'proton': f"# nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=water) geom=check guess=read"
        }
    }

    # Universal parameters for fluorine, nitrogen, and coupling constants
    for solvent_key, solvent in solvents.items():
        methods[solvent_key]['fluorine'] = f"# nmr=giao wb97xd/{fluorine_basis} scrf=(iefpcm,solvent={solvent}) geom=check guess=read" if include_fluorine else None
        methods[solvent_key]['nitrogen'] = f"# nmr=giao b3lyp/{nitrogen_basis} scrf=(iefpcm,solvent={solvent}) geom=check guess=read" if include_nitrogen else None
        # No solvent keyword for coupling constant calculations: Fermi contact coupling is evaluated from the
        # gas-phase wavefunction, so the scrf block every other job type carries is deliberately absent here.
        # Iodine needs no special handling on this line: cc_basis is already "gen" for iodine-containing
        # compounds (set above, same as every other basis in this branch), and the gen block itself is emitted
        # by build_basis_set_block, so no special handling is needed on this line.
        methods[solvent_key]['cc'] = (
            f"# nmr=(giao,mixed) b3lyp/{cc_basis} geom=check guess=read" if include_cc else None
        )

    return methods.get(method_key)

def append_link1_header(gaussian_input, settings, compound_name, conformer_number):
    """Append the standard Link1 header lines (rwf, chk, nproc, mem) to the input list."""
    gaussian_input.append(settings['rwf'].format(compound_name=compound_name, conformer_number=conformer_number))
    gaussian_input.append(settings['chk'].format(compound_name=compound_name, conformer_number=conformer_number))
    gaussian_input.append(f"%nprocshared={settings['nprocshared']}")
    gaussian_input.append(f"%mem={settings['mem']}")

def generate_gaussian_input(compound_name, conformer_number, coordinates, connectivity, per_atom_charges, settings, method_params, include_cc, include_fluorine, include_nitrogen, multiplicity, method_key, all_elements=None, contains_iodine=False):
    gaussian_input = []
    
    def append_basis_block(job_type):
        method_line = method_params.get(job_type, "")
        # Only apply gen logic if iodine is present or /gen is explicitly in the method line
        needs_gen = contains_iodine or "/gen" in method_line.lower()

        # For fluorine, nitrogen, and cc  -- only include basis block if gen is required
        if job_type in {"fluorine", "nitrogen", "cc"} and not needs_gen:
            return  # Skip basis block entirely

        if needs_gen:
            # Use the already-computed all_elements passed into generate_gaussian_input
            all_elements_local = all_elements if all_elements is not None else {line.split()[0] for line in coordinates}

            # Decide basis source
            if compound_name.endswith("-csulfur"):
                basis_source = CSULFUR_BASIS
            elif compound_name.endswith("-chalogen"):
                basis_source = CHALOGEN_BASIS
            else:
                # Resolves through the configuration first, so a user-defined method behaves here exactly as a
                # built-in one instead of raising KeyError on the BASIS_SETS lookup
                basis_source = resolve_basis_source(method_key, method_params)

            block = build_basis_set_block(all_elements_local, method_key, job_type=job_type, basis_source=basis_source)
            gaussian_input.append(block)
            gaussian_input.append("")

    # Define RWF, Checkpoint, Processors, and Memory
    append_link1_header(gaussian_input, settings, compound_name, conformer_number)

    # Check for special calculation (csulfur, chalogen)
    is_special = compound_name.endswith("-csulfur") or compound_name.endswith("-chalogen")

    # Compute total charge for Gaussian input line
    total_charge = sum(per_atom_charges.values())

    # 1: Optimization and Frequency Calculation
    gaussian_input.append(method_params['opt'])
    gaussian_input.append("")
    gaussian_input.append(generate_job_title(compound_name, conformer_number, method_key, 'opt', method_params, connectivity, per_atom_charges))
    gaussian_input.append("")
    gaussian_input.append(f"{total_charge} {multiplicity}")
    gaussian_input.append("\n".join(coordinates))
    gaussian_input.append("")

    for atom1 in range(1, len(coordinates) + 1):
        bonds = connectivity.get(atom1, [])
        if bonds:
            gaussian_input.append(f"{atom1} {' '.join(bonds)}")
        else:
            gaussian_input.append(f"{atom1}")

    gaussian_input.append("")

    # NBO input block, read because the opt route carries pop=nboread. BNDIDX requests the Wiberg bond index
    # matrix, from which the analysis half derives true bond orders -- what the converged wavefunction says the
    # bonding is, rather than what the drawing program recorded in the input SDF.
    #
    # ORDER MATTERS. Gaussian reads the sections after the molecule specification in a fixed sequence:
    # connectivity, then the gen basis specification, then the NBO input. Emitting $NBO before the basis block
    # means Gaussian is still parsing basis input when it reaches that line and tries to read "$NBO" as an
    # atom label, which ends the job with an invalid-atom-type error. That only shows up when a gen basis is
    # actually present -- an iodine-containing compound, say -- so it passes unnoticed on ordinary molecules.
    append_basis_block("opt")

    gaussian_input.append(NBO_INPUT_BLOCK)
    gaussian_input.append("")

    gaussian_input.append("--Link1--")

    # 2: Carbon NMR Calculation
    append_link1_header(gaussian_input, settings, compound_name, conformer_number)
    gaussian_input.append(method_params['carbon'])
    gaussian_input.append("")
    gaussian_input.append(generate_job_title(compound_name, conformer_number, method_key, 'carbon', method_params, connectivity, per_atom_charges))
    gaussian_input.append("")
    gaussian_input.append(f"{total_charge} {multiplicity}")
    gaussian_input.append("")
    
    append_basis_block("carbon")

    # If NOT a special calculation (heavy atom carbon correction), add proton, fluorine, nitrogen, and cc calculations
    if not is_special: # Proton block
        gaussian_input.append("--Link1--")
        append_link1_header(gaussian_input, settings, compound_name, conformer_number)
        gaussian_input.append(method_params['proton'])
        gaussian_input.append("")
        gaussian_input.append(generate_job_title(compound_name, conformer_number, method_key, 'proton', method_params, connectivity, per_atom_charges))
        gaussian_input.append("")
        gaussian_input.append(f"{total_charge} {multiplicity}")
        gaussian_input.append("")
        
        append_basis_block("proton")

        if include_fluorine and method_params.get('fluorine'):
            gaussian_input.append("--Link1--")
            append_link1_header(gaussian_input, settings, compound_name, conformer_number)
            gaussian_input.append(method_params['fluorine'])
            gaussian_input.append("")
            gaussian_input.append(generate_job_title(compound_name, conformer_number, method_key,
                                                     'fluorine', method_params, connectivity, per_atom_charges))
            gaussian_input.append("")
            gaussian_input.append(f"{total_charge} {multiplicity}")
            gaussian_input.append("")
            
            append_basis_block("fluorine")

        if include_nitrogen and method_params.get('nitrogen'):
            gaussian_input.append("--Link1--")
            append_link1_header(gaussian_input, settings, compound_name, conformer_number)
            gaussian_input.append(method_params['nitrogen'])
            gaussian_input.append("")
            gaussian_input.append(generate_job_title(compound_name, conformer_number, method_key,
                                                     'nitrogen', method_params, connectivity, per_atom_charges))
            gaussian_input.append("")
            gaussian_input.append(f"{total_charge} {multiplicity}")
            gaussian_input.append("")
            
            append_basis_block("nitrogen")

        if include_cc and method_params.get('cc'):
            gaussian_input.append("--Link1--")
            append_link1_header(gaussian_input, settings, compound_name, conformer_number)
            gaussian_input.append(method_params['cc'])
            gaussian_input.append("")
            gaussian_input.append(generate_job_title(compound_name, conformer_number, method_key,
                                                     'cc', method_params, connectivity, per_atom_charges))
            gaussian_input.append("")
            gaussian_input.append(f"{total_charge} {multiplicity}")
            gaussian_input.append("")
            
            append_basis_block("cc")

    return "\n".join(gaussian_input) + "\n"



def ngig_process_compound_folder(
    compound_name, folder_type, conformer_files,
    output_base_dir, compound_settings
):
    """
    Generate .gjf files for all conformers in one (compound, folder_type) pair.
    Writes output into: output_base_dir/ngig-{compound_name}-{folder_type}/

    compound_settings is a dict of pre-collected user choices:
        method_key, include_cc, include_fluorine, include_nitrogen,
        temperature, include_csulfur, include_chalogen,
        tier
    """
    method_key        = compound_settings['method_key']
    include_cc        = compound_settings['include_cc']
    include_fluorine  = compound_settings['include_fluorine']
    include_nitrogen  = compound_settings['include_nitrogen']
    temperature       = compound_settings['temperature']
    include_csulfur   = compound_settings['include_csulfur']
    include_chalogen  = compound_settings['include_chalogen']
    tier              = compound_settings['tier']

    # Write GJF files directly into the base directory
    out_dir = output_base_dir

    # Scratch-file lines come from the selected machine profile when one was supplied, falling back to files
    # written beside the job. The profile's {compound} and {conformer} placeholders are translated to the
    # {compound_name} and {conformer_number} names the writer formats with, so the configuration file can use
    # the shorter, more obvious spellings.
    def machine_line(template, default_template):
        text = compound_settings.get(template) if isinstance(compound_settings, dict) else None
        if not text:
            return default_template
        return (text.replace('{compound}', compound_name)
                    .replace('{conformer}', '{conformer_number}'))

    settings = {
        "nprocshared": tier['nprocshared'],
        "mem":         tier['mem'],
        "chk":         machine_line('machine_chk', f"%chk={compound_name}_{{conformer_number}}.chk"),
        "rwf":         machine_line('machine_rwf', f"%rwf={compound_name}_{{conformer_number}}.rwf"),
    }

    temp_keyword = (
        f" temperature={temperature}"
        if (temperature and (include_csulfur or include_chalogen))
        else ""
    )

    generated_gjf_paths = []

    for conformer_number, sdf_file in conformer_files:
        coordinates, connectivity, per_atom_charges, heavy_atoms = ngig_parse_sdf(
            sdf_file, verbose=False
        )
        all_elements  = {line.split()[0] for line in coordinates}
        contains_iodine = "I" in all_elements

        method_params = get_method_parameters(
            method_key, include_cc, include_fluorine, include_nitrogen,
            temperature, contains_iodine=contains_iodine,
        )
        method_params = apply_optimization_guarantees(method_params, temperature)

        # Standard GJF
        standard_input = generate_gaussian_input(
            compound_name, conformer_number, coordinates, connectivity,
            per_atom_charges, settings, method_params,
            include_cc, include_fluorine, include_nitrogen,
            multiplicity=1, method_key=method_key,
            all_elements=all_elements, contains_iodine=contains_iodine
        )
        gjf_path = os.path.join(out_dir, f"{compound_name}_{conformer_number}.gjf")
        with open(gjf_path, 'w', encoding='utf-8') as f:
            f.write(standard_input)
        print(f"  Generated {compound_name}_{conformer_number}.gjf")
        generated_gjf_paths.append(gjf_path)

        # csulfur GJF
        if include_csulfur:
            solvent = {'1': 'chloroform', '5': 'water'}.get(method_key)
            scrf_block = f" scrf=(iefpcm,solvent={solvent})" if solvent else ""
            sulfur_method_params = {
                'opt':              f"# opt freq=noraman{temp_keyword} b3lyp/{'gen' if contains_iodine else CSULFUR_BASIS['opt']} geom=connectivity pop=nboread",
                'carbon':           f"# nmr=giao blyp/{'gen' if contains_iodine else CSULFUR_BASIS['carbon']} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999){scrf_block} geom=check guess=read",
                # Its own sulfur constants. This previously inherited the parent method's carbon factors,
                # which describe a different calculation entirely.
                'carbon_slope':     resolve_scaling_factors(method_key, 'csulfur')[0],
                'carbon_intercept': resolve_scaling_factors(method_key, 'csulfur')[1],
            }
            sulfur_settings = settings.copy()
            sulfur_settings["chk"] = settings["chk"].replace(f"{compound_name}_", f"{compound_name}-csulfur_")
            sulfur_settings["rwf"] = settings["rwf"].replace(f"{compound_name}_", f"{compound_name}-csulfur_")
            sulfur_input = generate_gaussian_input(
                f"{compound_name}-csulfur", conformer_number, coordinates,
                connectivity, per_atom_charges, sulfur_settings,
                sulfur_method_params, include_cc, include_fluorine,
                include_nitrogen, multiplicity=1, method_key=method_key,
                all_elements=all_elements, contains_iodine=contains_iodine
            )
            cs_path = os.path.join(out_dir, f"{compound_name}-csulfur_{conformer_number}.gjf")
            with open(cs_path, 'w', encoding='utf-8') as f:
                f.write(sulfur_input)
            print(f"  Generated {compound_name}-csulfur_{conformer_number}.gjf")
            generated_gjf_paths.append(cs_path)

        # chalogen GJF
        if include_chalogen:
            halogen_method_params = {
                'opt':              f"# opt freq=noraman{temp_keyword} b3lyp/{'gen' if contains_iodine else CHALOGEN_BASIS['opt']} geom=connectivity pop=nboread",
                'carbon':           f"# nmr=giao b3lyp/{'gen' if contains_iodine else CHALOGEN_BASIS['carbon']} geom=check guess=read",
                # Halogen factors are per atom, not one pair, so they are serialized into the title from the
                # structure rather than carried as a single slope and intercept
                '_coordinate_lines': coordinates,
            }
            halogen_settings = settings.copy()
            halogen_settings["chk"] = settings["chk"].replace(f"{compound_name}_", f"{compound_name}-chalogen_")
            halogen_settings["rwf"] = settings["rwf"].replace(f"{compound_name}_", f"{compound_name}-chalogen_")
            halogen_input = generate_gaussian_input(
                f"{compound_name}-chalogen", conformer_number, coordinates,
                connectivity, per_atom_charges, halogen_settings,
                halogen_method_params, include_cc, include_fluorine,
                include_nitrogen, multiplicity=1, method_key=method_key,
                all_elements=all_elements, contains_iodine=contains_iodine
            )
            ch_path = os.path.join(out_dir, f"{compound_name}-chalogen_{conformer_number}.gjf")
            with open(ch_path, 'w', encoding='utf-8') as f:
                f.write(halogen_input)
            print(f"  Generated {compound_name}-chalogen_{conformer_number}.gjf")
            generated_gjf_paths.append(ch_path)

    return generated_gjf_paths





# ================================================================================================================
# EMBEDDED: NMR analysis (from ngp2, version 3.2.1)
# ================================================================================================================
# Embedded unchanged -- this is the largest body of code, so the other three scripts yielded on
# every name collision. Includes the symmetry-corrected deduplication and frequency gate.


#!/usr/bin/env python3
# NMR Gaussian Parsing Script Generation 2 | Version 3.2.0 | Run this script in the directory where LOG files are located (derived from ngig.py GJF files).


# =============================================================================================================
# START OF CONSTANTS SECTION (used to modify important constants relating to data parsing that are non-dynamic)
# =============================================================================================================

R = 1.9872036e-3  # kcal/(mol*K)
HARTREE_TO_KCAL = 627.509474  # Conversion factor from Hartrees to kcal/mol

# NBO input block appended to optimization jobs. BNDIDX prints the Wiberg bond index matrix in the NAO basis,
# which is the source of true bond orders for the analysis half (see parse_wiberg_bond_index_matrix).
NBO_INPUT_BLOCK = "$NBO BNDIDX $END"

# Every generated .gjf is also copied here, so the set to submit is in one place rather than spread across
# the per-compound directories the generator organises them into.
GJF_OUTPUT_DIR = "gjf_files"

# ==================================================================================================================
# OUTPUT SELECTION
# ==================================================================================================================
# Every output this script produces can be switched off individually. The switches are consulted inside the
# functions that WRITE each output rather than around the code that computes it, which matters: shifts, energies
# and populations feed each other, so skipping a computation to save time would change the numbers in the outputs
# that remain. Suppressing only the write keeps every retained output byte-identical to a full run.
#
# All default to True, so running this file from the command line behaves exactly as it always has; the GUI sets
# them from its checkboxes before invoking main().
NGP_OUTPUT_SWITCHES = {
    'chemical_shifts':   True,   # Unweighted and Boltzmann-weighted proton/carbon/fluorine/nitrogen shifts
    'coupling_constants': True,  # Unweighted and weighted J values
    'conformer_sdf':     True,   # Per-conformer SDF files carrying the optimized geometry
    'distances':         True,   # Unweighted and weighted interatomic distances
    'noe_intensities':   True,   # NOE intensities (r^-6 weighted)
    'noe_multipliers':   True,   # Additive-NOE equivalence multipliers for equivalent-atom groups
    'frequencies':       True,   # Per-conformer vibrational frequency listings
    'pymol_script':      True,   # PyMOL labelling script for the weighted shifts
    'dedup_report':      True,   # Conformer deduplication record
    'wiberg_report':     False,  # Raw Wiberg bond indices beside the order each was classified as
}

NGP_OUTPUT_SWITCHES_BY_COMPOUND = {}
# Per-compound overrides, set by the interface. A compound present here uses its own selection; anything else
# falls back to the shared switches above, so the common case of one selection for everything needs no entries.

NGP_RESTRICT_TO_COMPOUNDS = set()
# When non-empty, only these compounds are analysed. The analysis discovers compounds by listing its working
# directory, which is right for a command-line run over a whole folder but wrong when the interface has been
# given the log files of one compound: everything else sharing that folder would be analysed too.

NGP_ACTIVE_COMPOUND = None
# The compound currently being analysed, set as the run reaches each one so ngp_output_enabled knows which
# selection applies without every writer having to be handed the compound name.


def ngp_output_enabled(key):
    """Whether a given output should be written. Unknown keys default to True so a new output is never silently lost."""
    per_compound = NGP_OUTPUT_SWITCHES_BY_COMPOUND.get(NGP_ACTIVE_COMPOUND)
    if per_compound is not None and key in per_compound:
        return per_compound[key]
    return NGP_OUTPUT_SWITCHES.get(key, True)

IMAGINARY_FREQUENCY_THRESHOLD = -12  # Threshold in cm-1 for significant imaginary frequencies
CARBON_SHIFT_PRECISION = 3  # Number of reported carbon shift decimal places in script output
PROTON_SHIFT_PRECISION = 3  # Number of reported proton shift decimal places in script output
FLUORINE_SHIFT_PRECISION = 3  # Number of reported fluorine shift decimal places in script output
NITROGEN_SHIFT_PRECISION = 3  # Number of reported nitrogen shift decimal places in script output
COUPLING_CONSTANT_PRECISION = 2  # Number of reported coupling constant decimal places in script output; adjust column distances below as needed
DISTANCE_PRECISION = 2  # Number of reported atomic distance decimal places in script output; adjust column distances below as needed
FLUORINE_SCALING = {'slope': -0.924, 'intercept': 207.78}  # Scaling factors for fluorine shifts based on Rzepa, et al., 2022, adjusted for user optimization level of theory
NITROGEN_SCALING = {'slope': -0.9776, 'intercept': 253.23}  # Scaling factors for nitrogen shifts based on Gonnella, et al., 2016, adjusted for NH3 reference
_OPTIMAL_PROCESSORS = None  # Set at runtime by main() to determine optimal number of processors for increased efficiency
_SERIALIZED_BLOCK_MAX_LINES = 500  # Maximum lines to read when capturing a serialized job title block; increase for very large molecules with many special bonds

# Log content cache settings (see LOG CONTENT CACHE subsection); a single LOG file is consulted by up to eight
# parsing steps per run, and on a network drive those repeated reads dominate the runtime
ENABLE_LOG_CONTENT_CACHE = True  # Set to False to read every LOG file from disk on every access, as in versions prior to 3.2.0
LOG_CACHE_MAX_SOURCE_BYTES = 256 * 1024 * 1024  # Approximate source-byte budget before least-recently-used eviction; in-memory footprint runs roughly two to three times this, so lower it on memory-constrained machines

# Conformer deduplication settings (see CONFORMER DEDUPLICATION SECTION for the full rationale and algorithm)
ENABLE_CONFORMER_DEDUPLICATION = True  # Set to False to weight every valid conformer, reproducing the behavior of versions prior to 3.1.0
DEDUP_ENERGY_WINDOW = 0.20  # kcal/mol; maximum Gibbs free energy separation for two conformers to be considered the same minimum
DEDUP_RMSD_THRESHOLD = 0.10  # Angstrom; maximum symmetry-corrected Cartesian RMSD after optimal proper-rotation superposition. Validated against 30 compounds with vibrational frequencies as ground truth: any value in [0.0916, 0.1067] gives identical merges across all of them, so this sits inside a real empty gap in the data. Do NOT loosen it -- 7 of the 30 change their merge counts by 0.20
DEDUP_MAX_DEVIATION_THRESHOLD = 0.15  # Angstrom; largest single-atom displacement after superposition, blocking merges of structures that agree on average but differ sharply in one region
DEDUP_ENABLE_FREQUENCY_GATE = True  # Require vibrational spectra to agree before merging, when frequency data is available for both conformers. Independent of geometry (it comes from the Hessian), so it can contradict the geometric verdict rather than restating it
DEDUP_FREQUENCY_RMSD_THRESHOLD = 2.0  # cm^-1; maximum all-mode RMSD between two conformers' frequency lists. Rarely the binding constraint: averaging over ~110 modes, most of them conformation-independent stretches, dilutes a real single-mode shift by roughly tenfold
DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD = 3.0  # cm^-1; maximum difference in ANY single mode. This is the metric that actually discriminates, because it does not dilute
DEDUP_ENABLE_INERTIA_PREFILTER = True  # Screen pairs on principal moments of inertia (invariant to both orientation and numbering) before the exact comparison. Saves time; verified not to change any verdict
DEDUP_INERTIA_RELATIVE_TOLERANCE = 0.05  # Fractional agreement required of each principal moment to reach the exact comparison. Deliberately loose: this filter exists to save time, not to make decisions
DEDUP_ENABLE_ORBIT_FAST_PATH = True  # Resolve correspondences by orbit decomposition instead of enumerating the whole automorphism group; every result is validated as a true automorphism before use, so this can only be faster, never less correct
DEDUP_ORBIT_MIN_ANCHORS = 3  # Minimum uniquely-labelled atoms needed to bootstrap the fast path's rotation
DEDUP_ORBIT_MAX_ITERATIONS = 25  # Safety valve on the rotate/reassign alternation; it settles within a few rounds in practice
DEDUP_MAX_ORBIT_SEED_TRIALS = 720  # Cap on seed combinations tried when there are too few singleton atoms to anchor directly
DEDUP_MAX_AUTOMORPHISMS = 500000  # Enumeration cap. A truncated group can only OVER-estimate RMSD_sym, so duplicates may be missed, none invented
DEDUP_AUTOMORPHISM_NODE_BUDGET = 10000000  # Backtracking node budget; raised faster than the count cap because a search tree can exhaust it before reaching that cap
DEDUP_MAX_RING_SIZE = 10  # Largest ring perceived for the ring-membership graph invariant
DEDUP_DEFAULT_MASS = 12.011
DEDUP_ATOMIC_MASSES = {'H': 1.008, 'B': 10.81, 'C': 12.011, 'N': 14.007, 'O': 15.999, 'F': 18.998, 'Na': 22.990,
                       'Mg': 24.305, 'Al': 26.982, 'Si': 28.085, 'P': 30.974, 'S': 32.06, 'Cl': 35.45,
                       'K': 39.098, 'Ca': 40.078, 'Fe': 55.845, 'Zn': 65.38, 'Se': 78.971, 'Br': 79.904, 'I': 126.904}

# Solvent scaling factors; input more scaling factors in this format for methods other than those listed
scaling_factors = {
    '1': {  # DELTA50: Chloroform; Cohen, et al., 2023
        'carbon': {'slope': -1.0065, 'intercept': 196.0386},
        'proton': {'slope': -1.0311, 'intercept': 32.2654}
    },
    '2': {  # DELTA50: DMSO; Cohen, et al., TBD
        'carbon': {'slope': -1.0099, 'intercept': 195.6824},
        'proton': {'slope': -1.0080, 'intercept': 32.0998}
    },
    '3': {  # Pierens: Methanol; Pierens, 2014
        'carbon': {'slope': -1.0399, 'intercept': 186.5993},
        'proton': {'slope': -1.0305, 'intercept': 31.9062}
    },
    '4': {  # DELTA50: Acetonitrile; Cohen, et al., TBD, pending full set completion
        'carbon': {'slope': -1.01028, 'intercept': 196.87159},
        'proton': {'slope': -1.02685, 'intercept': 32.17998}
    },
    '5': {  # Pierens: Water; Pierens, 2014
        'carbon': {'slope': -0.9736, 'intercept': 184.0777},
        'proton': {'slope': -1.0237, 'intercept': 31.9153}
    }
}

# Scaling factors for carbons attached to halogens when chalogen calculation LOG files are present
# Note: 'chalogen' is the internal job-type identifier used in file naming, not a typo of 'chalcogen'
HALOGEN_SCALING = {
    'Cl': {
        1: {'slope': -1.07, 'intercept': 207.3},
        2: {'slope': -1.03, 'intercept': 192.0},
        3: {'slope': -0.986, 'intercept': 175.9},
    },
    'Br': {
        1: {'slope': -1.07, 'intercept': 200.4},
        2: {'slope': -1.03, 'intercept': 167.3},
        3: {'slope': -0.986, 'intercept': 117.0},
    },
    'I': {
        1: {'slope': -1.02, 'intercept': 177.1},
        2: {'slope': -1.03, 'intercept': 124.0},
        3: {'slope': -0.986, 'intercept': 0.0},
    }
}

# Scaling factors for carbons attached to sulfur when csulfur calculation LOG files are present
SULFUR_SCALING_BY_METHOD = {
    '1': {'slope': -0.9124, 'intercept': 193.6390},  # Chloroform
    '2': {'slope': -0.9017, 'intercept': 192.7573},  # DMSO
    '3': {'slope': -0.8936, 'intercept': 193.0615},  # Methanol
    '4': {'slope': -0.8986, 'intercept': 193.3525},  # Acetonitrile
    '5': {'slope': -0.9073, 'intercept': 194.2800},  # Water
    '6': {'slope': -0.9027, 'intercept': 193.4181},  # Average fallback
}

# Define at module level
_SHIFT_PRECISION_MAP = {
    'C': CARBON_SHIFT_PRECISION,
    'H': PROTON_SHIFT_PRECISION,
    'F': FLUORINE_SHIFT_PRECISION,
    'N': NITROGEN_SHIFT_PRECISION
}


# ========================
# END OF CONSTANTS SECTION
# ========================

# =====================================
# START OF GLOBAL RUNTIME STATE SECTION
# =====================================

excluded_conformers = set()  # Accumulates across both process_files and process_frequencies calls within a compound  -- this is intentional, suppressing duplicate exclusion warnings for the same file; cleared between compounds in main(). Only mutated in the main process  -- worker processes receive a forked copy and do not write back to this set.

# Caches referenced by functions throughout the script
_RING_CACHE = {}      # Cache for ring detection results
_PATTERN_CACHE = {}   # Cache for compiled conformer filename regex patterns

_DEDUP_REMOVED_CONFORMERS = {}  # compound_name -> set of conformer numbers pruned as duplicate minima by process_files; read by process_special_calculations so the csulfur/chalogen ensembles match the main ensemble. Only mutated in the main process; cleared per compound in main().

# ===================================
# END OF GLOBAL RUNTIME STATE SECTION
# ===================================

# ====================================================================================================================
# START OF CHEMICAL EQUIVALENCE SECTION (modify this to change definitions relating to chemical equivalence detection)
# ====================================================================================================================


























def apply_equivalence_averaging_to_shifts(shifts, equivalent_groups):
    """
    Average chemical shifts for all chemically equivalent atoms.
    """
    averaged_shifts = shifts.copy()
    
    for group_id, group_info in equivalent_groups.items():
        atoms = group_info['atoms']
        
        # Calculate average shift for this equivalence group (single pass)
        total = 0.0
        count = 0
        valid_atoms = []
        
        for atom in atoms:
            if atom in shifts:
                total += shifts[atom]
                count += 1
                valid_atoms.append(atom)
        
        if count > 1:
            avg_shift = total / count
            # Apply average to all atoms in the group
            for atom in valid_atoms:
                averaged_shifts[atom] = avg_shift
    
    return averaged_shifts

def _to_numeric_key(g):
    """Convert group ID (int or 'single_N' string) to int for consistent sorting."""
    if isinstance(g, int):
        return g
    if isinstance(g, str) and g.startswith('single_'):
        return int(g.replace('single_', ''))
    # Unexpected key type  -- fall back to 0 rather than raising inside a sort key, which would crash the worker process with a confusing traceback. Print a warning so the bug is still visible
    print(f"Warning: unexpected group key type in _to_numeric_key: {g!r}  -- this indicates a bug in equivalence group construction. Falling back to sort key 0; coupling constant ordering may be incorrect.")
    return 0

def _resolve_group_atoms(key, group_to_atoms):
    """Resolve a group key (int or 'single_N' string) to a list of atom numbers."""
    if isinstance(key, str) and key.startswith('single_'):
        return [int(key.replace('single_', ''))]
    return group_to_atoms.get(key, [])

def apply_equivalence_averaging_to_coupling_constants(coupling_constants, equivalent_groups):
    """
    Average coupling constants for chemically equivalent atoms.
    For each pair of equivalence groups, calculate the average coupling constant
    and assign it to ALL atom pairs between those groups.
    """
    if not coupling_constants:
        return defaultdict(dict)
    
    # Create atom-to-group mapping
    atom_to_group = {}
    group_to_atoms = defaultdict(list)
    
    for group_id, group_info in equivalent_groups.items():
        for atom in group_info['atoms']:
            atom_to_group[atom] = group_id
            group_to_atoms[group_id].append(atom)
    
    # Collect all coupling constants by equivalence group pairs
    group_pair_couplings = defaultdict(list)
    
    seen_atom_pairs = set()
    for atom1 in coupling_constants:
        group1 = atom_to_group.get(atom1, f"single_{atom1}")
        
        for atom2, value in coupling_constants[atom1].items():
            # Deduplicate by canonical atom pair  -- coupling_constants stores both
            # (atom1 -> atom2) and (atom2 ->atom1) symmetrically; only collect one direction
            canonical_atom_pair = (min(atom1, atom2), max(atom1, atom2))
            if canonical_atom_pair in seen_atom_pairs:
                continue
            seen_atom_pairs.add(canonical_atom_pair)

            group2 = atom_to_group.get(atom2, f"single_{atom2}")
            pair_key = tuple(sorted([group1, group2], key=_to_numeric_key))
            group_pair_couplings[pair_key].append(value)
    
    # Average coupling constants for each group pair
    averaged_couplings = defaultdict(dict)
    
    for pair_key, values in group_pair_couplings.items():
        avg_value = sum(values) / len(values)
        
        atoms1 = _resolve_group_atoms(pair_key[0], group_to_atoms)
        atoms2 = _resolve_group_atoms(pair_key[1], group_to_atoms)
        
        for atom1 in atoms1:
            for atom2 in atoms2:
                if atom1 != atom2:
                    averaged_couplings[atom1][atom2] = avg_value
                    averaged_couplings[atom2][atom1] = avg_value

    return averaged_couplings

# ===================================
# END OF CHEMICAL EQUIVALENCE SECTION
# ===================================

# =====================================
# START OF PARSING OPTIMIZATION SECTION
# =====================================

# ----------------------------------------------------------------------------------------------------------
# LOG CONTENT CACHE
# ----------------------------------------------------------------------------------------------------------
# A single conformer LOG file is opened by connectivity extraction, the serialized block reader, element symbol
# extraction, standard orientation extraction, conformer validation, method key detection and frequency parsing.
# Each of those steps previously read the whole file from disk. Every one of them now goes through the accessors
# below, so a file is read once per process and served from memory afterwards.
#
# Two deliberate restrictions keep the cache from becoming a liability:
#   - It is active only in the main process. Pool workers each touch a given file once, so caching there would
#     add memory pressure across every worker without saving a single read.
#   - It is bounded by LOG_CACHE_MAX_SOURCE_BYTES and evicts least recently used entries, so a large ensemble of
#     large LOG files degrades to the previous read-from-disk behavior instead of exhausting memory.
# main() clears the cache between compounds; LOG files are not expected to change while the script is running.

_LOG_CONTENT_CACHE = OrderedDict()  # file path -> {'text': str, 'lines': list or None}, ordered least to most recently used
_LOG_CACHE_SOURCE_BYTES = 0         # Running total of cached text length, compared against LOG_CACHE_MAX_SOURCE_BYTES

def _log_cache_active():
    """Caching applies only in the main process; see the restrictions noted above."""
    return ENABLE_LOG_CONTENT_CACHE and current_process().name == 'MainProcess'

def _get_cached_log_entry(file_path):
    """
    Return the cache entry for a log file, reading it from disk on a miss.

    Returns None when caching is inactive, which tells the accessors below to fall back to a direct read.
    """
    global _LOG_CACHE_SOURCE_BYTES

    if not _log_cache_active():
        return None

    entry = _LOG_CONTENT_CACHE.get(file_path)
    if entry is not None:
        _LOG_CONTENT_CACHE.move_to_end(file_path)  # Mark as most recently used
        return entry

    with open(file_path, 'r') as f:
        text = f.read()

    entry = {'text': text, 'lines': None}
    _LOG_CONTENT_CACHE[file_path] = entry
    _LOG_CACHE_SOURCE_BYTES += len(text)

    # Evict least recently used entries until the budget is met, always keeping the entry just requested
    while _LOG_CACHE_SOURCE_BYTES > LOG_CACHE_MAX_SOURCE_BYTES and len(_LOG_CONTENT_CACHE) > 1:
        _, evicted_entry = _LOG_CONTENT_CACHE.popitem(last=False)
        _LOG_CACHE_SOURCE_BYTES -= len(evicted_entry['text'])

    return entry

def read_log_text(file_path):
    """Return the full text of a log file, served from the cache when one is active."""
    entry = _get_cached_log_entry(file_path)
    if entry is not None:
        return entry['text']

    with open(file_path, 'r') as f:
        return f.read()

def read_log_lines(file_path):
    """
    Return the lines of a log file exactly as file.readlines() would, served from the cache when one is active.

    StringIO is used rather than str.splitlines() because splitlines() also breaks on form feeds and other
    Unicode line boundaries that Gaussian emits inside a line; that would shift the fixed line offsets the
    standard orientation and Initial Parameters parsers rely on.

    The returned list is the cached object itself  -- callers must treat it as read only.
    """
    entry = _get_cached_log_entry(file_path)
    if entry is None:
        with open(file_path, 'r') as f:
            return f.readlines()

    if entry['lines'] is None:
        entry['lines'] = StringIO(entry['text']).readlines()
    return entry['lines']

def read_log_text_and_lines(file_path):
    """
    Return (text, lines) for a log file with a single disk read, whether or not the cache is active.

    Callers that need both views must use this rather than calling read_log_text and read_log_lines in turn:
    inside a pool worker, where caching does not apply, those two calls would read the file twice.
    """
    entry = _get_cached_log_entry(file_path)
    if entry is None:
        with open(file_path, 'r') as f:
            text = f.read()
        return text, StringIO(text).readlines()

    if entry['lines'] is None:
        entry['lines'] = StringIO(entry['text']).readlines()
    return entry['text'], entry['lines']

def clear_log_content_cache():
    """Drop all cached log content; called between compounds so memory does not accumulate across a run."""
    global _LOG_CACHE_SOURCE_BYTES
    _LOG_CONTENT_CACHE.clear()
    _LOG_CACHE_SOURCE_BYTES = 0

# Cache for frequency data to store all information that needs to be read only once
_frequency_cache = {}

# Pre-compiled frequency regex patterns for performance
_FREQ_PATTERNS = {
    'frequencies': re.compile(r'Frequencies\s+--\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)'),
    'red_masses': re.compile(r'Red\. masses\s+--\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)'),
    'frc_consts': re.compile(r'Frc consts\s+--\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)'),
    'ir_inten': re.compile(r'IR Inten\s+--\s+([\d\.\-]+)\s+([\d\.\-]+)\s+([\d\.\-]+)')
}

# Compilation patterns - compile all NMR extraction patterns once
_NMR_PATTERNS = {
    'isotropic_h': re.compile(r'\s+(\d+)\s+H\s+Isotropic\s+=\s+([\d\.\-]+)'),
    'isotropic_c': re.compile(r'\s+(\d+)\s+C\s+Isotropic\s+=\s+([\d\.\-]+)'),
    'isotropic_f': re.compile(r'\s+(\d+)\s+F\s+Isotropic\s+=\s+([\d\.\-]+)'),
    'isotropic_n': re.compile(r'\s+(\d+)\s+N\s+Isotropic\s+=\s+([\d\.\-]+)'),
}

# Pre-compiled patterns for file parsing
_FILE_PATTERNS = {
    'distance': re.compile(r'(\d+) - (\d+): ([\d\.\-]+)'),
    'noe': re.compile(r'(\d+) - (\d+): ([\d\.\-e\+]+)'),
    'sdf_atom': re.compile(r'M\s+V30\s+(\d+)\s+([A-Z][a-z]?)\s+([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)'),
    'energy': re.compile(r'Sum of electronic and thermal Free Energies=\s*([-\d.]+)')
}

# Performance settings
AUTO_DETECT_PROCESSORS = True       # Automatically detect optimal processor count
NUM_PROCESSORS_FALLBACK = 4         # Fallback if detection fails
RUNNING_UNDER_GUI = False
# Set to True once the window exists; it disables every worker pool below.
#
# Windows has no fork, so multiprocessing starts a child by RE-LAUNCHING the interpreter on this file. Run from
# a .pyw that means pythonw.exe opens the script again, and a second application window appears for every pool
# created. Inside that child, Tk variables exist with no mainloop behind them, so the first trace callback to
# fire raises "main thread is not in main loop". Both symptoms have this single cause.
#
# The parallel paths remain for command-line use, where they are safe and worth having. From the interface the
# analysis runs sequentially, which at these conformer counts costs seconds.

ENABLE_PARALLEL_PROCESSING = True   # Set to False to disable parallelization for debugging

# Performance optimization functions for multiprocessing
def detect_optimal_processors():
    """
    Automatically detect the number of available processors for the system.
    Returns optimal number of cores to use.
    """
    try:
        total_cores = cpu_count()
        
        # Try to get more detailed system info
        try:
            import psutil
            physical_cores = psutil.cpu_count(logical=False)
            memory_gb = psutil.virtual_memory().total / (1024**3)
            
            print(f"System Detection:")
            print(f"  Physical CPU cores: {physical_cores}")
            print(f"  Logical CPU cores: {total_cores}")
            print(f"  Total memory: {memory_gb:.1f} GB")
            
        except ImportError:
            physical_cores = total_cores
            memory_gb = 8
            
            print(f"System Detection (basic):")
            print(f"  Total CPU cores: {total_cores}")
        
        # Check for HPC scheduler environment (if script is submitted as a job; likely does not apply for standard intended use, but just in case someone repurposes the script elsewhere)
        hpc_cores = None
        hpc_env_vars = {
            'SLURM_CPUS_PER_TASK': 'SLURM',
            'SLURM_NTASKS': 'SLURM', 
            'PBS_NCPUS': 'PBS',
            'NCPUS': 'PBS',
            'PBS_NP': 'PBS',
            'LSB_DJOB_NUMPROC': 'LSF',
            'NSLOTS': 'SGE'
        }
        
        for var, scheduler in hpc_env_vars.items():
            if var in os.environ:
                hpc_cores = int(os.environ[var])
                print(f"  {scheduler} scheduler detected: {hpc_cores} cores allocated via {var}")
                break
        
        # Determine optimal cores based on system size
        if hpc_cores:
            # Use HPC allocation directly
            optimal_cores = hpc_cores
        elif total_cores >= 16:
            optimal_cores = min(total_cores - 2, int(total_cores * 0.8))
        elif total_cores >= 8:
            optimal_cores = min(total_cores - 1, int(total_cores * 0.75))
        else:
            optimal_cores = max(1, total_cores - 1)
        
        optimal_cores = max(1, min(optimal_cores, 128))  # Cap at 128 for safety
        
        print(f"  Optimal cores selected: {optimal_cores}")
        return optimal_cores
        
    except Exception as e:
        print(f"  Warning: Could not detect system specs ({e})")
        print(f"  Using fallback: {NUM_PROCESSORS_FALLBACK} cores")
        return NUM_PROCESSORS_FALLBACK

def format_time(seconds):
    """
    Format time for script completion reporting.
    """
    if seconds < 60:
        return f"{seconds:.1f} seconds"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        remaining_seconds = seconds % 60
        return f"{minutes}m {remaining_seconds:.1f}s"
    else:
        hours = int(seconds // 3600)
        remaining_minutes = int((seconds % 3600) // 60)
        remaining_seconds = seconds % 60
        return f"{hours}h {remaining_minutes}m {remaining_seconds:.1f}s"

def extract_all_conformer_data_single_pass(log_file, compound_name, conformer_num, method_key):
    """
    Read the log file once and extract all NMR data in a single pass to avoid extra file reads.
    """
    data = {
        'energy': None,
        'coordinates': None,
        'proton_shieldings': {},
        'carbon_shieldings': {},
        'fluorine_shieldings': {},
        'nitrogen_shieldings': {},
        'coupling_constants': defaultdict(dict)
    }
    
    # Section markers
    # Sections are located by job type alone. The type label says which atoms a section describes, which is
    # all the analysis needs; the method number it used to carry pointed at a scaling table the titles now
    # carry directly.
    proton_section = f"{compound_name}_{conformer_num}_proton"
    carbon_section = f"{compound_name}_{conformer_num}_carbon"
    fluorine_section = f"{compound_name}_{conformer_num}_fluorine"
    nitrogen_section = f"{compound_name}_{conformer_num}_nitrogen"
    
    current_section = None
    in_coupling_section = False
    coupling_section_closed = False
    coupling_primary_atoms = []

    # Read file once into memory (served from the log content cache when running in the main process)
    content, lines = read_log_text_and_lines(log_file)

    # Extract energy with regex (faster than line-by-line)
    energy_match = _FILE_PATTERNS['energy'].search(content)
    if energy_match:
        data['energy'] = float(energy_match.group(1))

    # Capture the final optimized geometry from the copy of the file already in memory for conformer deduplication
    # This costs no additional file read; a failure here is non-fatal because only deduplication consumes the geometry,
    # and process_files reports any conformer whose geometry could not be recovered
    try:
        data['coordinates'] = parse_standard_orientation_from_lines(lines, log_file)
    except (ValueError, IndexError):
        data['coordinates'] = None

    # Process line by line only for NMR data (already have lines)
    for line in lines:
        # Detect NMR sections
        if proton_section in line:
            current_section = 'proton'
            in_coupling_section = False
            continue
        elif carbon_section in line:
            current_section = 'carbon'
            in_coupling_section = False
            continue
        elif fluorine_section in line:
            current_section = 'fluorine'
            in_coupling_section = False
            continue
        elif nitrogen_section in line:
            current_section = 'nitrogen'
            in_coupling_section = False
            continue
        elif "Total nuclear spin-spin coupling J (Hz):" in line:
            in_coupling_section = True
            coupling_section_closed = False
            current_section = None
            coupling_primary_atoms = []
            data['coupling_constants'] = defaultdict(dict)  # Reset on each new coupling section  -- intentionally keeps only the last section; assumes at most one valid coupling section per file (the last one), which handles restarted jobs where an earlier incomplete section may be present
            continue
        elif "End of Minotr F.D. properties file" in line:
            current_section = None
            if in_coupling_section:
                coupling_section_closed = True
            in_coupling_section = False
            continue

        # Extract isotropic shieldings
        if current_section:
            if current_section == 'proton':
                match = _NMR_PATTERNS['isotropic_h'].search(line)
                if match:
                    data['proton_shieldings'][int(match.group(1))] = float(match.group(2))
            elif current_section == 'carbon':
                match = _NMR_PATTERNS['isotropic_c'].search(line)
                if match:
                    data['carbon_shieldings'][int(match.group(1))] = float(match.group(2))
            elif current_section == 'fluorine':
                match = _NMR_PATTERNS['isotropic_f'].search(line)
                if match:
                    data['fluorine_shieldings'][int(match.group(1))] = float(match.group(2))
            elif current_section == 'nitrogen':
                match = _NMR_PATTERNS['isotropic_n'].search(line)
                if match:
                    data['nitrogen_shieldings'][int(match.group(1))] = float(match.group(2))
        
        # Extract coupling constants
        if in_coupling_section:
            stripped = line.strip()
            if not stripped:
                continue
            
            # Split line into parts
            parts = stripped.split()
            if not parts:
                continue
            
            # Try to determine if this is a header line or data line
            # Header line: all parts are integers (atom numbers only)
            # Data line: first part is integer, rest contain 'D' (scientific notation)
            
            try:
                # Check for D-notation first (data lines contain scientific notation)
                # Header lines contain only integer atom numbers
                has_d_notation = any('D' in part for part in parts[1:])
                all_integers = all(part.lstrip('-').isdigit() for part in parts)

                if not has_d_notation and all_integers:
                    # This is a header line
                    coupling_primary_atoms = [int(x) for x in parts]
                else:
                    # This should be a data line
                    # First part should be an integer (secondary atom)
                    if not parts[0].lstrip('-').isdigit():
                        continue
                    
                    secondary_atom = int(parts[0])
                    
                    # Rest should contain 'D' notation
                    values = []
                    for part in parts[1:]:
                        if 'D' in part:
                            values.append(float(part.replace('D', 'E')))
                    
                    if values and coupling_primary_atoms:
                        # Assign values to the corresponding primary atoms
                        for i, value in enumerate(values):
                            if i < len(coupling_primary_atoms):
                                primary_atom = coupling_primary_atoms[i]
                                # Only store if atoms are different and value is reasonable
                                if primary_atom != secondary_atom and abs(value) < 1e10:
                                    data['coupling_constants'][primary_atom][secondary_atom] = round(value, 2)
            except (ValueError, IndexError):
                # Skip lines that don't match expected format
                pass
    
    if in_coupling_section and not coupling_section_closed:
        print(f"Warning: coupling constant section in {log_file} was not properly closed  -- file may be truncated. Coupling data may be incomplete.")
    
    return data

def process_single_conformer_worker(args):
    """
    Worker function using single-pass file reading.
    """
    (compound_name, conformer_num, method_key, custom_scaling, 
     structure_data) = args
    
    log_file = f"{compound_name}_{conformer_num}.log"
    
    try:
        # Extract ALL data in a single pass through the file
        data = extract_all_conformer_data_single_pass(log_file, compound_name, conformer_num, method_key)

        # Resolve scaling factors once to avoid repeated inline ternaries
        if custom_scaling:
            c_slope = custom_scaling['carbon']['slope']
            c_intercept = custom_scaling['carbon']['intercept']
            p_slope = custom_scaling['proton']['slope']
            p_intercept = custom_scaling['proton']['intercept']
        else:
            # Reached only for a log whose titles carry no scaling factors, i.e. one written before they
            # travelled there. Guessing constants would silently mis-scale every shift -- a water calculation
            # scaled as chloroform looks entirely plausible and is wrong -- so an unknown method stops here.
            table = scaling_factors.get(method_key)
            if not table:
                raise ValueError(
                    f"No scaling factors available for this compound: its job titles carry none and the "
                    f"method could not be identified from the log (method key {method_key!r}). Re-run the "
                    f"job setup so the factors are recorded in the titles.")
            c_slope = table['carbon']['slope']
            c_intercept = table['carbon']['intercept']
            p_slope = table['proton']['slope']
            p_intercept = table['proton']['intercept']

        # Process proton shifts
        proton_shieldings = data['proton_shieldings']
        proton_shifts = convert_to_chemical_shift(
            proton_shieldings,
            p_slope,
            p_intercept
        )

        # Apply equivalence averaging
        proton_shifts = apply_equivalence_averaging_to_shifts(
            proton_shifts,
            structure_data['equivalent_groups']
        )

        # Process carbon shifts
        carbon_shifts = convert_to_chemical_shift(
            data['carbon_shieldings'],
            c_slope,
            c_intercept
        )

        # Apply equivalence averaging
        carbon_shifts = apply_equivalence_averaging_to_shifts(
            carbon_shifts,
            structure_data['equivalent_groups']
        )

        # Process fluorine shifts
        # Fluorine and nitrogen always use their fixed module-level scaling constants regardless of method_key
        # These are element-specific (not solvent-specific) and have no method-6 custom equivalent
        fluorine_shifts = {}
        if data['fluorine_shieldings']:
            fluorine_shieldings = data['fluorine_shieldings']
            fluorine_shifts = convert_to_chemical_shift(
                fluorine_shieldings, 
                FLUORINE_SCALING['slope'], 
                FLUORINE_SCALING['intercept']
            )
            
            # Apply equivalence averaging
            fluorine_shifts = apply_equivalence_averaging_to_shifts(
                fluorine_shifts,
                structure_data['equivalent_groups']
            )

        # Process nitrogen shifts
        nitrogen_shifts = {}
        if data['nitrogen_shieldings']:
            nitrogen_shifts = convert_to_chemical_shift(
                data['nitrogen_shieldings'], 
                NITROGEN_SCALING['slope'], 
                NITROGEN_SCALING['intercept']
            )
            
            # Apply equivalence averaging
            nitrogen_shifts = apply_equivalence_averaging_to_shifts(
                nitrogen_shifts,
                structure_data['equivalent_groups']
            )

        # Apply equivalence averaging to coupling constants
        coupling_constants_averaged = apply_equivalence_averaging_to_coupling_constants(
            data['coupling_constants'],
            structure_data['equivalent_groups']
        )

        return {
            'conformer_num': conformer_num,
            'energy': data['energy'],
            'coordinates': data['coordinates'],
            'carbon_shifts': carbon_shifts,
            'proton_shifts': proton_shifts,
            'fluorine_shifts': fluorine_shifts,
            'nitrogen_shifts': nitrogen_shifts,
            'coupling_constants': coupling_constants_averaged,
            'success': True
        }

    except Exception as e:
        import traceback
        return {
            'conformer_num': conformer_num,
            'success': False,
            'error': f"{str(e)}\n{traceback.format_exc()}"
        }

# ===================================
# END OF PARSING OPTIMIZATION SECTION
# ===================================

# ==========================================================================================================
# START OF CONFORMER DEDUPLICATION SECTION (modify this to change how redundant DFT minima are identified)
#
# Geometry optimizations launched from different starting structures routinely converge to the same minimum.
# Every redundant copy that survives to the weighting step contributes an extra Boltzmann factor for a basin
# that should have been counted once, inflating that basin's population at the expense of every other
# conformer and biasing all weighted observables the script produces (shifts, couplings, distances and NOE
# intensities) toward whichever region of conformational space the search happened to oversample.
#
# The gates, their justification and the provenance of every threshold are documented in full at the head of
# the SYMMETRY-CORRECTED CONFORMER DEDUPLICATION section immediately below.

# ==================================================================================================================
# SYMMETRY-CORRECTED CONFORMER DEDUPLICATION
# ==================================================================================================================
# Replaces the interatomic-distance-matrix comparison used in versions 3.1.0 and 3.2.0. The quantity computed is
#
#     RMSD_sym(A, B) = min over P in Aut(G) of  Kabsch_RMSD(A, P . B)
#
# where Aut(G) is the automorphism group of the molecular graph. Searching only the graph-legal relabelings makes
# every rotor degeneracy fall out automatically instead of needing a special case: a methyl's three hydrogens form
# one orbit (S3), a tert-butyl's three methyls swap and each methyl's hydrogens swap, a phenyl ring flip exchanges
# ortho and meta positions together. Those are exactly the cases a fixed-numbering comparison fails on -- a 120
# degree methyl rotation is the same physical minimum, but atom-for-atom it looks like a completely different
# geometry and lands outside any sensible RMSD window.
#
# Two properties differ from the previous scheme and are deliberate:
#
#   ENANTIOMERS ARE NEVER MATCHED. The superposition is a proper rotation only, implemented with Horn's quaternion
#   method, which parametrizes rotations by unit quaternions and therefore cannot produce a reflection at all. A
#   distance matrix is reflection-invariant and cannot make this distinction even in principle. Mirror-image
#   conformer pairs (which only arise for achiral molecules, since reflecting a structure inverts every
#   stereocenter) are therefore retained as distinct. That is correct: they are exactly isoenergetic, carry equal
#   Boltzmann weights, and their equal-and-opposite rotational strengths are what make an achiral compound's VCD
#   and ECD spectra cancel to a flat line. Merging them would break that cancellation. For NMR they contribute
#   identically either way, so retaining them costs nothing.
#
#   THE AUTOMORPHISM SEARCH USES NO GEOMETRY. Orbits come from element, formal charge, degree, ring membership and
#   iterated neighbour-label refinement -- all pure graph invariants. Letting 3D distances into the orbit finding
#   would re-split a methyl's hydrogens into distinct classes and reintroduce the exact degeneracy the group
#   exists to resolve. Geometry enters only in the superposition step.
#
# THRESHOLD PROVENANCE. The criteria below were validated against 30 natural product and drug molecules (~6,200
# candidate conformer pairs) using vibrational frequencies as independent ground truth for whether two structures
# occupy the same minimum. Findings: any RMSD threshold in [0.0916, 0.1067] Angstrom produces identical merges
# across all 30 compounds, so 0.10 sits inside a real empty gap in the data rather than at an arbitrary point;
# only 4 pairs in ~6,200 were merged despite clearly different spectra; and the energy gate never actually binds
# (median energy gap among merged pairs 0.0025 kcal/mol against a 0.20 window) because energy is a function of
# geometry -- passing the RMSD gate very nearly forces passing the energy gate. The energy window therefore acts
# as a cheap pre-filter and an anomaly guard rather than as a discriminator: a pair with tight geometry but a
# large energy gap indicates a failed SCF, a different spin state or an inconsistent method, and should not be
# merged. Do not loosen DEDUP_RMSD_THRESHOLD; 7 of the 30 compounds change their merge counts by 0.20 Angstrom.

def dedup_build_adjacency(atom_types, connectivity):
    """
    Adjacency as {atom: set(neighbours)} over 1-based atom numbers, from ngp2's simple_connectivity.

    Bond order is never consulted anywhere in this module. Degree already encodes hybridization (a multiply
    bonded carbon has fewer other neighbours), and ignoring order handles every resonance system uniformly
    instead of needing a normalization pass for aromatic rings, carboxylates and nitro groups separately.
    """
    atom_count = len(atom_types)
    adjacency = {atom: set() for atom in range(1, atom_count + 1)}
    for atom, neighbors in (connectivity or {}).items():
        if not (1 <= atom <= atom_count):
            continue
        for neighbor in neighbors:
            if 1 <= neighbor <= atom_count and neighbor != atom:
                adjacency[atom].add(neighbor)
                adjacency[neighbor].add(atom)
    return adjacency

def dedup_ring_membership(adjacency):
    """
    Smallest ring size through each atom, or 0 for acyclic atoms. A genuine graph invariant, so adding it to the
    refinement can only sharpen the partition correctly -- it can never split atoms a real automorphism would
    exchange.
    """
    smallest = {atom: 0 for atom in adjacency}
    for atom1 in adjacency:
        for atom2 in adjacency[atom1]:
            if atom2 <= atom1:
                continue
            previous = {atom1: None}
            queue = deque([atom1])
            while queue:
                current = queue.popleft()
                if current == atom2:
                    break
                for neighbor in adjacency[current]:
                    if current == atom1 and neighbor == atom2:
                        continue
                    if neighbor not in previous:
                        previous[neighbor] = current
                        queue.append(neighbor)
            if atom2 not in previous:
                continue
            path, node = [], atom2
            while node is not None:
                path.append(node)
                node = previous[node]
            if 3 <= len(path) <= DEDUP_MAX_RING_SIZE:
                for member in path:
                    if smallest[member] == 0 or len(path) < smallest[member]:
                        smallest[member] = len(path)
    return smallest

def dedup_invariant_keys(atom_types, adjacency):
    """The geometry-free per-atom invariants seeding the refinement."""
    rings = dedup_ring_membership(adjacency)
    return {atom: (atom_types[atom - 1], len(adjacency[atom]), rings[atom]) for atom in adjacency}

def dedup_refine_labels(adjacency, initial_keys):
    """
    Iterated neighbour-label refinement (Morgan / Weisfeiler-Leman).

    Labels are ranked from sorted signature content each round rather than assigned in encounter order, so they
    depend only on the graph and never on the order atoms happen to be stored in.
    """
    ranks = {key: rank for rank, key in enumerate(sorted(set(initial_keys.values())))}
    labels = {atom: ranks[initial_keys[atom]] for atom in adjacency}
    while True:
        signatures = {atom: (labels[atom], tuple(sorted(labels[neighbor] for neighbor in adjacency[atom])))
                      for atom in adjacency}
        ranks = {signature: rank for rank, signature in enumerate(sorted(set(signatures.values())))}
        updated = {atom: ranks[signatures[atom]] for atom in adjacency}
        if len(set(updated.values())) == len(set(labels.values())):
            return updated
        labels = updated

def dedup_traversal_order(adjacency):
    """Order atoms so each is adjacent to something already placed, which keeps the search's candidate lists short."""
    order, seen = [], set()
    for start in sorted(adjacency):
        if start in seen:
            continue
        seen.add(start)
        order.append(start)
        queue = deque([start])
        while queue:
            current = queue.popleft()
            for neighbor in sorted(adjacency[current]):
                if neighbor not in seen:
                    seen.add(neighbor)
                    order.append(neighbor)
                    queue.append(neighbor)
    return order

def dedup_automorphism_permutations(adjacency, labels, atom_count):
    """
    The automorphism group as zero-based permutation arrays, identity first.

    Refinement labels supply the candidate lists so the search only ever tries atoms no graph invariant can
    distinguish, and edge consistency is checked in both directions so a completed map is a true automorphism.
    Identity leading matters in practice: conformers from one Gaussian batch share their numbering, so the first
    superposition tried for a genuine duplicate is usually the one that succeeds.

    Returns (permutations, truncated). A truncated group can only make RMSD_sym an OVER-estimate, so duplicates
    may be missed but none can be invented.
    """
    by_label = defaultdict(list)
    for atom in sorted(adjacency):
        by_label[labels[atom]].append(atom)

    order = dedup_traversal_order(adjacency)
    mapping, reverse, results = {}, {}, []
    budget = [DEDUP_AUTOMORPHISM_NODE_BUDGET]
    truncated = [False]

    def backtrack(position):
        if position == len(order):
            results.append(dict(mapping))
            if len(results) >= DEDUP_MAX_AUTOMORPHISMS:
                truncated[0] = True
            return
        atom = order[position]
        for candidate in by_label[labels[atom]]:
            if candidate in reverse:
                continue
            budget[0] -= 1
            if budget[0] <= 0:
                truncated[0] = True
                return
            if any(mapping[neighbor] not in adjacency[candidate]
                   for neighbor in adjacency[atom] if neighbor in mapping):
                continue
            if any(reverse[neighbor] not in adjacency[atom]
                   for neighbor in adjacency[candidate] if neighbor in reverse):
                continue
            mapping[atom] = candidate
            reverse[candidate] = atom
            backtrack(position + 1)
            del mapping[atom]
            del reverse[candidate]
            if truncated[0] and len(results) >= DEDUP_MAX_AUTOMORPHISMS:
                return

    backtrack(0)

    identity = tuple(range(atom_count))
    permutations, seen = [], set()
    for found in results:
        permutation = tuple(found[atom] - 1 for atom in range(1, atom_count + 1))
        if permutation not in seen:
            seen.add(permutation)
            permutations.append(permutation)
    if identity in seen:
        permutations.remove(identity)
        permutations.insert(0, identity)
    return permutations, truncated[0]

def dedup_centred_with_norm(coordinates):
    """Centered coordinates plus the sum of their squared norms, computed together since callers need both."""
    points = np.asarray(coordinates, dtype=float)
    points = points - points.mean(axis=0)
    return points, float((points ** 2).sum())

def dedup_superposition_from_centered(a, norm_a, b, norm_b, want_deviations=False):
    """
    Optimal proper-rotation superposition RMSD by Horn's quaternion method, for already-centered coordinates.

    The 4x4 matrix built from the correlation matrix has the optimal rotation quaternion as its largest
    eigenvector and the RMSD follows from the largest eigenvalue directly. Because rotations are parametrized by
    quaternions the result is always a proper rotation: a reflection cannot be produced, so the determinant-sign
    correction an SVD implementation needs is structurally unnecessary here.

    Taking already-centered input lets the caller center each side once and merely reindex per permutation --
    permuting labels does not move the centroid, so the two operations commute.
    """
    count = len(a)
    if count == 0:
        return 0.0, 0.0

    correlation = a.T.dot(b)
    (sxx, sxy, sxz), (syx, syy, syz), (szx, szy, szz) = correlation

    quaternion_matrix = np.array([
        [sxx + syy + szz, syz - szy,        szx - sxz,        sxy - syx],
        [syz - szy,       sxx - syy - szz,  sxy + syx,        szx + sxz],
        [szx - sxz,       sxy + syx,       -sxx + syy - szz,  syz + szy],
        [sxy - syx,       szx + sxz,        syz + szy,       -sxx - syy + szz],
    ], dtype=float)
    eigenvalues, eigenvectors = np.linalg.eigh(quaternion_matrix)
    best_index = int(np.argmax(eigenvalues))
    largest = float(eigenvalues[best_index])

    rmsd = math.sqrt(max(0.0, (norm_a + norm_b - 2.0 * largest)) / count)
    if not want_deviations:
        return rmsd, None

    qw, qx, qy, qz = (float(eigenvectors[0][best_index]), float(eigenvectors[1][best_index]),
                      float(eigenvectors[2][best_index]), float(eigenvectors[3][best_index]))
    length = math.sqrt(qw * qw + qx * qx + qy * qy + qz * qz)
    if length < 1e-12:
        return rmsd, None
    qw, qx, qy, qz = qw / length, qx / length, qy / length, qz / length

    forward = np.array([
        [qw*qw + qx*qx - qy*qy - qz*qz, 2.0*(qx*qy - qw*qz),           2.0*(qx*qz + qw*qy)],
        [2.0*(qx*qy + qw*qz),           qw*qw - qx*qx + qy*qy - qz*qz, 2.0*(qy*qz - qw*qx)],
        [2.0*(qx*qz - qw*qy),           2.0*(qy*qz + qw*qx),           qw*qw - qx*qx - qy*qy + qz*qz],
    ], dtype=float)

    # The quaternion expresses the rotation carrying the reference onto the target, so the TRANSPOSE brings the
    # target back onto the reference. Applying it the other way round leaves the eigenvalue RMSD untouched while
    # producing a wrong displacement -- invisible unless the two are cross-checked, which is what the guard below
    # does.
    rotated = b.dot(forward)
    differences = a - rotated
    squared = (differences ** 2).sum(axis=1)
    maximum = float(np.sqrt(squared).max())
    explicit_rmsd = math.sqrt(float(squared.sum()) / count)
    if abs(explicit_rmsd - rmsd) > max(1e-6, 1e-6 * max(explicit_rmsd, rmsd)):
        raise ArithmeticError(
            f"superposition inconsistency: eigenvalue RMSD {rmsd:.8f} disagrees with the RMSD implied by the "
            f"per-atom displacements {explicit_rmsd:.8f}")
    return rmsd, maximum

def dedup_symmetry_corrected_rmsd(coords_a, coords_b, permutations):
    """
    Minimum superposition RMSD over the automorphism group.

    Both sides are centered once before the loop; each permutation only reindexes already-centered points. The
    loop stops as soon as a permutation clears both thresholds, since one qualifying correspondence settles the
    question, and the identity permutation is tried first so a duplicate written with consistent numbering costs
    a single superposition.
    """
    a, norm_a = dedup_centred_with_norm(coords_a)
    b, norm_b = dedup_centred_with_norm(coords_b)

    best_rmsd, best_index, best_reordered = None, None, None
    for index, permutation in enumerate(permutations):
        reordered = b[list(permutation)]
        rmsd, _ = dedup_superposition_from_centered(a, norm_a, reordered, norm_b)
        if best_rmsd is None or rmsd < best_rmsd:
            best_rmsd, best_index, best_reordered = rmsd, index, reordered
        if rmsd <= DEDUP_RMSD_THRESHOLD:
            exact_rmsd, deviation = dedup_superposition_from_centered(a, norm_a, reordered, norm_b, True)
            if deviation is not None and deviation <= DEDUP_MAX_DEVIATION_THRESHOLD:
                return exact_rmsd, deviation, index, True
    if best_index is None:
        return None, None, None, False
    rmsd, deviation = dedup_superposition_from_centered(a, norm_a, best_reordered, norm_b, True)
    return rmsd, deviation, best_index, False

def dedup_hungarian_assignment(cost_matrix):
    """
    Optimal assignment minimizing total cost, by the Kuhn-Munkres algorithm.

    Every use here is on one automorphism orbit (a methyl's 3 hydrogens, a tert-butyl's 9, a ring's handful of
    swappable positions) rather than the whole molecule, so n is always small and the cubic cost is negligible.
    That is what makes the orbit-decomposition path cheap where enumerating the orbits' combined Cartesian
    product is not.
    """
    n = len(cost_matrix)
    if n == 0:
        return []
    INF = float('inf')
    u = [0.0] * (n + 1)
    v = [0.0] * (n + 1)
    p = [0] * (n + 1)
    way = [0] * (n + 1)
    for i in range(1, n + 1):
        p[0] = i
        j0 = 0
        minv = [INF] * (n + 1)
        used = [False] * (n + 1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], INF, -1
            for j in range(1, n + 1):
                if used[j]:
                    continue
                cur = cost_matrix[i0 - 1][j - 1] - u[i0] - v[j]
                if cur < minv[j]:
                    minv[j] = cur
                    way[j] = j0
                if minv[j] < delta:
                    delta = minv[j]
                    j1 = j
            for j in range(n + 1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minv[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while j0:
            j1 = way[j0]
            p[j0] = p[j1]
            j0 = j1
    assignment = [0] * n
    for j in range(1, n + 1):
        if p[j]:
            assignment[p[j] - 1] = j - 1
    return assignment

def dedup_kabsch_rotation(points_a, points_b):
    """
    The optimal proper rotation carrying points_b onto points_a, by Horn's quaternion method. Needed by the
    orbit-guided path, which applies the rotation directly to find each orbit's nearest correspondence rather
    than only reporting a final RMSD. Returns None when there are too few points to determine a rotation.
    """
    if len(points_a) < 3:
        return None
    a, _ = dedup_centred_with_norm(points_a)
    b, _ = dedup_centred_with_norm(points_b)
    correlation = a.T.dot(b)
    (sxx, sxy, sxz), (syx, syy, syz), (szx, szy, szz) = correlation
    quaternion_matrix = np.array([
        [sxx + syy + szz, syz - szy,        szx - sxz,        sxy - syx],
        [syz - szy,       sxx - syy - szz,  sxy + syx,        szx + sxz],
        [szx - sxz,       sxy + syx,       -sxx + syy - szz,  syz + szy],
        [sxy - syx,       szx + sxz,        syz + szy,       -sxx - syy + szz],
    ], dtype=float)
    eigenvalues, eigenvectors = np.linalg.eigh(quaternion_matrix)
    best_index = int(np.argmax(eigenvalues))
    qw, qx, qy, qz = (float(eigenvectors[0][best_index]), float(eigenvectors[1][best_index]),
                      float(eigenvectors[2][best_index]), float(eigenvectors[3][best_index]))
    length = math.sqrt(qw*qw + qx*qx + qy*qy + qz*qz)
    if length < 1e-12:
        return None
    qw, qx, qy, qz = qw/length, qx/length, qy/length, qz/length
    forward = np.array([
        [qw*qw + qx*qx - qy*qy - qz*qz, 2.0*(qx*qy - qw*qz),           2.0*(qx*qz + qw*qy)],
        [2.0*(qx*qy + qw*qz),           qw*qw - qx*qx + qy*qy - qz*qz, 2.0*(qy*qz - qw*qx)],
        [2.0*(qx*qz - qw*qy),           2.0*(qy*qz + qw*qx),           qw*qw - qx*qx - qy*qy + qz*qz],
    ], dtype=float)
    return forward

def dedup_orbit_guided_correspondence(adjacency, coords_a, coords_b, atoms_by_label):
    """
    Find the correspondence between two conformers directly, without enumerating the automorphism group.

    Several independent rotatable groups multiply their automorphism counts together, so |Aut(G)| reaches the
    hundreds of thousands for unremarkable drug-like molecules, and every element costs one superposition to try.
    This path avoids materializing the group at all for such cases.

    THE IDEA: refinement labels partition atoms into classes -- singletons (forced to map to themselves in any
    automorphism) and larger orbits. For a FIXED rotation the sum-of-squared-displacements objective separates
    exactly along those classes, because each atom's term depends only on which same-class atom it pairs with.
    So the optimal assignment within each class is found by ordinary bipartite matching on that class alone,
    independent of every other class -- no need for the combined Cartesian product that made the full group
    explode. The rotation and the assignment are mutually dependent, resolved by ICP-style alternation: seed a
    rotation from the singletons, assign every other class optimally under it, refit the rotation, repeat. Each
    half is exact given the other, so the total squared displacement can only decrease or hold.

    When there are too few singletons to seed from (a symmetric structure can have none), the smallest available
    classes are used as the seed instead, trying each of their internal permutations in turn and keeping the best
    validated result.

    SAFETY: this only PROPOSES a correspondence. Every candidate is validated as a genuine graph automorphism
    before its RMSD is computed, so a molecule where the heuristic does not apply cleanly simply fails validation
    and the caller falls back to exact enumeration. This path can make a comparison faster, never less correct.
    """
    atom_count = len(coords_a)
    classes_by_size = sorted(atoms_by_label.values(), key=len)
    singleton_atoms = [atoms[0] for atoms in classes_by_size if len(atoms) == 1]

    def run_from_seed(seed_correspondence, remaining_classes):
        correspondence = dict(seed_correspondence)
        previous = None
        for _ in range(DEDUP_ORBIT_MAX_ITERATIONS):
            anchor_a = [coords_a[atom - 1] for atom in correspondence]
            anchor_b = [coords_b[correspondence[atom] - 1] for atom in correspondence]
            rotation = dedup_kabsch_rotation(anchor_a, anchor_b)
            if rotation is None:
                return None
            centre_b = np.asarray(coords_b, dtype=float).mean(axis=0)
            centre_a = np.asarray(coords_a, dtype=float).mean(axis=0)
            updated = dict(seed_correspondence)
            for atoms_in_class in remaining_classes:
                shifted = np.asarray([coords_b[atom - 1] for atom in atoms_in_class], dtype=float) - centre_b
                rotated = shifted.dot(rotation) + centre_a
                cost = [[float(((np.asarray(coords_a[a - 1], dtype=float) - centre_a - (rotated[k] - centre_a)) ** 2).sum())
                        for k in range(len(atoms_in_class))] for a in atoms_in_class]
                assignment = dedup_hungarian_assignment(cost)
                for row, atom_a in enumerate(atoms_in_class):
                    updated[atom_a] = atoms_in_class[assignment[row]]
            if updated == previous:
                correspondence = updated
                break
            previous, correspondence = correspondence, updated
        else:
            return None

        if len(correspondence) != atom_count:
            return None
        permutation = [0] * atom_count
        for atom_a, atom_b in correspondence.items():
            permutation[atom_a - 1] = atom_b - 1
        for atom_a in range(1, atom_count + 1):
            image = permutation[atom_a - 1] + 1
            if {permutation[n - 1] + 1 for n in adjacency[atom_a]} != adjacency[image]:
                return None
        return tuple(permutation)

    def best_of(candidates):
        candidates = [c for c in candidates if c is not None]
        if not candidates:
            return None
        a, norm_a = dedup_centred_with_norm(coords_a)
        b_all = np.asarray(coords_b, dtype=float)
        best_permutation, best_rmsd = None, None
        for permutation in candidates:
            b, norm_b = dedup_centred_with_norm(b_all[list(permutation)])
            rmsd, _ = dedup_superposition_from_centered(a, norm_a, b, norm_b)
            if best_rmsd is None or rmsd < best_rmsd:
                best_rmsd, best_permutation = rmsd, permutation
            if best_rmsd <= DEDUP_RMSD_THRESHOLD * 0.1:
                break
        return best_permutation

    if len(singleton_atoms) >= DEDUP_ORBIT_MIN_ANCHORS:
        seed = {atom: atom for atom in singleton_atoms}
        remaining = [atoms for atoms in classes_by_size if len(atoms) > 1]
        return best_of([run_from_seed(seed, remaining)])

    seed_classes, trial_budget = [], 1
    for atoms_in_class in classes_by_size:
        candidate_budget = trial_budget * math.factorial(len(atoms_in_class))
        if candidate_budget > DEDUP_MAX_ORBIT_SEED_TRIALS and seed_classes:
            break
        seed_classes.append(atoms_in_class)
        trial_budget = candidate_budget
        if sum(len(c) for c in seed_classes) >= DEDUP_ORBIT_MIN_ANCHORS:
            break
    if sum(len(c) for c in seed_classes) < 3 or trial_budget > DEDUP_MAX_ORBIT_SEED_TRIALS:
        return None

    remaining_classes = [atoms for atoms in classes_by_size if atoms not in seed_classes]
    results = []
    for combo in itertools.product(*(itertools.permutations(atoms) for atoms in seed_classes)):
        seed = {}
        for original, permuted in zip(seed_classes, combo):
            seed.update(dict(zip(original, permuted)))
        result = run_from_seed(seed, remaining_classes)
        if result is not None:
            results.append(result)
    return best_of(results)

def dedup_principal_moments(atom_types, coordinates):
    """
    Principal moments of inertia, sorted ascending.

    Eigenvalues of the inertia tensor are invariant to BOTH orientation and atom numbering, so two writings of
    one geometry give the same three numbers with no permutation reasoning at all. That makes them an ideal
    cheap screen ahead of the exact comparison.
    """
    masses = np.array([DEDUP_ATOMIC_MASSES.get(symbol, DEDUP_DEFAULT_MASS) for symbol in atom_types], dtype=float)
    points = np.asarray(coordinates, dtype=float)
    centre = (masses[:, None] * points).sum(axis=0) / masses.sum()
    shifted = points - centre
    x, y, z = shifted[:, 0], shifted[:, 1], shifted[:, 2]
    tensor = np.array([
        [float((masses * (y*y + z*z)).sum()), -float((masses * x * y).sum()), -float((masses * x * z).sum())],
        [-float((masses * x * y).sum()), float((masses * (x*x + z*z)).sum()), -float((masses * y * z).sum())],
        [-float((masses * x * z).sum()), -float((masses * y * z).sum()), float((masses * (x*x + y*y)).sum())],
    ], dtype=float)
    return sorted(float(v) for v in np.linalg.eigvalsh(tensor))

def dedup_moments_compatible(moments_a, moments_b):
    """Whether two structures agree closely enough in their principal moments to be worth an exact comparison."""
    for first, second in zip(moments_a, moments_b):
        scale = max(abs(first), abs(second), 1e-9)
        if abs(first - second) / scale > DEDUP_INERTIA_RELATIVE_TOLERANCE:
            return False
    return True

def dedup_frequency_agreement(frequencies_a, frequencies_b):
    """
    Compare two conformers' vibrational spectra mode by mode.

    Two structures relaxed into the same basin have essentially the same normal modes, agreeing to within
    optimization-convergence noise. Two structures in different basins have different force constants and
    therefore different frequencies, most visibly in the low-frequency torsional modes that describe the very
    motions distinguishing conformers. This is independent evidence: it comes from the Hessian at each geometry
    and never from any distance comparison, so it can confirm or contradict the geometric verdict rather than
    restating it.

    Returns (all_rmsd, max_difference, comparable). comparable is False when the mode counts differ, which means
    the structures are not the same molecule at all (3N-6 is fixed by atom count) -- comparing them would be
    meaningless rather than merely inaccurate.

    NOTE ON WHICH METRIC BINDS: the all-mode RMSD dilutes badly. A molecule of this size has ~110 modes, of which
    ~25 are C-H and O-H stretches that barely shift between conformers, so a genuine conformational difference
    moving one low mode by 10 cm^-1 averages down to about 1 cm^-1 across all modes and slips under any sensible
    RMSD cutoff. The MAX single-mode difference does not dilute and is what actually discriminates; the RMSD is
    retained as a secondary guard because requiring both is strictly more conservative than either alone.
    """
    if len(frequencies_a) != len(frequencies_b) or not frequencies_a:
        return None, None, False
    a = np.sort(np.asarray(frequencies_a, dtype=float))
    b = np.sort(np.asarray(frequencies_b, dtype=float))
    differences = np.abs(a - b)
    return float(math.sqrt(float((differences ** 2).mean()))), float(differences.max()), True

def deduplicate_conformers(conformer_numbers, energy_by_conformer, coordinates_by_conformer,
                           atom_types, connectivity, frequencies_by_conformer=None):
    """
    Identify conformers that optimized to a minimum already represented by a lower-energy conformer.

    A pair is merged only when EVERY gate agrees: the energy gap is within DEDUP_ENERGY_WINDOW, the
    symmetry-corrected RMSD is within DEDUP_RMSD_THRESHOLD with no single atom displaced by more than
    DEDUP_MAX_DEVIATION_THRESHOLD, and -- when frequency data is available for both -- the vibrational spectra
    agree within DEDUP_FREQUENCY_RMSD_THRESHOLD overall and DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD in every single
    mode. Requiring all of them is deliberately conservative: a merge silently deletes a conformer and hands its
    Boltzmann weight to a structure that may not be it, which is not recoverable from the output, whereas
    retaining a redundant conformer merely inflates the ensemble slightly.

    Conformers are pooled from the lowest energy upward, so the survivor of any merge is always the more
    populated one, and each candidate is compared only against established representatives -- never against
    another duplicate -- so a chain of individually similar structures cannot bridge two genuinely different
    minima into one cluster.

    Returns (survivors, duplicate_records, ungated_conformers, diagnostics).
    """
    atom_count = len(atom_types)
    adjacency = dedup_build_adjacency(atom_types, connectivity)
    labels = dedup_refine_labels(adjacency, dedup_invariant_keys(atom_types, adjacency))
    permutations, truncated = dedup_automorphism_permutations(adjacency, labels, atom_count)
    atoms_by_label = defaultdict(list)
    for atom, label in labels.items():
        atoms_by_label[label].append(atom)
    atoms_by_label = dict(atoms_by_label)

    diagnostics = {'group_size': len(permutations), 'truncated': truncated, 'atom_count': atom_count,
                   'frequency_gated_pairs': 0, 'frequency_blocked_pairs': 0, 'frequency_unavailable': 0,
                   'frequency_blocked_records': [],
                   'energy_screened': 0, 'inertia_screened': 0, 'exact_comparisons': 0}

    prepared, ungated = {}, []
    for conformer in conformer_numbers:
        coordinates = coordinates_by_conformer.get(conformer)
        energy = energy_by_conformer.get(conformer)
        if coordinates is None or energy is None or len(coordinates) != atom_count:
            ungated.append(conformer)
            continue
        prepared[conformer] = {'coordinates': np.asarray(coordinates, dtype=float), 'energy': energy,
                               'moments': dedup_principal_moments(atom_types, coordinates)}
    if not prepared:
        return list(conformer_numbers), [], sorted(ungated), diagnostics

    minimum_energy = min(entry['energy'] for entry in prepared.values())
    for entry in prepared.values():
        entry['relative'] = (entry['energy'] - minimum_energy) * HARTREE_TO_KCAL

    ordered = sorted(prepared, key=lambda c: (prepared[c]['relative'], c))
    representatives, duplicate_records = [], []

    for conformer in ordered:
        candidate = prepared[conformer]
        matched = None
        for representative in representatives:
            reference = prepared[representative]
            gap = candidate['relative'] - reference['relative']
            if gap > DEDUP_ENERGY_WINDOW:
                diagnostics['energy_screened'] += 1
                continue
            if DEDUP_ENABLE_INERTIA_PREFILTER and not dedup_moments_compatible(reference['moments'], candidate['moments']):
                diagnostics['inertia_screened'] += 1
                continue

            diagnostics['exact_comparisons'] += 1
            rmsd = deviation = None
            permutation_label = None
            is_match = False
            if DEDUP_ENABLE_ORBIT_FAST_PATH and atoms_by_label:
                fast = dedup_orbit_guided_correspondence(adjacency, reference['coordinates'],
                                                         candidate['coordinates'], atoms_by_label)
                if fast is not None:
                    a, norm_a = dedup_centred_with_norm(reference['coordinates'])
                    b, norm_b = dedup_centred_with_norm(candidate['coordinates'][list(fast)])
                    rmsd, deviation = dedup_superposition_from_centered(a, norm_a, b, norm_b, True)
                    permutation_label = 'orbit-guided'
                    is_match = (rmsd <= DEDUP_RMSD_THRESHOLD and deviation is not None
                                and deviation <= DEDUP_MAX_DEVIATION_THRESHOLD)
            if permutation_label is None:
                rmsd, deviation, permutation_label, is_match = dedup_symmetry_corrected_rmsd(
                    reference['coordinates'], candidate['coordinates'], permutations)
            if not is_match:
                continue

            # Independent vibrational check, applied last because it can only ever BLOCK a merge the geometry
            # already accepted, never create one
            frequency_note = 'not available'
            if DEDUP_ENABLE_FREQUENCY_GATE and frequencies_by_conformer:
                spectra_a = frequencies_by_conformer.get(representative)
                spectra_b = frequencies_by_conformer.get(conformer)
                if spectra_a and spectra_b:
                    freq_rmsd, freq_max, comparable = dedup_frequency_agreement(spectra_a, spectra_b)
                    if comparable:
                        if (freq_rmsd > DEDUP_FREQUENCY_RMSD_THRESHOLD
                                or freq_max > DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD):
                            diagnostics['frequency_blocked_pairs'] += 1
                            # Recorded individually: a blocked pair is one the geometry accepted and the
                            # spectra rejected, which is exactly the case worth being able to inspect. It
                            # leaves no other trace, since it simply never becomes a duplicate record
                            diagnostics['frequency_blocked_records'].append({
                                'candidate': conformer, 'representative': representative,
                                'energy_gap': gap, 'rmsd': rmsd, 'max_deviation': deviation,
                                'freq_rmsd': freq_rmsd, 'freq_max': freq_max})
                            continue
                        diagnostics['frequency_gated_pairs'] += 1
                        frequency_note = f"RMSD {freq_rmsd:.3f}, max {freq_max:.3f} cm^-1"
                    else:
                        diagnostics['frequency_unavailable'] += 1
                else:
                    diagnostics['frequency_unavailable'] += 1

            record = {'duplicate': conformer, 'representative': representative, 'energy_gap': gap,
                      'rmsd': rmsd, 'max_deviation': deviation, 'permutation': permutation_label,
                      'frequency': frequency_note}
            if matched is None or rmsd < matched['rmsd']:
                matched = record

        if matched is not None:
            duplicate_records.append(matched)
        else:
            representatives.append(conformer)

    survivors = sorted(representatives) + sorted(ungated)
    return sorted(set(survivors)), duplicate_records, sorted(ungated), diagnostics

# ==================================================================================================================
# NOE EQUIVALENCE MULTIPLIERS
# ==================================================================================================================

def noe_equivalence_multiplier(count_a, count_b=1):
    """
    The r^-6 multiplier relating a per-atom distance to what an NOE between two equivalent-atom groups reports.

    NOE cross-relaxation scales as r^-6 and contributions from equivalent spins ADD. For a group of N equivalent
    protons all at distance r from a group of M equivalent partners, the total intensity is proportional to
    N*M*r^-6, so converting that intensity back through the usual r = I^(-1/6) relation gives an apparent
    distance of r*(N*M)^(-1/6) -- shorter than the true per-atom distance. A methyl (N=3) therefore appears
    3^(-1/6) = 0.833 times its real distance, and two methyls against each other 9^(-1/6) = 0.693 times.

    Returns the factor to multiply a per-atom distance by to get the apparent (NOE-derived) distance. Its
    reciprocal converts an experimentally measured apparent distance back to a per-atom distance.
    """
    count_a = max(1, int(count_a))
    count_b = max(1, int(count_b))
    return float((count_a * count_b) ** (-1.0 / 6.0))

def build_noe_equivalence_map(equivalent_groups, atom_count):
    """
    Map each 1-based atom number onto the size of the equivalence group it belongs to, defaulting to 1.

    Uses the equivalence classes ngp2 has already determined for the compound, so the NOE treatment and the shift
    averaging describe the same set of equivalent atoms rather than two independently-derived notions of it.
    """
    group_size = {atom: 1 for atom in range(1, atom_count + 1)}
    for group in (equivalent_groups or {}).values():
        atoms = group.get('atoms') or []
        size = group.get('count') or len(atoms)
        for atom in atoms:
            if 1 <= atom <= atom_count:
                group_size[atom] = max(1, int(size))
    return group_size

def apply_noe_equivalence_multipliers(distances, equivalent_groups, atom_count):
    """
    Apply additive-NOE equivalence scaling to a distance table.

    For every atom pair this computes the multiplicity factor from the two atoms' equivalence group sizes and
    returns both the factor and the apparent distance it implies. The result answers the question an NOE
    experiment actually poses: given this geometry, how short will the distance LOOK once every equivalent spin
    on both ends contributes to the same integrated cross peak.

    Returns (effective_distances, multipliers), both keyed [atom_i][atom_j] with 1-based atom numbers, matching
    the layout of the input distance table.
    """
    group_size = build_noe_equivalence_map(equivalent_groups, atom_count)
    effective = defaultdict(dict)
    multipliers = defaultdict(dict)
    for atom_i, partners in distances.items():
        for atom_j, distance in partners.items():
            factor = noe_equivalence_multiplier(group_size.get(atom_i, 1), group_size.get(atom_j, 1))
            multipliers[atom_i][atom_j] = factor
            effective[atom_i][atom_j] = distance * factor
    return effective, multipliers

def write_noe_equivalence_multipliers(multipliers, effective_distances, distances, equivalent_groups,
                                      atom_count, output_file):
    """Write the multiplier table, listing only pairs where equivalence actually changes the distance."""
    if not ngp_output_enabled('noe_multipliers'):
        return None  # Output suppressed by the 'noe_multipliers' switch; every retained output is unaffected
    group_size = build_noe_equivalence_map(equivalent_groups, atom_count)
    try:
        with open(output_file, 'w', encoding='utf-8') as handle:
            handle.write("NOE Equivalence Multipliers\n")
            handle.write("=" * 78 + "\n")
            handle.write("Additive r^-6 NOE physics: N equivalent spins at distance r contribute N*r^-6 to the\n")
            handle.write("integrated cross peak, so the apparent distance is r*(Na*Nb)^(-1/6), shorter than the\n")
            handle.write("true per-atom distance. Multiply an apparent (measured) distance by 1/factor to recover\n")
            handle.write("the per-atom distance. Only pairs with a factor other than 1 are listed.\n\n")
            handle.write(f"{'Atom i':>8}{'Atom j':>8}{'Ni':>5}{'Nj':>5}{'factor':>10}"
                        f"{'r (A)':>10}{'apparent (A)':>14}\n")
            handle.write("-" * 78 + "\n")
            written = 0
            for atom_i in sorted(multipliers):
                for atom_j in sorted(multipliers[atom_i]):
                    if atom_j <= atom_i:
                        continue
                    factor = multipliers[atom_i][atom_j]
                    if abs(factor - 1.0) < 1e-12:
                        continue
                    handle.write(f"{atom_i:>8}{atom_j:>8}{group_size.get(atom_i,1):>5}{group_size.get(atom_j,1):>5}"
                                f"{factor:>10.4f}{distances[atom_i][atom_j]:>10.4f}"
                                f"{effective_distances[atom_i][atom_j]:>14.4f}\n")
                    written += 1
            if not written:
                handle.write("  (no equivalent-atom pairs in this structure)\n")
    except OSError as error:
        print(f"  Warning: could not write NOE equivalence multipliers ({error})")

def write_text_atomically(path, text, encoding='utf-8'):
    """
    Write a text file so that it is either complete or absent, never half-written.

    Writing in place means an interrupt, a crash or a full disk mid-write leaves a truncated file that still
    looks like a result. For a deduplication report or a shift table that is worse than no file at all, because
    nothing about it says it is incomplete. Writing to a temporary file in the same directory and then renaming
    is atomic on both Windows and Linux, so the destination only ever holds the finished content.

    Returns True on success.
    """
    directory = os.path.dirname(os.path.abspath(path)) or '.'
    try:
        os.makedirs(directory, exist_ok=True)
        temporary = path + '.partial'
        with open(temporary, 'w', encoding=encoding) as handle:
            handle.write(text)
        os.replace(temporary, path)   # same filesystem by construction, so this is atomic
        return True
    except OSError as error:
        print(f"  Warning: could not write {os.path.basename(path)}: {error}")
        try:
            if os.path.exists(temporary):
                os.remove(temporary)
        except (OSError, NameError):
            pass
        return False


def write_deduplication_report(compound_name, survivors, duplicate_records, ungated_conformers,
                               conformers_considered, atom_selection_summary=None, diagnostics=None):
    """
    Write a per-compound record of the deduplication decisions.

    The report is written on every run, including runs where nothing is merged, so that the pruning applied to
    a published ensemble is always documented alongside the populations it produced.
    """
    if not ngp_output_enabled('dedup_report'):
        return None  # Output suppressed by the 'dedup_report' switch; every retained output is unaffected
    os.makedirs(compound_name, exist_ok=True)
    output_file = os.path.join(compound_name, f"{compound_name}_conformer_deduplication.txt")

    content = StringIO()
    content.write("Conformer Deduplication Report:\n\n")
    content.write("Two conformers are treated as the same minimum only when all of the following hold:\n")
    content.write(f"  Gibbs free energy separation <= {DEDUP_ENERGY_WINDOW:.2f} kcal/mol\n")
    content.write(f"  Symmetry-corrected RMSD <= {DEDUP_RMSD_THRESHOLD:.2f} Angstrom (minimized over the molecular graph's automorphism group)\n")
    content.write(f"  Largest single-atom displacement <= {DEDUP_MAX_DEVIATION_THRESHOLD:.2f} Angstrom\n")
    if DEDUP_ENABLE_FREQUENCY_GATE:
        content.write(f"  Vibrational frequency RMSD <= {DEDUP_FREQUENCY_RMSD_THRESHOLD:.1f} cm^-1 and every single mode within {DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD:.1f} cm^-1,\n")
        content.write("    applied whenever frequency data is available for both conformers\n")
    content.write("\nSuperposition is a proper rotation only, so mirror-image conformers are never merged. For an achiral\n")
    content.write("molecule those pairs are exactly isoenergetic and their equal-and-opposite rotational strengths are\n")
    content.write("what make its VCD and ECD cancel to a flat line; merging them would break that cancellation.\n\n")
    if atom_selection_summary:
        content.write(f"Atoms compared: {atom_selection_summary}\n")
    if diagnostics:
        content.write(f"Automorphism group: {diagnostics['group_size']} graph-legal relabeling(s)"
                     + ("  [truncated at the enumeration cap]\n" if diagnostics['truncated'] else "\n"))
        if diagnostics.get('frequency_gated_pairs') or diagnostics.get('frequency_blocked_pairs'):
            content.write(f"Frequency gate: {diagnostics['frequency_gated_pairs']} merge(s) confirmed by matching "
                         f"spectra, {diagnostics['frequency_blocked_pairs']} blocked by differing spectra\n")
        if diagnostics.get('frequency_unavailable'):
            content.write(f"Frequency data unavailable for {diagnostics['frequency_unavailable']} comparison(s); "
                         f"those fell back to the geometric gates alone\n")
    content.write(f"Conformers considered: {conformers_considered}\n")
    content.write(f"Unique minima retained: {len(survivors)}\n")
    content.write(f"Duplicates removed: {len(duplicate_records)}\n\n")
    content.write("Retained conformers: " + ", ".join(str(conformer) for conformer in survivors) + "\n\n")

    blocked = (diagnostics or {}).get('frequency_blocked_records') or []
    if blocked:
        content.write("Merges blocked by the frequency gate:\n")
        content.write("These pairs satisfied every geometric criterion but their vibrational spectra disagree, so\n")
        content.write("they were NOT merged. Frequencies come from the Hessian rather than from any distance\n")
        content.write("comparison, so this is independent evidence that the two are different minima despite very\n")
        content.write("similar geometries. This is also the main reason this script can retain more conformers than\n")
        content.write("a geometry-only deduplication of the same ensemble.\n")
        content.write(f"{'Candidate':>10}{'Representative':>16}{'dE (kcal/mol)':>16}{'RMSD (A)':>12}"
                     f"{'freq RMSD':>12}{'freq max':>11}\n")
        for record in sorted(blocked, key=lambda r: r['candidate']):
            content.write(
                f"{record['candidate']:>10}{record['representative']:>16}{record['energy_gap']:>16.4f}"
                f"{record['rmsd']:>12.4f}{record['freq_rmsd']:>12.3f}{record['freq_max']:>11.3f}\n")
        content.write("\n")

    if duplicate_records:
        content.write("Removed Conformers:\n")
        content.write(f"{'Duplicate':>10}{'Representative':>16}{'dE (kcal/mol)':>16}{'RMSD (A)':>12}{'Max dev (A)':>14}  Frequencies\n")
        for record in sorted(duplicate_records, key=lambda r: r['duplicate']):
            content.write(
                f"{record['duplicate']:>10}{record['representative']:>16}"
                f"{record['energy_gap']:>16.4f}{record['rmsd']:>12.4f}{record['max_deviation']:>14.4f}"
                f"  {record.get('frequency', 'not available')}\n"
            )

        merged_by_representative = defaultdict(list)
        for record in duplicate_records:
            merged_by_representative[record['representative']].append(record['duplicate'])

        content.write("\nRepresentatives that absorbed duplicates:\n")
        for representative in sorted(merged_by_representative):
            duplicates = merged_by_representative[representative]
            content.write(
                f"  Conformer {representative}: {len(duplicates)} duplicate(s) removed "
                f"({', '.join(str(duplicate) for duplicate in duplicates)})\n"
            )
    else:
        content.write("No duplicate minima were detected; every valid conformer was retained.\n")

    if ungated_conformers:
        content.write(
            "\nRetained without a geometry check (missing Gibbs free energy or unreadable final geometry): "
            + ", ".join(str(conformer) for conformer in ungated_conformers) + "\n"
        )

    # Written atomically: an interrupted run must not leave a truncated report that still looks like a result
    write_text_atomically(output_file, content.getvalue())

# ======================================
# END OF CONFORMER DEDUPLICATION SECTION
# ======================================

# ====================================
# START OF MAIN SCRIPT PARSING SECTION
# ====================================

# Primary script definitions start here for most functions

def get_temperature_from_log(file_path):
    for line in read_log_lines(file_path):
        if "temperature=" in line.lower():
            match = re.search(r"temperature\s*=\s*(\d+\.?\d*)", line.lower())
            if match:
                return float(match.group(1))
    return 298.0   # Gaussian's own default when no temperature keyword is present

def read_boltzmann_populations_from_file(compound_name):
    """
    Read pre-calculated Boltzmann populations from a text file.
    
    Expected file format:
    {compound_name}_boltzmann.txt
    
    Contents:
    Conformer 1: 45.23%
    Conformer 2: 32.15%
    Conformer 3: 22.62%
    
    Returns:
        dict: {conformer_number: population_fraction}
        None if file not found or parsing fails
    """
    boltzmann_file = f"{compound_name}_boltzmann.txt"
    
    if not os.path.exists(boltzmann_file):
        return None
    
    populations = {}
    
    try:
        with open(boltzmann_file, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or ':' not in line:
                    continue
                
                # Parse "Conformer X: YY.YY%"
                match = re.match(r'Conformer\s+(\d+)\s*:\s*([\d.]+)\s*%', line, re.IGNORECASE)
                if match:
                    conformer_num = int(match.group(1))
                    population_percent = float(match.group(2))
                    populations[conformer_num] = population_percent / 100.0  # Convert to fraction
        
        if not populations:
            print(f"Warning: No valid populations found in {boltzmann_file}")
            return None
        
        # Validate that populations sum to approximately 1.0
        total = sum(populations.values())
        # The zero case has to be excluded explicitly: abs(0 - 1.0) is 1.0, which passes the tolerance test and
        # then divides by zero. Populations summing to exactly zero means the file is unusable rather than
        # merely unnormalized, so nothing is salvageable by scaling it.
        if total <= 0:
            print(f"Warning: Populations in {boltzmann_file} sum to {total:.4f}; the file carries no usable "
                  f"weights and is ignored.")
            return {}
        if abs(total - 1.0) > 0.01:  # Allow 1% tolerance
            print(f"Warning: Populations in {boltzmann_file} sum to {total:.4f}, not 1.0")
            print("Normalizing populations...")
            populations = {k: v/total for k, v in populations.items()}
        
        return populations
        
    except Exception as e:
        print(f"Error reading {boltzmann_file}: {e}")
        return None

def extract_connectivity_from_parameters(log_file):
    """
    Extract connectivity information from the Initial Parameters section of the Gaussian output.
    Returns a dictionary of connections where each atom maps to its connected atoms.
    """
    connectivity_raw = defaultdict(set)
    
    lines = read_log_lines(log_file)
    
    # Find the Initial Parameters section
    start_idx = -1
    for i, line in enumerate(lines):
        if "Initial Parameters" in line and i + 1 < len(lines) and "Angstroms and Degrees" in lines[i + 1]:
            # Look for the header line with "Name  Definition"
            for j in range(i, min(i + 10, len(lines))):
                if "Name  Definition" in lines[j]:
                    start_idx = j + 2  # Skip the header and separator line
                    break
            break
    
    if start_idx == -1:
        raise ValueError(f"Could not find Initial Parameters section in {log_file}")
    
    # Parse connectivity lines
    # Upper bound: Initial Parameters section is never more than a few thousand lines even for large molecules
    # Without this, a malformed file missing the section terminator iterates to end-of-file silently
    max_lines_to_scan = start_idx + 5000
    for i in range(start_idx, min(len(lines), max_lines_to_scan)):
        line = lines[i].strip()
        
        # Skip blank lines within the section
        if not line:
            continue
        
        # Stop when hitting angle or dihedral parameters  -- signals end of bond section in Gaussian output
        # Gaussian always lists R() bonds before A() angles and D() dihedrals
        # Use full parameter line format check: Gaussian parameter lines start with '!' after stripping
        # Only break on A(/D( lines that match the parameter table format to avoid false stops on compound names containing those substrings
        if line.startswith('!') and re.search(r'[AD]\(\d+', line) and not re.search(r'R\(\d+,\d+\)', line):
            break
        if line.startswith('---'):
            break

        # Parse R(atom1,atom2) format
        match = re.search(r'R\((\d+),(\d+)\)', line)
        if match:
            atom1 = int(match.group(1))
            atom2 = int(match.group(2))
            connectivity_raw[atom1].add(atom2)
            connectivity_raw[atom2].add(atom1)

    return connectivity_raw

def parse_serialized_connectivity_and_charges(serialized_str, base_connectivity):
    """
    Parses serialized connectivity and charges from a single string.
    Contains non-single bonds in the opt/freq job title section.
    
    Args:
        serialized_str: The serialized string from job title
        base_connectivity: Base connectivity from Initial Parameters (all assumed bond order 1)
    
    Returns:
        per_atom_charges: dict {int: int}
        connectivity: dict {int: list of (int, float)}
    """
    # Parse charges
    charge_match = re.search(r'\[([^\]]*)\]', serialized_str)
    per_atom_charges = {}
    if charge_match:
        charge_str = charge_match.group(1)
        if charge_str.strip():
            for pair in charge_str.split('|'):
                if ':' in pair:  # Check if it's a valid charge pair
                    atom_str, charge_val = pair.split(':')
                    per_atom_charges[int(atom_str)] = int(charge_val)
    
    # Start with base connectivity (all bonds assumed to be order 1)
    connectivity = {}
    for atom1, connected_atoms in base_connectivity.items():
        connectivity[atom1] = [(atom2, 1.0) for atom2 in connected_atoms]
    
    # Parse special bond orders from the serialized string
    conn_match = re.search(r'\{([^\}]*)\}', serialized_str)
    if conn_match:
        conn_str = conn_match.group(1)
        if conn_str.strip():
            # Parse special bonds (non-single bonds)
            for bond_str in conn_str.split('|'):
                parts = bond_str.split('-')
                if len(parts) == 3:
                    try:
                        atom1 = int(parts[0])
                        atom2 = int(parts[1])
                        bond_order = float(parts[2])
                    except (ValueError, IndexError):
                        print(f"Warning: malformed bond string '{bond_str}' in serialized block  -- skipping this bond. Check the GJF serialization for {bond_str!r}.")
                        continue
                    
                    # Update the bond order for this specific bond
                    if atom1 in connectivity:
                        for i, (connected_atom, _) in enumerate(connectivity[atom1]):
                            if connected_atom == atom2:
                                connectivity[atom1][i] = (atom2, bond_order)
                                break
                        else:
                            print(f"Warning: bond {atom1}-{atom2} not found in connectivity for atom {atom1}")
                    else:
                        print(f"Warning: atom {atom1} from serialized bond not found in connectivity")
                    
                    if atom2 in connectivity:
                        for i, (connected_atom, _) in enumerate(connectivity[atom2]):
                            if connected_atom == atom1:
                                connectivity[atom2][i] = (atom1, bond_order)
                                break
                        else:
                            print(f"Warning: bond {atom2}-{atom1} not found in connectivity for atom {atom2}")
                    else:
                        print(f"Warning: atom {atom2} from serialized bond not found in connectivity")
    return per_atom_charges, connectivity

# ==================================================================================================================
# WIBERG BOND INDEX PARSING
# ==================================================================================================================
# Bond orders are read from the converged wavefunction rather than carried through the job title from the input
# SDF. The optimization route requests pop=nboread with a $NBO BNDIDX $END block, which makes Gaussian print the
# Wiberg bond index matrix in the NAO basis; classifying those indices gives the bond orders the calculation
# actually supports. This replaces the serialized {a-b-order|...} block that used to travel in the title, which
# recorded only what the drawing program believed and grew unwieldy for large molecules.

WBI_THRESHOLDS = {
    'min_bond':     0.35,   # Below this the pair is not bonded at all
    'single_max':   1.30,   # Up to here: single
    'aromatic_max': 1.60,   # Up to here: aromatic (MDL code 4)
    'double_max':   2.40,   # Up to here: double; above: triple
}

_WIBERG_CACHE = {}

def parse_wiberg_bond_index_matrix(log_file, num_atoms=None):
    """
    Parse the Wiberg bond index matrix in the NAO basis from a pop=nboread BNDIDX log.

    The matrix prints in column blocks, each introduced by an 'Atom' header giving that block's true atom
    indices, so the column headers must be tracked rather than assumed contiguous. Only the FIRST matrix is
    read: parsing stops at the 'Totals by atom' summary and never reaches the overlap-weighted or MO matrices
    printed after it, which look similar enough to be picked up by accident.

    Returns a symmetric {i: {j: wbi}} over 1-based atom indices, or None when the section is absent -- which is
    the normal case for a log produced before pop=nboread was added, and is handled by falling back rather than
    failing.
    """
    cache_key = os.path.abspath(log_file)
    if cache_key in _WIBERG_CACHE:
        return _WIBERG_CACHE[cache_key]

    try:
        lines = read_log_lines(log_file)
    except (OSError, NameError):
        try:
            with open(log_file, 'r', errors='replace') as handle:
                lines = handle.readlines()
        except OSError:
            _WIBERG_CACHE[cache_key] = None
            return None

    start = None
    for index, line in enumerate(lines):
        if line.strip().startswith("Wiberg bond index matrix in the NAO basis"):
            start = index + 1
            break
    if start is None:
        _WIBERG_CACHE[cache_key] = None
        return None

    matrix = defaultdict(dict)
    column_indices = []
    row_pattern = re.compile(r'^\s*(\d+)\.\s+[A-Za-z]{1,3}\s+(.*)$')
    header_pattern = re.compile(r'^\s*Atom\s+(\d+(?:\s+\d+)*)\s*$')

    position = start
    while position < len(lines):
        raw = lines[position]
        stripped = raw.strip()

        if (stripped.startswith("Wiberg bond index, Totals by atom")
                or stripped.startswith("Atom-atom overlap-weighted")
                or stripped.startswith("MO bond order")):
            break

        header = header_pattern.match(raw)
        if header:
            column_indices = [int(value) for value in header.group(1).split()]
            position += 1
            continue

        if stripped and set(stripped) <= set('- '):
            position += 1
            continue

        row = row_pattern.match(raw)
        if row and column_indices:
            row_atom = int(row.group(1))
            for offset, value in enumerate(row.group(2).split()):
                if offset >= len(column_indices):
                    break
                try:
                    matrix[row_atom][column_indices[offset]] = float(value)
                except ValueError:
                    pass
        position += 1

    if not matrix:
        _WIBERG_CACHE[cache_key] = None
        return None

    # Symmetrize defensively: the matrix is symmetric, but a truncated block can leave one direction unfilled
    for atom in sorted(matrix.keys()):
        for partner, value in list(matrix[atom].items()):
            if atom not in matrix[partner]:
                matrix[partner][atom] = value

    if num_atoms is not None and len(matrix) != num_atoms:
        print(f"  Warning: Wiberg matrix covers {len(matrix)} atoms, expected {num_atoms} "
              f"in {os.path.basename(log_file)}.")

    result = dict(matrix)
    _WIBERG_CACHE[cache_key] = result
    return result

WIBERG_VERIFY_SAMPLE = 4   # Conformers sampled to confirm bond orders really are conformation-independent

def verify_wiberg_consistency(compound_name, conformer_numbers, connectivity, reference_orders,
                              sample=WIBERG_VERIFY_SAMPLE):
    """
    Confirm that the bond orders taken from one conformer hold across the ensemble.

    Bond orders are derived once per compound, from the first conformer, because every conformer of a compound
    shares its constitution -- deriving them per conformer would be wasted work. That reasoning is sound for
    the CONNECTIVITY, but the Wiberg index is a continuous property of each converged wavefunction, and
    classifying it into an integer order means a bond sitting near a threshold can land on either side
    depending on conformation. An amide C-N is the usual example: around 1.28 it classifies single, around
    1.32 aromatic, and rotating that bond moves it across the boundary.

    So rather than assume, a few conformers spread through the ensemble are checked. Disagreement is reported
    with the actual indices, because it is genuinely informative: it means either a bond is borderline (worth
    knowing before the orders are used downstream) or something is wrong with a log. Nothing is changed
    automatically -- the reference orders stand -- since silently switching bond orders mid-ensemble would be
    worse than a clear warning.
    """
    if not reference_orders or len(conformer_numbers) < 2:
        return True

    # Spread the sample across the ensemble rather than taking the first few, which would all come from the
    # same region of conformational space and could easily share a borderline value
    candidates = [c for c in conformer_numbers[1:]]
    if not candidates:
        return True
    step = max(1, len(candidates) // sample)
    chosen = candidates[::step][:sample]

    disagreements = []
    for conformer in chosen:
        log_file = f"{compound_name}_{conformer}.log"
        if not os.path.exists(log_file):
            continue
        matrix = parse_wiberg_bond_index_matrix(log_file)
        if not matrix:
            continue
        for atom, bonds in connectivity.items():
            for neighbour, _order in bonds:
                if atom >= neighbour:
                    continue
                wbi = matrix.get(atom, {}).get(neighbour)
                if wbi is None:
                    continue
                order = classify_wiberg_bond_order(wbi) or 1
                expected = reference_orders.get((atom, neighbour))
                if expected is not None and order != expected:
                    disagreements.append((conformer, atom, neighbour, wbi, order, expected))

    if disagreements:
        print(f"  NOTE: bond orders are not identical across all sampled conformers of {compound_name}. "
              f"This usually means a bond's Wiberg index sits near a classification threshold.")
        print(f"        The orders from the reference conformer are used throughout; the differences are:")
        for conformer, atom, neighbour, wbi, order, expected in disagreements[:8]:
            print(f"          conformer {conformer}: bond {atom}-{neighbour} WBI {wbi:.3f} -> order {order}, "
                  f"reference says {expected}")
        if len(disagreements) > 8:
            print(f"          ... and {len(disagreements) - 8} more")
        return False
    if chosen:
        print(f"  Bond orders confirmed identical across {len(chosen)} sampled conformer(s).")
    return True


def classify_wiberg_bond_order(wbi, thresholds=WBI_THRESHOLDS):
    """Map a Wiberg bond index onto an MDL bond-order code: 1, 2, 3, 4 (aromatic), or None for no bond."""
    if wbi < thresholds['min_bond']:
        return None
    if wbi <= thresholds['single_max']:
        return 1
    if wbi <= thresholds['aromatic_max']:
        return 4
    if wbi <= thresholds['double_max']:
        return 2
    return 3

def write_wiberg_report(compound_name, conformer_number, connectivity, wiberg_matrix, atom_types,
                        output_file, thresholds=WBI_THRESHOLDS):
    """
    Write the raw Wiberg index for every bond next to the order it was classified as.

    A diagnostic rather than a result: if the bond orders in the output look wrong, this shows whether the
    matrix was read correctly and the indices are simply near a threshold, or whether the matrix was not read
    at all. Those two look identical from the SDF alone -- every bond single -- and call for opposite fixes.

    Bonds are listed in descending index order so anything with partial double-bond character appears first,
    and every classification boundary is printed so a borderline value can be judged against it.
    """
    lines = []
    lines.append(f"Wiberg bond indices -- {compound_name} conformer {conformer_number}")
    lines.append("=" * 86)
    lines.append("")
    lines.append("Classification boundaries (WBI_THRESHOLDS):")
    lines.append(f"  below {thresholds['min_bond']:.2f}          not a bond")
    lines.append(f"  up to {thresholds['single_max']:.2f}          single")
    lines.append(f"  up to {thresholds['aromatic_max']:.2f}          aromatic (MDL order 4)")
    lines.append(f"  up to {thresholds['double_max']:.2f}          double")
    lines.append(f"  above {thresholds['double_max']:.2f}          triple")
    lines.append("")
    lines.append("Only bonded pairs are listed. A bond whose index falls below the bonding threshold keeps")
    lines.append("order 1 rather than being deleted, because the connectivity has already established it.")
    lines.append("")
    lines.append(f"{'Atoms':>12}{'Elements':>12}{'Wiberg index':>16}{'Order':>8}   Note")
    lines.append("-" * 86)

    rows = []
    for atom, bonds in (connectivity or {}).items():
        for neighbour, existing in bonds:
            if atom >= neighbour:
                continue
            index = (wiberg_matrix or {}).get(atom, {}).get(neighbour)
            rows.append((index if index is not None else -1.0, atom, neighbour, index, existing))
    rows.sort(key=lambda row: -row[0])

    for _sort, atom, neighbour, index, existing in rows:
        pair = f"{atom}-{neighbour}"
        elements = (f"{atom_types[atom - 1]}-{atom_types[neighbour - 1]}"
                    if atom_types and atom <= len(atom_types) and neighbour <= len(atom_types) else "?")
        if index is None:
            lines.append(f"{pair:>12}{elements:>12}{'absent':>16}{int(existing):>8}   not in the matrix")
            continue
        order = classify_wiberg_bond_order(index, thresholds)
        note = ""
        if order is None:
            note = "below the bonding threshold; kept as single"
            order = 1
        else:
            for boundary, name in ((thresholds['single_max'], 'single/aromatic'),
                                   (thresholds['aromatic_max'], 'aromatic/double'),
                                   (thresholds['double_max'], 'double/triple')):
                if abs(index - boundary) <= 0.08:
                    note = f"within 0.08 of the {name} boundary"
                    break
        lines.append(f"{pair:>12}{elements:>12}{index:>16.4f}{order:>8}   {note}")

    counts = {}
    for _sort, atom, neighbour, index, existing in rows:
        order = classify_wiberg_bond_order(index, thresholds) if index is not None else None
        counts[order or 1] = counts.get(order or 1, 0) + 1
    lines.append("")
    lines.append("Bond order totals: " + ", ".join(f"{order}: {count}" for order, count in sorted(counts.items())))
    if set(counts) == {1}:
        lines.append("")
        lines.append("Every bond classified as single. If the structure should have double or aromatic bonds,")
        lines.append("compare the indices above against the boundaries: values clustered near 1.0 mean the")
        lines.append("matrix was read but the wavefunction really is that localized, whereas 'absent' on every")
        lines.append("row means the matrix was not found in the log at all.")

    write_text_atomically(output_file, "\n".join(lines) + "\n")


def apply_wiberg_bond_orders(connectivity, wiberg_matrix, thresholds=WBI_THRESHOLDS):
    """
    Rewrite a connectivity map's bond orders from the Wiberg matrix.

    connectivity is {atom: [(neighbour, order), ...]} and is returned in the same shape with orders replaced.
    Connectivity decides WHICH pairs are bonded -- that comes from the geometry and is not in question here --
    while the Wiberg index decides the order of each such bond. A pair the matrix scores below the bonding
    threshold keeps order 1 rather than being dropped, because the connectivity has already established the
    bond exists and silently deleting it would corrupt the molecular graph every later step depends on.

    Returns (connectivity, changed_count, missing_count).
    """
    if not wiberg_matrix:
        return connectivity, 0, 0

    changed, missing = 0, 0
    resolved = {}
    for atom, bonds in connectivity.items():
        updated = []
        for neighbour, existing_order in bonds:
            wbi = wiberg_matrix.get(atom, {}).get(neighbour)
            if wbi is None:
                missing += 1
                updated.append((neighbour, existing_order))
                continue
            order = classify_wiberg_bond_order(wbi, thresholds)
            if order is None:
                order = 1
            if float(order) != float(existing_order):
                changed += 1
            updated.append((neighbour, float(order)))
        resolved[atom] = updated
    return resolved, changed // 2, missing // 2


def extract_element_symbols(file_path):
    """
    Extract element symbols from the Gaussian output file by parsing the atomic coordinates section.
    """
    elements = []
    lines = read_log_lines(file_path)
    found = False
    for line in lines:
        if 'Charge = ' in line and 'Multiplicity = ' in line:
            found = True
            continue
        if found:
            parts = line.split()
            if len(parts) == 4:
                elements.append(parts[0])
            else:
                break
    return elements

def extract_compound_structure(compound_name, first_conformer_num, all_conformer_numbers=None):
    """
    Extract all structural data that remains constant across conformers.
    This should be called ONCE per compound.
    
    Returns a dictionary with all invariant structural information.
    """
    log_file = f"{compound_name}_{first_conformer_num}.log"
    
    # Extract base connectivity from Initial Parameters
    base_connectivity = extract_connectivity_from_parameters(log_file)
    
    # Extract full serialized block for charges and special bonds
    full_serialized_title = extract_full_serialized_block(
        log_file, compound_name, first_conformer_num, job_type='opt'
    )
    
    # Parse charges from the title. The title no longer carries bond orders -- those come from the Wiberg
    # matrix below -- but charges remain there because they are an input specification the calculation does not
    # determine.
    per_atom_charges, connectivity = parse_serialized_connectivity_and_charges(
        full_serialized_title, base_connectivity
    )

    # Extract element symbols and coordinates (needed for equivalence analysis)
    atom_types = extract_element_symbols(log_file)

    # True bond orders from the converged wavefunction. When the log predates pop=nboread the matrix is absent
    # and every bond keeps the order the connectivity gave it, so older logs still process rather than failing.
    wiberg_matrix = parse_wiberg_bond_index_matrix(log_file, num_atoms=len(atom_types) or None)
    if wiberg_matrix:
        connectivity, changed_bonds, missing_bonds = apply_wiberg_bond_orders(connectivity, wiberg_matrix)
        detail = f"{changed_bonds} bond order(s) set from the Wiberg matrix"
        if missing_bonds:
            detail += f"; {missing_bonds} bonded pair(s) absent from the matrix kept their existing order"
        print(f"  {detail}")
        # The orders above come from one conformer. Confirm that assumption holds rather than trusting it --
        # see verify_wiberg_consistency for why a borderline bond can classify differently between conformers.
        if all_conformer_numbers and len(all_conformer_numbers) > 1:
            reference_orders = {}
            for atom, bonds in connectivity.items():
                for neighbour, order in bonds:
                    if atom < neighbour:
                        reference_orders[(atom, neighbour)] = int(order)
            verify_wiberg_consistency(compound_name, list(all_conformer_numbers), connectivity,
                                      reference_orders)
    else:
        print("  No Wiberg bond index matrix in this log (pop=nboread/BNDIDX absent); "
              "bond orders left as connectivity supplied them")
    coordinates = extract_standard_orientation(log_file)

    # Convert connectivity to simple format and extract bond orders
    simple_connectivity = {}
    bond_orders = {}
    for atom, bonds in connectivity.items():
        simple_connectivity[atom] = [neighbor for neighbor, _ in bonds]
        for neighbor, bond_order in bonds:
            # Store bond orders in both directions
            bond_orders[(atom, neighbor)] = bond_order
            bond_orders[(neighbor, atom)] = bond_order
    
    # Run chemical equivalence analysis (needs coordinates)
    # Equivalence classes from the graph-automorphism engine rather than the older rule-based one. The bonds
    # are rebuilt here from connectivity and bond orders because that engine takes a bond map; it ignores the
    # orders themselves (it is bond-order independent), but the map is how it learns which atoms are bonded.
    equivalence_bonds = {}
    for atom, neighbours in (simple_connectivity or {}).items():
        for neighbour in neighbours:
            pair = (min(atom, neighbour), max(atom, neighbour))
            equivalence_bonds[pair] = float((bond_orders or {}).get(pair, 1.0))
    # There is deliberately no fallback detector. The rule-based engine this replaced was not merely less
    # capable but wrong in ways that do not announce themselves: it missed benzene's aromatic carbons, ethanol's
    # methylene pair and cyclohexane entirely, and it wrongly merged the methylene protons of
    # cis-1,2-dimethylcyclopropane through a collision between two of its own rules. Since these classes drive
    # shift and NOE averaging, quietly substituting it would produce averaged numbers that look normal and are
    # wrong. Failing the compound with a clear message is the honest outcome.
    try:
        equivalent_groups = equiv_equivalent_groups_from_graph(
            atom_types, coordinates, equivalence_bonds, per_atom_charges)
    except Exception as error:
        print(f"  ERROR: equivalence detection failed for {compound_name} ({error}).")
        print(f"         Chemical shift and NOE averaging depend on these classes, so this compound is "
              f"skipped rather than analysed with unknown equivalence.")
        return None

    # For distance calculations, still need methyl identification
    methyl_groups_for_distances = {}
    for atom, bonds in simple_connectivity.items():
        if atom_types[atom - 1] == 'C' and len(bonds) == 4:
            h_or_f_neighbors = [n for n in bonds if atom_types[n - 1] in ['H', 'F']]
            if len(h_or_f_neighbors) == 3:
                methyl_groups_for_distances[atom] = h_or_f_neighbors

    return {
        'connectivity': connectivity,
        'simple_connectivity': simple_connectivity,
        'bond_orders': bond_orders,
        'atom_types': atom_types,
        'per_atom_charges': per_atom_charges,
        'equivalent_groups': equivalent_groups,
        'methyl_groups_for_distances': methyl_groups_for_distances,
        'num_atoms': len(atom_types)
    }

def extract_full_serialized_block(log_file, compound_name, conformer_number, job_type='opt'):
    """
    Extracts the full job title with serialized connectivity and charges,
    including continuation lines, from the output file.
    """
    # (?!\d) prevents conformer_number=1 from matching inside _10, _11, etc.  -- without it, compound_1 would match compound_10; the _ preceding the conformer number does not provide this protection
    # Note: (?:-csulfur|-chalogen)? is never exercised in the current call path  -- this function is only called from extract_compound_structure with job_type='opt' on standard log files
    # Retained for potential future reuse; callers on special log files must use the correct job_type
    pattern = re.compile(
        rf"(?<![A-Za-z0-9_]){re.escape(compound_name)}(?:-csulfur|-chalogen)?_{conformer_number}(?!\d)_{re.escape(job_type)}",
        re.MULTILINE
    )

    lines = read_log_lines(log_file)

    block_lines = []
    capture = False

    for i, line in enumerate(lines):
        if not capture and pattern.search(line):
            # Start capturing from this line
            capture = True
            block_lines.append(line.strip())
            # A charge block is only written when some atom actually carries a formal charge, so a neutral
            # molecule's title is a single line with no bracket to close. Waiting for one made every neutral
            # compound read to the line cap and fail; if the title opens no block, it IS the whole block.
            if '[' not in line:
                break
            if ']' in line or '}' in line:
                break
            continue

        if capture:
            block_lines.append(line.strip())
            if ']' in line or '}' in line:
                break
            if len(block_lines) >= _SERIALIZED_BLOCK_MAX_LINES:
                raise ValueError(f"Serialized block not closed within {_SERIALIZED_BLOCK_MAX_LINES} lines in {log_file}  -- file may be truncated or malformed.")

    if not block_lines:
        raise ValueError(f"Serialized block not found for {compound_name} conformer {conformer_number}")

    # Join all lines and remove whitespace/newlines inside the block
    full_block = ''.join(block_lines)
    full_block = re.sub(r'\s+', '', full_block)

    return full_block

def write_v3000_sdf(output_path, compound_name, conformer_number, elements, coordinates, connectivity, per_atom_charges, boltzmann_population=None):
    # connectivity must be in the format returned by parse_serialized_connectivity_and_charges:
    #   {atom_index: [(neighbor_index, bond_order), ...]}
    # Do NOT pass the plain {atom_index: [neighbor_index, ...]} format from parse_sdf_connectivity  -- that format has no bond orders and would silently produce an SDF with all bonds typed as 1
    # boltzmann_population=None when called during SDF reconstruction in main()  -- population is not yet known at that point
    # replace_coordinates_in_sdf overwrites the header with the correct value later
    # If replace_coordinates_in_sdf fails for a conformer, the header will read "Boltzmann Population: N/A" rather than a misleading 0.00%, making the failure visible to downstream users
    num_atoms = len(elements)
    if len(coordinates) != num_atoms:
        raise ValueError(f"Coordinate count ({len(coordinates)}) does not match element count ({num_atoms}) for {compound_name} conformer {conformer_number}  -- log file may be truncated.")

    # Collect unique bonds using a dict keyed by canonical (atom1, atom2) pair to avoid duplicates
    # If the same bond appears with two different orders (indicates a bug upstream), last write wins
    bond_dict = {}
    for atom1, neighbors in connectivity.items():
        for atom2, bond_order in neighbors:
            key = tuple(sorted((atom1, atom2)))
            if key in bond_dict and bond_dict[key] != bond_order:
                # Keep the higher bond order as the more chemically informative value, but warn  -- conflicting orders indicate a bug in upstream serialization
                resolved = max(bond_dict[key], bond_order)
                print(f"Warning: conflicting bond orders for atoms {key[0]}-{key[1]} ({bond_dict[key]} vs {bond_order})  -- this indicates a bug in connectivity serialization. Using higher order ({resolved}); verify output manually.")
                bond_dict[key] = resolved
            else:
                bond_dict[key] = bond_order
    bond_set = [(k[0], k[1], v) for k, v in bond_dict.items()]
    num_bonds = len(bond_set)

    boltzmann_str = "N/A"  # Overwritten later by replace_coordinates_in_sdf with the raw Gibbs free energy

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(f"Generated by JSW NMR Gaussian Parsing Script\n")
        f.write(f"{compound_name} Conformer {conformer_number}\n")
        f.write(f"Total Gibbs Free Energy (Hartrees): {boltzmann_str}\n")
        f.write(f"  0  0  0  0  0  0            999 V3000\n")
        f.write("M  V30 BEGIN CTAB\n")
        f.write(f"M  V30 COUNTS {num_atoms} {num_bonds} 0 0 0\n")
        f.write("M  V30 BEGIN ATOM\n")

        # Write atoms with coordinates and charges
        # per_atom_charges keys are 1-based atom indices (consistent with Gaussian output and the enumeration below)
        # Out-of-bounds keys are warned here and silently dropped via .get(i, 0)  -- both behaviors are co-located for clarity
        out_of_bounds_keys = [key for key in per_atom_charges if key < 1 or key > num_atoms]
        for key in out_of_bounds_keys:
            print(f"Warning: per_atom_charges contains out-of-bounds atom index {key} (valid range 1-{num_atoms})  -- charge will be ignored. Check the GJF serialization for {compound_name} conformer {conformer_number}.")
        for i, (element, (x, y, z)) in enumerate(zip(elements, coordinates), start=1):
            charge = per_atom_charges.get(i, 0)
            charge_str = f" CHG={charge}" if charge != 0 else ""
            f.write(f"M  V30 {i} {element} {x:.6f} {y:.6f} {z:.6f}{charge_str}\n")

        f.write("M  V30 END ATOM\n")
        f.write("M  V30 BEGIN BOND\n")

        # Write bonds with bond orders
        # Note: bond_order 1.5 cannot appear here in the reconstruction path since serialized bonds are stored as integers (1, 2, 3); the 1.5 check is retained for safety if this function is ever called with normalized bond orders from normalize_aromatic_bonds
        for idx, (atom1, atom2, bond_order) in enumerate(sorted(bond_set), start=1):
            # Aromatic arrives two ways and both mean MDL bond type 4: as the fractional order 1.5, which is
            # how an input SDF expresses it, and as the code 4 itself, which is what the Wiberg classifier
            # returns. Accepting only 1.5 meant every aromatic bond derived from the Wiberg matrix was
            # rejected as "unusual" and written as a single bond -- so aromatic rings came out fully
            # single-bonded even though the matrix had been read correctly.
            if abs(bond_order - 1.5) < 0.01 or abs(bond_order - 4.0) < 0.01:
                bond_type = 4  # V3000 SDF aromatic bond type
            else:
                rounded = int(round(bond_order))
                if abs(bond_order - rounded) > 0.01:
                    print(f"Warning: non-standard bond order {bond_order} between atoms {atom1}-{atom2}, rounding to {rounded}")
                bond_type = rounded
                if bond_type not in {1, 2, 3}:
                    # Anything else is not expected in NMR-relevant organic molecules
                    print(f"Warning: unusual bond order {bond_order} between atoms {atom1}-{atom2}, defaulting to single bond")
                    bond_type = 1
            f.write(f"M  V30 {idx} {bond_type} {atom1} {atom2}\n")

        f.write("M  V30 END BOND\n")
        f.write("M  V30 END CTAB\n")
        f.write("M  END\n")

def parse_sdf_connectivity(sdf_file):
    """
    Connectivity, atom types and total charge from an SDF, for either connection table version.

    Returns ({atom: [neighbour, ...]}, [element, ...], total_charge) with 1-based atom numbers.

    V3000 was the only format handled originally, which was safe because the files reaching this in the normal
    flow are written by write_v3000_sdf. It returned an EMPTY result for a valid V2000 file rather than
    raising, though, so any future caller handed one would get a silently empty molecule -- no connectivity,
    no atoms, no error. Both formats are read now, and an unrecognized file says so instead of looking empty.
    """
    connectivity = {}
    atom_types = []
    total_charge = 0  # Store total molecular charge

    with open(sdf_file, 'r', errors='replace') as file:
        lines = file.readlines()

    if not any('V30' in line for line in lines[:200]):
        return _parse_sdf_connectivity_v2000(lines, sdf_file)

    reading_atoms = False
    reading_bonds = False

    for line in lines:
        line = line.strip()

        # Detect ATOM section
        if "BEGIN ATOM" in line:
            reading_atoms = True
            continue
        elif "END ATOM" in line:
            reading_atoms = False
            continue

        # Detect BOND section
        if "BEGIN BOND" in line:
            reading_bonds = True
            continue
        elif "END BOND" in line:
            reading_bonds = False
            continue

        # Parse ATOM lines
        if reading_atoms and line.startswith("M  V30"):
            parts = line.split()
            if len(parts) >= 7:
                atom_index = int(parts[2])  # Atom index as integer
                element = parts[3]  # Element symbol
                atom_types.append(element)  # Store element type

                # Initialize connectivity mapping
                connectivity[atom_index] = []

                # Extract charge if present (CHG=<integer>)
                charge_match = re.search(r"CHG=(-?\d+)", line)
                atom_charge = int(charge_match.group(1)) if charge_match else 0
                total_charge += atom_charge  # Accumulate molecular charge

        # Parse BOND lines
        if reading_bonds and line.startswith("M  V30"):
            parts = line.split()
            if len(parts) >= 5:
                atom1 = int(parts[4])  # First atom index
                atom2 = int(parts[5])  # Second atom index

                # Store connectivity as integers (no bond order)
                if atom1 in connectivity:
                    connectivity[atom1].append(atom2)  # Store only atom indices
                if atom2 in connectivity:
                    connectivity[atom2].append(atom1)  # Store only atom indices

    return connectivity, atom_types, total_charge


def _parse_sdf_connectivity_v2000(lines, sdf_file):
    """
    The V2000 branch: fixed-width atom block, then a bond block, then optional M CHG property lines.

    Counts come from the counts line rather than from scanning, because a V2000 file has no explicit section
    markers -- the atom block is simply the next N lines and the bond block the M lines after that.
    """
    connectivity = {}
    atom_types = []
    total_charge = 0

    counts_index = None
    for index, line in enumerate(lines[:12]):
        if line.strip().upper().endswith('V2000'):
            counts_index = index
            break
    if counts_index is None:
        print(f"  Warning: {os.path.basename(sdf_file)} has no recognizable V2000 or V3000 counts line; "
              f"no connectivity could be read from it.")
        return {}, [], 0

    try:
        atom_count = int(lines[counts_index][0:3])
        bond_count = int(lines[counts_index][3:6])
    except (ValueError, IndexError):
        print(f"  Warning: could not read the atom and bond counts from {os.path.basename(sdf_file)}.")
        return {}, [], 0

    for offset in range(atom_count):
        position = counts_index + 1 + offset
        if position >= len(lines):
            break
        parts = lines[position].split()
        if len(parts) < 4:
            break
        atom_types.append(parts[3])
        connectivity[offset + 1] = []

    for offset in range(bond_count):
        position = counts_index + 1 + atom_count + offset
        if position >= len(lines):
            break
        line = lines[position]
        try:
            # Fixed-width fields, since an unpadded bond line can run its columns together
            atom1, atom2 = int(line[0:3]), int(line[3:6])
        except (ValueError, IndexError):
            parts = line.split()
            if len(parts) < 2:
                break
            try:
                atom1, atom2 = int(parts[0]), int(parts[1])
            except ValueError:
                break
        if atom1 in connectivity:
            connectivity[atom1].append(atom2)
        if atom2 in connectivity:
            connectivity[atom2].append(atom1)

    # Formal charges live on M CHG property lines rather than on the atom lines
    for line in lines:
        if line.startswith('M  CHG'):
            parts = line.split()
            try:
                entries = int(parts[2])
            except (IndexError, ValueError):
                continue
            for entry in range(entries):
                try:
                    total_charge += int(parts[4 + 2 * entry])
                except (IndexError, ValueError):
                    break

    return connectivity, atom_types, total_charge


def calculate_relative_energies(energies):
    min_energy = min(energies)
    return [(energy - min_energy) * HARTREE_TO_KCAL for energy in energies]

def calculate_boltzmann_populations(relative_energies, temperature):
    """Calculate Boltzmann populations at given temperature."""
    if temperature <= 0:
        raise ValueError(f"Temperature must be positive, got {temperature} K  -- check that the log file temperature is valid.")
    if not all(math.isfinite(e) for e in relative_energies):
        raise ValueError(f"Non-finite relative energy detected: {relative_energies}  -- check log files for corrupted energy values.")
    boltzmann_factors = [math.exp(-energy / (R * temperature)) for energy in relative_energies]
    zero_factor_indices = [i for i, f in enumerate(boltzmann_factors) if f == 0.0]
    if zero_factor_indices:
        zero_energies = [relative_energies[i] for i in zero_factor_indices]
        print(f"Warning: {len(zero_factor_indices)} conformer(s) have negligible Boltzmann weight (relative energies: {zero_energies} kcal/mol  -- too large or floating-point underflow in exp())  -- these conformers will contribute zero weight.")
    partition_function = sum(boltzmann_factors)
    if partition_function == 0:
        raise ValueError("Partition function is zero  -- all Boltzmann factors underflowed to 0.0. Check that relative energies are in kcal/mol (not Hartrees), temperature is in Kelvin, and that no NaN or infinite energies are present. If energies are very large (>50 kcal/mol relative), floating-point underflow in exp() may be the cause.")
    return [factor / partition_function for factor in boltzmann_factors]

def convert_to_chemical_shift(isotropic_shieldings, slope, intercept):
    # Formula assumes scaling was fit as sigma_calc = slope * delta_exp + intercept (shielding as a function of shift  -- the standard computational NMR convention)
    # Rearranged: delta_calc = (sigma_calc - intercept) / slope
    # All scaling factor sets in this script use this convention
    # If adding new scaling factors fit in the opposite direction (delta = slope * sigma + intercept), a separate conversion function is needed
    return {atom_number: (isotropic_shielding - intercept) / slope 
            for atom_number, isotropic_shielding in isotropic_shieldings.items()}

def parse_log_file_frequencies(file_path, conformer_number, compound_name, method_key):
    # Check cache first
    cache_key = (file_path, conformer_number, compound_name, method_key)
    if cache_key in _frequency_cache:
        return _frequency_cache[cache_key]
    
    # Read entire file at once (served from the log content cache when running in the main process)
    content = read_log_text(file_path)
    
    frequencies = []
    red_masses = []
    frc_consts = []
    ir_intensities = []
    significant_imaginary_count = 0
    invalid_conformer = False

    freq_pattern = _FREQ_PATTERNS['frequencies']
    red_mass_pattern = _FREQ_PATTERNS['red_masses']
    frc_const_pattern = _FREQ_PATTERNS['frc_consts']
    ir_inten_pattern = _FREQ_PATTERNS['ir_inten']

    section_marker = f"{compound_name}_{conformer_number}_carbon"
    
    # Check for errors and section marker first (faster)
    section_found = section_marker in content
    invalid_conformer = (
        "Convergence failure" in content or
        "Error termination" in content or
        not section_found
    )

    # Use findall on entire content (much faster than line-by-line)
    for match in freq_pattern.finditer(content):
        freq_values = [float(match.group(i)) for i in range(1, 4)]
        frequencies.extend(freq_values)
        significant_imaginary_count += sum(1 for freq in freq_values if freq < IMAGINARY_FREQUENCY_THRESHOLD)
    
    for match in red_mass_pattern.finditer(content):
        red_masses.extend([float(match.group(i)) for i in range(1, 4)])
    
    for match in frc_const_pattern.finditer(content):
        frc_consts.extend([float(match.group(i)) for i in range(1, 4)])
    
    for match in ir_inten_pattern.finditer(content):
        ir_intensities.extend([float(match.group(i)) for i in range(1, 4)])

    result = (frequencies, red_masses, frc_consts, ir_intensities, significant_imaginary_count, invalid_conformer)

    _frequency_cache[cache_key] = result
    return result

def identify_valid_conformers(compound_name):
    valid_conformers = []
    
    # Use cached pattern if available
    if compound_name not in _PATTERN_CACHE:
        _PATTERN_CACHE[compound_name] = re.compile(rf"^{re.escape(compound_name)}_(\d+)\.log$")
    pattern = _PATTERN_CACHE[compound_name]
    
    conformer_files = []
    for f in os.listdir():
        match = pattern.match(f)
        if match:
            conformer_number = int(match.group(1))
            conformer_files.append((f, conformer_number))
            
    # Sort by conformer number
    conformer_files.sort(key=lambda x: x[1])

    for log_file, conformer_number in conformer_files:
        # Read file once for method key detection and error checking
        content, lines = read_log_text_and_lines(log_file)
        method_key = detect_method_parameters(lines, compound_name)

        # Pre-populate the frequency cache to avoid re-reading the file inside parse_log_file_frequencies  -- content is already in memory
        cache_key = (log_file, conformer_number, compound_name, method_key)
        if cache_key not in _frequency_cache:
            # Pre-populate cache using already-read content to avoid a second file read
            frequencies_local = []
            red_masses_local = []
            frc_consts_local = []
            ir_intensities_local = []
            sig_imag_local = 0
            section_marker = f"{compound_name}_{conformer_number}_carbon"
            section_found = section_marker in content
            invalid_local = (
                "Convergence failure" in content or
                "Error termination" in content or
                not section_found
            )
            for match in _FREQ_PATTERNS['frequencies'].finditer(content):
                fvals = [float(match.group(i)) for i in range(1, 4)]
                frequencies_local.extend(fvals)
                sig_imag_local += sum(1 for f in fvals if f < IMAGINARY_FREQUENCY_THRESHOLD)
            for match in _FREQ_PATTERNS['red_masses'].finditer(content):
                red_masses_local.extend([float(match.group(i)) for i in range(1, 4)])
            for match in _FREQ_PATTERNS['frc_consts'].finditer(content):
                frc_consts_local.extend([float(match.group(i)) for i in range(1, 4)])
            for match in _FREQ_PATTERNS['ir_inten'].finditer(content):
                ir_intensities_local.extend([float(match.group(i)) for i in range(1, 4)])
            _frequency_cache[cache_key] = (
                frequencies_local, red_masses_local, frc_consts_local,
                ir_intensities_local, sig_imag_local, invalid_local
            )

        frequencies, _, _, _, significant_imaginary_count, invalid_conformer = parse_log_file_frequencies(
            log_file, conformer_number, compound_name, method_key
        )
        
        if significant_imaginary_count == 0 and not invalid_conformer:
            valid_conformers.append(conformer_number)
        else:
            if log_file not in excluded_conformers:
                # Provide specific error messages
                reasons = []
                if significant_imaginary_count > 0:
                    reasons.append(f"{significant_imaginary_count} significant imaginary frequenc{'y' if significant_imaginary_count == 1 else 'ies'}")
                if invalid_conformer:
                    # Check what type of error it was (content already read above)
                    error_found = False
                    if "Convergence failure -- run terminated." in content:
                        reasons.append("a convergence failure")
                        error_found = True
                    if "Error termination" in content:
                        reasons.append("an error termination")
                        error_found = True

                    # If invalid but no specific error found, it's likely a naming issue
                    if not error_found:
                        reasons.append("improper naming (calculation section not found)")
                
                reason_str = " and ".join(reasons) if reasons else "unknown issue"
                print(f"Excluding {log_file} due to {reason_str}.")
                excluded_conformers.add(log_file)

    return valid_conformers

UNKNOWN_METHOD_KEY = 'unknown'
# Stands in when a log carries no method number, which is now the normal case: the number is no longer written
# into job titles because nothing downstream needs it. A value that cannot collide with a real method key is
# used deliberately -- borrowing an existing one ('6', say) would make a genuine custom-method log and an
# unidentifiable log indistinguishable everywhere below, and any table lookup would then quietly return the
# wrong constants instead of failing. Every remaining consumer either tolerates it or raises on it explicitly.


def detect_method_parameters(lines, compound_name=None):
    # Anchors from the right end of the job title token: _(\d+)(job_type)$
    # This avoids false matches from unusual compound names containing digits followed by job type keywords
    # The naming scheme guarantees method_key and job_type are always the rightmost underscore-delimited fields
    # compound_name=None fallback is retained for potential standalone use but is less robust; always pass compound_name in production
    # Older logs carry a method number in their titles; newer ones do not, and its absence is normal.
    # Note: (?:[^a-zA-Z]|$) ensures the job type is not followed by a letter but does not anchor to end-of-token strictly
    # A compound named e.g. compound_12_1opt_extra would still match  -- acceptable given the controlled naming scheme
    for line in lines:
        if compound_name:
            match = re.search(
                rf'(?<![A-Za-z0-9_]){re.escape(compound_name)}-?(?:csulfur|chalogen)?_\d+_(?:(\d+))?(opt|carbon|proton|fluorine|nitrogen|cc|csulfur|chalogen)(?:[^a-zA-Z]|$)',
                line, re.IGNORECASE
            )
        else:
            match = re.search(r'_(\d+)(opt|carbon|proton|fluorine|nitrogen)(?:[^a-zA-Z]|$)', line, re.IGNORECASE)
        if match:
            return match.group(1)
    return None

def generate_pymol_script(compound_name, chemical_shifts, structure_data, special_replacements=None, weighted_shifts=None, first_conformer_num=1):
    if not ngp_output_enabled('pymol_script'):
        return None  # Output suppressed by the 'pymol_script' switch; every retained output is unaffected
    connectivity = structure_data['simple_connectivity']
    atom_types = structure_data['atom_types']

    if special_replacements is None:
        special_replacements = {}
    if weighted_shifts is None:
        weighted_shifts = {}

    os.makedirs(compound_name, exist_ok=True)  # Ensure output directory exists

    script_lines = [
        f"load {compound_name}_{first_conformer_num}.sdf\n",
        "hide everything\n",
        "show sticks\n",
        "\n# Adding chemical shifts as labels\n"
    ]

    # Label all atoms with their shifts (already averaged by equivalence)
    for atom_number in chemical_shifts:
        if isinstance(chemical_shifts[atom_number], tuple):
            label_text, shift = chemical_shifts[atom_number]
        else:
            shift = chemical_shifts[atom_number]
            label_text = f"Atom {atom_number}"
        
        # Use special replacement shift if available
        if atom_number in special_replacements:
            shift = weighted_shifts.get(atom_number, shift)
            comment = f" # Replaced by {special_replacements[atom_number]} results"
        else:
            comment = ""
        
        script_lines.append(f"label id {atom_number}, '{shift:.2f}'{comment}\n")

    # Adding the visualization settings
    script_lines.extend([
        "\n# Set background color to black\n",
        "bg_color black\n",
        "\n# Set licorice stick radius\n",
        "set stick_radius, 0.15\n",
        "\n# Set atom colors\n",
        "set_color dark_grey, [0.5, 0.5, 0.5]\n",
        "set_color bright_grey, [0.8, 0.8, 0.8]\n",
        "set_color deep_blue, [0.0, 0.0, 0.8]\n",
        "set_color deep_red, [0.8, 0.0, 0.0]\n",
        "set_color light_pink, [1.0, 0.75, 0.8]\n",
        "color dark_grey, elem C\n",
        "color bright_grey, elem H\n",
        "color deep_blue, elem N\n",
        "color deep_red, elem O\n",
        "color light_pink, elem F\n",
        "\n# Set label properties\n",
        "set label_font_id, 5\n",
        "set label_size, 15\n",
        "\n# Set label color\n",
        "set_color deep_gold, [1.0, 0.8, 0.0]\n",
        "set label_color, deep_gold\n",
        "\n# General settings for enhanced visual quality\n",
        "set antialias_shader, 2\n",
        "set line_smooth, 1\n",
        "set specular, 1.00000\n",
        "set use_shaders, 0\n",
        "set stick_use_shader, 1\n",
        "set render_as_cylinders, 1\n",
        "set line_as_cylinders, 1\n",
        "set stick_as_cylinders, 1\n",
        "set dot_as_spheres, 1\n",
        "set depth_cue, 0\n",
        "\n# Apply visualization settings\n",
        "show sticks, all\n"
    ])

    with open(os.path.join(compound_name, f"{compound_name}_chemical_shifts.pml"), "w", encoding='utf-8') as f:
        f.writelines(script_lines)

def replace_coordinates_in_sdf(sdf_file, coordinates, output_file, compound_name, conformer_number, gibbs_free_energy):
    """
    Write one conformer's SDF: the compound's template with this conformer's coordinates and energy substituted.

    SCOPE NOTE: the parse_sdf_connectivity call below re-derives compound-invariant data (connectivity, atom
    types, total charge) on every conformer. That is redundant by construction -- every conformer of a compound
    shares them. It is retained because the measured cost is 0.11 s across 1400 conformers, under 1% of a run,
    and hoisting it would mean restructuring the 360-line caller. A rewrite should take the parsed template as a
    parameter instead; the compound-scoped versus conformer-scoped split everywhere else in this file already
    follows that pattern (connectivity, equivalence classes, bond orders and the alignment reference are all
    derived once per compound, with only coordinates, energies and conformer numbers varying).
    """
    if not ngp_output_enabled('conformer_sdf'):
        return None  # Output suppressed by the 'conformer_sdf' switch; every retained output is unaffected
    connectivity, atom_types, total_charge = parse_sdf_connectivity(sdf_file)
    
    with open(sdf_file, 'r') as f:
        sdf_lines = f.readlines()

    if len(sdf_lines) < 4:
        raise ValueError(f"SDF file {sdf_file} is too short to be valid.")

    # Replace only the first three lines (keep V3000 line intact)
    sdf_lines[0] = "Generated by JSW NMR Gaussian Parsing script.\n"
    sdf_lines[1] = f"Compound: {compound_name} Conformer: {conformer_number}\n"
    if gibbs_free_energy is not None:
        sdf_lines[2] = f"Total Gibbs Free Energy (Hartrees): {gibbs_free_energy:.10f}\n"
    else:
        sdf_lines[2] = f"Total Gibbs Free Energy (Hartrees): N/A\n"

    # Locate the "M  END" line
    end_index = None
    for i, line in enumerate(sdf_lines):
        if line.strip() == "M  END":
            end_index = i
            break

    if end_index is None:
        raise ValueError(f"No 'M  END' found in {sdf_file}")

    # Locate the V3000 ATOM section start
    v3000_start = None
    for i, line in enumerate(sdf_lines):
        if "BEGIN ATOM" in line:
            v3000_start = i
            break

    if v3000_start is None:
        raise ValueError(f"No 'V3000' ATOM section found in {sdf_file}")

    # Preserve V3000 line (line 4) and update ATOM coordinates
    atom_index = 0
    for i in range(v3000_start + 1, end_index):  # Only modify within the ATOM section
        line = sdf_lines[i].strip()
        if "END ATOM" in line:
            break  # Stop at the end of the ATOM section

        if line.startswith("M  V30"):  # Ensure correct spacing
            parts = line.split()
            # parts[1] == "V30" is always true given startswith("M  V30"); real guard is len(parts) >= 7
            # Malformed lines (< 7 parts) are skipped without incrementing atom_index  -- correct behavior
            if len(parts) >= 7 and parts[1] == "V30":
                atom_index += 1
                new_x, new_y, new_z = coordinates[atom_index - 1]  # Zero-based index correction
                parts[4] = f"{new_x:.6f}"
                parts[5] = f"{new_y:.6f}"
                parts[6] = f"{new_z:.6f}"
                formatted_line = "M  V30 " + " ".join(parts[2:])  # Ensure two spaces after M
                sdf_lines[i] = formatted_line + "\n"

    # Keep only lines up to "M  END" (remove everything after)
    sdf_lines = sdf_lines[:end_index + 1]

    # Write the modified SDF content to the output file
    with open(output_file, 'w', encoding='utf-8') as f:
        f.writelines(sdf_lines)

def print_method_key_message(method_key):
    messages = {
        '1': "Method 1 (DELTA50: Chloroform) detected.",
        '2': "Method 2 (DELTA50: DMSO) detected.",
        '3': "Method 3 (Pierens: Methanol) detected.",
        '4': "Method 4 (DELTA50: Acetonitrile) detected.",
        '5': "Method 5 (Pierens: Water) detected.",
    }
    if method_key in messages:
        print(messages[method_key])

def process_files(compound_name, success_flag, sdf_file=None, temperature=298.0):
    # Record which compound is being processed so the output switches resolve to its own selection
    globals()['NGP_ACTIVE_COMPOUND'] = compound_name
    # Note: sdf_file=None default is vestigial from an earlier design where SDF files were optional
    # In current main() flow, a reconstructed SDF is always passed; the None branch is unreachable in normal operation

    pymol_labels = {}   # Initialized to satisfy linters; populated before the final return
    weighted_shifts = {}  # Initialized to satisfy linters; populated before the final return

    if sdf_file is None:
        # Unreachable in normal main() flow  -- retained as a safety net for standalone or future use
        # Consider replacing with raise RuntimeError(...) if this branch should never be hit in production
        print(f"No SDF file available for {compound_name}. Skipping.")
        return None

    # Exclusion reason messages will be suppressed for files already excluded by process_files (intentional deduplication)
    # If process_frequencies is ever called standalone, exclusion reasons will print correctly
    valid_conformers = identify_valid_conformers(compound_name)
    
    if not valid_conformers:
        print(f"No valid conformers for {compound_name}. Skipping this compound.")
        return None
    
    # Parse non-changing structural characteristics once
    print(f"Extracting structural data for {compound_name}...")
    try:
        structure_data = extract_compound_structure(compound_name, valid_conformers[0], valid_conformers)
    except Exception as e:
        print(f"Error: Could not extract structural data for {compound_name}: {e}")
        print(f"  This usually means the log file is missing an 'Initial Parameters' section or a valid serialized block.")
        return None

    # extract_compound_structure returns None when equivalence detection fails. Everything downstream indexes
    # into structure_data, so this has to stop here rather than surfacing later as an opaque TypeError.
    if structure_data is None:
        print(f"Skipping {compound_name}: structural data could not be established.")
        return None

    method_key = None
    custom_scaling = None
    
    # Detect method key and custom scaling from first conformer
    log_file = f"{compound_name}_{valid_conformers[0]}.log"
    method_key = detect_method_parameters(read_log_lines(log_file), compound_name)

    # A method number is no longer written into job titles: sections are found by job type and every scaled
    # job carries its own factors, so nothing downstream requires it. Older logs still have one and it is
    # used where present; its absence is normal and must not skip the compound.
    if method_key is None:
        method_key = UNKNOWN_METHOD_KEY
    else:
        print_method_key_message(method_key)

    # Scaling factors are read from the job titles for EVERY method, not only the custom one. The titles record
    # the factors that were actually used when the jobs were written, so a method defined in the configuration
    # file, or one whose constants were edited between submission and analysis, still scales by the numbers that
    # produced the shieldings rather than by whatever a local table says today.
    carbon_slope, carbon_intercept = None, None
    proton_slope, proton_intercept = None, None

    for line in read_log_lines(log_file):
        if f"{compound_name}_{valid_conformers[0]}_carbon" in line and "s:" in line and "i:" in line and carbon_slope is None:
            match = re.search(r's:([-+]?[0-9]*\.?[0-9]+)\s+i:([-+]?[0-9]*\.?[0-9]+)', line)
            if match:
                carbon_slope = float(match.group(1))
                carbon_intercept = float(match.group(2))
        if f"{compound_name}_{valid_conformers[0]}_proton" in line and "s:" in line and "i:" in line and proton_slope is None:
            match = re.search(r's:([-+]?[0-9]*\.?[0-9]+)\s+i:([-+]?[0-9]*\.?[0-9]+)', line)
            if match:
                proton_slope = float(match.group(1))
                proton_intercept = float(match.group(2))
        if carbon_slope is not None and proton_slope is not None:
            break

    if carbon_slope is not None and proton_slope is not None:
        custom_scaling = {
            'carbon': {'slope': carbon_slope, 'intercept': carbon_intercept},
            'proton': {'slope': proton_slope, 'intercept': proton_intercept}
        }
        print(f"  Scaling factors read from the job titles: carbon s={carbon_slope} i={carbon_intercept}, "
              f"proton s={proton_slope} i={proton_intercept}")
    else:
        # Logs written before scaling factors travelled in the title still analyse, using the built-in table
        print("  No scaling factors in the job titles (a log from an earlier version); using the built-in "
              "table for this method.")

    # Prepare arguments for parallel processing
    worker_args = [
        (compound_name, i, method_key, custom_scaling, structure_data)
        for i in valid_conformers
    ]
    
    # Process conformers in parallel (only if worthwhile, and never from inside the interface -- see
    # RUNNING_UNDER_GUI for why)
    if ENABLE_PARALLEL_PROCESSING and not RUNNING_UNDER_GUI and len(valid_conformers) > 3:
        with Pool(processes=min(_OPTIMAL_PROCESSORS or cpu_count(), len(valid_conformers))) as pool:
            results = pool.map(process_single_conformer_worker, worker_args)
    else:
        results = [process_single_conformer_worker(args) for args in worker_args]

    # Collect results
    energies = []
    conformers_with_energy = [] # Track which conformers have valid energies
    coordinates_by_conformer = {}  # Final optimized geometries, used by the deduplication step below
    carbon_shifts = {}
    proton_shifts = {}
    fluorine_shifts = {}
    nitrogen_shifts = {}
    coupling_constants_list = []
    
    for result in results:
        if result['success']:
            i = result['conformer_num']
            if result['energy'] is not None:
                energies.append(result['energy'])
                conformers_with_energy.append(i)
            if result.get('coordinates'):
                coordinates_by_conformer[i] = result['coordinates']
            carbon_shifts[i] = result['carbon_shifts']
            proton_shifts[i] = result['proton_shifts']
            if result['fluorine_shifts']:
                fluorine_shifts[i] = result['fluorine_shifts']
            if result['nitrogen_shifts']:
                nitrogen_shifts[i] = result['nitrogen_shifts']
            if result['coupling_constants']:
                coupling_constants_list.append((i, result['coupling_constants']))
        else:
            print(f"  Warning: conformer {result['conformer_num']} failed and will be excluded from weighted averages.")
            print(f"  Error details: {result.get('error', 'Unknown error')}")
    
    # Raw Gibbs free energy lookup (Hartrees), built before deduplication so that the energy gate below and the
    # conformer SDF headers further down both read from the same map. It intentionally still contains any
    # conformer that is pruned below, and is only ever queried for conformers that survived
    energy_by_conformer = {conformer: energies[index] for index, conformer in enumerate(conformers_with_energy)}

    # Prune conformers that optimized to a minimum already represented by a lower-energy conformer
    # This runs before anything is written or weighted so that every product of this run  -- unweighted files,
    # conformer SDF files, distances, NOE intensities and the populations themselves  -- describes the same
    # deduplicated ensemble; the pruned conformers stay fully documented in the deduplication report
    duplicate_records = []
    if ENABLE_CONFORMER_DEDUPLICATION and len(valid_conformers) > 1:
        # Vibrational spectra for the independent frequency gate. parse_log_file_frequencies reads through the
        # log content cache and memoizes its own result, so pulling them here costs no extra file I/O and the
        # later process_frequencies call is served from the same cache
        frequencies_by_conformer = {}
        if DEDUP_ENABLE_FREQUENCY_GATE:
            for conformer_num in valid_conformers:
                try:
                    conformer_frequencies, _, _, _, _, freq_invalid = parse_log_file_frequencies(
                        f"{compound_name}_{conformer_num}.log", conformer_num, compound_name, method_key
                    )
                    if conformer_frequencies and not freq_invalid:
                        frequencies_by_conformer[conformer_num] = conformer_frequencies
                except Exception:
                    pass  # A conformer without readable frequencies simply falls back to the geometric gates

        survivors, duplicate_records, ungated_conformers, dedup_diagnostics = deduplicate_conformers(
            valid_conformers, energy_by_conformer, coordinates_by_conformer,
            structure_data['atom_types'], structure_data['simple_connectivity'],
            frequencies_by_conformer
        )
        atom_selection_summary = (
            f"all {dedup_diagnostics['atom_count']} atoms, {dedup_diagnostics['group_size']} graph-legal "
            f"relabeling(s)" + ("  [automorphism enumeration truncated at its cap]" if dedup_diagnostics['truncated'] else "")
        )
        write_deduplication_report(
            compound_name, survivors, duplicate_records, ungated_conformers, len(valid_conformers),
            atom_selection_summary, dedup_diagnostics
        )

        if ungated_conformers:
            print(f"  Note: conformer(s) {ungated_conformers} could not be geometry checked (missing Gibbs free energy or unreadable final geometry) and were retained.")

        if duplicate_records:
            removed_conformers = {record['duplicate'] for record in duplicate_records}
            print(f"  Deduplication: {len(removed_conformers)} of {len(valid_conformers)} conformer(s) optimized to a minimum already represented by a lower-energy conformer  -- removed from the ensemble.")
            _DEDUP_REMOVED_CONFORMERS[compound_name] = removed_conformers

            # Filter every collection that feeds the weighting step; energies and conformers_with_energy are
            # parallel lists and must be filtered together to stay index aligned
            valid_conformers = [conformer for conformer in valid_conformers if conformer not in removed_conformers]
            retained_energy_pairs = [
                (conformer, energy) for conformer, energy in zip(conformers_with_energy, energies)
                if conformer not in removed_conformers
            ]
            conformers_with_energy = [conformer for conformer, _ in retained_energy_pairs]
            energies = [energy for _, energy in retained_energy_pairs]
            coupling_constants_list = [
                (conformer, cc_data) for conformer, cc_data in coupling_constants_list
                if conformer not in removed_conformers
            ]
        else:
            print("  Deduplication: no duplicate minima detected.")

    # Save unweighted data
    unweighted_dir = os.path.join(compound_name, "Unweighted NMR Data")
    os.makedirs(unweighted_dir, exist_ok=True)

    # Convert to dict for O(1) lookup instead of O(n) search per conformer
    cc_by_conformer = {conf_num: cc for conf_num, cc in coupling_constants_list}

    # Pre-merge all conformer shifts once  -- reused for both unweighted output and weighted accumulation
    merged_shifts_by_conformer = {}
    for i in valid_conformers:
        if i not in carbon_shifts:
            print(f"  Warning: No carbon shifts found for conformer {i}, skipping unweighted output.")
            continue

        # Save unweighted coupling constants
        cc_data = cc_by_conformer.get(i)
        if cc_data:
            unweighted_cc_file = os.path.join(unweighted_dir, f"{compound_name}_conformer_{i}_coupling_constants.txt")
            save_coupling_constants(cc_data, unweighted_cc_file, header="Unweighted Coupling Constants (Hz):")

        # Save unweighted chemical shifts
        # Shift priority (highest to lowest): nitrogen > fluorine > proton > carbon
        # Later dicts in the merge overwrite earlier ones; warnings are printed for overlaps
        overlap_ch = set(proton_shifts[i]) & set(carbon_shifts[i])
        for atom_number in overlap_ch:
            print(f"Warning: atom {atom_number} appears in both proton and carbon shifts for conformer {i}  -- using proton shift. Check log file for parsing errors.")
        overlap_fch = set(fluorine_shifts.get(i, {})) & (set(proton_shifts[i]) | set(carbon_shifts[i]))
        for atom_number in overlap_fch:
            print(f"Warning: atom {atom_number} appears in both fluorine and C/H shifts for conformer {i}  -- using fluorine shift. Check log file for parsing errors.")
        # Note: fluorine-vs-nitrogen overlap is not checked here; nitrogen takes priority over fluorine via dict merge order
        # An atom appearing in both fluorine and nitrogen shifts would be an extreme parsing error and is not expected in valid Gaussian output
        overlap_n = set(nitrogen_shifts.get(i, {})) & (set(proton_shifts[i]) | set(carbon_shifts[i]) | set(fluorine_shifts.get(i, {})))
        for atom_number in overlap_n:
            print(f"Warning: atom {atom_number} appears in both nitrogen and C/H/F shifts for conformer {i}  -- using nitrogen shift. Check log file for parsing errors.")

        all_shifts = {
            **carbon_shifts[i],
            **proton_shifts[i],
            **fluorine_shifts.get(i, {}),
            **nitrogen_shifts.get(i, {})
        }
        merged_shifts_by_conformer[i] = all_shifts  # Cache for weighted accumulation below

        unweighted_shift_file = os.path.join(unweighted_dir, f"{compound_name}_conformer_{i}_shifts.txt")
        save_shifts(all_shifts, unweighted_shift_file, structure_data, 'unweighted')

    # Try to read populations from file first if file exists
    populations_from_file = read_boltzmann_populations_from_file(compound_name)
    
    if populations_from_file is not None:
        print(f"Using Boltzmann populations from {compound_name}_boltzmann.txt")
        
        # Filter valid_conformers to only those present in the population file
        boltzmann_conformers = [c for c in valid_conformers if c in populations_from_file]
        dropped = [c for c in valid_conformers if c not in populations_from_file]
        if dropped:
            print(f"Warning: Conformers {dropped} not found in population file  -- excluded from Boltzmann weighting.")

        if not boltzmann_conformers:
            print(f"Error: No valid conformers match the population file for {compound_name}")
            return None

        boltzmann_populations = [populations_from_file[c] for c in boltzmann_conformers]
        
        total = sum(boltzmann_populations)
        if total > 0:
            boltzmann_populations = [p/total for p in boltzmann_populations]
        else:
            print(f"Error: All populations are zero for {compound_name}")
            return None

    else:
        # Fall back to energy-based calculation
        if not energies:
            print(f"Skipping Boltzmann populations and weighted calculations for {compound_name} due to missing energies and population file.")
            return None
        
        print(f"No population file found, calculating from energies...")
        if len(conformers_with_energy) != len(valid_conformers):
            print(f"Warning: {len(valid_conformers) - len(conformers_with_energy)} conformer(s) missing energies, excluded from Boltzmann weighting.")
        relative_energies = calculate_relative_energies(energies)
        boltzmann_populations = calculate_boltzmann_populations(relative_energies, temperature)
        boltzmann_conformers = conformers_with_energy
        
    if not boltzmann_conformers:
        print(f"Warning: No conformers available for Boltzmann weighting for {compound_name}.")
        return None

    # Build population lookup dict once for O(1) access
    population_by_conformer = {conf: boltzmann_populations[idx] for idx, conf in enumerate(boltzmann_conformers)}

    # The raw Gibbs free energy lookup used for the SDF headers below was built before deduplication

    # Generate optimized SDF files
    conformer_sdf_dir = os.path.join(compound_name, "Conformer SDF Files")
    os.makedirs(conformer_sdf_dir, exist_ok=True)
    # SCOPE NOTE (relevant to any rewrite): only the coordinates and the energy vary per conformer here. The
    # template's connectivity, atom types and charges are compound-invariant, but replace_coordinates_in_sdf
    # re-derives them from the template file on every pass. Measured at 0.11 s across 1400 conformers -- under
    # 1% of a typical run -- so it is left alone rather than restructuring this function for it. In a rewrite,
    # parse the template once per compound and pass it in.
    for i in boltzmann_conformers:
        conformer_sdf_file = os.path.join(conformer_sdf_dir, f"{compound_name}_{i}.sdf")
        try:
            coordinates = extract_standard_orientation(f"{compound_name}_{i}.log")
            replace_coordinates_in_sdf(sdf_file, coordinates, conformer_sdf_file, compound_name, i, energy_by_conformer.get(i))
        except Exception as e:
            print(f"Error processing {compound_name}_{i}.log: {e}")
    
    print("Generated final SDF file(s) with optimized geometries and Boltzmann populations.")
    
    # Calculate weighted shifts
    weighted_shifts = defaultdict(float)
    weighted_coupling_constants = defaultdict(dict)

    for i in boltzmann_conformers:
        pop = population_by_conformer[i]
        for atom_number, shift in merged_shifts_by_conformer.get(i, {}).items():
            weighted_shifts[atom_number] += shift * pop

    # Note: coupling constants absent in a conformer are treated as zero for Boltzmann weighting
    # This means couplings that only exist in some conformers will be weighted by their fractional population, not normalized to conformers where they exist
    for conformer_index, cc_data in coupling_constants_list:
        pop = population_by_conformer.get(conformer_index)
        if pop is None:
            continue
        for primary_atom in cc_data.keys():
            for secondary_atom, value in cc_data[primary_atom].items():
                if primary_atom not in weighted_coupling_constants or secondary_atom not in weighted_coupling_constants[primary_atom]:
                    weighted_coupling_constants[primary_atom][secondary_atom] = 0
                weighted_coupling_constants[primary_atom][secondary_atom] += value * pop

    if len(weighted_shifts) == 0:
        print(f"Warning: No weighted shifts computed for {compound_name}  -- all conformer populations may be zero or no conformers had parseable shifts.")
        return None

    os.makedirs(compound_name, exist_ok=True)
    
    with open(os.path.join(compound_name, f"{compound_name}_boltzmann_populations.txt"), 'w', encoding='utf-8') as f:
        f.write("Boltzmann Populations:\n")
        for i, population in enumerate(boltzmann_populations):
            f.write(f"Conformer {boltzmann_conformers[i]}: {population:.2%}\n")
        if duplicate_records:
            # Prefixed with '#' so the line stays inert if this file is ever reused as a {compound}_boltzmann.txt input
            f.write(f"\n# {len(duplicate_records)} conformer(s) removed as duplicate minima before weighting; see {compound_name}_conformer_deduplication.txt\n")

    # Write raw energies file in the same format for all valid conformers with energies
    with open(os.path.join(compound_name, f"{compound_name}_raw_energies.txt"), 'w', encoding='utf-8') as f:
        f.write("Raw Energies (Hartrees):\n")
        for i, conf_num in enumerate(boltzmann_conformers):
            # Find the energy for this conformer from the energies list
            # boltzmann_conformers and energies are aligned when populations_from_file is None;
            # when populations come from file, energies may not align, so use conformers_with_energy index
            if populations_from_file is not None:
                # Energy may not be available for file-based populations; look up by conformer number
                if conf_num in conformers_with_energy:
                    energy_idx = conformers_with_energy.index(conf_num)
                    f.write(f"Conformer {conf_num}: {energies[energy_idx]:.10f}\n")
                else:
                    f.write(f"Conformer {conf_num}: N/A\n")
            else:
                f.write(f"Conformer {conf_num}: {energies[i]:.10f}\n")

    weighted_shift_file = os.path.join(compound_name, f"{compound_name}_weighted_shifts.txt")
    pymol_labels = save_shifts(weighted_shifts, weighted_shift_file, structure_data, 'weighted')

    print(f"Saved chemical shifts.")

    if weighted_coupling_constants:
        output_file = os.path.join(compound_name, f"{compound_name}_weighted_coupling_constants.txt")
        save_coupling_constants(weighted_coupling_constants, output_file, header="Weighted Coupling Constants (Hz):")
        print(f"Saved coupling constants.")

    process_sdf_files(compound_name, structure_data)
    boltzmann_weight_distances(compound_name, population_by_conformer, structure_data)
    print(f"Saved atomic distances and NOE intensities.")
    
    success_flag['flag'] = True  # Mark at least one successful analysis
    return pymol_labels, structure_data, weighted_shifts
    
def process_single_frequency_worker(args):
    """
    Worker function to extract frequency data from a single log file.
    """
    log_file, conformer_num, compound_name, method_key = args
    
    try:
        frequencies, red_masses, frc_consts, ir_intensities, significant_imaginary_count, invalid_conformer = parse_log_file_frequencies(
            log_file, conformer_num, compound_name, method_key
        )
        
        return {
            'log_file': log_file,
            'frequencies': frequencies,
            'red_masses': red_masses,
            'frc_consts': frc_consts,
            'ir_intensities': ir_intensities,
            'significant_imaginary_count': significant_imaginary_count,
            'success': True
        }
        
    except Exception as e:
        return {
            'log_file': log_file,
            'success': False,
            'error': str(e)
        }

def process_frequencies(compound_name, success_flag):
    """
    Optimized frequency extraction with parallel processing.
    """
    if not ngp_output_enabled('frequencies'):
        return None  # Output suppressed by the 'frequencies' switch; every retained output is unaffected
    valid_conformers = identify_valid_conformers(compound_name)

    if not valid_conformers:
        return

    # Detect method key from first valid conformer
    method_key = detect_method_parameters(
        read_log_lines(f"{compound_name}_{valid_conformers[0]}.log"), compound_name
    )

    frequency_dir = os.path.join(compound_name, "Frequencies")
    os.makedirs(frequency_dir, exist_ok=True)

    # Prepare arguments for parallel processing
    worker_args = [
        (f"{compound_name}_{i}.log", i, compound_name, method_key)
        for i in valid_conformers
    ]
    
    # Process frequencies in parallel (never from inside the interface -- see RUNNING_UNDER_GUI)
    if ENABLE_PARALLEL_PROCESSING and not RUNNING_UNDER_GUI and len(valid_conformers) > 1:
        with Pool(processes=min(_OPTIMAL_PROCESSORS or cpu_count(), len(valid_conformers))) as pool:
            results = pool.map(process_single_frequency_worker, worker_args)
    else:
        results = [process_single_frequency_worker(args) for args in worker_args]

    # Collect all output data first (batch preparation)
    output_data = []
    
    for result in results:
        if result['success']:
            log_file = result['log_file']
            frequencies = result['frequencies']
            red_masses = result['red_masses']
            frc_consts = result['frc_consts']
            ir_intensities = result['ir_intensities']
            significant_imaginary_count = result['significant_imaginary_count']
            
            output_file_name = os.path.join(frequency_dir, log_file.replace('.log', '_frequencies.txt'))
            
            # Build content in memory using StringIO
            content = StringIO()
            content.write(f"File: {log_file}\n")
            content.write(f"Number of significant imaginary frequencies: {significant_imaginary_count}\n\n")
            
            content.write("Frequencies (cm^-1):\n")
            for j in range(0, len(frequencies), 5):
                content.write(" ".join(f"{frequencies[k]:.4f}".ljust(10) for k in range(j, min(j+5, len(frequencies)))) + "\n")
            
            content.write("\nReduced masses (amu):\n")
            for j in range(0, len(red_masses), 5):
                content.write(" ".join(f"{red_masses[k]:.4f}".ljust(10) for k in range(j, min(j+5, len(red_masses)))) + "\n")
            
            content.write("\nForce constants (mDyne/A):\n")
            for j in range(0, len(frc_consts), 5):
                content.write(" ".join(f"{frc_consts[k]:.4f}".ljust(10) for k in range(j, min(j+5, len(frc_consts)))) + "\n")
            
            content.write("\nIR Intensities (KM/Mole):\n")
            for j in range(0, len(ir_intensities), 5):
                content.write(" ".join(f"{ir_intensities[k]:.4f}".ljust(10) for k in range(j, min(j+5, len(ir_intensities)))) + "\n")
            
            content.write("\n")
            
            # Store filename and content for batch writing
            output_data.append((output_file_name, content.getvalue()))
    
    # Write all files in one batch (reduces I/O overhead)
    for filename, content in output_data:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(content)
    
    print("Extracted vibrational frequency data for all valid conformers.")
    success_flag['flag'] = True

def parse_special_log_file(log_file):
    # Note: this function uses line-by-line string matching rather than _FREQ_PATTERNS compiled regexes
    # This is intentional  -- special log files (csulfur/chalogen) do not go through the frequency cache and are parsed only once per run, so the performance difference is negligible
    # If frequency line format handling is ever changed, update both this function and parse_log_file_frequencies
    frequencies = []
    red_masses = []
    frc_consts = []
    ir_intensities = []
    significant_imaginary_count = 0
    invalid_conformer = False

    log_contents = read_log_text(log_file)

    if "Error termination" in log_contents:
        return [], [], [], [], 0, True  # empty data, but mark as invalid
    
    lines = log_contents.splitlines()

    for i, line in enumerate(lines):
        if "Frequencies --" in line:
            freqs = [float(x) for x in line.split()[2:]]
            frequencies.extend(freqs)
            # Count significant imaginary frequencies; invalid_conformer is not set here  -- the caller (process_special_calculations) checks significant_imaginary_count > 0 separately, consistent with how parse_log_file_frequencies handles this
            significant_imaginary_count += sum(f < IMAGINARY_FREQUENCY_THRESHOLD for f in freqs)

        elif "Red. masses --" in line:
            red_masses.extend([float(x) for x in line.split()[3:]])
        elif "Frc consts  --" in line:
            frc_consts.extend([float(x) for x in line.split()[3:]])
        elif "IR Inten    --" in line:
            ir_intensities.extend([float(x) for x in line.split()[3:]])

    return frequencies, red_masses, frc_consts, ir_intensities, significant_imaginary_count, invalid_conformer

def process_special_calculations(compound_name, special_type, sdf_file, structure_data, T, method_key):
    """
    Processes csulfur or chalogen calculations for a given compound.
    Returns a 4-tuple (weighted_shifts, per_conformer_shifts, populations, conformer_numbers) on success,
    or None on error or if no matching log files are found.
    The caller must handle both None and tuple returns.
    """
    # Extract what we need from structure_data
    connectivity = structure_data['simple_connectivity']
    atom_types = structure_data['atom_types']
    equivalent_groups = structure_data['equivalent_groups']

    # Determine matching log files
    log_files = sorted([
        f for f in os.listdir() 
        if re.match(rf"^{re.escape(compound_name)}-{special_type}_(\d+)\.log$", f)
    ], key=lambda x: int(re.search(r'_(\d+)\.log$', x).group(1)))
    
    if not log_files:
        return  # No matching special calculations found

    # For chalogen, method_key is used directly as the section marker  -- cannot proceed without it
    if special_type == 'chalogen' and method_key is None:
        print(f"Warning: Cannot process {special_type} calculations for {compound_name}  -- method key is None.")
        return

    # Guard against missing or unrecognized method key for sulfur scaling
    # Use a separate variable to avoid corrupting the section marker search
    sulfur_method_key = method_key
    if special_type == 'csulfur':
        if method_key is None or method_key not in SULFUR_SCALING_BY_METHOD:
            print(f"Warning: method key '{method_key}' not recognized for csulfur scaling. Using average fallback ('6').")
            sulfur_method_key = '6'

    # Only print if special calculation log files exist
    if special_type == 'csulfur':
        print("C-Sulfur calculations (Pierens: WC04) detected. Generating C-Sulfur files.")
    elif special_type == 'chalogen':
        print("C-Halogen calculations (Giesen: Halogen) detected. Generating C-Halogen files.")

    # Exclude the conformers that the main analysis pruned as duplicate minima so this ensemble matches the
    # deduplicated ensemble used for the standard shifts; without this filter the special calculation would
    # reinflate exactly the basins that were oversampled by the conformer search
    removed_duplicates = _DEDUP_REMOVED_CONFORMERS.get(compound_name)
    if removed_duplicates:
        retained_log_files = []
        for log_file in log_files:
            conformer_match = re.search(r'_(\d+)\.log$', log_file)
            if conformer_match and int(conformer_match.group(1)) in removed_duplicates:
                continue
            retained_log_files.append(log_file)
        if len(retained_log_files) != len(log_files):
            print(f"Excluding {len(log_files) - len(retained_log_files)} {special_type} conformer(s) removed as duplicate minima.")
        log_files = retained_log_files
        if not log_files:
            print(f"No {special_type} calculations remain for {compound_name} after deduplication.")
            return

    # Halogen priority weighting for scaling factors
    halogen_weights = {'Cl': 1, 'Br': 2, 'I': 3}
    halogens = {'Cl', 'Br', 'I'}

    # Prepare storage  -- store as paired list to keep conformer numbers and energies in sync
    conformer_energy_pairs = []  # List of (conformer_number, energy) tuples
    carbon_shifts = {}

    # Parse all special log files once and cache results to avoid double reads
    special_freq_cache = {log_file: parse_special_log_file(log_file) for log_file in log_files}

    # Loop over each special log file
    for log_file in log_files:
        conformer_number = int(log_file.split('_')[-1].split('.')[0])

        # Use cached frequency data
        frequencies, red_masses, frc_consts, ir_intensities, significant_imaginary_count, invalid_conformer = special_freq_cache[log_file]

        # Read file once for both error checking and energy extraction (served from the log content cache)
        content = read_log_text(log_file)

        if invalid_conformer or significant_imaginary_count > 0:
            # Provide specific error messages
            reasons = []
            if significant_imaginary_count > 0:
                reasons.append(f"{significant_imaginary_count} significant imaginary frequenc{'y' if significant_imaginary_count == 1 else 'ies'}")
            
            if "Convergence failure -- run terminated." in content:
                reasons.append("a convergence failure")
            if "Error termination" in content:
                reasons.append("an error termination")
            
            # If invalid but no specific error found, it's likely a naming issue
            if invalid_conformer and not reasons:
                reasons.append("improper naming (calculation section not found)")
            
            reason_str = " and ".join(reasons) if reasons else "unknown issue"
            print(f"Excluding {log_file} due to {reason_str}.")
            continue  # Skip this conformer

        # Extract energy using compiled regex
        energy_match = _FILE_PATTERNS['energy'].search(content)
        energy = float(energy_match.group(1)) if energy_match else None

        # If missing energy for some wacky unknown reason, this helps avoid errors
        if energy is None:
            continue

        # Parse isotropic shielding data for carbon atoms  -- done before appending energy so that conformers with no valid shielding data are excluded from population weighting entirely
        # Use sulfur_method_key for section marker to handle None/unrecognized method keys
        section_marker_key = sulfur_method_key if special_type == 'csulfur' else method_key
        # Defensive check: unreachable in practice  -- chalogen returns early above if method_key is None, and csulfur always falls back to '6'  -- retained as a safety net
        if section_marker_key is None:

            print(f"Warning: Cannot parse shielding data from {log_file}  -- method key is None.")
            continue

        shielding_data = {}
        # Scaling factors as recorded in this job's own title. Chalogen carries them per atom because the
        # constants differ between carbons; csulfur carries a single pair.
        title_halogen_factors = {}
        title_sulfur_factors = None
        inside = False
        for line in content.splitlines():
            if f"{compound_name}-{special_type}_{conformer_number}_carbon" in line:
                if special_type == 'chalogen':
                    title_halogen_factors = parse_halogen_scaling_from_title(line)
                else:
                    match = re.search(r's:([-+]?[0-9]*\.?[0-9]+)\s+i:([-+]?[0-9]*\.?[0-9]+)', line)
                    if match:
                        title_sulfur_factors = (float(match.group(1)), float(match.group(2)))
                inside = True
                continue
            if inside and "End of Minotr F.D. properties file" in line:
                break
            if inside and "Isotropic =" in line and "C" in line:
                atom_number = int(line.split()[0])
                match = re.search(r'Isotropic\s*=\s*(-?\d+\.\d+)', line)
                if match:
                    value = float(match.group(1))
                    shielding_data[atom_number] = value

        if not shielding_data:
            print(f"Warning: No shielding data found in {log_file}. Check that the method key '{method_key}' matches the {special_type} calculation naming.")
            continue

        conformer_energy_pairs.append((conformer_number, energy))

        # Filter only carbon atoms attached to the relevant element
        selected_shieldings = {}
        for atom, value in shielding_data.items():
            neighbors = connectivity.get(atom, [])
            neighbor_elements = {atom_types[n - 1] for n in neighbors}

            if special_type == "csulfur" and 'S' in neighbor_elements and not halogens.intersection(neighbor_elements):
                selected_shieldings[atom] = value

            elif special_type == "chalogen":
                halogens_present = [atom_types[n - 1] for n in neighbors if atom_types[n - 1] in HALOGEN_SCALING]
                n_halogens = len(halogens_present)
                
                if n_halogens >= 1:
                    # Cap at 3
                    n_halogens = min(n_halogens, 3)
                    # Pick the heaviest halogen present
                    heaviest = max(halogens_present, key=lambda x: halogen_weights[x])
                    selected_shieldings[atom] = (value, heaviest, n_halogens)  # Store halogen + count

        # Convert shieldings to shifts for this conformer
        conformer_shifts = {}
        for atom, val in selected_shieldings.items():
            if special_type == 'chalogen':
                shielding, halogen, n_halogens = val
                # The title records what actually applied to this carbon; the table is only a fallback for
                # logs written before the factors travelled in the title
                if atom in title_halogen_factors:
                    slope, intercept = title_halogen_factors[atom]
                else:
                    slope = HALOGEN_SCALING[halogen][n_halogens]['slope']
                    intercept = HALOGEN_SCALING[halogen][n_halogens]['intercept']
            else:
                if title_sulfur_factors:
                    slope, intercept = title_sulfur_factors
                else:
                    # No factors in the title means a log from before they travelled there; without a method
                    # number there is no way to know which sulfur constants applied, and guessing would
                    # mis-scale every sulfur-bound carbon without any sign of it
                    entry = SULFUR_SCALING_BY_METHOD.get(sulfur_method_key)
                    if not entry:
                        raise ValueError(
                            f"{compound_name}: this csulfur log carries no scaling factors in its titles and "
                            f"its method could not be identified, so the correct sulfur constants are unknown. "
                            f"Re-run the job setup so the factors are recorded.")
                    slope, intercept = entry['slope'], entry['intercept']
                shielding = val
            
            shift = (shielding - intercept) / slope
            conformer_shifts[atom] = shift
        
        # Apply equivalence averaging to this conformer's shifts
        conformer_shifts_averaged = apply_equivalence_averaging_to_shifts(
            conformer_shifts,
            equivalent_groups
        )
        
        carbon_shifts[conformer_number] = conformer_shifts_averaged

    # Derive valid_conformer_numbers from conformer_energy_pairs to avoid dual-append desync risk
    valid_conformer_numbers = [c for c, _ in conformer_energy_pairs]

    # Try to read populations from file first
    populations_from_file = read_boltzmann_populations_from_file(f"{compound_name}-{special_type}")
    
    if populations_from_file is not None:
        print(f"Using populations from {compound_name}-{special_type}_boltzmann.txt")
        
        boltzmann_populations = []
        for conformer_num in valid_conformer_numbers:
            if conformer_num in populations_from_file:
                boltzmann_populations.append(populations_from_file[conformer_num])
            else:
                print(f"Warning: conformer {conformer_num} not found in population file  -- assigning 0.0 weight; this conformer will contribute zero to the weighted average. The remaining conformer populations will be renormalized to sum to 1.0.")
                boltzmann_populations.append(0.0)

        total = sum(boltzmann_populations)
        if total > 0:
            boltzmann_populations = [p/total for p in boltzmann_populations]
    else:
        # Fall back to energy-based calculation
        if not conformer_energy_pairs:
            return
        
        energies = [e for _, e in conformer_energy_pairs]
        min_energy = min(energies)
        relative_energies = [(e - min_energy) * HARTREE_TO_KCAL for e in energies]
        try:
            boltzmann_populations = calculate_boltzmann_populations(relative_energies, T)
        except ValueError as e:
            print(f"Error: Could not calculate Boltzmann populations for {compound_name} {special_type}: {e}")
            return None

    # Compute weighted shifts using explicit conformer-population pairing
    # Only conformers present in carbon_shifts contribute  -- renormalize to avoid systematic underestimation if some conformers had valid energies/populations but failed shielding parsing
    contributing_weight = sum(
        pop for conformer, pop in zip(valid_conformer_numbers, boltzmann_populations)
        if conformer in carbon_shifts
    )
    weighted_shifts = defaultdict(float)
    if contributing_weight > 0:
        for conformer, pop in zip(valid_conformer_numbers, boltzmann_populations):
            if conformer in carbon_shifts:
                normalized_pop = pop / contributing_weight
                for atom, shift in carbon_shifts[conformer].items():
                    weighted_shifts[atom] += shift * normalized_pop
    if contributing_weight < 0.999:
        print(f"Warning: {special_type} weighted shifts renormalized  -- some conformers had populations but no parsed shifts (contributing weight: {contributing_weight:.4f}).")

    # Filter to only conformers that contributed shifts  -- conformers with valid energies but no parsed shielding data are excluded here so the populations file accurately reflects what was actually averaged, not just what had energies
    contributing_conformers = [
        (conformer, pop)
        for conformer, pop in zip(valid_conformer_numbers, boltzmann_populations)
        if conformer in carbon_shifts
    ]
    if contributing_conformers:
        valid_conformer_numbers_for_output = [c for c, _ in contributing_conformers]
        boltzmann_populations_for_output = [p for _, p in contributing_conformers]
        # Renormalize output populations to sum to 1.0 for display
        total_output = sum(boltzmann_populations_for_output)
        if total_output > 0:
            boltzmann_populations_for_output = [p / total_output for p in boltzmann_populations_for_output]
    else:
        valid_conformer_numbers_for_output = valid_conformer_numbers
        boltzmann_populations_for_output = boltzmann_populations

    # Save frequency data for each valid conformer
    frequency_dir = os.path.join(compound_name, "Frequencies")
    os.makedirs(frequency_dir, exist_ok=True)

    for log_file in log_files:
        conformer_number = int(log_file.split('_')[-1].split('.')[0])
        frequencies, red_masses, frc_consts, ir_intensities, _, invalid_conformer = special_freq_cache[log_file]
        if invalid_conformer:
            continue

        output_file_name = os.path.join(frequency_dir, log_file.replace('.log', '_frequencies.txt'))

        with open(output_file_name, 'w', encoding='utf-8') as output_file:
            output_file.write(f"File: {log_file}\n")
            output_file.write(f"Number of significant imaginary frequencies: {sum(1 for f in frequencies if f < IMAGINARY_FREQUENCY_THRESHOLD)}\n\n")

            output_file.write("Frequencies (cm^-1):\n")
            for j in range(0, len(frequencies), 5):
                output_file.write(" ".join(f"{frequencies[k]:.4f}".ljust(10) for k in range(j, min(j+5, len(frequencies)))) + "\n")

            output_file.write("\nReduced masses (amu):\n")
            for j in range(0, len(red_masses), 5):
                output_file.write(" ".join(f"{red_masses[k]:.4f}".ljust(10) for k in range(j, min(j+5, len(red_masses)))) + "\n")

            output_file.write("\nForce constants (mDyne/A):\n")
            for j in range(0, len(frc_consts), 5):
                output_file.write(" ".join(f"{frc_consts[k]:.4f}".ljust(10) for k in range(j, min(j+5, len(frc_consts)))) + "\n")

            output_file.write("\nIR Intensities (KM/Mole):\n")
            for j in range(0, len(ir_intensities), 5):
                output_file.write(" ".join(f"{ir_intensities[k]:.4f}".ljust(10) for k in range(j, min(j+5, len(ir_intensities)))) + "\n")

            output_file.write("\n")

    return dict(weighted_shifts), carbon_shifts, boltzmann_populations_for_output, valid_conformer_numbers_for_output

def save_coupling_constants(coupling_constants, output_file, header="Coupling Constants (Hz):"):
    if not ngp_output_enabled('coupling_constants'):
        return None  # Output suppressed by the 'coupling_constants' switch; every retained output is unaffected
    max_width = 18  # Fixed width for each entry
    
    # Create a set to track which pairs are already written
    written_pairs = set()
    
    # Pre-sort secondary atoms once per primary atom
    sorted_secondaries = {
        primary: sorted(coupling_constants[primary].keys())
        for primary in coupling_constants
    }
    
    with open(output_file, 'w', encoding='utf-8') as file:
        file.write(f"{header}\n")
        primary_atoms_sorted = sorted(coupling_constants.keys())
        for primary_atom in primary_atoms_sorted:
            line_entries = []
            for secondary_atom in sorted_secondaries[primary_atom]:
                # Create a canonical pair representation (always smaller first)
                pair = (min(primary_atom, secondary_atom), max(primary_atom, secondary_atom))
                
                # Only write if we haven't written this pair yet
                if pair not in written_pairs:
                    written_pairs.add(pair)
                    value = coupling_constants[primary_atom][secondary_atom]
                    entry = f"{pair[0]} - {pair[1]}: {value:.{COUPLING_CONSTANT_PRECISION}f}".ljust(max_width)
                    line_entries.append(entry)

            wrote_entries = bool(line_entries)
            while line_entries:
                file.write(''.join(line_entries[:5]) + '\n')  # 5 entries per line
                line_entries = line_entries[5:]
            
            if wrote_entries and primary_atom != primary_atoms_sorted[-1]:
                file.write('\n')  # Blank line between sets

def parse_standard_orientation_from_lines(lines, source_label='log file'):
    """
    Parse the final standard orientation block from an already-read list of log file lines.

    Split out from extract_standard_orientation so that callers holding the file in memory (the single-pass
    conformer parser) can recover the optimized geometry without a second read from disk. Both entry points
    share this parser so the coordinates used for deduplication are byte-for-byte the coordinates written
    into the conformer SDF files.
    """
    # Find the last occurrence of 'Standard orientation'
    standard_orientation_start = None
    for i in range(len(lines) - 1, -1, -1):
        if 'Standard orientation:' in lines[i]:
            standard_orientation_start = i
            break

    if standard_orientation_start is None:
        raise ValueError(f"No 'Standard orientation' found in {source_label}")

    # Extract the coordinates
    coordinates = []
    for line in lines[standard_orientation_start + 5:]:
        if '-----' in line:
            break
        parts = line.split()
        # Guard against a truncated block: the original slice-and-index approach raised an opaque IndexError
        if len(parts) < 6:
            raise ValueError(
                f"Malformed coordinate row in the final standard orientation block of {source_label} "
                f"({line.strip()!r})  -- the file may be truncated"
            )
        x, y, z = parts[3], parts[4], parts[5]
        coordinates.append((float(x), float(y), float(z)))

    return coordinates

# Generation of optimized conformer SDF files
def extract_standard_orientation(logfile):
    return parse_standard_orientation_from_lines(read_log_lines(logfile), logfile)

def save_shifts(shifts, output_file, structure_data, shift_type):
    """
    Save chemical shifts with special formatting for equivalent groups.
    Uses equivalence groups to determine which atoms to group together.
    Equivalent atoms are displayed as comma-separated lists.
    """
    if not ngp_output_enabled('chemical_shifts'):
        return None  # Output suppressed by the 'chemical_shifts' switch; every retained output is unaffected
    connectivity = structure_data['simple_connectivity']
    atom_types = structure_data['atom_types']
    equivalent_groups = structure_data['equivalent_groups']

    all_shifts = []
    processed_atoms = set()

    # Process equivalence groups - group atoms based on equivalent_groups structure
    for group_id, group_info in equivalent_groups.items():
        atoms = group_info['atoms']
        element = group_info['element']
        
        # Check if all atoms in group have shift values
        valid_atoms = [atom for atom in atoms if atom in shifts]

        if len(valid_atoms) < 2:
            continue
        
        # Get the shift value (should be the same for all after averaging)
        shift_value = shifts[valid_atoms[0]]
        
        # Format as comma-separated list
        atoms_str = ', '.join(map(str, sorted(valid_atoms)))
        label = f"Atoms {atoms_str} ({element})"

        all_shifts.append((min(valid_atoms), label, shift_value, element, sorted(valid_atoms)))
        processed_atoms.update(valid_atoms)

    # Process remaining individual atoms (not in equivalence groups)
    for atom_number, shift in shifts.items():
        if atom_number not in processed_atoms:
            element = atom_types[atom_number - 1]
            label = f"Atom {atom_number} ({element})"
            all_shifts.append((atom_number, label, shift, element, [atom_number]))

    # Sort key is min(valid_atoms) for equivalence groups and atom_number for singles
    # This means groups and singles are interleaved by first atom index, which is the intended behavior
    all_shifts.sort()
    pymol_labels = {}
    
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(f"{shift_type.capitalize()} Chemical Shifts (ppm):\n")
        for sort_key, label, shift, element, atom_list in all_shifts:
            precision = get_shift_precision(element)
            f.write(f"{label}: {shift:.{precision}f}\n")
            # Build PyMOL labels in the same pass  -- no second iteration needed
            if element in ['C', 'H', 'F', 'N']:
                for atom_num in atom_list:
                    pymol_labels[atom_num] = (label, shift)
    
    return pymol_labels

def get_shift_precision(element):
    """Get precision for chemical shift based on element."""
    return _SHIFT_PRECISION_MAP.get(element, 2)

# Atomic distance section
def find_sdf_files(compound_name):
    """
    Finds all conformer SDF files in the 'Conformer SDF Files' directory.
    """
    conformer_sdf_dir = os.path.join(compound_name, "Conformer SDF Files")
    return [os.path.join(conformer_sdf_dir, file) for file in os.listdir(conformer_sdf_dir) if file.endswith('.sdf')]

def parse_sdf_file(file_path):
    """
    Parses a V3000 SDF file to extract atomic coordinates and element symbols.
    Optimized to read file once.
    """
    atoms = []
    coordinates = []
    
    # Read entire file at once
    with open(file_path, 'r') as f:
        content = f.read()
    
    # Find ATOM block boundaries
    begin_idx = content.find("BEGIN ATOM")
    end_idx = content.find("END ATOM")
    
    if begin_idx == -1 or end_idx == -1:
        return atoms, coordinates
    
    # Extract only the ATOM block
    atom_block = content[begin_idx:end_idx]
    
    # Pre-compile regex for atom lines
    atom_pattern = _FILE_PATTERNS['sdf_atom']
    
    for match in atom_pattern.finditer(atom_block):
        element = match.group(2)
        x, y, z = float(match.group(3)), float(match.group(4)), float(match.group(5))
        atoms.append(element)
        coordinates.append((x, y, z))
    
    return atoms, coordinates

def calculate_circle_center_and_radius(atoms, coordinates):
    """
    Calculate the centroid and approximate radius of a circle through three points.
    Uses the centroid (average position) as the circle center rather than the true circumcenter.
    For methyl groups (approximately equilateral triangles), the centroid and circumcenter
    are nearly identical, making this approximation appropriate for NMR distance analysis.
    """
    # Get the three points
    p1 = coordinates[atoms[0] - 1]
    p2 = coordinates[atoms[1] - 1] 
    p3 = coordinates[atoms[2] - 1]
    
    # Calculate vectors
    v1 = (p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2])
    v2 = (p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2])
    
    # Cross product to get normal
    normal = (
        v1[1]*v2[2] - v1[2]*v2[1],
        v1[2]*v2[0] - v1[0]*v2[2],
        v1[0]*v2[1] - v1[1]*v2[0]
    )
    
    # Normalize the normal vector
    norm = math.sqrt(normal[0]**2 + normal[1]**2 + normal[2]**2)
    if norm == 0:
        # Points are collinear, fallback to centroid
        center = (
            (p1[0] + p2[0] + p3[0]) / 3,
            (p1[1] + p2[1] + p3[1]) / 3,
            (p1[2] + p2[2] + p3[2]) / 3
        )
        radius = math.sqrt(
            (p1[0] - center[0])**2 + (p1[1] - center[1])**2 + (p1[2] - center[2])**2
        )
        return center, radius, (0, 0, 1)  # Default normal if collinear
    
    normal = (normal[0]/norm, normal[1]/norm, normal[2]/norm)
    
    # For methyl groups, use the centroid as approximation and calculate radius as average distance
    center = (
        (p1[0] + p2[0] + p3[0]) / 3,
        (p1[1] + p2[1] + p3[1]) / 3,
        (p1[2] + p2[2] + p3[2]) / 3
    )
    
    # Calculate radius as average distance from center to points
    r1 = math.sqrt((p1[0] - center[0])**2 + (p1[1] - center[1])**2 + (p1[2] - center[2])**2)
    r2 = math.sqrt((p2[0] - center[0])**2 + (p2[1] - center[1])**2 + (p2[2] - center[2])**2)
    r3 = math.sqrt((p3[0] - center[0])**2 + (p3[1] - center[1])**2 + (p3[2] - center[2])**2)
    radius = (r1 + r2 + r3) / 3
    
    return center, radius, normal

def distance_point_to_circle(point, center, radius, normal):
    """
    Calculate the shortest distance from a point to a circle in 3D space.
    Optimized with NumPy for speed.
    """
    # Convert to numpy arrays for vectorized operations
    point = np.array(point)
    center = np.array(center)
    normal = np.array(normal)
    
    # Vector from circle center to the point
    to_point = point - center
    
    # Project this vector onto the plane of the circle
    dot_product = np.dot(to_point, normal)
    projection = to_point - dot_product * normal
    
    # Distance from center to projection
    proj_length = np.linalg.norm(projection)
    
    if proj_length < 1e-10:
        # Point is directly above/below circle center
        return np.sqrt(dot_product**2 + radius**2)
    
    # Closest point on circle
    scale = radius / proj_length
    closest_on_circle = center + scale * projection
    
    # Distance from original point to closest point on circle
    return np.linalg.norm(point - closest_on_circle)

def _make_orthogonal_basis(normal):
    """
    Return two unit vectors orthogonal to normal.
    Uses pure Python math intentionally  -- normal is passed as a NumPy array from the caller
    but the tuple arithmetic here avoids NumPy overhead for this small fixed-size operation.
    """
    if abs(normal[0]) > 0.001:
        orth1 = (-normal[1], normal[0], 0)
    else:
        orth1 = (0, -normal[2], normal[1])
    norm = math.sqrt(sum(v**2 for v in orth1))
    orth1 = tuple(v/norm for v in orth1)
    orth2 = (
        normal[1]*orth1[2] - normal[2]*orth1[1],
        normal[2]*orth1[0] - normal[0]*orth1[2],
        normal[0]*orth1[1] - normal[1]*orth1[0]
    )
    return orth1, orth2

def distance_between_circles(circle1_info, circle2_info):
    """
    Calculate the true shortest distance between two circles in 3D space.
    Optimized with NumPy.
    """
    center1 = np.array(circle1_info['center'])
    center2 = np.array(circle2_info['center'])
    radius1 = circle1_info['radius']
    radius2 = circle2_info['radius']
    normal1 = np.array(circle1_info['normal'])
    normal2 = np.array(circle2_info['normal'])
    
    # Vector between circle centers
    center_vector = center2 - center1
    center_distance = np.linalg.norm(center_vector)

    if center_distance == 0:
        # Circles are concentric
        return abs(radius1 - radius2)
    
    # Check if circles are coplanar (same plane)
    dot_product = np.dot(normal1, normal2)

    if abs(abs(dot_product) - 1.0) < 1e-6:  # Circles are parallel/coplanar
        # Project center2 onto circle1's plane
        proj_dist = sum(center_vector[i] * normal1[i] for i in range(3))
        
        if abs(proj_dist) < 1e-6:  # Circles are in the same plane
            # Distance between coplanar circles
            return max(0, center_distance - radius1 - radius2)
        else:
            # Circles are in parallel planes
            # Find closest points considering the plane separation
            in_plane_dist = math.sqrt(center_distance**2 - proj_dist**2)
            circle_separation = max(0, in_plane_dist - radius1 - radius2)
            return math.sqrt(circle_separation**2 + proj_dist**2)
    
    # Non-coplanar circles: use fixed 36-point sampling (10 degrees resolution)
    # This gives ~0.01-0.05 Ang accuracy for typical methyl group geometries, which is sufficient for NMR distance analysis at DISTANCE_PRECISION = 2
    min_distance = float('inf')

    # Generate sample points on circle1
    num_samples = 36  # Every 10 degrees
    orth1_1, orth1_2 = _make_orthogonal_basis(normal1)
    for i in range(num_samples):
        angle1 = 2 * math.pi * i / num_samples
        
        # Point on circle1
        point1 = (
            center1[0] + radius1 * (math.cos(angle1) * orth1_1[0] + math.sin(angle1) * orth1_2[0]),
            center1[1] + radius1 * (math.cos(angle1) * orth1_1[1] + math.sin(angle1) * orth1_2[1]),
            center1[2] + radius1 * (math.cos(angle1) * orth1_1[2] + math.sin(angle1) * orth1_2[2])
        )
        
        # Find closest point on circle2 to this point on circle1
        closest_dist = distance_point_to_circle(point1, center2, radius2, normal2)
        min_distance = min(min_distance, closest_dist)

    # Also check the reverse - points on circle2 to circle1
    orth2_1, orth2_2 = _make_orthogonal_basis(normal2)
    for i in range(num_samples):
        angle2 = 2 * math.pi * i / num_samples
        
        # Point on circle2
        point2 = (
            center2[0] + radius2 * (math.cos(angle2) * orth2_1[0] + math.sin(angle2) * orth2_2[0]),
            center2[1] + radius2 * (math.cos(angle2) * orth2_1[1] + math.sin(angle2) * orth2_2[1]),
            center2[2] + radius2 * (math.cos(angle2) * orth2_1[2] + math.sin(angle2) * orth2_2[2])
        )
        
        # Find closest point on circle1 to this point on circle2
        closest_dist = distance_point_to_circle(point2, center1, radius1, normal1)
        min_distance = min(min_distance, closest_dist)

    return min_distance

def adjust_methyl_distances(distances, methyl_groups_for_distances, coordinates):
    adjusted_distances = distances.copy()

    # Calculate circle representations for each methyl group
    methyl_circles = {}
    for carbon, atoms in methyl_groups_for_distances.items():
        if len(atoms) == 3:  # Ensure it's actually a methyl group
            center, radius, normal = calculate_circle_center_and_radius(atoms, coordinates)
            methyl_circles[carbon] = {
                'center': center,
                'radius': radius,
                'normal': normal,
                'atoms': atoms
            }

    # Apply circle-based distances
    
    # 1. Methyl-to-methyl distances
    methyl_carbons = list(methyl_circles.keys())
    for i, carbon1 in enumerate(methyl_carbons):
        for carbon2 in methyl_carbons[i+1:]:
            circle1 = methyl_circles[carbon1]
            circle2 = methyl_circles[carbon2]
            circle_distance = distance_between_circles(circle1, circle2)
            
            # Set this distance for all atom pairs between the two methyls
            for atom1 in circle1['atoms']:
                for atom2 in circle2['atoms']:
                    adjusted_distances[atom1][atom2] = circle_distance
                    adjusted_distances[atom2][atom1] = circle_distance

    # Pre-compute set of all methyl atoms for O(1) membership checks  -- avoids rebuilding a list on every iteration
    methyl_atoms_set = {a for atoms in methyl_groups_for_distances.values() for a in atoms}

    # 2. Atom-to-methyl distances
    for atom in distances:
        if atom not in methyl_atoms_set:  # Not part of any methyl
            atom_coords = coordinates[atom - 1]  # Convert to 0-based index
            
            for carbon, circle_info in methyl_circles.items():
                circle_distance = distance_point_to_circle(
                    atom_coords, circle_info['center'], 
                    circle_info['radius'], circle_info['normal']
                )
                
                # Set this distance for all atoms in the methyl group
                for methyl_atom in circle_info['atoms']:
                    adjusted_distances[atom][methyl_atom] = circle_distance
                    adjusted_distances[methyl_atom][atom] = circle_distance

    # 3. Intra-methyl distances (atoms within the same methyl)
    for carbon, circle_info in methyl_circles.items():
        atoms = circle_info['atoms']
        # Calculate actual distances between atoms in the same methyl
        for i, atom1 in enumerate(atoms):
            for atom2 in atoms[i+1:]:
                actual_dist = math.sqrt(
                    (coordinates[atom1-1][0] - coordinates[atom2-1][0]) ** 2 +
                    (coordinates[atom1-1][1] - coordinates[atom2-1][1]) ** 2 +
                    (coordinates[atom1-1][2] - coordinates[atom2-1][2]) ** 2
                )
                adjusted_distances[atom1][atom2] = actual_dist
                adjusted_distances[atom2][atom1] = actual_dist

    return adjusted_distances

def process_sdf_files(compound_name, structure_data=None):
    """
    Compute interatomic distances, NOE intensities and NOE equivalence multipliers from the per-conformer SDFs.

    Despite the name this does not WRITE the conformer SDF files (replace_coordinates_in_sdf does that); it reads
    them and produces the distance-derived outputs, so it is gated on those rather than on the SDF switch. It
    only short-circuits when every output it can produce is switched off -- otherwise it runs and the individual
    writers below decide what actually lands on disk.
    """
    if not any(ngp_output_enabled(key) for key in ('distances', 'noe_intensities', 'noe_multipliers')):
        return None  # Every output this function produces is switched off
    sdf_files = find_sdf_files(compound_name)
    
    if not sdf_files:
        return
    
    unweighted_dir = os.path.join(compound_name, "Unweighted Atomic Distances")
    unweighted_noe_dir = os.path.join(compound_name, "Unweighted NOE Intensities")
    os.makedirs(unweighted_dir, exist_ok=True)
    os.makedirs(unweighted_noe_dir, exist_ok=True)
    
    if structure_data is None:
        # Legacy fallback  -- not reached in normal main() flow since structure_data is always passed
        # Retained for safety in case process_sdf_files is called standalone, and for documentation purposes
        sdf_file_path = sdf_files[0]
        connectivity, atom_types, _ = parse_sdf_connectivity(sdf_file_path)
        # Build methyl groups for distance calculations
        methyl_groups_for_distances = {}
        for atom, bonds in connectivity.items():
            if atom_types[atom - 1] == 'C' and len(bonds) == 4:
                h_or_f_neighbors = [n for n in bonds if atom_types[n - 1] in ['H', 'F']]
                if len(h_or_f_neighbors) == 3:
                    methyl_groups_for_distances[atom] = h_or_f_neighbors
    else:
        connectivity = structure_data['simple_connectivity']
        methyl_groups_for_distances = structure_data['methyl_groups_for_distances']

    # Process each SDF file sequentially (faster than parallel for this task)
    for sdf_file in sdf_files:
        atoms, coordinates = parse_sdf_file(sdf_file)
        
        # Use vectorized distance calculation with NumPy
        coords = np.array(coordinates, dtype=np.float64)
        num_atoms = len(coords)

        diff = coords[:, np.newaxis, :] - coords[np.newaxis, :, :]
        dist_matrix = np.sqrt(np.sum(diff**2, axis=2))

        # More efficient: use numpy indexing to extract upper triangle
        distances = defaultdict(dict)
        upper_tri_indices = np.triu_indices(num_atoms, k=1)
        for idx in range(len(upper_tri_indices[0])):
            i, j = upper_tri_indices[0][idx], upper_tri_indices[1][idx]
            dist = float(dist_matrix[i, j])
            distances[i + 1][j + 1] = dist
            distances[j + 1][i + 1] = dist

        # Adjust for methyl groups
        distances = adjust_methyl_distances(distances, methyl_groups_for_distances, coordinates)
        
        # Calculate NOE intensities
        noe_intensities = calculate_noe_intensities(distances)
        
        # Write distances
        sdf_base = os.path.splitext(os.path.basename(sdf_file))[0]
        output_file = os.path.join(unweighted_dir, f"{sdf_base}_distances.txt")
        write_distances_to_file(distances, output_file)
        
        # Write NOE intensities
        noe_output_file = os.path.join(unweighted_noe_dir, f"{sdf_base}_noe_intensities.txt")
        write_noe_intensities_to_file(noe_intensities, noe_output_file, "Unweighted NOE Intensities")

        # Equivalence multipliers: what an NOE actually reports once every equivalent spin on both ends
        # contributes to the same integrated cross peak (additive r^-6 physics, see noe_equivalence_multiplier)
        if structure_data and structure_data.get('equivalent_groups'):
            effective_distances, noe_multipliers = apply_noe_equivalence_multipliers(
                distances, structure_data['equivalent_groups'], num_atoms
            )
            multiplier_file = os.path.join(unweighted_dir, f"{sdf_base}_noe_equivalence_multipliers.txt")
            write_noe_equivalence_multipliers(
                noe_multipliers, effective_distances, distances,
                structure_data['equivalent_groups'], num_atoms, multiplier_file
            )

def boltzmann_weight_distances(compound_name, population_by_conformer, structure_data=None):
    """
    Boltzmann-weight the per-conformer distances and NOE intensities.

    Despite the name this produces two output families, so it is gated on either being wanted rather than on
    'distances' alone -- gating on one meant unticking Atomic distances silently discarded weighted NOE
    intensities as well, even with NOE intensities ticked. The individual writers below still decide what is
    actually written.
    """
    if not any(ngp_output_enabled(key) for key in ('distances', 'noe_intensities', 'noe_multipliers')):
        return None  # Every output this function produces is switched off
    unweighted_dir = os.path.join(compound_name, "Unweighted Atomic Distances")
    unweighted_noe_dir = os.path.join(compound_name, "Unweighted NOE Intensities")
    def _distance_sort_key(x):
        m = re.search(rf'{re.escape(compound_name)}_(\d+)_distances', x)
        return int(m.group(1)) if m else 0

    def _noe_sort_key(x):
        m = re.search(rf'{re.escape(compound_name)}_(\d+)_noe', x)
        return int(m.group(1)) if m else 0

    unweighted_files = sorted(
        [os.path.join(unweighted_dir, file) for file in os.listdir(unweighted_dir) if file.endswith('_distances.txt')],
        key=_distance_sort_key
    )
    unweighted_noe_files = sorted(
        [os.path.join(unweighted_noe_dir, file) for file in os.listdir(unweighted_noe_dir) if file.endswith('_noe_intensities.txt')],
        key=_noe_sort_key
    )

    if not unweighted_files:
        print(f"No unweighted atomic distance files found for {compound_name}.")
        return

    distance_pattern = _FILE_PATTERNS['distance']

    # Note: weighted distances use linear averaging (sum pi*ri), not r_eff = (sum pi*ri^-^6)^(-1/6)
    # For NOE-based distance interpretation, use the weighted NOE intensities file instead
    # The NOE file stores sum pi * ri^-^6 (weighted average NOE intensity)  -- to convert to r_eff, take value^(-1/6)
    # This is the physically correct NOE averaging; the file is labeled "Weighted NOE Intensities" accordingly

    weighted_distances = defaultdict(lambda: defaultdict(float))
    total_distance_weight = 0.0
    for file in unweighted_files:
        num_match = re.search(rf'{re.escape(compound_name)}_(\d+)_distances', file)
        if not num_match:
            continue
        conformer_num = int(num_match.group(1))
        weight = population_by_conformer.get(conformer_num)
        if weight is None:
            continue
        total_distance_weight += weight
        with open(file, 'r') as f:
            content = f.read()
        # Each pair is read once from the file (written as primary < secondary only by write_distances_to_file)
        # Only atom1 < atom2 direction is stored  -- write_distances_to_file enforces primary < secondary on output, so the symmetric entry is never read and storing it would waste memory for large molecules
        for match in distance_pattern.findall(content):
            atom1, atom2, dist = int(match[0]), int(match[1]), float(match[2])
            weighted_distances[atom1][atom2] += dist * weight
    if total_distance_weight < 1e-6:
        # Use epsilon rather than exact zero  -- a near-zero weight (e.g., from floating-point underflow in Boltzmann populations) would pass an exact == 0 check but produce wildly inflated distances when used as a divisor in the normalization step below
        print(f"Warning: total distance weight is effectively zero ({total_distance_weight:.2e}) for {compound_name}  -- no conformer distance files matched population entries. Weighted distance output will be empty.")
        return
    if abs(total_distance_weight - 1.0) > 0.001:
        print(f"Warning: weighted distances for {compound_name} have total weight {total_distance_weight:.4f} (expected 1.0)  -- some conformers may be missing distance files or population weights sum incorrectly.")
    # Always normalize  -- even small deviations from 1.0 (e.g., 0.9995 due to a missing conformer file) would otherwise produce silently incorrect distances
    for atom1 in weighted_distances:
        for atom2 in weighted_distances[atom1]:
            weighted_distances[atom1][atom2] /= total_distance_weight

    output_file = os.path.join(compound_name, f"{compound_name}_weighted_distances.txt")
    write_distances_to_file(weighted_distances, output_file, weighted=True)

    if unweighted_noe_files:
        noe_pattern = _FILE_PATTERNS['noe']
        weighted_noe_intensities = defaultdict(lambda: defaultdict(float))
        total_noe_weight = 0.0
        for file in unweighted_noe_files:
            num_match = re.search(rf'{re.escape(compound_name)}_(\d+)_noe', file)
            if not num_match:
                continue
            conformer_num = int(num_match.group(1))
            weight = population_by_conformer.get(conformer_num)
            if weight is None:
                continue
            total_noe_weight += weight
            with open(file, 'r') as f:
                content = f.read()
            for match in noe_pattern.findall(content):
                atom1, atom2, intensity = int(match[0]), int(match[1]), float(match[2])
                # Each pair appears once in the file (primary < secondary); only that direction stored  -- symmetric entry unused on write
                weighted_noe_intensities[atom1][atom2] += intensity * weight
        # Normalize using total_noe_weight  -- tracked independently from total_distance_weight since the NOE and distance file sets may not match exactly (e.g., missing files for some conformers)
        if abs(total_noe_weight - 1.0) > 0.001:
            print(f"Warning: weighted NOE intensities for {compound_name} have total weight {total_noe_weight:.4f} (expected 1.0)  -- some conformers may be missing NOE files or population weights sum incorrectly.")
        # Always normalize when weight is non-negligible  -- same reasoning as distance normalization above
        if total_noe_weight >= 1e-6:
            for atom1 in weighted_noe_intensities:
                for atom2 in weighted_noe_intensities[atom1]:
                    weighted_noe_intensities[atom1][atom2] /= total_noe_weight

        noe_output_file = os.path.join(compound_name, f"{compound_name}_weighted_noe_intensities.txt")
        write_noe_intensities_to_file(weighted_noe_intensities, noe_output_file, "Weighted NOE Intensities")

        # Equivalence multipliers on the WEIGHTED distances too. These are the values compared against
        # experiment, so the additive r^-6 correction matters more here than on any single conformer; applying
        # it only to the unweighted set left the comparison-ready numbers uncorrected.
        if structure_data and structure_data.get('equivalent_groups') and weighted_distances:
            atom_count = len(structure_data.get('atom_types') or [])
            if atom_count:
                effective_distances, noe_multipliers = apply_noe_equivalence_multipliers(
                    weighted_distances, structure_data['equivalent_groups'], atom_count)
                multiplier_file = os.path.join(
                    compound_name, f"{compound_name}_weighted_noe_equivalence_multipliers.txt")
                write_noe_equivalence_multipliers(
                    noe_multipliers, effective_distances, weighted_distances,
                    structure_data['equivalent_groups'], atom_count, multiplier_file)

def write_distances_to_file(distances, output_file, weighted=False):
    if not ngp_output_enabled('distances'):
        return None  # Output suppressed by the 'distances' switch; every retained output is unaffected
    max_width = 18  # Fixed width for each entry
    
    # Use StringIO for efficient string building
    buffer = StringIO()
    if weighted:
        buffer.write("Weighted Atomic Distances (Angstroms):\n")
    else:
        buffer.write("Unweighted Atomic Distances (Angstroms):\n")

    primary_atoms_sorted = sorted(distances.keys())
    
    for primary_atom in primary_atoms_sorted:
        line_entries = []
        for secondary_atom in sorted(distances[primary_atom].keys()):
            if primary_atom < secondary_atom:  # Ensures no repeats
                value = distances[primary_atom][secondary_atom]
                entry = f"{primary_atom} - {secondary_atom}: {value:.{DISTANCE_PRECISION}f}".ljust(max_width)
                line_entries.append(entry)

        # Write in chunks of 5
        for i in range(0, len(line_entries), 5):
            buffer.write(''.join(line_entries[i:i+5]))
            buffer.write('\n')

        # Only add blank line if we wrote entries AND there are more primary atoms coming
        if line_entries and primary_atom != primary_atoms_sorted[-1]:
            buffer.write('\n')  # Blank line between sets

    # Write all at once  -- UTF-8 required for Unicode characters in the weighted header (sum, i, *)
    with open(output_file, 'w', encoding='utf-8') as file:
        file.write(buffer.getvalue())

def calculate_noe_intensities(distances):
    """
    Calculate 1/r^6 values from distances for NOE intensity comparison.
    """
    noe_intensities = defaultdict(lambda: defaultdict(float))
    
    for atom1 in distances:
        for atom2 in distances[atom1]:
            if atom1 != atom2:  # Always true given triu_indices(k=1) construction; retained as a safety guard
                distance = distances[atom1][atom2]
                if distance > 0:  # Avoid division by zero
                    noe_intensity = 1.0 / (distance ** 6)
                    noe_intensities[atom1][atom2] = noe_intensity
    
    return noe_intensities

def write_noe_intensities_to_file(noe_intensities, output_file, title="NOE Intensities"):
    """
    Write NOE intensities (1/r^6 values) to file with scientific notation for readability.
    """
    if not ngp_output_enabled('noe_intensities'):
        return None  # Output suppressed by the 'noe_intensities' switch; every retained output is unaffected
    max_width = 22  # Slightly wider than NOE file structure for scientific notation

    buffer = StringIO()
    buffer.write(f"{title} (1/r^6 values):\n\n")
    primary_atoms_sorted = sorted(noe_intensities.keys())
    for primary_atom in primary_atoms_sorted:
        line_entries = []
        for secondary_atom in sorted(noe_intensities[primary_atom].keys()):
            if primary_atom < secondary_atom:  # Ensures no repeats
                value = noe_intensities[primary_atom][secondary_atom]
                entry = f"{primary_atom} - {secondary_atom}: {value:.3e}".ljust(max_width)
                line_entries.append(entry)

        wrote_entries = bool(line_entries)  # Capture before the while loop drains it
        while line_entries:
            buffer.write(''.join(line_entries[:4]) + '\n')  # 4 entries per line due to wider format
            line_entries = line_entries[4:]
        # Matches write_distances_to_file pattern  -- only write blank line if entries were written for this primary atom
        if wrote_entries and primary_atom != primary_atoms_sorted[-1]:
            buffer.write('\n')  # Blank line between sets

    with open(output_file, 'w', encoding='utf-8') as file:
        file.write(buffer.getvalue())

# Script main processing
def run_ngp_analysis():
    # Start timing
    script_start_time = time.time()

    # Print startup banner
    print("=" * 85)
    print("Jared's NMR Gaussian Parsing Script - Generation 2 Version 3.2.0")
    print("=" * 85)
    
    # Detect optimal processors
    global _OPTIMAL_PROCESSORS
    if AUTO_DETECT_PROCESSORS:
        _OPTIMAL_PROCESSORS = detect_optimal_processors()
    else:
        _OPTIMAL_PROCESSORS = NUM_PROCESSORS_FALLBACK
        print(f"Using manual processor setting: {_OPTIMAL_PROCESSORS} cores")

    print("=" * 85)
    
    compound_names_set = set()
    success_flag = {'flag': False}

    # Detect compounds. The directory is scanned because that is how this runs from the command line, but the
    # result is then intersected with NGP_RESTRICT_TO_COMPOUNDS when the caller has named a set -- loading the
    # log files of one compound and having every other compound in the same folder analysed as well is not
    # what anyone means by that selection.
    for file_name in os.listdir():
        # Use greedy match to capture everything before the final _\d+.log
        match = re.match(r"^(.+)_(\d+)\.log$", file_name)
        if match:
            compound = match.group(1)
            # Remove special suffixes if present
            if compound.endswith('-csulfur'):
                compound = compound[:-8]
            elif compound.endswith('-chalogen'):
                compound = compound[:-9]
            compound_names_set.add(compound)

    # Sort alphabetically for consistent, reproducible processing order
    if NGP_RESTRICT_TO_COMPOUNDS:
        requested = set(NGP_RESTRICT_TO_COMPOUNDS)
        ignored = sorted(compound_names_set - requested)
        compound_names_set &= requested
        if ignored:
            print(f"Ignoring {len(ignored)} compound(s) present in the folder but not selected: "
                  f"{', '.join(ignored[:6])}" + (f", and {len(ignored) - 6} more" if len(ignored) > 6 else ""))

    compound_names = sorted(compound_names_set)

    if not compound_names:
        print("No valid compound files found.")
        return

    print(f"Found {len(compound_names)} compound(s) to process\n")
    
    # Track statistics
    total_conformers_processed = 0
    total_compounds_processed = 0

    # Loop over each compound
    for compound_idx, compound_name in enumerate(compound_names, 1):

        print(f"[{compound_idx}/{len(compound_names)}] Processing {compound_name}...")

        # Remove existing output directory before processing to avoid stale data
        # (e.g., old Boltzmann files referencing conformers that no longer exist, in case they are removed)
        if os.path.exists(compound_name) and os.path.isdir(compound_name):
            print(f"  Note: Removing existing output directory '{compound_name}' to avoid stale data.")
            shutil.rmtree(compound_name)

        # Find all relevant output files for this compound
        log_files = sorted([
            f for f in os.listdir()
            if re.match(rf"^{re.escape(compound_name)}_\d+\.log$", f) or
               re.match(rf"^{re.escape(compound_name)}-csulfur_\d+\.log$", f) or
               re.match(rf"^{re.escape(compound_name)}-chalogen_\d+\.log$", f)
        ])

        if not log_files:
            print(f"No output files found for {compound_name}. Skipping.")
            continue

        # Prepare a dict to hold paths to reconstructed SDF files keyed by conformer number
        reconstructed_sdfs = {}

        # Reconstruct SDF files from output files
        for log_file in log_files:
            # Skip special calculation files for reconstruction
            if '-csulfur_' in log_file or '-chalogen_' in log_file:
                continue
                
            # Extract conformer number from filename
            match = re.search(r'_(\d+)\.log$', log_file)
            if not match:
                print(f"  Could not extract conformer number from {log_file}. Skipping.")
                continue
            conformer_number = int(match.group(1))

            try:
                # Extract base connectivity from Initial Parameters section
                base_connectivity = extract_connectivity_from_parameters(log_file)
                
                # Extract full multi-line job title line containing special bonds and charges
                full_serialized_title = extract_full_serialized_block(log_file, compound_name, conformer_number, job_type='opt')

                # Parse charges from the title. Bond ORDERS are no longer carried there -- the title records
                # charges only -- so everything comes back as a single bond and has to be corrected below.
                per_atom_charges, connectivity = parse_serialized_connectivity_and_charges(full_serialized_title, base_connectivity)

                # Extract element symbols and coordinates
                elements = extract_element_symbols(log_file)
                coordinates = extract_standard_orientation(log_file)

                # True bond orders from this conformer's own Wiberg matrix. Without this every reconstructed
                # SDF is written with single bonds throughout, because the connectivity above only says WHICH
                # atoms are bonded; the orders come from the converged wavefunction.
                conformer_wiberg = parse_wiberg_bond_index_matrix(log_file, num_atoms=len(elements) or None)
                if conformer_wiberg:
                    connectivity, _changed, _missing = apply_wiberg_bond_orders(connectivity, conformer_wiberg)
                if ngp_output_enabled('wiberg_report'):
                    wiberg_dir = os.path.join(compound_name, "Wiberg Bond Indices")
                    os.makedirs(wiberg_dir, exist_ok=True)
                    write_wiberg_report(
                        compound_name, conformer_number, connectivity, conformer_wiberg, elements,
                        os.path.join(wiberg_dir, f"{compound_name}_{conformer_number}_wiberg.txt"))

                # Construct path for reconstructed SDF in compound subdirectory temporarily
                temp_sdf_dir = os.path.join(compound_name, "Temp SDF Files")
                os.makedirs(temp_sdf_dir, exist_ok=True)
                reconstructed_sdf_path = os.path.join(temp_sdf_dir, f"{compound_name}_{conformer_number}.sdf")

                # Write reconstructed SDF
                write_v3000_sdf(reconstructed_sdf_path, compound_name, conformer_number, elements, coordinates, connectivity, per_atom_charges)
                reconstructed_sdfs[conformer_number] = reconstructed_sdf_path

            except Exception as e:
                print(f"  Error reconstructing SDF for {compound_name} conformer {conformer_number}: {e}")
                continue

        if not reconstructed_sdfs:
            print(f"  No reconstructed SDF files created for {compound_name}. Skipping.")
            continue

        total_conformers_processed += len(reconstructed_sdfs)

        # For downstream processing, pick one reconstructed SDF (e.g., first conformer) to get connectivity and atom types
        first_conformer = sorted(reconstructed_sdfs.keys())[0]
        sdf_file = reconstructed_sdfs[first_conformer]

        # Create output directory for this compound if it doesn't exist
        os.makedirs(compound_name, exist_ok=True)

        # Continue with rest of processing using 'sdf_file' as a reconstructed SDF path

        # Set default temperature (local variable)
        T = 298.0  # Default temperature
                
        # Get method key
        method_key = None
        
        # Process log files for the compound
        # Use only standard (non-special) log files for temperature and method key detection
        standard_log_files = [f for f in log_files if '-csulfur_' not in f and '-chalogen_' not in f]
        if log_files:
            if standard_log_files:
                first_log_file = standard_log_files[0]
            else:
                print(f"Warning: No standard log files found for {compound_name}  -- falling back to special file for temperature and method detection. Results may be incorrect.")
                first_log_file = log_files[0]
            temp_from_log = get_temperature_from_log(first_log_file)  # Dynamically update T

            if temp_from_log != 298.0:  # Check if the temperature was found and differs from the default
                T = temp_from_log
                print(f"Temperature set to {T} K for {compound_name}.")
            else:
                T = 298.0  # Explicitly set T to default, though this is already the fallback
            
            # Older logs carry a method number in their titles and newer ones do not, because nothing needs
            # it any more: sections are located by job type and every scaled job records its own factors.
            # Its absence is the normal case and is not worth reporting.
            method_key = detect_method_parameters(read_log_lines(first_log_file), compound_name)
            if method_key is None:
                method_key = UNKNOWN_METHOD_KEY

        # Pass the reconstructed SDF file to process_files
        try:
            main_result = process_files(compound_name, success_flag, sdf_file, T)
            process_frequencies(compound_name, success_flag)
            if main_result is None:
                print()  # Blank line separator between compounds even when processing found nothing
            elif not isinstance(main_result, tuple) or len(main_result) != 3:
                print(f"Warning: process_files returned unexpected result for {compound_name}, skipping.")
                print()
            else:
                pymol_labels, structure_data, weighted_shifts = main_result

                # Only process special calculations if there were valid conformers from main jobs
                main_boltzmann_path = os.path.join(compound_name, f"{compound_name}_boltzmann_populations.txt")
                if os.path.exists(main_boltzmann_path):
                    for special_type in ['csulfur', 'chalogen']:
                        special_result = process_special_calculations(
                            compound_name, special_type, sdf_file, structure_data, T, method_key
                        )
                        if special_result is None:
                            continue

                        weighted, per_conformer_shifts, populations, valid_conformer_numbers = special_result

                        # Save weighted shifts
                        with open(os.path.join(compound_name, f"{compound_name}_{special_type}_weighted_shifts.txt"), 'w', encoding='utf-8') as f:
                            f.write(f"Weighted ({special_type}) Carbon Shifts (ppm):\n")
                            for atom, shift in sorted(weighted.items()):
                                f.write(f"Atom {atom} (C): {shift:.3f}\n")
                        
                        # Save unweighted shifts for each conformer
                        unweighted_dir = os.path.join(compound_name, "Unweighted NMR Data")
                        os.makedirs(unweighted_dir, exist_ok=True)
                        for conformer_num, atom_dict in per_conformer_shifts.items():
                            file_path = os.path.join(unweighted_dir, f"{compound_name}_{special_type}_conformer_{conformer_num}_shifts.txt")
                            with open(file_path, 'w', encoding='utf-8') as f:
                                f.write(f"Unweighted ({special_type}) Carbon Shifts (ppm):\n") # Equivalence averaging has still been applied
                                for atom, shift in atom_dict.items():
                                    f.write(f"Atom {atom} (C): {shift:.3f}\n")

                        # Save Boltzmann populations
                        pop_file = os.path.join(compound_name, f"{compound_name}_{special_type}_boltzmann_populations.txt")
                        with open(pop_file, 'w', encoding='utf-8') as f:
                            f.write("Boltzmann Populations:\n")
                            for i, pop in enumerate(populations):
                                f.write(f"Conformer {valid_conformer_numbers[i]}: {pop:.2%}\n")

                special_replacements = {}
                for special_type in ['csulfur', 'chalogen']:
                    special_file = os.path.join(compound_name, f"{compound_name}_{special_type}_weighted_shifts.txt")
                    if os.path.exists(special_file):
                        with open(special_file, 'r') as f:
                            for line in f:
                                if line.startswith("Atom"):
                                    parts = line.strip().split()
                                    if len(parts) < 2:
                                        continue
                                    try:
                                        ppm = float(parts[-1])
                                    except (ValueError, IndexError):
                                        continue
                                    label_part = line.split('(')[0]
                                    number_matches = re.findall(r'\b\d+\b', label_part)
                                    for atom_str in number_matches:
                                        try:
                                            atom_num = int(atom_str)
                                            weighted_shifts[atom_num] = ppm
                                            special_replacements[atom_num] = special_type
                                        except ValueError:
                                            continue

                # Only generate PyMOL script if the main calculation had valid conformers
                if os.path.exists(os.path.join(compound_name, f"{compound_name}_boltzmann_populations.txt")) and pymol_labels:
                    structured_weighted_shifts = pymol_labels
                    for atom_number, source in special_replacements.items():
                        if atom_number < 1 or atom_number > len(structure_data['atom_types']):
                            print(f"Warning: Atom {atom_number} out of bounds in special replacements, skipping")
                            continue
                        if atom_number in weighted_shifts:
                            element = structure_data['atom_types'][atom_number - 1]
                            structured_weighted_shifts[atom_number] = (f"Atom {atom_number} ({element})", weighted_shifts[atom_number])

                    generate_pymol_script(compound_name, structured_weighted_shifts, structure_data, special_replacements, weighted_shifts, first_conformer_num=first_conformer)
                    print(f"PyMOL script generated.")

                # Remove empty compound folder if it exists
                if os.path.exists(compound_name) and not os.listdir(compound_name):
                    os.rmdir(compound_name)

                print()
                total_compounds_processed += 1

        except Exception as e:
            import traceback
            print(f"Error: Unhandled exception while processing {compound_name}  -- skipping this compound.")
            print(f"  {e}")
            print(f"  {traceback.format_exc()}")

        finally:
            # Always clean up temp SDF files and clear caches, even if processing raised an exception or was skipped
            temp_sdf_dir = os.path.join(compound_name, "Temp SDF Files")
            if os.path.exists(temp_sdf_dir):
                shutil.rmtree(temp_sdf_dir)

            # Clear per-compound caches and state between compounds to free memory and avoid stale data
            _frequency_cache.clear()
            _RING_CACHE.clear()
            clear_log_content_cache()  # Release cached LOG file text before moving to the next compound
            _DEDUP_REMOVED_CONFORMERS.clear()  # Reset per-compound  -- consumed by process_special_calculations earlier in this same iteration
            excluded_conformers.clear()  # Reset per-compound  -- suppresses duplicate warnings within a compound while ensuring a clean state for each new compound

    # Calculate total time
    script_total_time = time.time() - script_start_time
    
    # Print final summary
    print("=" * 85)
    print("PROCESSING COMPLETE")
    print("=" * 85)
    print(f"Total runtime: {format_time(script_total_time)}")
    print(f"Compounds processed: {total_compounds_processed}")
    print(f"Conformers processed: {total_conformers_processed}")
    print("=" * 85)
    
    # Condition if all processing fails
    if not success_flag['flag']:
        print("All analyses failed. That's too bad; we'll get 'em next time!")
    # Condition when all processing is complete, as long as one such processing is successful
    else:
        print("All processing is complete. Your results are ready. Have a great day and happy analyzing!")

# ==================================
# END OF MAIN SCRIPT PARSING SECTION
# ==================================


# ==================================================================================================================
# GRAPHICAL INTERFACE
# ==================================================================================================================
# Two tabs matching the two halves of the workflow. Everything below the GUI layer is the original command-line
# logic embedded unchanged apart from the namespacing noted at the top of this file, so a result produced here is
# the same result those scripts produce; the GUI supplies inputs and collects outputs rather than reimplementing
# anything.
#
# THREADING MODEL. Every long-running job (splitting, clustering, job generation, log analysis) runs on a worker
# thread, never on the Tk main loop, so the window keeps repainting and the Cancel button stays responsive while
# Gaussian inputs are being written or thousands of logs parsed. Worker threads never touch widgets directly --
# they post text through a queue that the main thread drains on a timer, because Tk is not thread-safe and
# calling into it from a worker is the classic way to get a silent hang or a crash that only shows up on someone
# else's machine.


def cluster_simplify_output(cluster_root, compound_name):
    """
    Reduce a compound's clustering output to two folders: what passed as unique, and what did not.

    The clustering algorithm writes a great deal along the way -- one directory per cluster, a duplicate copy of
    each cluster's medoid, method-comparison CSVs -- all of which is diagnostic detail about HOW the partition
    was reached. Downstream only two facts matter: which conformers go to DFT and which were set aside. This
    runs after clustering finishes and keeps exactly those, so the algorithm itself is untouched and only its
    leftovers are cleared.

    Returns (selected_paths, rejected_paths).
    """
    compound_directory = os.path.join(cluster_root, compound_base_name(compound_name))
    if not os.path.isdir(compound_directory):
        compound_directory = cluster_root

    def gather(directory_name):
        directory = os.path.join(compound_directory, directory_name)
        if not os.path.isdir(directory):
            return []
        return [os.path.join(directory, name) for name in sorted(os.listdir(directory))
                if name.lower().endswith('.sdf')]

    selected_source = gather(CLUSTER_DFT_DIR)
    rejected_source = gather(CLUSTER_LOW_PRIORITY_DIR)
    if not selected_source and not rejected_source:
        return [], []

    selected_directory = os.path.join(compound_directory, CLUSTER_SELECTED_DIR)
    rejected_directory = os.path.join(compound_directory, CLUSTER_REJECTED_DIR)
    os.makedirs(selected_directory, exist_ok=True)
    os.makedirs(rejected_directory, exist_ok=True)

    selected, rejected = [], []
    for source, destination_directory, collector in ((selected_source, selected_directory, selected),
                                                     (rejected_source, rejected_directory, rejected)):
        for path in source:
            # The medoid duplicate is the same structure written twice under a decorated name; keeping it would
            # double-count that conformer downstream
            if os.path.splitext(os.path.basename(path))[0].endswith('_medoid'):
                continue
            destination = os.path.join(destination_directory, os.path.basename(path))
            try:
                shutil.copy2(path, destination)
                collector.append(destination)
            except (IOError, OSError) as error:
                print(f"  WARNING: could not place {os.path.basename(path)}: {error}")

    removed = 0
    for name in sorted(os.listdir(compound_directory)):
        if name in (CLUSTER_SELECTED_DIR, CLUSTER_REJECTED_DIR):
            continue
        target = os.path.join(compound_directory, name)
        try:
            if os.path.isdir(target):
                shutil.rmtree(target)
                removed += 1
            elif name.lower().endswith(('.csv', '.txt', '.png')):
                os.remove(target)
                removed += 1
        except OSError:
            pass

    print(f"  Output simplified: {len(selected)} unique -> {CLUSTER_SELECTED_DIR}{os.sep}, "
          f"{len(rejected)} set aside -> {CLUSTER_REJECTED_DIR}{os.sep} "
          f"({removed} intermediate item(s) cleared)")
    return selected, rejected


SDF_ELEMENT_PATTERN = re.compile(r'^\s*-?\d+\.\d+\s+-?\d+\.\d+\s+-?\d+\.\d+\s+([A-Z][a-z]?)\b')

def detect_elements_in_sdf(path, structure_limit=1):
    """
    The set of element symbols present in an SDF, reading both connection-table versions.

    Used to decide which of the element-specific calculations can apply at all: offering a fluorine shift
    calculation for a molecule containing no fluorine invites a job that produces nothing. Only the first
    structure is examined by default, since every conformer of one compound shares its constitution, which
    keeps this instant even for a file holding a thousand structures.
    """
    elements = set()
    try:
        with open(path, 'r', errors='replace') as handle:
            structures_seen = 0
            in_v3000_atoms = False
            for line in handle:
                stripped = line.strip()
                if stripped.startswith('$$$$'):
                    structures_seen += 1
                    if structures_seen >= structure_limit:
                        break
                    continue
                upper = stripped.upper()
                if 'BEGIN ATOM' in upper:
                    in_v3000_atoms = True
                    continue
                if 'END ATOM' in upper:
                    in_v3000_atoms = False
                    continue
                if in_v3000_atoms and stripped.startswith('M  V30'):
                    parts = stripped[6:].split()
                    if len(parts) >= 5:
                        elements.add(parts[1].capitalize())
                    continue
                match = SDF_ELEMENT_PATTERN.match(line)
                if match:
                    elements.add(match.group(1).capitalize())
    except OSError:
        return set()
    return elements

# ==================================================================================================================
# EXTERNAL CONFIGURATION
# ==================================================================================================================
# Methods and machine profiles live in a plain text file next to this script rather than inside it, so the
# chemistry and the site-specific paths can both be edited, versioned and shared without touching code.
#
# The file is written automatically from the built-in defaults the first time this runs, which means a fresh copy
# works with no setup and the generated file doubles as documentation of the format. It is never overwritten
# afterwards: an edited file is the user's, and silently replacing it on an upgrade would discard exactly the
# work this feature exists to enable.
#
# WHAT GOES WHERE, and why the split matters:
#   [method:N] sections describe CHEMISTRY -- functionals, basis sets, solvent keywords, scaling constants. These
#              travel with the science and should be identical on every machine that runs the same protocol.
#   [machine:NAME] sections describe a COMPUTER -- where scratch files go, how many cores and how much memory the
#              queue allows. These differ per site and should never travel with a method.
#
# Mixing the two is the usual reason a protocol stops reproducing when it moves between machines, so they are
# kept in separate section types and selected independently in the interface.

CONFIG_FILENAME = 'nmr_workbench_config.txt'

DEFAULT_CONFIG_TEXT = '''# ==================================================================================================================
# NMR Workbench configuration
# ==================================================================================================================
# Edit freely. This file is read at startup and is never rewritten once it exists, so your changes persist.
# To return to the shipped defaults, delete this file and run the program again -- it will be recreated.
#
# ------------------------------------------------------------------------------------------------------------
# METHOD SECTIONS  [method:KEY]
# ------------------------------------------------------------------------------------------------------------
# KEY is what appears in the interface and can be any short name. Add as many as you like; new sections show up
# in the dropdown automatically.
#
#   label            Text shown in the dropdown.
#   *_basis          Basis set substituted into the matching route below.
#   *_route          The complete Gaussian route line. Placeholders available:
#                       {temperature}     expands to " temperature=298.0" (or nothing when unset)
#                       {opt_basis} {carbon_basis} {proton_basis} {fluorine_basis} {nitrogen_basis} {cc_basis}
#                    A basis becomes "gen" automatically for iodine-containing compounds, and the gen block is
#                    written separately, so the routes below need no special iodine handling.
#   carbon_slope / carbon_intercept / proton_slope / proton_intercept
#                    Linear scaling constants applied to computed shieldings. Optional; leave blank if the
#                    method has none.
#
# NOTE on cc_route: coupling constants are deliberately computed WITHOUT a solvent keyword, because Fermi
# contact coupling is evaluated from the gas-phase wavefunction. Do not add scrf to that line.
#
# NOTE on opt_route: keep "geom=connectivity pop=nboread". pop=nboread is what makes Gaussian print the Wiberg
# bond index matrix, which the analysis half reads to determine true bond orders. Removing it means bond orders
# fall back to whatever the input SDF claimed.
#
# ------------------------------------------------------------------------------------------------------------
# MACHINE SECTIONS  [machine:NAME]
# ------------------------------------------------------------------------------------------------------------
#   label            Text shown in the dropdown.
#   chk / rwf        Checkpoint and read-write file lines. Placeholders: {compound} {conformer}
#                    Leave rwf blank to omit the %rwf line entirely.
#   tier.NAME        A resource tier, written as "cores, memory". Add or remove tiers as your queue requires.

[method:1]
label = 1  chloroform
opt_basis = 6-311g(d,p)
carbon_basis = def2svp
proton_basis = 6-311++g(2d,p)
fluorine_basis = aug-cc-pvdz
nitrogen_basis = cc-pvdz
cc_basis = 6-31g(d)
opt_route = # opt freq=noraman{temperature} b3lyp/{opt_basis} scrf=(iefpcm,solvent=chloroform) geom=connectivity pop=nboread empiricaldispersion=gd3
carbon_route = # nmr=giao wb97xd/{carbon_basis} scrf=(iefpcm,solvent=chloroform) geom=check guess=read
proton_route = # nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=chloroform) geom=check guess=read
fluorine_route = # nmr=giao wb97xd/{fluorine_basis} scrf=(iefpcm,solvent=chloroform) geom=check guess=read
nitrogen_route = # nmr=giao b3lyp/{nitrogen_basis} scrf=(iefpcm,solvent=chloroform) geom=check guess=read
cc_route = # nmr=(giao,mixed) b3lyp/{cc_basis} geom=check guess=read

[method:2]
label = 2  DMSO
opt_basis = 6-311g(d,p)
carbon_basis = def2svp
proton_basis = 6-311++g(2d,p)
fluorine_basis = aug-cc-pvdz
nitrogen_basis = cc-pvdz
cc_basis = 6-31g(d)
opt_route = # opt freq=noraman{temperature} b3lyp/{opt_basis} scrf=(iefpcm,solvent=dmso) geom=connectivity pop=nboread empiricaldispersion=gd3
carbon_route = # nmr=giao wb97xd/{carbon_basis} scrf=(iefpcm,solvent=dmso) geom=check guess=read
proton_route = # nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=dmso) geom=check guess=read
fluorine_route = # nmr=giao wb97xd/{fluorine_basis} scrf=(iefpcm,solvent=dmso) geom=check guess=read
nitrogen_route = # nmr=giao b3lyp/{nitrogen_basis} scrf=(iefpcm,solvent=dmso) geom=check guess=read
cc_route = # nmr=(giao,mixed) b3lyp/{cc_basis} geom=check guess=read

[method:3]
label = 3  methanol
opt_basis = 6-31+g(d,p)
carbon_basis = 6-311+g(2d,p)
proton_basis = aug-cc-pvdz
fluorine_basis = aug-cc-pvdz
nitrogen_basis = cc-pvdz
cc_basis = 6-31g(d)
opt_route = # opt freq=noraman{temperature} b3lyp/{opt_basis} geom=connectivity pop=nboread
carbon_route = # nmr=giao mpw1pw91/{carbon_basis} scrf=(iefpcm,solvent=methanol) geom=check guess=read
proton_route = # nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=methanol) geom=check guess=read
fluorine_route = # nmr=giao wb97xd/{fluorine_basis} scrf=(iefpcm,solvent=methanol) geom=check guess=read
nitrogen_route = # nmr=giao b3lyp/{nitrogen_basis} scrf=(iefpcm,solvent=methanol) geom=check guess=read
cc_route = # nmr=(giao,mixed) b3lyp/{cc_basis} geom=check guess=read

[method:4]
label = 4  acetonitrile
opt_basis = 6-311g(d,p)
carbon_basis = def2svp
proton_basis = 6-311++g(2d,p)
fluorine_basis = aug-cc-pvdz
nitrogen_basis = cc-pvdz
cc_basis = 6-31g(d)
opt_route = # opt freq=noraman{temperature} b3lyp/{opt_basis} scrf=(iefpcm,solvent=acetonitrile) geom=connectivity pop=nboread empiricaldispersion=gd3
carbon_route = # nmr=giao wb97xd/{carbon_basis} scrf=(iefpcm,solvent=acetonitrile) geom=check guess=read
proton_route = # nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=acetonitrile) geom=check guess=read
fluorine_route = # nmr=giao wb97xd/{fluorine_basis} scrf=(iefpcm,solvent=acetonitrile) geom=check guess=read
nitrogen_route = # nmr=giao b3lyp/{nitrogen_basis} scrf=(iefpcm,solvent=acetonitrile) geom=check guess=read
cc_route = # nmr=(giao,mixed) b3lyp/{cc_basis} geom=check guess=read

[method:5]
label = 5  water
opt_basis = 6-31+g(d,p)
carbon_basis = aug-cc-pvdz
proton_basis = aug-cc-pvdz
fluorine_basis = aug-cc-pvdz
nitrogen_basis = cc-pvdz
cc_basis = 6-31g(d)
opt_route = # opt freq=noraman{temperature} b3lyp/{opt_basis} geom=connectivity pop=nboread
carbon_route = # nmr=giao blyp/{carbon_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=water) geom=check guess=read
proton_route = # nmr=giao blyp/{proton_basis} iop(3/76=1000001189,3/77=0961409999,3/78=0000109999) scrf=(iefpcm,solvent=water) geom=check guess=read
fluorine_route = # nmr=giao wb97xd/{fluorine_basis} scrf=(iefpcm,solvent=water) geom=check guess=read
nitrogen_route = # nmr=giao b3lyp/{nitrogen_basis} scrf=(iefpcm,solvent=water) geom=check guess=read
cc_route = # nmr=(giao,mixed) b3lyp/{cc_basis} geom=check guess=read

# ------------------------------------------------------------------------------------------------------------
# Machines
# ------------------------------------------------------------------------------------------------------------

[machine:default]
label = Default (files beside the job)
chk = %chk={compound}_{conformer}.chk
rwf = %rwf={compound}_{conformer}.rwf
tier.small = 16, 31GB
tier.medium = 32, 63GB
tier.large = 64, 127GB

# Example of a site with a dedicated scratch area. Copy, rename and edit for your own machines.
# [machine:hpc]
# label = HPC cluster (scratch)
# chk = %chk=/scratch/$USER/{compound}_{conformer}.chk
# rwf = %rwf=/scratch/$USER/{compound}_{conformer}.rwf
# tier.small = 16, 31GB
# tier.medium = 32, 63GB
# tier.large = 64, 127GB
# tier.huge = 128, 255GB
'''

WORKBENCH_METHODS = {}
WORKBENCH_MACHINES = {}
WORKBENCH_CONFIG_PATH = None
WORKBENCH_CONFIG_PROBLEMS = []


def check_logs_carry_scaling_factors(paths_by_compound):
    """
    Confirm, before an analysis starts, that each compound's logs record their scaling factors.

    Shifts are scaled by the constants written into the job titles. A log produced before those travelled
    there has none, and its method number cannot supply them either -- the number is no longer written, and
    guessing constants would mis-scale every shift in a way that looks entirely plausible in the output.

    Checking up front rather than at the point of use means the user is told immediately what to do, instead
    of waiting through an analysis that then stops partway with the same information.

    Returns a list of compound names whose logs are missing factors; empty means every compound is ready.
    """
    incomplete = []
    pattern = re.compile(r"_(?:carbon|proton)\b.*\bs:[-+]?[0-9]*\.?[0-9]+\s+i:[-+]?[0-9]*\.?[0-9]+")
    for compound, paths in sorted(paths_by_compound.items()):
        found = False
        for path in sorted(paths)[:3]:      # the first few conformers settle it; they share a job setup
            try:
                with open(path, 'r', errors='replace') as handle:
                    for line in handle:
                        if pattern.search(line):
                            found = True
                            break
            except OSError:
                continue
            if found:
                break
        if not found:
            incomplete.append(compound)
    return incomplete


def check_output_location(directory, estimated_files=0):
    """
    Confirm a directory can actually be written to before a long run starts.

    Creating the directory and beginning work discovers an unwritable path, a disconnected network drive or a
    full disk only partway through -- after clustering has already run and with partial output on disk. The
    checks here cost milliseconds and turn all of that into one message before anything happens.

    Returns a list of problems; empty means good to proceed.
    """
    problems = []
    try:
        os.makedirs(directory, exist_ok=True)
    except OSError as error:
        return [f"Cannot create the output folder: {error}"]

    # Writability is tested by actually writing, because permission bits, read-only network mounts and
    # filesystem quotas do not all show up the same way in a stat() check
    probe = os.path.join(directory, '.write_test')
    try:
        with open(probe, 'w', encoding='utf-8') as handle:
            handle.write('test')
        os.remove(probe)
    except OSError as error:
        problems.append(f"The output folder is not writable: {error}")
        return problems

    try:
        usage = shutil.disk_usage(directory)
        free_mb = usage.free / (1024 * 1024)
        # Gaussian inputs are small, but a large ensemble plus clustering copies adds up; warn well before the
        # point where a run would fail partway
        needed_mb = max(50, estimated_files * 0.05)
        if free_mb < needed_mb:
            problems.append(f"Only {free_mb:.0f} MB free on that drive; roughly {needed_mb:.0f} MB is needed.")
        elif free_mb < needed_mb * 4:
            problems.append(f"Low disk space: {free_mb:.0f} MB free. The run should fit but leaves little room.")
    except OSError:
        pass   # Disk usage is unavailable on some network mounts; not a reason to block the run

    return problems


def workbench_directory():
    """The directory this program lives in, used as the default output location."""
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except NameError:
        return os.getcwd()


def workbench_config_path():
    """
    Where the configuration file lives: beside this script.

    Deliberately not the current working directory, which changes as the analysis tab moves between log
    directories -- the configuration should follow the program, not whatever folder was last opened.
    """
    return os.path.join(workbench_directory(), CONFIG_FILENAME)


def load_workbench_config(path=None):
    """
    Read methods and machine profiles from the configuration file, creating it from defaults if absent.

    Returns (methods, machines, problems). Parsing is deliberately forgiving: a malformed section is reported
    and skipped rather than aborting the load, so one bad edit costs that one method instead of preventing the
    program from starting -- which would leave no way to reach the file and fix it.
    """
    path = path or workbench_config_path()
    problems = []

    if not os.path.exists(path):
        try:
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write(DEFAULT_CONFIG_TEXT)
            problems.append(f"Created a default configuration file at {path}")
        except OSError as error:
            problems.append(f"Could not create {path} ({error}); using built-in defaults for this session.")
            return _parse_workbench_config_text(DEFAULT_CONFIG_TEXT, problems)

    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as handle:
            text = handle.read()
    except OSError as error:
        problems.append(f"Could not read {path} ({error}); using built-in defaults for this session.")
        text = DEFAULT_CONFIG_TEXT

    methods, machines, problems = _parse_workbench_config_text(text, problems)
    if not methods:
        problems.append("No usable [method:...] sections were found; falling back to the built-in defaults.")
        methods, machines, problems = _parse_workbench_config_text(DEFAULT_CONFIG_TEXT, problems)
    return methods, machines, problems


def _parse_workbench_config_text(text, problems):
    """
    Parse the configuration format.

    Written by hand rather than with configparser because route lines contain '%' and ':' characters that
    configparser's interpolation and delimiter handling would mangle, and because a route line's value must
    survive verbatim -- a silently altered Gaussian route is far worse than a parse error.
    """
    methods, machines = {}, {}
    section_kind, section_name, section = None, None, {}

    def commit():
        if section_kind == 'method' and section_name:
            required = ('opt_route', 'carbon_route', 'proton_route')
            missing = [key for key in required if not section.get(key)]
            if missing:
                problems.append(f"[method:{section_name}] is missing {', '.join(missing)}; skipped.")
            else:
                methods[section_name] = dict(section)
        elif section_kind == 'machine' and section_name:
            tiers = {}
            for key, value in section.items():
                if not key.startswith('tier.'):
                    continue
                parts = [piece.strip() for piece in value.split(',')]
                if len(parts) != 2 or not parts[0].isdigit():
                    problems.append(f"[machine:{section_name}] tier '{key[5:]}' should read "
                                    f"'cores, memory' (e.g. '32, 63GB'); skipped.")
                    continue
                tiers[key[5:]] = {'nprocshared': int(parts[0]), 'mem': parts[1]}
            if not tiers:
                problems.append(f"[machine:{section_name}] defines no usable tiers; skipped.")
            else:
                machines[section_name] = {'label': section.get('label', section_name),
                                          'chk': section.get('chk', '%chk={compound}_{conformer}.chk'),
                                          'rwf': section.get('rwf', ''),
                                          'tiers': tiers}

    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith('#') or line.startswith(';'):
            continue
        if line.startswith('[') and line.endswith(']'):
            commit()
            header = line[1:-1].strip()
            if ':' in header:
                kind, name = header.split(':', 1)
                section_kind, section_name, section = kind.strip().lower(), name.strip(), {}
            else:
                problems.append(f"Section [{header}] is not [method:NAME] or [machine:NAME]; skipped.")
                section_kind, section_name, section = None, None, {}
            continue
        if '=' not in line or section_kind is None:
            continue
        key, value = line.split('=', 1)
        section[key.strip().lower()] = value.strip()
    commit()

    return methods, machines, problems


def build_method_from_config(method_key, include_cc, include_fluorine, include_nitrogen,
                             temperature=None, contains_iodine=False):
    """
    Build one method's route lines from its configuration entry.

    Returns the same dictionary shape the built-in methods produced, so every caller is unchanged. Iodine is
    handled here rather than in the config: any basis becomes "gen", matching the gen block written into the
    input separately, which keeps the configuration free of a detail that is the same for every method.
    """
    entry = WORKBENCH_METHODS.get(method_key)
    if not entry:
        return None

    temperature_keyword = f" temperature={temperature}" if temperature else ""
    substitutions = {'temperature': temperature_keyword}
    for basis_key in ('opt_basis', 'carbon_basis', 'proton_basis', 'fluorine_basis',
                      'nitrogen_basis', 'cc_basis'):
        substitutions[basis_key] = "gen" if contains_iodine else entry.get(basis_key, '')

    def render(route_key):
        template = entry.get(route_key)
        if not template:
            return None
        try:
            return template.format(**substitutions)
        except (KeyError, IndexError, ValueError) as error:
            WORKBENCH_CONFIG_PROBLEMS.append(
                f"[method:{method_key}] {route_key} uses an unknown placeholder ({error}); "
                f"the route was written unchanged.")
            return template

    result = {
        'opt': render('opt_route'),
        'carbon': render('carbon_route'),
        'proton': render('proton_route'),
        'fluorine': render('fluorine_route') if include_fluorine else None,
        'nitrogen': render('nitrogen_route') if include_nitrogen else None,
        'cc': render('cc_route') if include_cc else None,
    }
    for scaling_key in ('carbon_slope', 'carbon_intercept', 'proton_slope', 'proton_intercept'):
        if entry.get(scaling_key):
            result[scaling_key] = entry[scaling_key]
    return result

# ==================================================================================================================
# OPTIMIZATION ROUTE GUARANTEES
# ==================================================================================================================
# Certain keywords are not optional on an optimization job, regardless of where the route came from -- a built-in
# method, an edited configuration file, or the custom fields in the interface:
#
#   opt                 without it the geometry is never optimized
#   freq=noraman        the frequencies confirm a true minimum and supply the thermochemistry the Boltzmann
#                       weighting needs; noraman skips Raman intensities nothing here uses
#   geom=connectivity   the connectivity block written into the input is only read when this is present
#   pop=nboread         makes Gaussian read the $NBO block and print the Wiberg bond index matrix, which is
#                       where the analysis half gets true bond orders
#
# Omitting any of them produces a job that runs, finishes, and is then useless to the rest of this pipeline --
# usually with no obvious error. A missing pop=nboread simply means no matrix, and bond orders silently fall
# back to whatever the input SDF claimed. So rather than trusting every route to be written correctly, anything
# missing is added here and reported, instead of the omission passing unnoticed.

# (detection token, keyword to add). The detection token is deliberately narrower than the keyword: Gaussian
# accepts grouped forms such as pop=(nboread,nbo) and geom=(connectivity,check), which carry the required
# behaviour without matching the literal keyword text. Detecting on the inner token recognises those and leaves
# them alone, where matching the full keyword would append a contradictory duplicate.
OPTIMIZATION_REQUIRED_KEYWORDS = (
    ('opt', 'opt'),
    ('freq', 'freq=noraman'),
    ('connectivity', 'geom=connectivity'),
    ('nboread', 'pop=nboread'),
)


def enforce_optimization_keywords(route, temperature=None):
    """
    Guarantee the keywords an optimization route must carry. Returns (route, added).

    Detection is by keyword stem rather than exact text, so a route already carrying freq=noraman, or a variant
    such as pop=(nboread,nbo), is left alone instead of gaining a duplicate. Anything genuinely absent is
    appended, and the temperature keyword is added when a temperature was requested and none is present.
    """
    if not route:
        return route, []

    body = route.strip()
    lowered = body.lower()
    added = []

    for stem, keyword in OPTIMIZATION_REQUIRED_KEYWORDS:
        if stem == 'opt':
            # 'opt' occurs inside other words, so it has to be matched as a standalone token
            if re.search(r'(?<![A-Za-z0-9=])opt\b', lowered):
                continue
        elif stem in lowered:
            continue
        body += " " + keyword
        added.append(keyword)

    if temperature and 'temperature=' not in lowered:
        body += " temperature=" + str(temperature)
        added.append("temperature=" + str(temperature))

    return body, added


def apply_optimization_guarantees(method_parameters, temperature=None, announce=True):
    """Run the optimization route through enforce_optimization_keywords, reporting anything it had to add."""
    if not method_parameters or not method_parameters.get('opt'):
        return method_parameters
    route, added = enforce_optimization_keywords(method_parameters['opt'], temperature)
    if added:
        method_parameters['opt'] = route
        if announce:
            print("  Added required optimization keyword(s): " + ", ".join(added))
    return method_parameters


def build_route_preview(method_key, include_cc, include_fluorine, include_nitrogen, temperature,
                        machine_key, tier_name, contains_iodine=False,
                        compound_name=None, structure=None, include_csulfur=False, include_chalogen=False):
    """
    The input file as it will actually be written, resolved as far as the settings allow.

    Almost nothing in a Gaussian input actually varies between conformers of one compound. The route lines,
    resource lines, scaling factors, formal charges, total charge and multiplicity, the job title, the
    connectivity block and any gen basis block are all fixed once the compound and the settings are chosen.
    Only two things genuinely change from one conformer to the next: the conformer NUMBER and the COORDINATES.
    Those are the only placeholders shown; everything else is the literal text.

    structure, when supplied, is (elements, connectivity, per_atom_charges) read from one of the loaded SDF
    files. Without it the charge-dependent parts cannot be resolved and fall back to placeholders, which is
    what happens before any file is loaded.
    """
    lines = []
    machine = WORKBENCH_MACHINES.get(machine_key, {})
    tiers = machine.get('tiers') or {'medium': {'nprocshared': 32, 'mem': '63GB'}}
    tier = tiers.get(tier_name) or next(iter(tiers.values()))

    chk_template = machine.get('chk') or '%chk={compound}_{conformer}.chk'
    rwf_template = machine.get('rwf', '')
    name = compound_name or '{compound}'

    elements, connectivity, per_atom_charges = (structure or (None, None, None))
    if elements:
        total_charge = sum((per_atom_charges or {}).values())
        charge_line = f"{total_charge} 1"          # multiplicity is 1 for every job this program writes
        serialized = serialize_connectivity_and_charge(connectivity or {}, per_atom_charges or {})
        connectivity_block = []
        for atom in range(1, len(elements) + 1):
            bonds = (connectivity or {}).get(atom, [])
            connectivity_block.append(f"{atom} {' '.join(bonds)}" if bonds else f"{atom}")
        element_set = set(elements)
    else:
        charge_line = "{charge} {multiplicity}"
        serialized = None
        connectivity_block = ["{connectivity}"]
        element_set = set()

    try:
        parameters = get_method_parameters(method_key, include_cc, include_fluorine, include_nitrogen,
                                           temperature, contains_iodine)
    except Exception as error:
        return "(cannot build the routes yet: " + str(error) + ")"
    if not parameters:
        return "(no method selected)"
    parameters = apply_optimization_guarantees(dict(parameters), temperature, announce=False)
    if not parameters.get('opt'):
        return "(this method defines no optimization route)"

    def header(job_name):
        block = []
        fields = {'compound': job_name, 'conformer': '{conformer}'}
        if rwf_template:
            block.append(rwf_template.format(**fields))
        block.append(chk_template.format(**fields))
        block.append("%nprocshared=" + str(tier['nprocshared']))
        block.append("%mem=" + str(tier['mem']))
        return block

    def title(job_name, job_type, params):
        """The real job title, with only the conformer number left open."""
        text = f"{job_name}_{{conformer}}_{job_type}"
        if job_type == 'opt':
            if serialized:
                text += " " + serialized
        else:
            slope, intercept = resolve_scaling_factors(method_key, job_type, params)
            if slope is not None and intercept is not None:
                text += f" s:{slope} i:{intercept}"
        return text

    def basis_block(job_type):
        """The gen basis block, shown in full whenever a gen basis is actually in play."""
        if not element_set:
            return []
        route = parameters.get(job_type) or ''
        if '/gen' not in route.replace(' ', '') and not contains_iodine:
            return []
        try:
            text = build_basis_set_block(element_set, method_key, job_type,
                                         resolve_basis_source(method_key, parameters))
        except Exception:
            return []
        return ([''] + text.rstrip('\n').split('\n')) if text.strip() else []

    def one_file(job_name, params, job_types):
        block = []
        first = True
        for job_type in job_types:
            route = params.get(job_type)
            if not route:
                continue
            if not first:
                block.append("--Link1--")
            block.extend(header(job_name))
            block.append(route)
            block.append("")
            block.append(title(job_name, job_type, params))
            block.append("")
            block.append(charge_line)
            if first:
                # Only the first job carries coordinates and connectivity; every later job runs
                # geom=check guess=read and takes its geometry from the checkpoint
                block.append("{coordinates}")
                block.append("")
                block.extend(connectivity_block)
                block.append("")
                block.extend(basis_block(job_type))
                block.append(NBO_INPUT_BLOCK)
            else:
                block.extend(basis_block(job_type))
            block.append("")
            first = False
        return block

    order = ('opt', 'carbon', 'proton', 'fluorine', 'nitrogen', 'cc')
    files = [(f"{name}_{{conformer}}.gjf", one_file(name, parameters, order))]

    # The element-specific corrections are written as their own complete input files, not as extra Link1
    # sections, so they are shown separately with their own filenames rather than run together
    temperature_keyword = f" temperature={temperature}" if temperature else ""
    for enabled, suffix, basis in ((include_csulfur, 'csulfur', 'CSULFUR'),
                                   (include_chalogen, 'chalogen', 'CHALOGEN')):
        if not enabled:
            continue
        table = CSULFUR_BASIS if basis == 'CSULFUR' else CHALOGEN_BASIS
        special = {
            'opt': f"# opt freq=noraman{temperature_keyword} b3lyp/"
                   f"{'gen' if contains_iodine else table['opt']} geom=connectivity pop=nboread",
            'carbon': f"# nmr=giao b3lyp/{'gen' if contains_iodine else table['carbon']} "
                      f"geom=check guess=read",
            'carbon_slope': parameters.get('carbon_slope', ''),
            'carbon_intercept': parameters.get('carbon_intercept', ''),
        }
        job_name = f"{name}-{suffix}"
        files.append((f"{job_name}_{{conformer}}.gjf", one_file(job_name, special, ('opt', 'carbon'))))

    rendered = []
    for index, (filename, block) in enumerate(files):
        if index:
            rendered.append("")
            rendered.append("=" * 78)
        rendered.append(f"===== {filename} " + "=" * max(0, 78 - 8 - len(filename)))
        rendered.append("")
        rendered.extend(block)
    return "\n".join(rendered).rstrip() + "\n"

class equiv_LabelRegistry:
    """Maps signature tuples onto small integers, shared across refinement runs so labels stay comparable."""

    def __init__(self):
        self._ids = {}

    def identifier(self, signature):
        if signature not in self._ids:
            self._ids[signature] = len(self._ids)
        return self._ids[signature]

def equiv_refine_labels(adjacency, initial_labels, registry):
    """
    Refine atom labels until the partition stops splitting.

    Each round replaces an atom's label with a hash of its own label plus the sorted multiset of neighbour
    labels, so distinctions propagate outward one bond per round. Refinement only ever splits classes, so a
    round that does not increase the class count has reached the fixed point.

    No bond order enters this signature -- see equiv_build_adjacency.
    """
    labels = dict(initial_labels)
    class_count = len(set(labels.values()))

    for _ in range(len(adjacency) + 1):
        updated = {}
        for atom, neighbors in adjacency.items():
            signature = (labels[atom], tuple(sorted(labels[neighbor] for neighbor in neighbors)))
            updated[atom] = registry.identifier(signature)
        labels = updated
        new_count = len(set(labels.values()))
        if new_count == class_count:
            break
        class_count = new_count

    return labels

def equiv_initial_invariants(molecule, adjacency, registry):
    """Starting labels: everything about an atom that no symmetry operation can change."""
    labels = {}
    for atom in adjacency:
        labels[atom] = registry.identifier((
            'atom',
            molecule['elements'][atom - 1],
            molecule['charges'].get(atom, 0),
            molecule['isotopes'].get(atom, 0),
            len(adjacency[atom]),
        ))
    return labels

# ==================================================================================================================
# STEREOCHEMICAL CONSTRAINTS
# ==================================================================================================================

def equiv_collect_parity_centres(molecule, adjacency):
    """
    Collect every atom whose neighbour arrangement carries a handedness.

    Four-coordinate atoms are always included, and trivalent P/S/Se are included because they hold their
    configuration. Trivalent nitrogen is included only inside a 3- or 4-membered ring (equiv_SMALL_RING_NITROGEN_SIZES),
    where the inversion barrier is raised enough to occasionally matter; ordinary acyclic or larger-ring trivalent
    nitrogen is excluded because it inverts freely at room temperature. Centres whose neighbours are coplanar carry
    no handedness and are skipped, which removes sp2 carbon automatically.

    Every qualifying centre is kept, not only those with four different substituents. That is deliberate: it is
    precisely the parity of a CH2 or a ring carbon that decides whether its two hydrogens can be interchanged, and
    dropping those centres is what makes rule-based implementations merge the two protons of a rigid cyclopropane
    methylene.

    Atoms with 5 or more neighbours (trigonal bipyramidal, octahedral, ...) and cumulated-diene (allene-type) axes
    are NOT handled here at all -- point parity is not the right test for either, and a wrong test would be worse
    than no test. equiv_EquivalenceEngine excludes those atoms and their substituents from every equivalence class
    entirely (see equiv_HYPERVALENT_DEGREE_THRESHOLD / CUMULATED_DIENE_BOND_ORDER_TOLERANCE), rather than attempt to
    validate them here with a check that does not actually apply to their geometry.
    """
    centres = {}
    coordinates = molecule['coordinates']
    small_ring_atoms = set()
    for ring in equiv_find_relevant_rings(adjacency):
        if len(ring) in equiv_SMALL_RING_NITROGEN_SIZES:
            small_ring_atoms.update(ring)

    for atom, neighbors in adjacency.items():
        ordered = sorted(neighbors)
        if len(ordered) == 4:
            reference = [coordinates[neighbor - 1] for neighbor in ordered]
            volume = equiv_signed_volume(reference[0], reference[1], reference[2], reference[3])
        elif len(ordered) == 3 and (molecule['elements'][atom - 1] in equiv_PYRAMIDAL_STEREO_ELEMENTS or
                                     (molecule['elements'][atom - 1] == 'N' and atom in small_ring_atoms)):
            reference = [coordinates[neighbor - 1] for neighbor in ordered]
            volume = equiv_signed_volume(coordinates[atom - 1], reference[0], reference[1], reference[2])
        else:
            continue

        if abs(volume) >= equiv_PARITY_VOLUME_TOLERANCE:
            centres[atom] = ordered

    return centres

def equiv_collect_unverifiable_atoms(molecule, adjacency):
    """
    Collect every atom this script cannot correctly validate the stereochemistry of, so it can be excluded from
    every equivalence class outright rather than risk a wrong merge through an unhandled geometry.

    Two patterns are covered:
      - Hypervalent/hypercoordinate centres (>=5 neighbours): trigonal bipyramidal, octahedral and similar
        coordination geometries have their own stereochemistry (axial/equatorial, cis/trans/fac/mer) that a single
        signed volume does not capture. The centre itself and every atom directly bonded to it are excluded.
      - Cumulated-diene (allene-type) axes: a 2-coordinate atom that must be carrying two double bonds at once
        (not just one, and not a triple bond to a single neighbour -- see equiv_is_cumulated_diene_centre) to satisfy
        its own valence. Axial chirality is decided by comparing the orientation of the two TERMINAL substituent
        planes, a different geometric test than point parity, which this script does not perform. Every
        substituent on both terminal atoms is excluded.

    Returns a set of 1-based atom indices.
    """
    unverifiable = set()

    for atom, neighbors in adjacency.items():
        if len(neighbors) >= equiv_HYPERVALENT_DEGREE_THRESHOLD:
            unverifiable.add(atom)
            unverifiable.update(neighbors)

    for atom in adjacency:
        if equiv_is_cumulated_diene_centre(molecule, adjacency, atom):
            for terminal in adjacency[atom]:
                unverifiable.add(terminal)
                unverifiable.update(other for other in adjacency[terminal] if other != atom)

    return unverifiable

def equiv_is_cumulated_diene_centre(molecule, adjacency, atom):
    """
    True when an atom must be carrying two double bonds simultaneously (an allene-type axis).

    A 2-coordinate atom needing 2 extra bond-order units to satisfy its standard valence (carbon: wants 4, has
    2 -- short by 2) could be resolved either by a triple bond to ONE neighbour (an alkyne, no axial chirality:
    only one plane of substitution exists) or by a separate double bond to EACH of its two neighbours (a
    genuine cumulated diene, with a plane of substitution at both ends). Those two cases are told apart by
    what is true of the neighbours: an alkyne's partner carbon is itself only 2-coordinate (its own 2 valence
    units are already spent entirely on the triple bond back), whereas each terminal atom of a real allene has
    at least one further substituent beyond the central atom (>=3 total neighbours), which is what actually
    creates a plane capable of axial chirality in the first place.

    A 2-coordinate atom that only needs 1 extra unit (nitrogen: wants 3, has 2) is satisfied by an ordinary
    single double bond to just one neighbour -- an imine or azo nitrogen, for instance, including one whose
    OTHER substituent happens to itself be 3-coordinate (an N-aryl imine's aryl ipso carbon). Requiring a
    deficit of at least 2 is what keeps this from misfiring on that common, unrelated case.
    """
    if len(adjacency[atom]) != 2:
        return False
    element = molecule['elements'][atom - 1]
    if element not in equiv__STANDARD_VALENCE or molecule['charges'].get(atom, 0) != 0:
        return False
    if equiv__STANDARD_VALENCE[element] - 2 < 2:
        return False
    return all(len(adjacency[neighbor]) >= 3 for neighbor in adjacency[atom])

def equiv_centre_parity(molecule, centre, neighbor_order):
    """Sign of the ordered neighbour arrangement about a centre; +1 or -1."""
    coordinates = molecule['coordinates']
    points = [coordinates[neighbor - 1] for neighbor in neighbor_order]
    if len(points) == 4:
        volume = equiv_signed_volume(points[0], points[1], points[2], points[3])
    else:
        volume = equiv_signed_volume(coordinates[centre - 1], points[0], points[1], points[2])
    return 1 if volume > 0 else -1

# Standard (neutral-atom) valence for the elements this affects most: the minimum bonding capacity below which
# an atom of that element MUST be using at least one multiple bond to satisfy its valence. Used only for
# 2-coordinate atoms, where local planarity (see equiv_is_locally_planar) cannot be tested directly -- a degree-2
# nitrogen (imine, azo) is valence-deficient (wants 3) and must have a double bond somewhere; a degree-2 oxygen
# (ether, alcohol) is not (wants exactly 2) and is correctly left alone. A +1 formal charge raises N and O's
# entries by one (ammonium/iminium nitrogen, oxocarbenium oxygen); other charge states are rare enough in stable
# organic structures that they are not specifically covered, and fall through to the SAFE default below.
equiv__STANDARD_VALENCE = {'H': 1, 'C': 4, 'N': 3, 'O': 2, 'S': 2, 'P': 3, 'F': 1, 'Cl': 1, 'Br': 1, 'I': 1, 'B': 3}

def equiv_is_locally_planar(molecule, adjacency, atom):
    """
    True when an atom's own arrangement (itself plus its neighbours) is geometrically flat.

    This is the direct, geometry-only signature of sp2 hybridization, using the same signed-volume math as
    stereocentre detection. It only applies where there are enough neighbours to define a meaningful local
    plane (3, the ordinary alkene/carbonyl/amide case); 2-coordinate atoms are handled by equiv_is_valence_deficient
    instead, and 4-coordinate atoms are essentially never planar (that would itself signal a stereocentre, not
    a double bond) so they are not tested here at all.
    """
    neighbors = sorted(adjacency[atom])
    if len(neighbors) != 3:
        return False
    coordinates = molecule['coordinates']
    points = [coordinates[atom - 1]] + [coordinates[neighbor - 1] for neighbor in neighbors]
    volume = equiv_signed_volume(points[0], points[1], points[2], points[3])
    return abs(volume) < equiv_PARITY_VOLUME_TOLERANCE

def equiv_is_valence_deficient(molecule, adjacency, atom):
    """
    True when a 2-coordinate atom's element cannot satisfy its standard valence without a multiple bond.

    This is what distinguishes an imine or azo nitrogen (degree 2, wants 3 -- a double bond MUST be present)
    from an ether oxygen or thioether sulfur (degree 2, wants exactly 2 -- fully satisfied, freely rotating).
    Only applied at degree 2; see equiv_is_locally_planar for the degree-3 case, which geometry already covers
    directly. Elements outside equiv__STANDARD_VALENCE, and formal charges other than a simple +1 on N/O, fall
    through to True (flagged as potentially restricted) -- the safe default when the valence is genuinely
    unknown, since flagging a bond that turns out to be free only costs an unmerged pair, never an incorrect one.
    """
    if len(adjacency[atom]) != 2:
        return False
    element = molecule['elements'][atom - 1]
    charge = molecule['charges'].get(atom, 0)
    if element not in equiv__STANDARD_VALENCE:
        return True
    expected = equiv__STANDARD_VALENCE[element]
    if charge == 1 and element in ('N', 'O'):
        expected += 1
    elif charge != 0:
        return True
    return len(adjacency[atom]) < expected

def equiv_collect_rigid_bonds(molecule, adjacency):
    """
    Collect bonds across which substituents cannot exchange sides, with the cis/trans relationships to preserve.

    A bond qualifies when BOTH of its atoms show sp2-like character -- geometric planarity at degree 3
    (equiv_is_locally_planar), or standard-valence deficiency at degree 2 (equiv_is_valence_deficient). This covers formal
    double bonds and amide-type C-N linkages exactly as before, without reading bond order from the file at
    all: an amide carbon and amide nitrogen are both genuinely planar in any reasonable 3D structure, which is
    what actually makes the bond rigid, not a label saying so. Relationships near 90 degrees are left out: they
    are neither cis nor trans, and reading a sign off them would make the result depend on numerical noise.
    """
    coordinates = molecule['coordinates']
    rigid = []
    sp2_like = {atom: (equiv_is_locally_planar(molecule, adjacency, atom) or equiv_is_valence_deficient(molecule, adjacency, atom))
               for atom in adjacency}

    for atom1 in sorted(adjacency):
        for atom2 in sorted(adjacency[atom1]):
            if atom2 <= atom1:
                continue
            if not (sp2_like[atom1] and sp2_like[atom2]):
                continue

            for first in sorted(adjacency[atom1]):
                if first == atom2:
                    continue
                for second in sorted(adjacency[atom2]):
                    if second == atom1:
                        continue
                    relationship = equiv_torsion_side(coordinates, first, atom1, atom2, second)
                    if relationship is not None:
                        rigid.append((first, atom1, atom2, second, relationship))

    return rigid

def equiv_torsion_side(coordinates, first, atom1, atom2, second):
    """
    Return +1 when two substituents sit on the same side of a bond, -1 when opposite, None when undefined.

    Reflection maps cis onto cis, so this relationship must be preserved by proper and improper operations alike,
    unlike a parity, which inverts under reflection.
    """
    axis = equiv_subtract(coordinates[atom2 - 1], coordinates[atom1 - 1])
    axis_length = equiv_norm(axis)
    if axis_length < 1e-9:
        return None

    branch1 = equiv_subtract(coordinates[first - 1], coordinates[atom1 - 1])
    branch2 = equiv_subtract(coordinates[second - 1], coordinates[atom2 - 1])
    unit = (axis[0] / axis_length, axis[1] / axis_length, axis[2] / axis_length)
    # Project each substituent into the plane perpendicular to the bond, then compare directions
    perpendicular1 = equiv_subtract(branch1, tuple(component * equiv_dot(branch1, unit) for component in unit))
    perpendicular2 = equiv_subtract(branch2, tuple(component * equiv_dot(branch2, unit) for component in unit))
    length1, length2 = equiv_norm(perpendicular1), equiv_norm(perpendicular2)
    if length1 < 1e-6 or length2 < 1e-6:
        return None

    cosine = equiv_dot(perpendicular1, perpendicular2) / (length1 * length2)
    if abs(cosine) < equiv_CIS_TRANS_COS_TOLERANCE:
        return None
    return 1 if cosine > 0 else -1

# ==================================================================================================================
# AUTOMORPHISM SEARCH
# ==================================================================================================================

equiv_CIS_TRANS_COS_TOLERANCE = 0.08      # |cos(torsion)| below this leaves a cis/trans relationship undefined and unchecked
equiv_HYPERVALENT_DEGREE_THRESHOLD = 5  # Atoms bonded to this many or more neighbours (trigonal bipyramidal, octahedral, ...) have stereochemistry (axial/equatorial, cis/trans/fac/mer) this script has no mechanism to verify; such atoms and every atom directly bonded to them are excluded from every equivalence class rather than risk validating them with a check (point parity) that does not actually apply to that coordination geometry
equiv_MAX_RING_SIZE = 10                  # Largest ring considered when perceiving conjugated systems
equiv_MAX_SEARCH_NODES = 2000000          # Backtracking node budget per atom pair; exceeded means the pair is reported as undetermined (the safe direction -- see the exhaustion warning in the report)
# Every tolerance below is a noise filter, not a chemistry judgment call: DFT-optimized geometries carry
# positional uncertainty many times smaller than any of these values (a converged gradient corresponds to
# sub-0.001 Angstrom positional noise), so each threshold is set as tight as that noise floor allows rather
# than to a "typical looks-planar" scale. Tightening a threshold can only ever cause the script to treat MORE
# borderline centres as stereogenic or MORE borderline torsions as checkable -- i.e. it can only turn a
# would-be merge into a split, never the reverse -- which is the direction this script is deliberately biased
# toward throughout: a missed merge costs a slightly less consolidated dataset; a wrong merge is silently
# unrecoverable once it feeds into downstream averaging.
equiv_PARITY_VOLUME_TOLERANCE = 0.02      # Cubic Angstroms; below this a centre is treated as planar and carries no parity
equiv_PYRAMIDAL_STEREO_ELEMENTS = frozenset({'P', 'S', 'Se', 'As'})  # Trivalent centres that hold their configuration; ordinary trivalent N is excluded because acyclic/unstrained amine inversion is fast at room temperature -- this is settled chemistry, not an unresolved risk, so it is deliberately NOT folded into the conservative bias above (see equiv_SMALL_RING_NITROGEN_SIZES for the one case where trivalent N genuinely can be configurationally stable)
equiv_RIGID_GEOMETRY_TOLERANCE = 0.15     # Angstroms; interatomic equiv_distance agreement required to call a mapping a symmetry of the deposited geometry (governs the rigid/averaged LABEL only, never whether atoms merge)
equiv_SMALL_RING_NITROGEN_SIZES = frozenset({3, 4})  # Ring sizes in which trivalent nitrogen's inversion barrier is raised enough that it is treated as a stereocentre (e.g. aziridine); larger rings and acyclic amines still invert fast and are left unchecked

def equiv_cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])

def equiv_build_adjacency(molecule):
    """
    Adjacency as {atom: set(neighbours)} over 1-based atom numbers.

    Bond order is deliberately not retained here or anywhere in the graph structure that follows. See the module
    docstring's BOND ORDER INDEPENDENCE section for why: in short, degree already carries the information bond
    order would add (a multiply-bonded atom simply has fewer other neighbours than a saturated one would), and
    not distinguishing bond order sidesteps having to trust a field that different SDF writers encode differently
    for the exact same molecule (Kekule vs delocalized aromatic rings, resonance structures for non-ring groups
    like carboxylates or nitro groups, and so on).
    """
    adjacency = {atom: set() for atom in range(1, molecule['atom_count'] + 1)}
    for (atom1, atom2) in molecule['bonds']:
        if atom1 in adjacency and atom2 in adjacency and atom1 != atom2:
            adjacency[atom1].add(atom2)
            adjacency[atom2].add(atom1)
    return adjacency

def equiv_distance(a, b):
    return equiv_norm(equiv_subtract(a, b))

def equiv_dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]

def equiv_find_relevant_rings(adjacency):
    """
    Return the smallest ring through each bond.

    This is cheaper than a full cycle enumeration and is all that small-ring detection needs (currently used to
    find 3- and 4-membered rings for the small-ring-nitrogen stereocentre check): every ring that matters is the
    smallest ring through at least one of its own bonds.
    """
    rings = set()
    for atom1 in adjacency:
        for atom2 in adjacency[atom1]:
            if atom2 <= atom1:
                continue
            # Shortest path from atom1 back to atom2 without using the direct bond closes the smallest ring
            previous = {atom1: None}
            queue = deque([atom1])
            while queue:
                current = queue.popleft()
                if current == atom2:
                    break
                for neighbor in adjacency[current]:
                    if current == atom1 and neighbor == atom2:
                        continue
                    if neighbor not in previous:
                        previous[neighbor] = current
                        queue.append(neighbor)
            if atom2 not in previous:
                continue
            path, node = [], atom2
            while node is not None:
                path.append(node)
                node = previous[node]
            if 3 <= len(path) <= equiv_MAX_RING_SIZE:
                rings.add(tuple(sorted(path)))
    return [list(ring) for ring in rings]

def equiv_norm(a):
    return math.sqrt(equiv_dot(a, a))

def equiv_signed_volume(p0, p1, p2, p3):
    """Signed volume of the tetrahedron p0-p1-p2-p3; its sign is the handedness of the ordered triple about p0."""
    return equiv_dot(equiv_subtract(p1, p0), equiv_cross(equiv_subtract(p2, p0), equiv_subtract(p3, p0)))

def equiv_subtract(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


class equiv_EquivalenceEngine:
    """Holds everything derived from one molecule and answers "can atom A map onto atom B" questions."""

    def __init__(self, molecule):
        self.molecule = molecule
        self.adjacency = equiv_build_adjacency(molecule)
        self.registry = equiv_LabelRegistry()
        self.base_labels = equiv_refine_labels(self.adjacency, equiv_initial_invariants(molecule, self.adjacency, self.registry), self.registry)

        self.parity_centres = equiv_collect_parity_centres(molecule, self.adjacency)
        self.rigid_bonds = equiv_collect_rigid_bonds(molecule, self.adjacency)
        self.unverifiable_atoms = equiv_collect_unverifiable_atoms(molecule, self.adjacency)

        # For incremental pruning: which constraints become checkable once a given atom is mapped
        self.centres_touching = defaultdict(list)
        for centre, neighbors in self.parity_centres.items():
            for atom in [centre] + neighbors:
                self.centres_touching[atom].append(centre)
        self.bonds_touching = defaultdict(list)
        for index, constraint in enumerate(self.rigid_bonds):
            for atom in constraint[:4]:
                self.bonds_touching[atom].append(index)

        self._seeded_cache = {}
        self.search_exhausted = False
        self.exhausted_atoms = set()  # Source atoms for which the search hit its node budget; reported by name, not just a generic flag

        # The search recurses once per atom, so the interpreter default is raised for large structures
        sys.setrecursionlimit(max(sys.getrecursionlimit(), molecule['atom_count'] * 4 + 1000))

    def seeded_labels(self, atom):
        """Refinement with one atom individualized; two atoms can only correspond if these labels match throughout."""
        if atom not in self._seeded_cache:
            seeded = dict(self.base_labels)
            seeded[atom] = self.registry.identifier(('seed', self.base_labels[atom]))
            self._seeded_cache[atom] = equiv_refine_labels(self.adjacency, seeded, self.registry)
        return self._seeded_cache[atom]

    def find_mapping(self, source, target, required_sign, require_rigid):
        """
        Search for an automorphism carrying source onto target under two fixed constraints.

        required_sign fixes how parities must transform: +1 for a rotation-like operation, -1 for a reflection-like
        one. Fixing it up front turns the stereochemical test into a pruning rule that applies the moment a centre
        becomes fully mapped, instead of a check that can only run once a whole candidate mapping exists.

        require_rigid additionally demands that every interatomic equiv_distance survive the mapping, which is true only
        when the operation is a symmetry of the deposited geometry itself rather than one that needs bond rotation
        or ring flipping. Callers try the constrained combinations first, so a successful search proves the label it
        reports rather than merely being consistent with it.

        Returns the mapping, or None.
        """
        labels_source = self.seeded_labels(source)
        labels_target = self.seeded_labels(target)

        # Cheap rejection: individualizing either atom must produce the same class sizes, or no mapping can exist
        source_histogram = defaultdict(int)
        target_histogram = defaultdict(int)
        for atom in self.adjacency:
            source_histogram[labels_source[atom]] += 1
            target_histogram[labels_target[atom]] += 1
        if source_histogram != target_histogram:
            return None

        candidates_by_label = defaultdict(list)
        for atom in sorted(self.adjacency):
            candidates_by_label[labels_target[atom]].append(atom)

        coordinates = self.molecule['coordinates']
        order = self._mapping_order(source)
        mapping, reverse = {}, {}
        budget = [equiv_MAX_SEARCH_NODES]

        def constraints_hold(atom):
            """Check the stereochemical constraints completed by mapping this atom. No state is accumulated."""
            for centre in self.centres_touching[atom]:
                neighbors = self.parity_centres[centre]
                if centre not in mapping or any(neighbor not in mapping for neighbor in neighbors):
                    continue
                before = equiv_centre_parity(self.molecule, centre, neighbors)
                after = equiv_centre_parity(self.molecule, mapping[centre], [mapping[neighbor] for neighbor in neighbors])
                if before * after != required_sign:
                    return False  # A mixed set of parities corresponds to no rotation and no reflection

            for index in self.bonds_touching[atom]:
                first, atom1, atom2, second, relationship = self.rigid_bonds[index]
                if any(participant not in mapping for participant in (first, atom1, atom2, second)):
                    continue
                image = equiv_torsion_side(coordinates, mapping[first], mapping[atom1], mapping[atom2], mapping[second])
                if image is not None and image != relationship:
                    return False  # Reflection maps cis onto cis, so this must hold for either sign

            return True

        def backtrack(position):
            if position == len(order):
                return True

            atom = order[position]
            for candidate in candidates_by_label[labels_source[atom]]:
                if candidate in reverse:
                    continue

                budget[0] -= 1
                if budget[0] <= 0:
                    self.search_exhausted = True
                    self.exhausted_atoms.add(source)
                    return False

                # Edge consistency in both directions is what makes the finished mapping a true automorphism.
                # Only connectivity is checked -- no bond order -- per the module docstring's BOND ORDER
                # INDEPENDENCE section.
                if any(mapping[neighbor] not in self.adjacency[candidate]
                       for neighbor in self.adjacency[atom] if neighbor in mapping):
                    continue
                if any(reverse[neighbor] not in self.adjacency[atom]
                       for neighbor in self.adjacency[candidate] if neighbor in reverse):
                    continue
                if require_rigid and any(
                        abs(equiv_distance(coordinates[atom - 1], coordinates[mapped - 1]) -
                            equiv_distance(coordinates[candidate - 1], coordinates[image - 1])) > equiv_RIGID_GEOMETRY_TOLERANCE
                        for mapped, image in mapping.items()):
                    continue

                mapping[atom] = candidate
                reverse[candidate] = atom
                if constraints_hold(atom) and backtrack(position + 1):
                    return True
                del mapping[atom]
                del reverse[candidate]

            return False

        mapping[source] = target
        reverse[target] = source
        if not constraints_hold(source) or not backtrack(1):
            return None
        return dict(mapping)

    def relate(self, source, target):
        """
        Determine how two atoms are related, if at all.

        The four constrained searches are tried strongest first, so the reported relationship is the best one that
        actually exists: a rotation of the deposited geometry, then a reflection of it, then the same two allowing
        conformational motion. Returns (sign, rigid) or None when the atoms are inequivalent.
        """
        if source in self.unverifiable_atoms or target in self.unverifiable_atoms:
            return None  # See equiv_collect_unverifiable_atoms: this script cannot check this atom's stereochemistry, so it is never merged with anything
        for require_rigid in (True, False):
            for required_sign in (1, -1):
                if self.find_mapping(source, target, required_sign, require_rigid) is not None:
                    return required_sign, require_rigid
        return None

    def _mapping_order(self, source):
        """
        Order atoms so that each one is adjacent to something already mapped, keeping candidate lists short.

        The traversal restarts on any unvisited atom so disconnected records (salts, solvates, co-crystals) are
        covered rather than silently truncated.
        """
        order, seen = [source], {source}
        queue = deque([source])
        while True:
            while queue:
                current = queue.popleft()
                for neighbor in sorted(self.adjacency[current]):
                    if neighbor not in seen:
                        seen.add(neighbor)
                        order.append(neighbor)
                        queue.append(neighbor)
            remaining = [atom for atom in sorted(self.adjacency) if atom not in seen]
            if not remaining:
                return order
            seen.add(remaining[0])
            order.append(remaining[0])
            queue.append(remaining[0])

def equiv_find_equivalence_classes(molecule):
    """
    Partition the atoms of a molecule into equivalence classes.

    Refinement classes bound the work: only atoms sharing a refined label are ever tested against each other, and
    within a class each atom is tested against the representatives found so far, so a fully symmetric group costs
    one search per member.
    """
    engine = equiv_EquivalenceEngine(molecule)

    by_label = defaultdict(list)
    for atom in sorted(engine.adjacency):
        by_label[engine.base_labels[atom]].append(atom)

    classes = []
    for label in sorted(by_label, key=lambda key: (by_label[key][0],)):
        members = by_label[label]
        if len(members) == 1:
            classes.append({'atoms': list(members), 'sign': 1, 'rigid': True})
            continue

        groups = []
        for atom in members:
            for group in groups:
                relationship = engine.relate(group['atoms'][0], atom)
                if relationship is not None:
                    sign, rigid = relationship
                    group['atoms'].append(atom)
                    # Aggregated conservatively: one reflection-only link makes the whole class chirality sensitive,
                    # and one link needing conformational motion makes the whole class an averaged equivalence
                    group['sign'] = min(group['sign'], sign)
                    group['rigid'] = group['rigid'] and rigid
                    break
            else:
                groups.append({'atoms': [atom], 'sign': 1, 'rigid': True})
        classes.extend(groups)

    classes.sort(key=lambda group: group['atoms'][0])
    return classes, engine

def equiv_equivalent_groups_from_graph(elements, coordinates, bonds, charges=None, isotopes=None):
    """
    Adapter for callers that already hold a molecular graph rather than an SDF file.

    elements    list of element symbols, indexed from zero
    coordinates list of (x, y, z) tuples, indexed from zero
    bonds       {(atom1, atom2): order} over 1-based atom numbers, either key order accepted. The order value
                is accepted for compatibility with callers that naturally have it (e.g. ngp2's own connectivity
                dict) but is not read by anything downstream -- pass 1.0 for every bond if order isn't available
    charges     optional {atom: formal charge}
    isotopes    optional {atom: mass number}

    Returns {group_id: {'atoms': [...], 'element': symbol, 'count': n}} covering only the multi-atom classes,
    which is the shape the ngp2 pipeline already consumes from find_equivalent_atoms.
    """
    normalized_bonds = {}
    for (atom1, atom2), order in bonds.items():
        normalized_bonds[(min(atom1, atom2), max(atom1, atom2))] = float(order)

    molecule = {'title': '', 'version': 'graph', 'elements': list(elements),
                'coordinates': [tuple(position) for position in coordinates],
                'bonds': normalized_bonds, 'charges': dict(charges or {}), 'isotopes': dict(isotopes or {}),
                'atom_count': len(elements)}

    classes, _ = equiv_find_equivalence_classes(molecule)
    groups = {}
    for group_id, group in enumerate([entry for entry in classes if len(entry['atoms']) > 1], start=1):
        groups[group_id] = {'atoms': sorted(group['atoms']),
                            'element': elements[group['atoms'][0] - 1],
                            'count': len(group['atoms'])}
    return groups

# ==================================================================================================================
# REPORTING
# ==================================================================================================================




# ==================================================================================================================
# MAIN
# ==================================================================================================================



# ==================================================================================================================
# CONFORMER ALIGNMENT
# ==================================================================================================================
# Conformers arrive in whatever coordinate frame their sampler happened to produce. Two structures can be the
# same conformation and still look unrelated when loaded together, because one is translated and rotated with
# respect to the other. This step removes that difference by superimposing every conformer onto a common
# reference before anything else looks at them.
#
# WHAT IS AND IS NOT CHANGED. The transform applied is a proper rotation plus a translation -- a rigid-body
# motion. Rigid motions preserve every distance between points in the structure they act on, so every bond
# length, every angle, every torsion and every interatomic distance is bit-for-bit the same conformation
# afterwards; only its position and orientation in space differ. That is the whole point: the conformer is
# unchanged, its viewpoint is normalised. Reflection is deliberately excluded, since a reflection also preserves
# distances but inverts chirality, which would turn a structure into its mirror image while appearing to be a
# better fit.
#
# WHICH ATOMS DRIVE THE FIT. Heavy atoms and heteroatom-bound hydrogens. Carbon-bound hydrogens are excluded
# from the FIT (not from the output) because a methyl rotor's three hydrogens move independently of the
# skeleton; letting them pull on the superposition would rotate the whole molecule to chase a spinning group
# rather than settling the framework that actually defines the conformation. Every atom is then transformed by
# the resulting matrix, so nothing is dropped from the file.
#
# WHERE IT SITS. Immediately after any multi-structure file is split -- splitting is what produces the
# individual conformers this operates on -- and before clustering. Clustering compares geometry, so giving it a
# consistent frame is strictly better input, and job generation then inherits the aligned coordinates.

ALIGNMENT_POLAR_PARENTS = frozenset({'N', 'O', 'S', 'P'})
ALIGNMENT_HYDROGENS = frozenset({'H', 'D', 'T'})
ALIGNED_OUTPUT_DIR = "aligned_conformers"


def select_alignment_atoms(elements, connectivity):
    """
    Zero-based indices of the atoms that drive the superposition: heavy atoms plus polar hydrogens.

    Falls back to every atom when that selection would leave too few points to determine a rotation (fewer than
    three), which happens for very small molecules -- a diatomic has no meaningful orientation to fit anyway,
    and using everything is better than refusing to align.
    """
    selected = []
    for index, element in enumerate(elements):
        atom = index + 1
        if element not in ALIGNMENT_HYDROGENS:
            selected.append(index)
            continue
        neighbours = connectivity.get(atom, [])
        if any(elements[n - 1] in ALIGNMENT_POLAR_PARENTS
               for n in neighbours if 1 <= n <= len(elements)):
            selected.append(index)
    if len(selected) < 3:
        return list(range(len(elements)))
    return selected


def kabsch_transform(reference_points, target_points):
    """
    The rotation and the two centroids that superimpose target_points onto reference_points.

    Returns (rotation, target_centroid, reference_centroid) so the caller can apply
    (coordinates - target_centroid) @ rotation + reference_centroid to any atom set, including atoms that took
    no part in computing the fit. Returns None when a rotation cannot be determined.
    """
    if len(reference_points) != len(target_points) or len(reference_points) < 3:
        return None
    reference = np.asarray(reference_points, dtype=float)
    target = np.asarray(target_points, dtype=float)
    reference_centroid = reference.mean(axis=0)
    target_centroid = target.mean(axis=0)
    rotation = dedup_kabsch_rotation(reference, target)
    if rotation is None:
        return None
    return rotation, target_centroid, reference_centroid


def apply_rigid_transform(coordinates, transform):
    """Apply a (rotation, target_centroid, reference_centroid) transform to every coordinate."""
    rotation, target_centroid, reference_centroid = transform
    points = np.asarray(coordinates, dtype=float)
    return (points - target_centroid).dot(rotation) + reference_centroid


def rewrite_sdf_coordinates(text, new_coordinates):
    """
    Replace the coordinates in an SDF record, leaving every other byte alone.

    Rewriting only the coordinate fields rather than regenerating the file keeps the header, the counts line,
    the bond block, property lines and any data fields exactly as they were -- including anything this program
    does not itself understand. Both connection table versions are handled: V2000 coordinates occupy the first
    thirty characters of each atom line as three fixed ten-character fields, while V3000 carries them as
    whitespace-separated tokens on an 'M  V30' atom line.

    Returns (text, atoms_rewritten).
    """
    lines = text.split('\n')
    output = []
    index = 0
    written = 0

    version = 'V3000' if any('V3000' in line for line in lines[:6]) or \
                         any(line.startswith('M  V30') for line in lines) else 'V2000'

    if version == 'V2000':
        counts_line = None
        for position, line in enumerate(lines):
            if 'V2000' in line:
                counts_line = position
                break
        if counts_line is None:
            return text, 0
        try:
            atom_count = int(lines[counts_line][0:3])
        except (ValueError, IndexError):
            return text, 0

        for position, line in enumerate(lines):
            if counts_line < position <= counts_line + atom_count and index < len(new_coordinates):
                x, y, z = new_coordinates[index]
                # Fixed-width fields: the element symbol and everything after it are preserved verbatim from
                # column 30 onward, so charges and stereo flags survive untouched
                output.append(f"{x:10.4f}{y:10.4f}{z:10.4f}{line[30:]}")
                index += 1
                written += 1
            else:
                output.append(line)
        return '\n'.join(output), written

    in_atom_block = False
    for line in lines:
        upper = line.strip().upper()
        if 'BEGIN ATOM' in upper:
            in_atom_block = True
            output.append(line)
            continue
        if 'END ATOM' in upper:
            in_atom_block = False
            output.append(line)
            continue
        if in_atom_block and line.startswith('M  V30') and index < len(new_coordinates):
            parts = line[6:].split()
            if len(parts) >= 5:
                x, y, z = new_coordinates[index]
                trailing = ' '.join(parts[5:])
                rebuilt = f"M  V30 {parts[0]} {parts[1]} {x:.6f} {y:.6f} {z:.6f}"
                if trailing:
                    rebuilt += ' ' + trailing
                output.append(rebuilt)
                index += 1
                written += 1
                continue
        output.append(line)
    return '\n'.join(output), written


def align_conformer_files(conformer_files, output_directory, report=print):
    """
    Superimpose every conformer onto the first, writing aligned copies.

    conformer_files is a list of (conformer_number, path). The lowest-numbered conformer becomes the reference
    and is copied through unchanged, so the alignment is reproducible: running twice gives the same frame, and
    the reference structure is never itself moved.

    A conformer whose atom count differs from the reference is copied through unaligned rather than skipped,
    with a warning -- dropping a conformer silently would change which structures reach clustering.

    Returns (aligned_files, statistics).
    """
    if not conformer_files:
        return [], {}

    os.makedirs(output_directory, exist_ok=True)
    ordered = sorted(conformer_files, key=lambda pair: pair[0])
    reference_number, reference_path = ordered[0]

    try:
        reference_elements, reference_coordinates, reference_connectivity, _ = cluster_parse_sdf(reference_path)
    except Exception as error:
        report(f"  Could not read the alignment reference {os.path.basename(reference_path)} ({error}); "
               f"alignment skipped.")
        return list(conformer_files), {}

    alignment_indices = select_alignment_atoms(reference_elements, reference_connectivity)
    heavy = sum(1 for i in alignment_indices if reference_elements[i] not in ALIGNMENT_HYDROGENS)
    report(f"  Reference: conformer {reference_number}. Fitting on {len(alignment_indices)} atom(s) "
           f"({heavy} heavy, {len(alignment_indices) - heavy} polar hydrogen) of {len(reference_elements)}.")

    reference_fit_points = [reference_coordinates[i] for i in alignment_indices]
    aligned_files = []
    statistics = {'aligned': 0, 'reference': 0, 'unchanged': 0, 'rmsd_before': [], 'rmsd_after': []}

    for number, path in ordered:
        destination = os.path.join(output_directory, os.path.basename(path))
        try:
            with open(path, 'r', errors='replace') as handle:
                text = handle.read()
        except OSError as error:
            report(f"  Could not read {os.path.basename(path)} ({error}); left out of the aligned set.")
            continue

        if path == reference_path:
            try:
                with open(destination, 'w', encoding='utf-8') as handle:
                    handle.write(text)
                aligned_files.append((number, destination))
                statistics['reference'] += 1
            except OSError as error:
                report(f"  Could not write the reference copy ({error}).")
            continue

        try:
            elements, coordinates, _connectivity, _ = cluster_parse_sdf(path)
        except Exception as error:
            report(f"  Could not parse {os.path.basename(path)} ({error}); copied through unaligned.")
            elements, coordinates = None, None

        if not coordinates or elements is None or len(elements) != len(reference_elements):
            if elements is not None and len(elements) != len(reference_elements):
                report(f"  {os.path.basename(path)} has {len(elements)} atoms, the reference has "
                       f"{len(reference_elements)}; copied through unaligned.")
            try:
                with open(destination, 'w', encoding='utf-8') as handle:
                    handle.write(text)
                aligned_files.append((number, destination))
                statistics['unchanged'] += 1
            except OSError:
                pass
            continue

        target_fit_points = [coordinates[i] for i in alignment_indices]
        transform = kabsch_transform(reference_fit_points, target_fit_points)
        if transform is None:
            with open(destination, 'w', encoding='utf-8') as handle:
                handle.write(text)
            aligned_files.append((number, destination))
            statistics['unchanged'] += 1
            continue

        before = float(np.sqrt(((np.asarray(target_fit_points) - np.asarray(reference_fit_points)) ** 2)
                               .sum(axis=1).mean()))
        moved = apply_rigid_transform(coordinates, transform)
        after_points = moved[alignment_indices]
        after = float(np.sqrt(((after_points - np.asarray(reference_fit_points)) ** 2).sum(axis=1).mean()))
        statistics['rmsd_before'].append(before)
        statistics['rmsd_after'].append(after)

        rewritten, written = rewrite_sdf_coordinates(text, [tuple(row) for row in moved])
        if written != len(coordinates):
            report(f"  {os.path.basename(path)}: rewrote {written} of {len(coordinates)} coordinate(s); "
                   f"copied through unaligned to avoid a partial edit.")
            rewritten = text
            statistics['unchanged'] += 1
        else:
            statistics['aligned'] += 1

        try:
            with open(destination, 'w', encoding='utf-8') as handle:
                handle.write(rewritten)
            aligned_files.append((number, destination))
        except OSError as error:
            report(f"  Could not write {os.path.basename(destination)} ({error}).")

    if statistics['rmsd_before']:
        mean_before = sum(statistics['rmsd_before']) / len(statistics['rmsd_before'])
        mean_after = sum(statistics['rmsd_after']) / len(statistics['rmsd_after'])
        report(f"  Aligned {statistics['aligned']} conformer(s). Mean fit-atom RMSD to the reference: "
               f"{mean_before:.3f} A before, {mean_after:.3f} A after.")
        report(f"  Internal geometry is unchanged -- the transform is a rotation plus a translation, which "
               f"preserves every interatomic distance.")
    if statistics['unchanged']:
        report(f"  {statistics['unchanged']} conformer(s) were copied through without alignment.")

    return aligned_files, statistics

JOB_SETUP_HELP = """\
TAB 1 -- JOB SETUP:  conformer SDFs in, Gaussian input files out

Conformational searching happens before this tab. Bring in the conformers it produced.

1. CONFORMER INPUT
   Add individual SDF files, a whole folder, or one collective SDF holding the entire ensemble -- any mix
   works. A file containing several structures is split automatically at the start of the run; you do not need
   to split it first. The summary line reports how many structures were found, which is worth reading: a file
   turning out to hold hundreds of conformers is usually the first sign the wrong file was picked.

   NAMING MATTERS. Files must be named {compound}_{number}.sdf -- the compound name and conformer number are
   read from the filename. A file without a trailing _<number> is reported and skipped rather than silently
   ignored. Split files inherit the collective file's name with _confs stripped.

   ALIGNMENT is automatic and not optional. Every conformer is superimposed on the lowest-numbered one so they
   overlay when viewed together. This is a rotation plus a translation, which cannot change the structure:
   every bond length, angle and interatomic distance is identical afterwards. Only the viewpoint moves.

2. CLUSTERING (optional)
   Reduces a large ensemble to a representative subset before jobs are written. Two curated presets are
   provided, or set linkage, TAU, selection mode and dihedral weight yourself.
     - Chemical shifts        complete linkage, TAU 0.40, tiered selection
     - All NMR (shifts + J)   complete linkage, TAU 0.15, lowest-energy only
   Only the conformers that pass clustering get job files. The rest are kept in not_selected/ so nothing is
   lost. Requires SciPy; if it is not installed this section disables itself and every conformer is set up.

3. GAUSSIAN JOB SETTINGS
   COMPOUND SCOPE. If several compounds are loaded, the selector at the top right controls what a run touches:
     - "Process every loaded compound" ticked  -> all compounds, one shared set of settings
     - unticked                                -> ONLY the compound named in the selector; the others are left
                                                  completely alone, not clustered and given no job files
   The Run button names the scope so it is visible before you commit.

   METHOD. Solvent methods and their basis sets, route lines and scaling constants all come from
   nmr_workbench_config.txt beside this program. Edit that file to change a method or add your own; new
   entries appear in the dropdown automatically. "custom" instead takes route lines typed directly into the
   fields below it.

   MACHINE. Also from the configuration file. A machine profile carries the %chk and %rwf paths and the
   resource tiers your queue allows, so site-specific paths never travel with the chemistry.

   ELEMENT-SPECIFIC OPTIONS. Fluorine, nitrogen, carbon-sulfur and carbon-halogen calculations enable only
   when the loaded structures actually contain those atoms. With one setting shared across compounds, only
   options valid for every compound are offered.

   PREVIEW. Shows the input file exactly as it will be written. Everything fixed by your settings appears
   verbatim; {title}, {charge} {multiplicity}, {coordinates}, {connectivity} and {conformer} mark what varies
   per structure. Optimization jobs always carry opt, freq=noraman, geom=connectivity and pop=nboread even if
   a custom route omits them -- pop=nboread is what produces the Wiberg bond index matrix that tab 2 reads for
   true bond orders.

OUTPUT
   Job files land in gjf_files/ as a single flat set ready to submit. Split conformers, aligned copies and any
   clustering output are kept in their own folders alongside. All .gjf files are written with Unix line
   endings, since CRLF in a Gaussian input is a silent parse failure on a Linux cluster.
"""

ANALYSIS_HELP = """\
TAB 2 -- ANALYSIS:  Gaussian LOG files in, NMR predictions out

1. LOG INPUT
   Add the completed Gaussian output. Files must be named {compound}_{conformer}.log -- compounds are grouped
   from those names, and the panel lists what it found before you run. Anything not matching that pattern is
   named explicitly rather than silently skipped, because a mis-named file is otherwise invisible to the
   analysis and the run simply covers fewer conformers than expected.

   ONE DIRECTORY AT A TIME. The analysis writes its results beside the logs and works in a single directory.
   If your selection spans several, a warning says so and the directory holding the most files is used.

2. OPTIONS
   TEMPERATURE feeds the Boltzmann weighting.

   DEDUPLICATION merges conformers that optimized to the same minimum. Two are merged only when EVERY gate
   agrees: energy within 0.20 kcal/mol, symmetry-corrected RMSD within 0.10 A with no single atom displaced
   more than 0.15 A, and -- where frequency data exists for both -- vibrational spectra agreeing within
   2.0 cm^-1 overall and 3.0 cm^-1 in every individual mode. Those thresholds were validated against 30
   compounds using vibrational frequencies as independent ground truth. Switching deduplication off weights
   every valid conformer, which double-counts any basin the search reached twice.

   Mirror-image conformers are deliberately NOT merged. For an achiral compound their equal and opposite
   rotational strengths are what make its VCD and ECD cancel to a flat line; merging them would break that.

3. OUTPUTS
   Tick only what you want. Unticked outputs are not written, but the calculation behind them still runs --
   shifts, energies and populations depend on each other, so everything you do keep is identical to a full
   run. Two outputs feed the structure viewer below: conformer SDF files supply the geometry and the PyMOL
   labelling script supplies the shift labels. Untick either and the viewer says which one is missing.

4. STRUCTURE VIEWER
   Opens the lowest-energy conformer automatically with its predicted shifts overlaid. The dropdown switches
   conformers, ordered by Gibbs free energy rather than filename. The checkbox hides the labels to see the
   geometry alone. Drag to rotate, scroll to zoom, right-drag to pan.

   The labels are the weighted shifts, already averaged over chemically equivalent atoms -- the same values
   written to the PyMOL script, so what you read here is what you would read there.

NOTES ON WHAT THE ANALYSIS READS
   Bond orders come from the Wiberg bond index matrix in the log, not from the input SDF, so they reflect the
   converged wavefunction. They are taken from one conformer and confirmed against a sample of others; a
   disagreement is reported rather than assumed away, since it usually means a bond sits near a classification
   threshold.

   Scaling factors are read from the job titles, so shifts are scaled by the constants that were actually used
   when the jobs were written -- not by whatever a table says today.
"""


def show_help_window(parent, title, text):
    """
    A scrollable, read-only help window.

    Its own toplevel rather than a message box: this text is far longer than a dialog can show, and it is
    worth being able to leave it open beside the tab it describes while working through the settings.
    """
    window = tk.Toplevel(parent)
    window.title(title)
    window.geometry("860x640")
    window.transient(parent)

    frame = ttk.Frame(window, padding=8)
    frame.pack(fill='both', expand=True)

    widget = scrolledtext.ScrolledText(frame, wrap='word', font=('Consolas', 9))
    widget.pack(fill='both', expand=True)
    widget.insert('1.0', text)
    widget.configure(state='disabled')

    ttk.Button(frame, text="Close", command=window.destroy).pack(pady=(8, 0))
    window.bind('<Escape>', lambda event: window.destroy())
    return window

class ConsoleRedirector:
    """
    Captures writes to stdout/stderr and forwards them to the GUI log through a queue.

    The embedded scripts communicate progress by printing, and rewriting all of that to use a callback would mean
    touching hundreds of lines of otherwise-unmodified logic. Redirecting the stream instead leaves that code
    exactly as it was while still surfacing everything it says in the interface.
    """

    def __init__(self, queue_object, stream_name='stdout'):
        self.queue = queue_object
        self.stream_name = stream_name
        self._buffer = ''

    def write(self, text):
        if not text:
            return
        self._buffer += text
        while '\n' in self._buffer:
            line, self._buffer = self._buffer.split('\n', 1)
            self.queue.put(('log', line))

    def flush(self):
        if self._buffer:
            self.queue.put(('log', self._buffer))
            self._buffer = ''


class DropTarget:
    """
    Drag-and-drop file input, when the running Python can actually provide it.

    Plain tkinter has NO drag-and-drop support. It requires the tkdnd Tcl extension, reached from Python through
    either the tkinterdnd2 package or a tkdnd package already present in the Tcl library path. Neither ships with
    CPython, so on a stock install -- and on a locked-down machine where packages cannot be added -- drag and
    drop is simply unavailable, and no amount of code in this file changes that.

    Both routes are attempted here, and when neither works the interface says so plainly instead of leaving a
    drop zone that looks live and silently ignores everything dropped on it. The Add files and Add folder buttons
    do the same job and are always present.
    """

    def __init__(self, widget, on_files):
        self.widget = widget
        self.on_files = on_files
        self.native_dnd = False
        self.reason = ""
        try:
            widget.drop_target_register('DND_Files')
            widget.dnd_bind('<<Drop>>', self._handle_drop)
            self.native_dnd = True
            return
        except Exception as error:
            self.reason = str(error)
        # Second route: tkdnd may be loadable directly into this Tcl interpreter even when the Python wrapper
        # was never imported, which happens when tkdnd is installed system-wide rather than via pip
        try:
            widget.tk.call('package', 'require', 'tkdnd')
            widget.tk.call('tkdnd::drop_target', 'register', widget._w, 'DND_Files')
            widget.bind('<<Drop>>', self._handle_drop)
            self.native_dnd = True
            self.reason = ""
        except Exception as error:
            self.reason = str(error)

    def _handle_drop(self, event):
        raw = event.data
        paths, current, in_brace = [], '', False
        for character in raw:
            if character == '{':
                in_brace = True
            elif character == '}':
                in_brace = False
            elif character == ' ' and not in_brace:
                if current:
                    paths.append(current)
                current = ''
            else:
                current += character
        if current:
            paths.append(current)
        self.on_files([p for p in paths if p])


SCROLLABLE_FRAMES = []
# Every ScrollableFrame in the application, so the wheel can be routed to whichever one the pointer is inside
# rather than to whichever widget happened to be bound.


def route_wheel_to_scroll_area(event):
    """
    Send a wheel event to the scroll area under the pointer, wherever inside it the pointer happens to be.

    Bound once on the application. Walking up from the widget under the cursor means every descendant of a
    scroll area scrolls it -- including widgets created long after the area itself, which per-widget binding
    could never cover.
    """
    widget = event.widget
    while widget is not None:
        for frame in SCROLLABLE_FRAMES:
            try:
                if widget is frame or widget is frame.canvas or widget is frame.interior:
                    frame.handle_wheel(event)
                    return 'break'
            except tk.TclError:
                continue
        try:
            widget = widget.master
        except AttributeError:
            break
    return None


class ScrollableFrame(ttk.LabelFrame):
    """
    A labelled frame whose contents scroll when they do not fit.

    Tk has no scrollable frame: only Canvas scrolls, so the real content lives in an inner frame placed on a
    canvas, and the canvas scrollregion is kept in step with that frame's requested size. The inner frame is
    also widened to match the canvas so its children can still expand horizontally -- without that, everything
    inside collapses to its minimum width the moment it is put on a canvas.
    """

    def __init__(self, parent, text, padding=8):
        super().__init__(parent, text=text, padding=0)
        self.canvas = tk.Canvas(self, highlightthickness=0, borderwidth=0)
        self.scrollbar = ttk.Scrollbar(self, orient='vertical', command=self.canvas.yview)
        self.interior = ttk.Frame(self.canvas, padding=padding)

        self._window = self.canvas.create_window((0, 0), window=self.interior, anchor='nw')
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        self.scrollbar.grid(row=0, column=1, sticky='ns')
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self.interior.bind('<Configure>', self._on_interior_configure)
        self.canvas.bind('<Configure>', self._on_canvas_configure)

        # Registered so one application-wide wheel handler can find whichever scroll area the pointer is over.
        # Binding each child individually only covered widgets that existed at the time, which is why the
        # wheel worked over some parts of a panel and not others -- anything nested or added later had no
        # binding at all.
        SCROLLABLE_FRAMES.append(self)

    def _on_interior_configure(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox('all'))

    def _on_canvas_configure(self, event):
        self.canvas.itemconfigure(self._window, width=event.width)


    def handle_wheel(self, event):
        if getattr(event, 'num', None) == 4:
            delta = -1
        elif getattr(event, 'num', None) == 5:
            delta = 1
        else:
            delta = -1 if event.delta > 0 else 1
        self.canvas.yview_scroll(delta, 'units')
        return 'break'

    def bind_wheel_to_children(self):
        """Retained for callers; the application-wide handler now covers every descendant automatically."""
        return


class FileListPanel(ttk.LabelFrame):
    """A file list with add/remove controls, used by both tabs."""

    def __init__(self, parent, title, filetypes, on_change=None):
        super().__init__(parent, text=title, padding=8)
        self.filetypes = filetypes
        self.on_change = on_change
        self.paths = []

        hint = ttk.Label(self, text="", wraplength=560, foreground='#555555')
        hint.grid(row=0, column=0, columnspan=4, sticky='w', pady=(0, 6))

        self.listbox = tk.Listbox(self, height=10, selectmode=tk.EXTENDED, activestyle='none')
        self.listbox.grid(row=1, column=0, columnspan=4, sticky='nsew')
        scrollbar = ttk.Scrollbar(self, orient='vertical', command=self.listbox.yview)
        scrollbar.grid(row=1, column=4, sticky='ns')
        self.listbox.configure(yscrollcommand=scrollbar.set)

        ttk.Button(self, text="Add files...", command=self.browse_files).grid(row=2, column=0, sticky='ew', pady=(6, 0))
        ttk.Button(self, text="Add folder...", command=self.browse_folder).grid(row=2, column=1, sticky='ew', pady=(6, 0))
        ttk.Button(self, text="Remove selected", command=self.remove_selected).grid(row=2, column=2, sticky='ew', pady=(6, 0))
        ttk.Button(self, text="Clear", command=self.clear).grid(row=2, column=3, sticky='ew', pady=(6, 0))

        self.count_label = ttk.Label(self, text="0 file(s)")
        self.count_label.grid(row=3, column=0, columnspan=4, sticky='w', pady=(4, 0))

        for column in range(4):
            self.columnconfigure(column, weight=1)
        self.rowconfigure(1, weight=1)

        self.drop_target = DropTarget(self.listbox, self.add_paths)
        hint.configure(text="Drag files or folders here, or use the buttons below."
                            if self.drop_target.native_dnd
                            else "Add files or a whole folder using the buttons below.")

    def add_paths(self, paths):
        extensions = tuple(extension for _, extension in self.filetypes)
        for path in paths:
            if os.path.isdir(path):
                for name in sorted(os.listdir(path)):
                    full = os.path.join(path, name)
                    if os.path.isfile(full) and name.lower().endswith(extensions):
                        self._add_one(full)
            elif os.path.isfile(path) and path.lower().endswith(extensions):
                self._add_one(path)
        self._refresh()

    def _add_one(self, path):
        full = os.path.abspath(path)
        if full not in self.paths:
            self.paths.append(full)
            self.listbox.insert(tk.END, full)

    def _refresh(self):
        self.count_label.configure(text=f"{len(self.paths)} file(s)")
        if self.on_change:
            self.on_change(self.paths)

    def browse_files(self):
        chosen = filedialog.askopenfilenames(
            title="Select files",
            filetypes=[(label, f"*{extension}") for label, extension in self.filetypes] + [("All files", "*.*")])
        if chosen:
            self.add_paths(list(chosen))

    def browse_folder(self):
        folder = filedialog.askdirectory(title="Select a folder")
        if folder:
            self.add_paths([folder])

    def remove_selected(self):
        for index in reversed(self.listbox.curselection()):
            self.listbox.delete(index)
            del self.paths[index]
        self._refresh()

    def clear(self):
        self.listbox.delete(0, tk.END)
        self.paths = []
        self._refresh()


class JobSetupTab(ttk.Frame):
    """
    Tab 1: SDF conformers in, Gaussian input files out.

    Bring in conformers however they come -- one file per conformer, a single file holding the whole ensemble, or
    a mixture -- and the run handles the rest. Multi-structure files are split automatically as the first step of
    the pipeline rather than as a separate action, because splitting is never something to decide, only something
    that either needs doing or does not.
    """

    def __init__(self, parent, app):
        super().__init__(parent, padding=10)
        self.app = app

        left = ttk.Frame(self)
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        right = ttk.Frame(self)
        right.grid(row=0, column=1, sticky='nsew')
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2)
        self.rowconfigure(0, weight=1)

        # ---- 1. input ----
        header = ttk.Frame(left)
        header.grid(row=0, column=0, sticky='ew', pady=(0, 4))
        ttk.Button(header, text="How to use this tab",
                   command=lambda: show_help_window(self, "Job setup - how to use", JOB_SETUP_HELP)
                   ).pack(side='right')
        left.rowconfigure(1, weight=1)

        self.file_panel = FileListPanel(left, "1. Conformer input (.sdf)", [("SDF files", ".sdf")],
                                        on_change=self._on_files_changed)
        self.file_panel.grid(row=1, column=0, sticky='nsew')
        left.columnconfigure(0, weight=1)

        self.input_summary = ttk.Label(left, text="No files loaded.", wraplength=580, justify='left',
                                       foreground='#333333')
        self.input_summary.grid(row=2, column=0, sticky='w', pady=(6, 0))

        # Alignment is not exposed as a choice. The transform applied is a proper rotation plus a translation,
        # which is distance-preserving by definition: verified at 1.7e-14 Angstrom over 780 pairwise distances,
        # i.e. floating-point noise. The structure is mathematically unchanged and only its position and
        # orientation move, so there is nothing for a user to weigh up -- an option here would only invite
        # switching off something that cannot do harm.

        # ---- 2. clustering ----
        cluster_frame = ttk.LabelFrame(left, text="2. Clustering (optional)", padding=8)
        cluster_frame.grid(row=3, column=0, sticky='ew', pady=(8, 0))
        self.cluster_mode = tk.StringVar(value='none')

        modes = [
            ('none', "No clustering  -- set up every conformer provided"),
            ('shifts', "Chemical shifts  (complete linkage, TAU 0.40, tiered selection)"),
            ('all_nmr', "All NMR: shifts + J  (complete linkage, TAU 0.15, lowest-energy only)"),
            ('custom', "Custom  -- choose linkage, TAU and selection yourself"),
        ]
        for row, (value, label) in enumerate(modes):
            ttk.Radiobutton(cluster_frame, text=label, value=value, variable=self.cluster_mode,
                            command=self._on_cluster_mode_changed).grid(row=row, column=0, columnspan=3, sticky='w')

        self.custom_frame = ttk.Frame(cluster_frame)
        self.custom_frame.grid(row=len(modes), column=0, columnspan=3, sticky='ew', pady=(6, 0))
        # Strict one-widget-per-cell layout. The Selection combobox previously spanned columns 1-2 while the
        # Dihedral weight label also sat in column 2, so the combobox was drawn over the label and its dropdown
        # arrow could not be clicked. Column 2 carries left padding to separate the two label/field pairs.
        ttk.Label(self.custom_frame, text="Linkage:").grid(row=0, column=0, sticky='w')
        self.linkage_var = tk.StringVar(value='complete')
        ttk.Combobox(self.custom_frame, textvariable=self.linkage_var, state='readonly', width=14,
                     values=list(SUPPORTED_LINKAGES)).grid(row=0, column=1, sticky='w', padx=(4, 0))
        ttk.Label(self.custom_frame, text="TAU:").grid(row=0, column=2, sticky='e', padx=(24, 0))
        self.tau_var = tk.StringVar(value='0.30')
        ttk.Entry(self.custom_frame, textvariable=self.tau_var, width=9).grid(row=0, column=3, sticky='w', padx=(4, 0))

        ttk.Label(self.custom_frame, text="Selection:").grid(row=1, column=0, sticky='w', pady=(6, 0))
        self.selection_var = tk.StringVar(value='tiered')
        ttk.Combobox(self.custom_frame, textvariable=self.selection_var, state='readonly', width=14,
                     values=['lowest_energy', 'tiered', 'medoid']).grid(row=1, column=1, sticky='w',
                                                                        padx=(4, 0), pady=(6, 0))
        ttk.Label(self.custom_frame, text="Dihedral wt:").grid(row=1, column=2, sticky='e', padx=(24, 0), pady=(6, 0))
        self.dihedral_var = tk.StringVar(value='0.5')
        ttk.Entry(self.custom_frame, textvariable=self.dihedral_var, width=9).grid(row=1, column=3, sticky='w',
                                                                                   padx=(4, 0), pady=(6, 0))
        self.custom_frame.columnconfigure(3, weight=1)

        self.cluster_note = ttk.Label(cluster_frame, text="", wraplength=560, foreground='#8a4b00')
        self.cluster_note.grid(row=len(modes) + 1, column=0, columnspan=3, sticky='w', pady=(6, 0))
        if not SCIPY_AVAILABLE:
            for child in cluster_frame.winfo_children():
                try:
                    if isinstance(child, ttk.Radiobutton) and str(child.cget('value')) != 'none':
                        child.configure(state='disabled')
                except tk.TclError:
                    pass
            self.cluster_note.configure(
                text="Clustering is unavailable because SciPy is not installed in this Python. The hierarchical "
                     "linkage it performs has no practical pure-Python substitute at ensemble sizes in the "
                     "thousands, so this section stays disabled; everything else on this tab works normally and "
                     "every conformer provided will be set up.")
        self._on_cluster_mode_changed()

        # ---- 3. Gaussian settings ----
        # Settings are held per compound. A directory holding several compounds would otherwise silently apply
        # one molecule's choices to all of them -- and since the element-specific options depend on which atoms
        # are actually present, a single shared setting cannot even be correct for two different molecules.
        compound_frame = ttk.LabelFrame(right, text="Compound being configured", padding=8)
        compound_frame.grid(row=0, column=0, sticky='ew')
        self.compound_var = tk.StringVar(value='')
        self.compound_box = ttk.Combobox(compound_frame, textvariable=self.compound_var, state='readonly',
                                         width=28, values=[])
        self.compound_box.grid(row=0, column=0, sticky='ew')
        self.compound_box.bind('<<ComboboxSelected>>', lambda event: self._on_compound_changed())
        self.apply_to_all = tk.BooleanVar(value=True)
        ttk.Checkbutton(compound_frame,
                        text="Process every loaded compound with these settings\n"
                             "(unticked: process ONLY the compound selected above)",
                        variable=self.apply_to_all, command=self._on_apply_all_changed).grid(
            row=1, column=0, sticky='w', pady=(4, 0))
        self.compound_status = ttk.Label(compound_frame, text="Load SDF files to see detected compounds.",
                                         wraplength=300, foreground='#555555', justify='left')
        self.compound_status.grid(row=2, column=0, sticky='w', pady=(4, 0))
        compound_frame.columnconfigure(0, weight=1)

        settings_container = ScrollableFrame(right, "3. Gaussian job settings", padding=8)
        settings_container.grid(row=1, column=0, sticky='nsew', pady=(8, 0))
        settings_frame = settings_container.interior
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1)

        self.per_compound_settings = {}
        self.compound_elements = {}
        self.compound_names = []
        self._current_compound = None

        row = 0
        ttk.Label(settings_frame, text="Solvent / method:").grid(row=row, column=0, sticky='w')
        # Populated entirely from the configuration file. To add a method, add a [method:...] section there;
        # it appears here on the next start with no code change and behaves exactly like any other.
        self.method_labels = {}
        method_values = []
        for key in sorted(WORKBENCH_METHODS, key=lambda k: (len(k), k)):
            label = WORKBENCH_METHODS[key].get('label') or key
            self.method_labels[label] = key
            method_values.append(label)
        self.method_var = tk.StringVar(value=method_values[0])
        method_box = ttk.Combobox(settings_frame, textvariable=self.method_var, state='readonly', width=26,
                                  values=method_values)
        method_box.grid(row=row, column=1, sticky='ew', pady=2)
        method_box.bind('<<ComboboxSelected>>', lambda event: self._refresh_preview())
        row += 1

        row += 1

        ttk.Label(settings_frame, text="Temperature (K):").grid(row=row, column=0, sticky='w')
        self.temperature_var = tk.StringVar(value='298.0')
        ttk.Entry(settings_frame, textvariable=self.temperature_var, width=12).grid(row=row, column=1, sticky='w', pady=2)
        row += 1
        # Machine and tier both come from the configuration file. Selecting a machine repopulates its tiers,
        # since a queue's allowed sizes are a property of that machine and not of the chemistry.
        ttk.Label(settings_frame, text="Machine:").grid(row=row, column=0, sticky='w')
        self.machine_labels = {}
        machine_values = []
        for key in sorted(WORKBENCH_MACHINES):
            label = WORKBENCH_MACHINES[key].get('label') or key
            self.machine_labels[label] = key
            machine_values.append(label)
        if not machine_values:
            machine_values = ['Default (files beside the job)']
            self.machine_labels[machine_values[0]] = 'default'
        self.machine_var = tk.StringVar(value=machine_values[0])
        machine_box = ttk.Combobox(settings_frame, textvariable=self.machine_var, state='readonly', width=26,
                                   values=machine_values)
        machine_box.grid(row=row, column=1, sticky='ew', pady=2)
        machine_box.bind('<<ComboboxSelected>>', lambda event: self._on_machine_changed())
        row += 1

        ttk.Label(settings_frame, text="Resources:").grid(row=row, column=0, sticky='w')
        self.tier_var = tk.StringVar(value='')
        self.tier_box = ttk.Combobox(settings_frame, textvariable=self.tier_var, state='readonly', width=26)
        self.tier_box.grid(row=row, column=1, sticky='ew', pady=2)
        row += 1

        ttk.Separator(settings_frame, orient='horizontal').grid(row=row, column=0, columnspan=2, sticky='ew', pady=6)
        row += 1
        ttk.Label(settings_frame, text="Additional calculations:").grid(row=row, column=0, columnspan=2, sticky='w')
        row += 1
        self.include_cc = tk.BooleanVar(value=False)
        self.include_fluorine = tk.BooleanVar(value=False)
        self.include_nitrogen = tk.BooleanVar(value=False)
        self.include_csulfur = tk.BooleanVar(value=False)
        self.include_chalogen = tk.BooleanVar(value=False)
        # Each element-specific calculation is keyed by the elements that make it meaningful. A fluorine shift
        # job on a molecule containing no fluorine would run and produce nothing, so these stay disabled until
        # the loaded structures actually contain the relevant atoms -- read from the SDFs rather than assumed.
        self.element_checkbuttons = {}
        calculation_rows = [
            ("Coupling constants", self.include_cc, None),
            ("Fluorine shifts", self.include_fluorine, {'F'}),
            ("Nitrogen shifts", self.include_nitrogen, {'N'}),
            ("Carbon-sulfur correction", self.include_csulfur, {'S'}),
            ("Carbon-halogen correction", self.include_chalogen, {'F', 'Cl', 'Br', 'I'}),
        ]
        for label, variable, required in calculation_rows:
            button = ttk.Checkbutton(settings_frame, text=label, variable=variable)
            button.grid(row=row, column=0, columnspan=2, sticky='w')
            if required is not None:
                self.element_checkbuttons[label] = (button, variable, required)
            row += 1
        self.element_note = ttk.Label(settings_frame, text="", wraplength=300, foreground='#555555',
                                      justify='left')
        self.element_note.grid(row=row, column=0, columnspan=2, sticky='w', pady=(2, 0))
        row += 1
        self._apply_element_availability(set(), known=False)

        ttk.Separator(settings_frame, orient='horizontal').grid(row=row, column=0, columnspan=2, sticky='ew', pady=6)
        row += 1
        ttk.Label(settings_frame, text="Output folder:").grid(row=row, column=0, sticky='w')
        # Beside this program rather than in a subfolder of wherever it was launched from: the working
        # directory changes as the analysis tab moves between log directories, and a path the user recognises
        # is more useful than one they have to go looking for.
        self.output_var = tk.StringVar(value=workbench_directory())
        ttk.Entry(settings_frame, textvariable=self.output_var, width=24).grid(row=row, column=1, sticky='ew', pady=2)
        row += 1
        ttk.Button(settings_frame, text="Choose...", command=self._choose_output).grid(row=row, column=1, sticky='w')
        row += 1

        ttk.Separator(settings_frame, orient='horizontal').grid(row=row, column=0, columnspan=2,
                                                                sticky='ew', pady=6)
        row += 1
        ttk.Label(settings_frame, text="Keep intermediate folders:").grid(row=row, column=0, columnspan=2,
                                                                         sticky='w')
        row += 1
        self.keep_split = tk.BooleanVar(value=False)
        self.keep_aligned = tk.BooleanVar(value=False)
        self.keep_clustered = tk.BooleanVar(value=True)
        for label, variable in (("Split conformers", self.keep_split),
                                ("Aligned conformers", self.keep_aligned),
                                ("Clustering output", self.keep_clustered)):
            ttk.Checkbutton(settings_frame, text=label, variable=variable).grid(row=row, column=0,
                                                                                columnspan=2, sticky='w')
            row += 1
        ttk.Label(settings_frame,
                  text="These are produced either way, since the pipeline needs them, and simply removed "
                       "afterwards when unticked. The job files themselves are never optional.",
                  wraplength=300, foreground='#555555', justify='left').grid(row=row, column=0, columnspan=2,
                                                                             sticky='w', pady=(2, 0))
        row += 1

        settings_frame.columnconfigure(1, weight=1)

        # Live route preview. Shows the actual lines that will be written, rebuilt from the same function the
        # writer calls, so what is displayed cannot drift from what is produced.
        self.preview_frame = ttk.LabelFrame(right, text="Calculation preview", padding=6)
        preview_frame = self.preview_frame
        preview_frame.grid(row=2, column=0, sticky='nsew', pady=(8, 0))
        self.preview_text = tk.Text(preview_frame, height=13, wrap='none', state='disabled',
                                    font=('Consolas', 8), background='#f7f7f7')
        self.preview_text.grid(row=0, column=0, sticky='nsew')
        preview_scroll_y = ttk.Scrollbar(preview_frame, orient='vertical', command=self.preview_text.yview)
        preview_scroll_y.grid(row=0, column=1, sticky='ns')
        preview_scroll_x = ttk.Scrollbar(preview_frame, orient='horizontal', command=self.preview_text.xview)
        preview_scroll_x.grid(row=1, column=0, sticky='ew')
        self.preview_text.configure(yscrollcommand=preview_scroll_y.set, xscrollcommand=preview_scroll_x.set)
        preview_frame.columnconfigure(0, weight=1)
        preview_frame.rowconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)

        self.run_button = ttk.Button(right, text="Generate Gaussian inputs", command=self.run_pipeline,
                                     state='disabled')
        self.run_button.grid(row=3, column=0, sticky='ew', pady=(8, 0))
        # Anything that can change a route line triggers a refresh. Traced on the variables rather than bound
        # to each widget, so a value set in code (switching compounds, restoring a snapshot) updates the
        # preview exactly as typing does.
        for variable in (self.method_var, self.temperature_var, self.machine_var, self.tier_var,
                         self.compound_var,
                         self.include_cc, self.include_fluorine, self.include_nitrogen,
                         self.include_csulfur, self.include_chalogen):
            try:
                variable.trace_add('write', lambda *args: self._refresh_preview())
            except (AttributeError, tk.TclError):
                pass
        self._on_machine_changed()
        self._refresh_preview()
        # Bind the wheel to every widget now that the panel's contents exist, so scrolling works over the
        # nested Custom method frame and not only over the bare background
        settings_container.bind_wheel_to_children()

    def _choose_output(self):
        folder = filedialog.askdirectory(title="Output folder", initialdir=self.output_var.get() or os.getcwd())
        if folder:
            self.output_var.set(folder)

    # ---- per-compound settings and element availability ----

    # Clustering belongs here too: a different molecule can warrant a different TAU or selection mode, and
    # leaving these out was why every compound clustered identically no matter what the selector said.
    SETTINGS_WIDGET_KEYS = ('method_var', 'temperature_var', 'machine_var', 'tier_var',
                            'keep_split', 'keep_aligned', 'keep_clustered',
                            'include_cc', 'include_fluorine',
                            'include_nitrogen', 'include_csulfur', 'include_chalogen',
                            'cluster_mode', 'linkage_var', 'tau_var', 'selection_var', 'dihedral_var')

    def _capture_settings(self):
        """Snapshot the settings widgets, so switching compounds does not discard what was just entered."""
        snapshot = {key: getattr(self, key).get() for key in self.SETTINGS_WIDGET_KEYS}
        return snapshot

    def _restore_settings(self, snapshot):
        for key in self.SETTINGS_WIDGET_KEYS:
            if key in snapshot:
                getattr(self, key).set(snapshot[key])
        self._on_cluster_mode_changed()

    def _apply_element_availability(self, elements, known=True):
        """
        Enable each element-specific calculation only when the structures contain the atoms it needs.

        A disabled option is also cleared, because leaving a ticked-but-disabled box would carry a selection into
        the run that the user can no longer see or change.
        """
        missing = []
        for label, (button, variable, required) in self.element_checkbuttons.items():
            available = (not known) or bool(elements & required)
            try:
                button.configure(state='normal' if available else 'disabled')
            except tk.TclError:
                pass
            if not available:
                variable.set(False)
                missing.append(label.split(' shifts')[0].split(' correction')[0])
        if not known:
            self.element_note.configure(text="")
        elif missing:
            self.element_note.configure(
                text="Unavailable for this compound (no such atoms present): " + ", ".join(sorted(missing)) + ".")
        else:
            self.element_note.configure(text="All element-specific calculations apply to this compound.")

    def _on_apply_all_changed(self):
        state = 'disabled' if self.apply_to_all.get() else 'readonly'
        try:
            self.compound_box.configure(state=state)
        except tk.TclError:
            pass
        if self.apply_to_all.get():
            count = len(self.compound_names)
            self.compound_status.configure(
                text=(f"ALL {count} loaded compound(s) will be processed with these settings. "
                      if count else "All loaded compounds will be processed with these settings. ")
                     + "Element-specific options are limited to those valid for every compound, since one "
                       "setting cannot be correct for two molecules with different atoms.")
            self._update_run_button_text()
            union = None
            for elements in self.compound_elements.values():
                union = set(elements) if union is None else (union & elements)
            union = union or set()
            self._apply_element_availability(union, known=bool(self.compound_elements))
        else:
            self._on_compound_changed()

    def _on_compound_changed(self):
        """Save the settings for the compound being left, then load those for the one being selected."""
        if self._current_compound is not None:
            self.per_compound_settings[self._current_compound] = self._capture_settings()
        compound = self.compound_var.get()
        self._current_compound = compound or None
        if not compound:
            return
        if compound in self.per_compound_settings:
            self._restore_settings(self.per_compound_settings[compound])
        elements = self.compound_elements.get(compound, set())
        self._apply_element_availability(elements)
        formula = ", ".join(sorted(elements)) if elements else "unknown"
        others = [name for name in self.compound_names if name != compound]
        suffix = (f" The other {len(others)} loaded compound(s) will NOT be processed."
                  if others and not self.apply_to_all.get() else "")
        self.compound_status.configure(
            text=f"Working on {compound}. Elements present: {formula}.{suffix}")
        self._update_run_button_text()
        self._refresh_preview()

    def _update_run_button_text(self):
        """Name the scope on the button itself, so what a run will touch is visible before pressing it."""
        button = getattr(self, 'run_button', None)
        if button is None:
            return
        try:
            if self.apply_to_all.get():
                count = len(self.compound_names)
                label = (f"Generate Gaussian inputs  ({count} compounds)" if count > 1
                         else "Generate Gaussian inputs")
            else:
                selected = self.compound_var.get() or "selected compound"
                label = f"Generate Gaussian inputs  ({selected} only)"
            button.configure(text=label)
        except tk.TclError:
            pass


    def _refresh_preview(self):
        # Tk is not thread-safe, and a variable written from a worker thread fires its trace on that thread.
        # Rebuilding the preview from there raises "main thread is not in main loop"; skipping is correct,
        # because the preview describes settings and those only change from the interface.
        if threading.current_thread() is not threading.main_thread():
            return
        """
        Rebuild the preview from the current settings.

        Called on every change, so it must never raise: a half-typed temperature or an incomplete custom method
        is the normal state while someone is filling the form, and an exception there would break the interface
        rather than the value. Anything unusable is reported inside the preview instead.
        """
        widget = getattr(self, 'preview_text', None)
        if widget is None:
            return
        try:
            method_key = self.method_labels.get(self.method_var.get(), '1')
            machine_key = self.machine_labels.get(self.machine_var.get(), 'default')
            tier_name = getattr(self, 'tier_display', {}).get(self.tier_var.get())
            try:
                temperature = float(self.temperature_var.get())
            except (TypeError, ValueError):
                temperature = None

            compound = self.compound_var.get()
            # Read one of the loaded structures so the charges, total charge, connectivity and any gen basis
            # block resolve to their real values instead of placeholders. These are compound properties, not
            # conformer properties, so any conformer of the compound gives the same answer.
            structure = self._preview_structure(compound)
            elements = structure[0] if structure else []
            text = build_route_preview(method_key, self.include_cc.get(), self.include_fluorine.get(),
                                       self.include_nitrogen.get(), temperature, machine_key, tier_name,
                                       contains_iodine=('I' in set(elements)),
                                       compound_name=compound or None, structure=structure,
                                       include_csulfur=self.include_csulfur.get(),
                                       include_chalogen=self.include_chalogen.get())
            self._set_preview_text(text)
        except Exception as error:
            self._set_preview_text("(preview unavailable: " + str(error) + ")")

    def _update_preview_visibility(self):
        """
        Show the preview only once a compound is loaded.

        Before that there is no compound name to put in the %chk and %rwf lines, and showing the placeholder
        form would misrepresent what the file is going to contain.
        """
        frame = getattr(self, 'preview_frame', None)
        if frame is None:
            return
        compound = self.compound_var.get()
        try:
            if compound:
                frame.grid()
                frame.configure(text=f"Calculation preview -- {compound}  (exactly what will be written)")
            else:
                frame.grid_remove()
        except tk.TclError:
            pass

    def _preview_structure(self, compound):
        """
        Elements, connectivity and formal charges for the selected compound, cached per compound.

        Read from the first loaded file for that compound. Every conformer shares its constitution, so one is
        enough, and caching keeps the preview responsive while settings are being changed -- it refreshes on
        every keystroke and re-reading an SDF each time would make typing feel sticky.
        """
        if not compound:
            return None
        cache = getattr(self, '_preview_structure_cache', None)
        if cache is None:
            cache = self._preview_structure_cache = {}
        if compound in cache:
            return cache[compound]

        path = None
        for candidate in self.file_panel.paths:
            stem = os.path.splitext(os.path.basename(candidate))[0]
            for suffix in ('_confs', '.sdf_Conf', '_Conf'):
                if stem.endswith(suffix):
                    stem = stem[:-len(suffix)]
                    break
            match = re.match(r'^(.+?)_(\d+)$', stem)
            if (match.group(1) if match else stem) == compound:
                path = candidate
                break
        if path is None:
            cache[compound] = None
            return None

        try:
            # ngig_parse_sdf is what the writer itself calls, so the connectivity comes back in the exact
            # Gaussian block form ("2 1.0") and the charges in the exact keying the title serializer expects.
            # Using a different parser here would risk a preview that differs from the file in formatting.
            coordinate_lines, connectivity, charges, _heavy = ngig_parse_sdf(path)
            atom_types = [line.split()[0] for line in coordinate_lines if line.split()]
            result = (atom_types, connectivity, charges)
        except Exception:
            result = None
        cache[compound] = result
        return result

    def _set_preview_text(self, text):
        self._update_preview_visibility()
        try:
            self.preview_text.configure(state='normal')
            self.preview_text.delete('1.0', tk.END)
            self.preview_text.insert('1.0', text)
            self.preview_text.configure(state='disabled')
        except tk.TclError:
            pass

    def _on_machine_changed(self):
        """Repopulate the tier list for the selected machine, keeping the current choice when it still exists."""
        machine_key = self.machine_labels.get(self.machine_var.get(), 'default')
        machine = WORKBENCH_MACHINES.get(machine_key, {})
        tiers = machine.get('tiers') or {'medium': {'nprocshared': 32, 'mem': '63GB'}}
        self.tier_display = {}
        values = []
        for name in sorted(tiers, key=lambda n: tiers[n]['nprocshared']):
            label = f"{name}  ({tiers[name]['nprocshared']} CPU / {tiers[name]['mem']})"
            self.tier_display[label] = name
            values.append(label)
        try:
            self.tier_box.configure(values=values)
        except tk.TclError:
            pass
        if self.tier_var.get() not in values:
            self.tier_var.set(values[len(values) // 2] if values else '')
        self._refresh_preview()


    def _on_cluster_mode_changed(self):
        state = 'normal' if self.cluster_mode.get() == 'custom' else 'disabled'
        for child in self.custom_frame.winfo_children():
            try:
                child.configure(state=state)
            except tk.TclError:
                pass

    def _on_files_changed(self, paths):
        """
        Summarize what was loaded, including how many structures any multi-structure file holds.

        Splitting is not offered as a choice because it is not one: a file holding many structures has to be
        split before anything downstream can address its conformers individually, so the run does it. Reporting
        the count up front is still worthwhile, since a file turning out to hold hundreds of structures is
        frequently the first sign that the wrong file was picked.
        """
        self.run_button.configure(state='normal' if paths else 'disabled')
        if not paths:
            self.input_summary.configure(text="No files loaded.")
            self.compound_box.configure(values=[])
            self.compound_var.set('')
            self.compound_elements = {}
            self.per_compound_settings = {}
            self.compound_names = []
            self._current_compound = None
            self.compound_status.configure(text="Load SDF files to see detected compounds.")
            self._apply_element_availability(set(), known=False)
            return

        single, multi, total_structures, unreadable = 0, [], 0, 0
        for path in paths:
            try:
                with open(path, 'r', errors='replace') as handle:
                    count = handle.read().count('$$$$')
            except OSError:
                unreadable += 1
                continue
            count = max(count, 1)
            total_structures += count
            if count > 1:
                multi.append((os.path.basename(path), count))
            else:
                single += 1

        parts = [f"{len(paths)} file(s) loaded, {total_structures} conformer(s) total."]
        if multi:
            listed = ", ".join(f"{name} ({count})" for name, count in multi[:3])
            if len(multi) > 3:
                listed += f", and {len(multi) - 3} more"
            parts.append(f"{len(multi)} multi-structure file(s) will be split automatically: {listed}.")
        if single and multi:
            parts.append(f"{single} file(s) already hold a single conformer and pass through unchanged.")
        if unreadable:
            parts.append(f"{unreadable} file(s) could not be read and will be skipped.")

        # Group by compound and read the elements present, so the settings panel can offer only the
        # element-specific calculations that actually apply. One structure per compound is enough: every
        # conformer of a compound shares its constitution.
        compounds = defaultdict(list)
        for path in paths:
            stem = os.path.splitext(os.path.basename(path))[0]
            for suffix in ('_confs', '.sdf_Conf', '_Conf'):
                if stem.endswith(suffix):
                    stem = stem[:-len(suffix)]
                    break
            match = re.match(r'^(.+?)_(\d+)$', stem)
            compounds[match.group(1) if match else stem].append(path)

        self._preview_structure_cache = {}   # loaded files changed, so any cached structure is stale
        self.compound_elements = {name: detect_elements_in_sdf(sorted(files)[0])
                                  for name, files in compounds.items()}
        names = sorted(compounds)
        # Kept in Python rather than read back from the widget: Combobox.cget('values') returns a space-joined
        # STRING on many Tk builds, so list() on it yields individual characters. Every real compound name then
        # missed the per-compound lookup and silently fell back to one shared settings object, which is why
        # every molecule received the same clustering and method regardless of the selector.
        self.compound_names = names
        self.compound_box.configure(values=names)
        self.per_compound_settings = {n: v for n, v in self.per_compound_settings.items() if n in compounds}
        # Seed a snapshot for every compound now. Previously only compounds the user had actually switched to
        # had one, and the rest silently fell back to whatever was on screen at the moment Run was pressed --
        # which is why unticking 'use for every compound' appeared to change nothing.
        default_snapshot = self._capture_settings()
        for name in names:
            self.per_compound_settings.setdefault(name, dict(default_snapshot))
        if names:
            parts.append(f"Compounds detected: {', '.join(names[:6])}"
                         + (f", and {len(names) - 6} more." if len(names) > 6 else "."))
            if self.compound_var.get() not in names:
                self.compound_var.set(names[0])
                self._current_compound = None
        self._on_apply_all_changed()
        self.input_summary.configure(text=" ".join(parts))

    def run_pipeline(self):
        paths = list(self.file_panel.paths)
        if not paths:
            return
        try:
            settings_by_compound = self._collect_all_settings()
        except ValueError as error:
            messagebox.showerror("Invalid settings", str(error))
            return
        if not settings_by_compound:
            messagebox.showerror("Nothing to do", "No compounds were detected in the loaded files.")
            return

        # Checked before the run rather than during it: an unwritable path or a full disk discovered halfway
        # through leaves partial output and wastes whatever clustering has already been done
        problems = check_output_location(self.output_var.get().strip() or workbench_directory(),
                                         estimated_files=len(paths) * 3)
        if problems:
            blocking = [p for p in problems if 'Low disk space' not in p]
            if blocking:
                messagebox.showerror("Output folder problem", "\n".join(blocking))
                return
            if not messagebox.askyesno("Low disk space", "\n".join(problems) + "\n\nContinue anyway?"):
                return

        self.app.run_worker(self._pipeline_worker, (paths, settings_by_compound), "Setting up Gaussian jobs")

    def _collect_all_settings(self):
        """
        Which compounds to process, and with what settings.

        Ticked: every loaded compound is processed with the settings currently on screen.
        Unticked: ONLY the compound chosen in the selector is processed, and the others are left untouched --
        no clustering, no job files. That is the point of the selector: to work on one molecule at a time
        rather than to pre-configure several and run them together.
        """
        if self._current_compound is not None:
            self.per_compound_settings[self._current_compound] = self._capture_settings()
        shared = self._collect_settings()

        if self.apply_to_all.get():
            names = list(self.compound_names) or [name for name in [self.compound_var.get()] if name]
            return {name: shared for name in names if name}

        selected = self.compound_var.get()
        if not selected:
            raise ValueError("No compound is selected. Choose one from the selector, or tick "
                             "'Process every loaded compound' to run them all.")
        return {selected: shared}

    def _collect_settings(self):
        method_key = self.method_labels.get(self.method_var.get(), '1')
        machine_key = self.machine_labels.get(self.machine_var.get(), 'default')
        tier_name = getattr(self, 'tier_display', {}).get(self.tier_var.get())
        if tier_name is None:
            tier_name = (self.tier_var.get().split() or ['medium'])[0]
        try:
            temperature = float(self.temperature_var.get())
        except ValueError:
            raise ValueError("Temperature must be a number.")

        mode = self.cluster_mode.get()
        if mode == 'custom':
            try:
                tau = float(self.tau_var.get())
            except ValueError:
                raise ValueError("TAU must be a number.")
            if not 0 < tau <= 1:
                raise ValueError("TAU must be greater than 0 and no more than 1.")
            try:
                dihedral_weight = float(self.dihedral_var.get())
            except ValueError:
                raise ValueError("Dihedral weight must be a number.")
            cluster_settings = (self.linkage_var.get(), tau, self.selection_var.get(), dihedral_weight)
        elif mode == 'shifts':
            cluster_settings = ('complete', 0.40, 'tiered', CLUSTER_DIHEDRAL_WEIGHT_DEFAULT)
        elif mode == 'all_nmr':
            cluster_settings = ('complete', 0.15, 'lowest_energy', CLUSTER_DIHEDRAL_WEIGHT_DEFAULT)
        else:
            cluster_settings = None

        return {
            'method_key': method_key,
            'temperature': temperature,
            'machine': machine_key,
            'tier': tier_name,
            'include_cc': self.include_cc.get(),
            'include_fluorine': self.include_fluorine.get(),
            'include_nitrogen': self.include_nitrogen.get(),
            'include_csulfur': self.include_csulfur.get(),
            'include_chalogen': self.include_chalogen.get(),
            # A blank box means "here" rather than an error: os.makedirs('') raises, and refusing to run over
            # an empty field is less useful than doing the obvious thing
            'output_dir': self.output_var.get().strip() or workbench_directory(),
            'keep_split': self.keep_split.get(),
            'keep_aligned': self.keep_aligned.get(),
            'keep_clustered': self.keep_clustered.get(),
            'cluster': cluster_settings,
        }

    def _pipeline_worker(self, paths, settings_by_compound):
        """
        Split, optionally cluster, then write Gaussian inputs.

        Conformers are grouped by compound using the {compound}_{conformer} convention the rest of this toolchain
        uses, so a directory holding several compounds is handled correctly rather than being treated as one
        oversized ensemble.
        """
        # Output folder, clustering and line endings are run-wide rather than per compound, so any compound's
        # snapshot carries them; the element-specific and method choices below are read per compound.
        reference_settings = next(iter(settings_by_compound.values()))
        output_dir = reference_settings['output_dir']
        os.makedirs(output_dir, exist_ok=True)

        # --- split any multi-structure file ---
        conformer_files = []
        created_split_files = []      # exactly what this run wrote, so cleanup touches nothing else
        split_dir = os.path.join(output_dir, 'split_conformers')
        split_count = 0
        for path in paths:
            try:
                with open(path, 'r', errors='replace') as handle:
                    content = handle.read()
            except OSError as error:
                print(f"  Skipping {os.path.basename(path)}: {error}")
                continue
            if content.count('$$$$') <= 1:
                conformer_files.append(path)
                continue
            os.makedirs(split_dir, exist_ok=True)
            base = os.path.splitext(os.path.basename(path))[0]
            # Strip the suffixes the common conformer-search tools append, so the split files inherit the
            # compound name rather than carrying the search tool's naming into every downstream filename
            for suffix in ('_confs', '.sdf_Conf', '_Conf'):
                if base.endswith(suffix):
                    base = base[:-len(suffix)]
                    break
            entries = sms_split_sdf_entries(content)
            print(f"Splitting {os.path.basename(path)}: {len(entries)} structures -> {base}_1 .. {base}_{len(entries)}")
            for index, entry in enumerate(entries, start=1):
                target = os.path.join(split_dir, f"{base}_{index}.sdf")
                with open(target, 'w', encoding='utf-8') as handle:
                    handle.write(entry)
                conformer_files.append(target)
                created_split_files.append(target)
                split_count += 1
        if split_count:
            print(f"Wrote {split_count} split conformer file(s) to {split_dir}\n")

        if not conformer_files:
            print("No usable conformer files after splitting.")
            return ('pipeline_done', [])

        # Group by compound as (conformer_number, path) pairs sorted numerically -- the exact shape the input
        # generator expects, matching what its own directory scan produces. Files whose names do not carry a
        # conformer number are reported rather than silently dropped, since a name that does not match is the
        # usual reason a run covers fewer conformers than expected.
        requested_compounds = set(settings_by_compound)
        by_compound = defaultdict(list)
        unnumbered = []
        for path in conformer_files:
            stem = os.path.splitext(os.path.basename(path))[0]
            match = re.match(r'^(.+?)_(\d+)$', stem)
            if not match:
                unnumbered.append(os.path.basename(path))
                continue
            by_compound[match.group(1)].append((int(match.group(2)), os.path.abspath(path)))
        for compound_name in by_compound:
            by_compound[compound_name].sort(key=lambda pair: pair[0])
        if unnumbered:
            shown = ", ".join(unnumbered[:5]) + (f", and {len(unnumbered) - 5} more" if len(unnumbered) > 5 else "")
            print(f"  Skipped (no _<number> in the filename): {shown}")
        if not by_compound:
            print("No conformer files matched the {compound}_{number}.sdf naming convention.")
            return ('pipeline_done', [])

        # Restrict to what was actually requested. With a single compound selected, every other loaded compound
        # is left completely alone -- not clustered, no job files written.
        skipped_compounds = sorted(set(by_compound) - requested_compounds)
        if skipped_compounds:
            by_compound = defaultdict(list, {name: pairs for name, pairs in by_compound.items()
                                             if name in requested_compounds})
            print(f"Processing only: {', '.join(sorted(by_compound))}")
            print(f"  Not processed (loaded but not selected): {', '.join(skipped_compounds)}")
        if not by_compound:
            print("The selected compound has no conformer files matching the "
                  "{compound}_{number}.sdf naming convention.")
            return ('pipeline_done', [])
        print(f"{len(by_compound)} compound(s) across "
              f"{sum(len(v) for v in by_compound.values())} conformer file(s)")

        # --- optional alignment: after splitting produced individual conformers, before clustering sees them ---
        if True:   # always aligned; see the note where the option used to live
            aligned_root = os.path.join(output_dir, ALIGNED_OUTPUT_DIR)
            realigned = {}
            for compound_name, pairs in sorted(by_compound.items()):
                print(f"\nAligning {compound_name} ({len(pairs)} conformer(s))")
                aligned, _stats = align_conformer_files(
                    pairs, os.path.join(aligned_root, compound_name), report=print)
                realigned[compound_name] = aligned or pairs
            by_compound = defaultdict(list, realigned)

        # --- optional clustering ---
        if any(settings_by_compound.get(name, reference_settings)['cluster'] for name in by_compound) \
                and SCIPY_AVAILABLE:
            cluster_root = os.path.join(output_dir, 'clustered_output')
            os.makedirs(cluster_root, exist_ok=True)
            selected = {}
            for compound_name, pairs in sorted(by_compound.items()):
                compound_cluster = settings_by_compound.get(compound_name, reference_settings)['cluster']
                if not compound_cluster:
                    selected[compound_name] = pairs
                    print(f"\n  {compound_name}: clustering not requested; all {len(pairs)} conformer(s) kept")
                    continue
                # Applied per compound, immediately before that compound is clustered, so two compounds in one
                # run can genuinely use different settings
                linkage_method, tau, selection_mode, dihedral_weight = compound_cluster
                globals()['CLUSTER_LINKAGE_METHOD'] = linkage_method
                globals()['CLUSTER_TAU'] = tau
                globals()['CLUSTER_SELECTION_MODE'] = selection_mode
                globals()['CLUSTER_DIHEDRAL_WEIGHT'] = dihedral_weight
                print(f"\n  {compound_name}: clustering {len(pairs)} conformer(s) -- {linkage_method} linkage, "
                      f"TAU {tau}, {selection_mode} selection, dihedral weight {dihedral_weight}")
                # Clustering indexes conformer_files[0][1], i.e. it expects the same (conformer_number, path)
                # tuples the input generator does. Passing bare paths made [1] read the second CHARACTER of the
                # path string, which on Windows is the drive-letter colon -- an invalid filename.
                # Clustering partitions the ensemble but performs NO selection on its own -- deciding which
                # member of each cluster goes to DFT is a separate step, and in the original command-line script
                # it happened back in its own main(). Calling only the partitioning left every conformer looking
                # selected, which is why clustering appeared to have no effect on which jobs were written.
                result = cluster_organise_conformers_into_clusters(compound_name, pairs, cluster_root)
                cluster_arguments = [(compound_name, pairs, cluster_root)]
                members_map = {}
                for rank, info in (result or {}).items():
                    members_map[rank] = info.get('members_dist_info', [])
                collect_dft_structures(cluster_arguments, [result], [members_map], cluster_root)
                collect_low_priority_structures(cluster_arguments, [result], [members_map], cluster_root)

                if CLUSTER_SIMPLE_OUTPUT:
                    kept, rejected = cluster_simplify_output(cluster_root, compound_name)
                else:
                    kept = cluster_collect_selected_files(cluster_root, compound_name)
                    rejected = []
                if kept:
                    repaired = []
                    for path in kept:
                        stem = os.path.splitext(os.path.basename(path))[0]
                        match = re.match(r'^(.+?)_(\d+)$', stem)
                        if match:
                            repaired.append((int(match.group(2)), os.path.abspath(path)))
                    repaired.sort(key=lambda pair: pair[0])
                    selected[compound_name] = repaired or pairs
                    print(f"  {compound_name}: {len(pairs)} conformer(s) -> {len(repaired or pairs)} unique "
                          f"kept for job setup, {len(rejected)} set aside")
                else:
                    # Falling back to every conformer here would silently undo the reduction the user asked
                    # for, so say plainly that it happened rather than quietly generating far more jobs
                    selected[compound_name] = pairs
                    print(f"  WARNING: {compound_name}: clustering selected nothing, so ALL {len(pairs)} "
                          f"conformer(s) will be set up. Check the clustering settings.")
            by_compound = selected

        # --- Gaussian input generation ---

        generated = []
        for compound_name, pairs in sorted(by_compound.items()):
            settings = settings_by_compound.get(compound_name, reference_settings)
            enabled = [name for name, flag in (('coupling constants', settings['include_cc']),
                                               ('fluorine', settings['include_fluorine']),
                                               ('nitrogen', settings['include_nitrogen']),
                                               ('C-S', settings['include_csulfur']),
                                               ('C-halogen', settings['include_chalogen'])) if flag]
            print(f"  settings: method {settings['method_key']}, {settings['temperature']} K, "
                  f"{settings.get('machine', 'default')}/{settings['tier']} resources"
                  + (f", extras: {', '.join(enabled)}" if enabled else ", no extra calculations"))
            compound_settings = {
                'method_key': settings['method_key'],
                'include_cc': settings['include_cc'],
                'include_fluorine': settings['include_fluorine'],
                'include_nitrogen': settings['include_nitrogen'],
                'temperature': settings['temperature'],
                'include_csulfur': settings['include_csulfur'],
                'include_chalogen': settings['include_chalogen'],
                'tier': None,   # replaced below from the machine profile
            }
            # Written straight into the job folder rather than into the output root and moved afterwards.
            # Every other stage writes to its own directory, and files appearing at the top level only to
            # vanish a moment later is confusing to watch.
            gjf_directory = os.path.join(output_dir, GJF_OUTPUT_DIR)
            os.makedirs(gjf_directory, exist_ok=True)

            # Resource tier and scratch-file paths come from the selected machine profile
            machine = WORKBENCH_MACHINES.get(settings.get('machine', 'default'), {})
            tiers = machine.get('tiers') or {'medium': {'nprocshared': 32, 'mem': '63GB'}}
            tier = tiers.get(settings['tier']) or next(iter(tiers.values()))
            compound_settings['tier'] = tier
            compound_settings['machine_chk'] = machine.get('chk') or '%chk={compound}_{conformer}.chk'
            compound_settings['machine_rwf'] = machine.get('rwf', '')
            print(f"\nGenerating inputs for {compound_name} ({len(pairs)} conformer(s))")
            written = ngig_process_compound_folder(
                compound_name, 'conformers', pairs, gjf_directory, compound_settings)
            if written:
                generated.extend(written)

        # Always applied: these jobs run on a Linux cluster, where CRLF in a .gjf is a silent source of parse
        # failures, so there is no case for making it optional.
        if generated:
            ngig_convert_gjf_files_to_unix(generated)
            print(f"Converted {len(generated)} file(s) to Unix line endings")

        # Gather every .gjf into one directory. The generator organises them per compound and job type, which is
        # useful for reading but awkward for submission, where what is wanted is simply the set of files to send.
        # The generator now writes into the job folder directly, so nothing needs moving; anything it left in
        # a nested directory is still gathered up, and emptied directories are cleared.
        if generated:
            gjf_directory = os.path.join(output_dir, GJF_OUTPUT_DIR)
            os.makedirs(gjf_directory, exist_ok=True)
            source_directories = set()
            for path in generated:
                if not path.lower().endswith('.gjf'):
                    continue
                destination = os.path.join(gjf_directory, os.path.basename(path))
                if os.path.abspath(destination) == os.path.abspath(path):
                    continue
                try:
                    source_directories.add(os.path.dirname(os.path.abspath(path)))
                    if os.path.exists(destination):
                        os.remove(destination)
                    shutil.move(path, destination)
                except (IOError, OSError) as error:
                    print(f"  WARNING: could not collect {os.path.basename(path)}: {error}")
            for directory in sorted(source_directories, key=len, reverse=True):
                try:
                    if os.path.isdir(directory) and not os.listdir(directory):
                        os.rmdir(directory)
                except OSError:
                    pass
            print(f"{len(generated)} job file(s) in {GJF_OUTPUT_DIR}{os.sep}")

        # Intermediate folders are cleaned up last, after the job files are safely written. They cannot be
        # skipped: splitting produces what alignment reads, alignment produces what clustering reads, and
        # clustering produces the selection the generator uses. The choice is whether to keep them.
        #
        # Only THIS run's files are removed, never the whole folder. These directories are shared across runs,
        # so a compound processed on its own would otherwise delete the split conformers of every compound
        # processed before it -- which is exactly what happened when one run's cleanup reached into another
        # compound's files. The folder itself goes only if it ends up empty.
        cleanup_targets = []
        if not reference_settings.get('keep_split', False):
            cleanup_targets.append(('split conformers', os.path.join(output_dir, 'split_conformers'),
                                    created_split_files))
        if not reference_settings.get('keep_aligned', False):
            cleanup_targets.append(('aligned conformers', os.path.join(output_dir, ALIGNED_OUTPUT_DIR),
                                    None))
        if not reference_settings.get('keep_clustered', True):
            cleanup_targets.append(('clustering output', os.path.join(output_dir, 'clustered_output'), None))

        for label, directory, explicit_files in cleanup_targets:
            if not os.path.isdir(directory):
                continue
            if explicit_files is None:
                # These are organised per compound, so only this run's compounds are removed
                targets = [os.path.join(directory, name) for name in sorted(by_compound)
                           if os.path.exists(os.path.join(directory, name))]
            else:
                targets = [path for path in explicit_files if os.path.exists(path)]

            removed, blocked = 0, 0
            for target in targets:
                # A brief retry, because a file written moments ago can still be held briefly on Windows by a
                # virus scanner or an indexer; one failure should not abandon the rest of the cleanup
                for attempt in range(3):
                    try:
                        if os.path.isdir(target):
                            shutil.rmtree(target)
                        else:
                            os.remove(target)
                        removed += 1
                        break
                    except OSError:
                        if attempt == 2:
                            blocked += 1
                        else:
                            time.sleep(0.2)
            try:
                if os.path.isdir(directory) and not os.listdir(directory):
                    os.rmdir(directory)
            except OSError:
                pass

            if blocked:
                print(f"Cleaned up {removed} {label} item(s); {blocked} were locked by another process and "
                      f"have been left in place.")
            elif removed:
                print(f"Cleaned up {removed} {label} item(s)")

        print(f"\nDone. {len(generated)} Gaussian input file(s) written to "
              f"{os.path.join(output_dir, GJF_OUTPUT_DIR)}")
        return ('pipeline_done', generated)




# ==================================================================================================================
# 3D STRUCTURE VIEWER
# ==================================================================================================================
# Shows one conformer as a stick structure with its predicted chemical shifts overlaid, so the numbers can be read
# against the geometry that produced them.
#
# WHY THIS IS DRAWN ON A TK CANVAS RATHER THAN LIFTED WHOLESALE FROM THE STANDALONE VIEWER.
# That viewer renders through pygame and PyOpenGL. Neither ships with CPython, and neither can be installed on a
# machine that blocks package installation -- so embedding it unchanged would produce a window that simply never
# opens here. There is also a structural obstacle: pygame drives its own window and event loop, and running that
# inside an application already owned by Tk's mainloop means two loops competing for the same thread. Redrawing
# on a Canvas avoids both problems and needs nothing beyond the standard library.
#
# What IS carried over verbatim is everything that determines how it looks: the CPK element colours, the deep-gold
# label colour, the dark background, and the default viewing orientation. A stick structure is geometrically
# simple enough that a Canvas reproduces it faithfully -- each bond is drawn as two half-segments meeting at the
# bond midpoint, each half taking its own atom's colour, which is exactly what a stick representation is.
#
# LABEL SOURCE. The labels are the same values the PyMOL script writes. No translation was needed: that script
# emits "label id 5, '7.26'" and the standalone viewer's label parser already reads precisely that form, so the
# two formats were identical to begin with. The shifts shown here are therefore the same numbers, already
# equivalence-averaged, that appear in the PyMOL output.

VIEWER_CPK_COLORS = {
    "H":  (0.95, 0.95, 0.95), "C":  (0.42, 0.44, 0.47),
    "N":  (0.07, 0.20, 0.97), "O":  (0.90, 0.07, 0.07),
    "F":  (0.50, 0.90, 0.15), "Cl": (0.12, 0.94, 0.12),
    "Br": (0.65, 0.16, 0.16), "I":  (0.58, 0.00, 0.58),
    "S":  (1.00, 1.00, 0.19), "P":  (1.00, 0.50, 0.00),
    "Na": (0.67, 0.36, 0.95), "K":  (0.56, 0.25, 0.83),
    "Ca": (0.24, 1.00, 0.00), "Mg": (0.54, 1.00, 0.00),
    "Fe": (0.88, 0.40, 0.20), "Zn": (0.49, 0.50, 0.69),
    "DEFAULT": (0.75, 0.75, 0.75),
}
VIEWER_LABEL_COLOR = "#ffcc00"       # deep gold, matching the standalone viewer
VIEWER_BACKGROUND = "#14141a"        # the standalone viewer's dark background
VIEWER_STICK_WIDTH = 7               # on-screen bond thickness in pixels at unit zoom
VIEWER_DEPTH_MIN_BRIGHTNESS = 0.66   # how much of its own colour the furthest atom keeps; the rest is background.
                                     # Kept high on purpose: cueing should say which atom is nearer, not push
                                     # the far side of the molecule into the background where it cannot be read
VIEWER_DEPTH_MIN_WIDTH = 0.72        # how thick the furthest stick is relative to the nearest
VIEWER_MULTIPLE_BOND_GAP = 0.78      # separation between the lines of a double or triple bond, in stick widths
VIEWER_AROMATIC_GAP = 1.5           # the dashed partner sits further off than a double bond's second line,
                                     # since at close range the two read as one thick bond rather than two
VIEWER_AROMATIC_INSET = 0.22         # fraction trimmed from each end of a dashed partner. Without it the
                                     # dashes of neighbouring bonds in a ring run past each other and cross at
                                     # the vertices instead of stopping short and meeting
VIEWER_SHADING_STRIPS = 23           # lengthwise strips per stick. Enough that the bands blend into a smooth
                                     # gradient at normal zoom rather than reading as visible stripes
VIEWER_SPHERE_SHELLS = 6             # nested circles forming the lit sphere at each atom
VIEWER_LIGHT_DIRECTION = (-0.42, -0.50, 0.76)   # from the upper left and slightly toward the viewer
VIEWER_AMBIENT = 0.62                # how lit the side facing away from the light still is. Generous, because
                                     # a dark carbon shaded to a third of its brightness is indistinguishable
                                     # from the background
VIEWER_SPECULAR_STRENGTH = 0.55      # brightness of the narrow highlight along the top of each stick


def viewer_shade(colour, factor):
    """
    Scale a colour's brightness, with a tint toward white for values above 1.

    Multiplying alone gives a convincing shaded side but a lifeless highlight, because a fully lit surface of a
    dark colour is still dark. Pushing the excess toward white instead is what makes a stick read as a glossy
    cylinder rather than a flat band.
    """
    red = int(colour[1:3], 16)
    green = int(colour[3:5], 16)
    blue = int(colour[5:7], 16)
    if factor <= 1.0:
        red, green, blue = red * factor, green * factor, blue * factor
    else:
        excess = min(1.0, factor - 1.0)
        red = red + (255 - red) * excess
        green = green + (255 - green) * excess
        blue = blue + (255 - blue) * excess
    return "#%02x%02x%02x" % (max(0, min(255, int(red))),
                              max(0, min(255, int(green))),
                              max(0, min(255, int(blue))))


def viewer_cylinder_strips(width, perpendicular_x, perpendicular_y, strips=VIEWER_SHADING_STRIPS):
    """
    Offsets and brightness factors describing a lit cylinder seen side-on.

    A stick drawn as one flat line disappears into its neighbours when several run through the same region --
    there is nothing to say which is in front. Drawing it instead as a few lengthwise strips of varying
    brightness gives the round, shaded look a real cylinder has, and that shading alone separates overlapping
    bonds without any depth buffer.

    Each strip sits at a fraction t across the stick's width, from -1 at one edge to +1 at the other. On a
    cylinder the surface normal there is t across and sqrt(1 - t^2) toward the viewer, so the usual Lambertian
    dot product with the light gives the brightness. The screen-space perpendicular is passed in so the
    highlight follows the bond's orientation rather than sitting on the same side of every stick.

    Returns [(offset_in_pixels, brightness_factor, cap_overhang_in_pixels), ...] ordered edge to edge.
    """
    light_x, light_y, light_z = VIEWER_LIGHT_DIRECTION
    sideways = perpendicular_x * light_x + perpendicular_y * light_y
    half = width / 2.0

    # How lit the best-placed strip on THIS bond can be. A stick lying along the light direction can never
    # reach the same peak as one lying across it, so scaling by this keeps the highlight equally crisp on
    # every bond instead of leaving some looking glossy and others flat.
    brightest = math.sqrt(sideways * sideways + light_z * light_z) or 1.0

    result = []
    for index in range(strips):
        across = (index - (strips - 1) / 2.0) / max(1e-9, (strips - 1) / 2.0)
        toward_viewer = math.sqrt(max(0.0, 1.0 - across * across))
        lambert = max(0.0, across * sideways + toward_viewer * light_z)
        brightness = VIEWER_AMBIENT + (1.0 - VIEWER_AMBIENT) * lambert
        # A narrow specular band along the lit side. Raised to a power of the NORMALISED value so the peak is
        # reached on every bond; using the raw dot product left the highlight far below full strength.
        brightness += VIEWER_SPECULAR_STRENGTH * ((lambert / brightest) ** 10)
        # How far this strip runs past the end of the cylinder to form a hemispherical cap. Seen side-on a
        # capsule is a rectangle closed by semicircles, so the strip at height t reaches sqrt(1 - t^2) of the
        # radius beyond the end. Building the cap out of the cylinder's own strips is what makes it part of
        # the stick rather than a sphere sitting on top of it.
        result.append((across * half, brightness, toward_viewer * half))
    return result


def viewer_sphere_shells(radius, shells=VIEWER_SPHERE_SHELLS):
    """
    Nested circles describing a lit sphere, largest and darkest first.

    A stick representation joins cylinders at each atom, and without something filling that joint the ends
    show as flat cut-offs and the seam between two bonds of different colours is a visible notch. A sphere of
    exactly the stick's radius closes it, which is what a real stick model does.

    Each shell is drawn smaller than the last and displaced toward the light, so the brightest sits off-centre
    on the lit side -- the same way the specular band sits off-centre on a cylinder.

    Returns [(radius, offset_x_fraction, offset_y_fraction, brightness), ...].
    """
    light_x, light_y, light_z = VIEWER_LIGHT_DIRECTION
    length = math.sqrt(light_x * light_x + light_y * light_y) or 1.0
    toward_x, toward_y = light_x / length, light_y / length

    result = []
    for index in range(shells):
        fraction = index / max(1, shells - 1)
        shell_radius = radius * (1.0 - 0.78 * fraction)
        displacement = radius * 0.55 * fraction
        lambert = VIEWER_AMBIENT + (1.0 - VIEWER_AMBIENT) * (0.35 + 0.65 * fraction)
        if index == shells - 1:
            lambert += VIEWER_SPECULAR_STRENGTH      # the small bright spot
        result.append((shell_radius, toward_x * displacement, toward_y * displacement, lambert))
    return result


def viewer_blend_toward_background(colour, nearness):
    """
    Fade a colour toward the background by how far back it sits.

    Depth cueing, and the cheapest way to tell front from back when both are the same element: a carbon in
    front stays its full colour while one behind is mixed toward the background. No lighting, no shading and
    no per-pixel work -- one interpolation per segment, computed while the scene is being built.

    nearness runs 0 (furthest) to 1 (nearest).
    """
    red = int(colour[1:3], 16)
    green = int(colour[3:5], 16)
    blue = int(colour[5:7], 16)
    back_red = int(VIEWER_BACKGROUND[1:3], 16)
    back_green = int(VIEWER_BACKGROUND[3:5], 16)
    back_blue = int(VIEWER_BACKGROUND[5:7], 16)
    weight = VIEWER_DEPTH_MIN_BRIGHTNESS + (1.0 - VIEWER_DEPTH_MIN_BRIGHTNESS) * max(0.0, min(1.0, nearness))
    return "#%02x%02x%02x" % (
        int(back_red + (red - back_red) * weight),
        int(back_green + (green - back_green) * weight),
        int(back_blue + (blue - back_blue) * weight))


def viewer_element_colour(symbol):
    """A '#rrggbb' string for an element, from the same CPK table the standalone viewer uses."""
    r, g, b = VIEWER_CPK_COLORS.get(symbol, VIEWER_CPK_COLORS["DEFAULT"])
    return "#%02x%02x%02x" % (int(r * 255), int(g * 255), int(b * 255))


def parse_pymol_label_file(path):
    """
    Read shift labels from a PyMOL script written by this program.

    The line form is "label id <atom>, '<value>'" -- the same shape the standalone viewer already parsed, so
    nothing is converted here; the values are read as written. Returns {atom_number: label_text}.
    """
    labels = {}
    pattern = re.compile(r"label\s+id\s+(\d+)\s*,\s*'([^']*)'")
    try:
        with open(path, 'r', errors='replace') as handle:
            for line in handle:
                line = line.split('#')[0].strip()
                if not line:
                    continue
                match = pattern.match(line)
                if match:
                    labels[int(match.group(1))] = match.group(2)
    except OSError:
        return {}
    return labels


class StructureViewer(ttk.Frame):
    """
    A stick-structure viewer on a Tk Canvas: drag to rotate, scroll to zoom, right-drag to pan.

    One structure at a time by design. The point is to read shifts against a geometry, and overlaying several
    conformers would obscure exactly the labels the window exists to show.
    """

    def __init__(self, parent):
        super().__init__(parent)
        self.elements = []
        self.coordinates = []
        self.bonds = []
        self.bond_orders = {}
        self.bond_rings = {}
        self.labels = {}
        self.show_labels = True

        # Starting orientation copied from the standalone viewer so a structure opens looking the same way
        self.rotation = self._rotation_y(-30.0).dot(self._rotation_x(20.0))
        self.zoom = 28.0
        self.pan = [0.0, 0.0]
        self._drag = None

        self.canvas = tk.Canvas(self, bg=VIEWER_BACKGROUND, highlightthickness=0, height=420)
        self.canvas.grid(row=0, column=0, sticky='nsew')
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self.canvas.bind('<ButtonPress-1>', self._start_rotate)
        self.canvas.bind('<B1-Motion>', self._rotate)
        self.canvas.bind('<ButtonPress-3>', self._start_pan)
        self.canvas.bind('<B3-Motion>', self._pan_drag)
        self.canvas.bind('<MouseWheel>', self._wheel)
        self.canvas.bind('<Button-4>', self._wheel)
        self.canvas.bind('<Button-5>', self._wheel)
        self.canvas.bind('<Configure>', lambda event: self.redraw())

    # ---- geometry helpers ----
    @staticmethod
    def _rotation_x(degrees):
        r = math.radians(degrees)
        return np.array([[1, 0, 0], [0, math.cos(r), -math.sin(r)], [0, math.sin(r), math.cos(r)]])

    @staticmethod
    def _rotation_y(degrees):
        r = math.radians(degrees)
        return np.array([[math.cos(r), 0, math.sin(r)], [0, 1, 0], [-math.sin(r), 0, math.cos(r)]])

    # ---- content ----
    @staticmethod
    def find_ring_members(bonds, atom_a, atom_b, largest=8):
        """
        The atoms of the smallest ring containing one bond, or None if the bond is not in a ring.

        Found by deleting the bond and taking the shortest remaining path between its two atoms: that path
        plus the bond is by definition the smallest cycle through it. Used so an aromatic bond's dashed
        partner can be placed toward the ring's centre, which is the convention -- placed on an arbitrary side
        instead, the dashes of one ring end up scattered inside and outside it.
        """
        adjacency = defaultdict(set)
        for first, second in bonds:
            adjacency[first].add(second)
            adjacency[second].add(first)
        adjacency[atom_a].discard(atom_b)
        adjacency[atom_b].discard(atom_a)

        # Breadth-first, so the first path found is the shortest and the ring returned is the SMALLEST one
        # through this bond. That matters at a ring fusion: a shared bond lies in two rings, and the larger
        # envelope surrounding both would put the dash outside the ring it visually belongs to.
        previous = {atom_a: None}
        queue = deque([atom_a])
        while queue:
            current = queue.popleft()
            if current == atom_b:
                break
            for neighbour in sorted(adjacency[current]):
                if neighbour not in previous:
                    previous[neighbour] = current
                    queue.append(neighbour)
        if atom_b not in previous:
            return None
        path, node = [], atom_b
        while node is not None:
            path.append(node)
            node = previous[node]
        return path if len(path) <= largest else None

    def load_structure(self, elements, coordinates, bonds, labels=None, bond_orders=None):
        """
        Replace the displayed structure.

        bonds is a list of (atom_a, atom_b); bond_orders optionally maps those pairs to 1, 2, 3 or 4, which is
        what lets a double bond be drawn as two lines and an aromatic one as a solid line with a dashed
        partner. Without it everything draws as a single bond, which is what happens for a structure whose
        orders were never determined.

        Coordinates are centred so rotation happens about the molecule.
        """
        # Normalised so a pair is found whichever way round it was recorded. A bond written as (6, 1) rather
        # than (1, 6) would otherwise miss the lookup and be drawn as a single bond, which is silent and looks
        # exactly like a structure that genuinely has no double bonds there.
        self.bond_orders = {}
        for pair, order in (bond_orders or {}).items():
            try:
                first, second = int(pair[0]), int(pair[1])
            except (TypeError, ValueError, IndexError):
                continue
            self.bond_orders[(min(first, second), max(first, second))] = order
        self.elements = list(elements)
        points = np.asarray(coordinates, dtype=float)
        if len(points):
            points = points - points.mean(axis=0)
        self.coordinates = points
        self.bonds = list(bonds)
        self.labels = dict(labels or {})
        if len(points):
            # Fit the structure to the window on load rather than making the user hunt for it
            extent = float(np.abs(points).max()) or 1.0
            self.zoom = min(self.canvas.winfo_width() or 600, self.canvas.winfo_height() or 420) / (extent * 2.8)
        # Ring membership for aromatic bonds, resolved once here rather than per frame: it depends only on
        # the bonding, which does not change while a structure is displayed
        # Ring lookup for aromatic bonds, searched over the AROMATIC bonds only. Searching the whole molecule
        # let a path leave the aromatic ring, cross a saturated ring fused to it and come back, so the dash was
        # placed toward a ring that is not conjugated at all. Restricted this way the ring found is by
        # construction fully aromatic, which is the ring the inner line belongs in.
        aromatic_bonds = []
        for pair, order in self.bond_orders.items():
            try:
                if int(round(float(order))) == 4:
                    aromatic_bonds.append(pair)
            except (TypeError, ValueError):
                continue

        self.bond_rings = {}
        for pair in aromatic_bonds:
            members = self.find_ring_members(aromatic_bonds, pair[0], pair[1])
            if members:
                self.bond_rings[pair] = members

        self.pan = [0.0, 0.0]
        self.redraw()

    def clear(self):
        self.elements, self.coordinates, self.bonds, self.labels = [], [], [], {}
        self.bond_orders, self.bond_rings = {}, {}
        self.canvas.delete('all')

    def set_labels_visible(self, visible):
        self.show_labels = bool(visible)
        self.redraw()

    # ---- interaction ----
    def _start_rotate(self, event):
        self._drag = ('rotate', event.x, event.y)

    def _rotate(self, event):
        if not self._drag or self._drag[0] != 'rotate':
            return
        _, x0, y0 = self._drag
        self.rotation = (self._rotation_y((event.x - x0) * 0.5)
                         .dot(self._rotation_x((event.y - y0) * 0.5))
                         .dot(self.rotation))
        self._drag = ('rotate', event.x, event.y)
        self.redraw()

    def _start_pan(self, event):
        self._drag = ('pan', event.x, event.y)

    def _pan_drag(self, event):
        if not self._drag or self._drag[0] != 'pan':
            return
        _, x0, y0 = self._drag
        self.pan[0] += event.x - x0
        self.pan[1] += event.y - y0
        self._drag = ('pan', event.x, event.y)
        self.redraw()

    def _wheel(self, event):
        step = 1.1 if (getattr(event, 'delta', 0) > 0 or getattr(event, 'num', 0) == 4) else 1 / 1.1
        self.zoom = max(2.0, min(400.0, self.zoom * step))
        self.redraw()

    # ---- drawing ----
    def build_scene(self, width, height):
        """
        Turn the structure into a flat list of 2D primitives, ready to draw.

        Deliberately separated from the drawing itself and containing no Tk call of any kind: this is the
        projection, depth sorting and colour assignment, which is the part that survives a change of rendering
        backend unchanged. See the PORTING NOTE below for why that split matters.

        Returns a list of primitives, already sorted back to front:
            ('line', x1, y1, x2, y2, colour, width, dash)   dash is None for a solid line
            ('dot',  x, y, radius, colour)
            ('text', x, y, string, colour)
        """
        if not len(self.coordinates):
            return []

        centre_x = width / 2 + self.pan[0]
        centre_y = height / 2 + self.pan[1]

        rotated = self.coordinates.dot(self.rotation.T)
        screen = [(centre_x + point[0] * self.zoom, centre_y - point[1] * self.zoom) for point in rotated]
        depth = rotated[:, 2]
        stick = max(2, int(VIEWER_STICK_WIDTH * self.zoom / 28.0))

        # Depth is normalised across this structure rather than against a fixed range, so a flat molecule and
        # a globular one both use the full contrast available instead of one of them coming out uniformly dim
        near, far = float(depth.max()), float(depth.min())
        span = (near - far) or 1.0

        def nearness(z):
            return (z - far) / span

        primitives = []
        for atom_a, atom_b in self.bonds:
            index_a, index_b = atom_a - 1, atom_b - 1
            if not (0 <= index_a < len(screen) and 0 <= index_b < len(screen)):
                continue
            xa, ya = screen[index_a]
            xb, yb = screen[index_b]
            mid_x, mid_y = (xa + xb) / 2.0, (ya + yb) / 2.0
            z = float(depth[index_a] + depth[index_b]) / 2.0
            depth_fraction = nearness(z)
            width = max(1, int(round(stick * (VIEWER_DEPTH_MIN_WIDTH
                                              + (1.0 - VIEWER_DEPTH_MIN_WIDTH) * depth_fraction))))
            colour_a = viewer_blend_toward_background(viewer_element_colour(self.elements[index_a]),
                                                      nearness(float(depth[index_a])))
            colour_b = viewer_blend_toward_background(viewer_element_colour(self.elements[index_b]),
                                                      nearness(float(depth[index_b])))

            # getattr rather than a direct attribute read: a structure loaded before bond orders existed, or
            # any caller that supplies only geometry, should still draw as plain sticks rather than fail
            order = getattr(self, 'bond_orders', {}).get((min(atom_a, atom_b), max(atom_a, atom_b)), 1)
            try:
                order = int(round(float(order)))
            except (TypeError, ValueError):
                order = 1

            # Parallel lines are offset along the screen-space perpendicular of the bond, which keeps the
            # separation constant however the molecule is turned
            length = math.hypot(xb - xa, yb - ya) or 1.0
            offset_x = -(yb - ya) / length * stick * VIEWER_MULTIPLE_BOND_GAP
            offset_y = (xb - xa) / length * stick * VIEWER_MULTIPLE_BOND_GAP

            if order == 2:
                lanes = [(-0.5, None), (0.5, None)]
            elif order == 3:
                lanes = [(-1.0, None), (0.0, None), (1.0, None)]
            elif order == 4:
                # Aromatic: the full line on the bond itself and a dashed partner set toward the ring's
                # centre. Which side that is depends on the ring, not on the bond, so it is resolved from the
                # ring's centroid; picking a fixed side would put some dashes inside a ring and some outside.
                ring = getattr(self, 'bond_rings', {}).get((min(atom_a, atom_b), max(atom_a, atom_b)))
                inner_a = inner_b = None
                if ring:
                    ring_x = sum(screen[member - 1][0] for member in ring) / float(len(ring))
                    ring_y = sum(screen[member - 1][1] for member in ring) / float(len(ring))
                    gap = stick * VIEWER_AROMATIC_GAP

                    def contract(point):
                        """Pull a ring atom toward the ring centre by the inner-line gap."""
                        towards_x, towards_y = ring_x - point[0], ring_y - point[1]
                        distance = math.hypot(towards_x, towards_y) or 1.0
                        scale = max(0.0, min(0.9, gap / distance))
                        return (point[0] + towards_x * scale, point[1] + towards_y * scale)

                    inner_a = contract(screen[index_a])
                    inner_b = contract(screen[index_b])
                lanes = [(0.0, None), (0.0, (5, 4))]
            else:
                lanes = [(0.0, None)]

            thin = max(1, int(width * 0.74)) if len(lanes) > 1 else width
            for shift, dash in lanes:
                dx, dy = offset_x * shift, offset_y * shift
                # A stick is two half-bonds meeting at the midpoint, each in its own atom's colour. Each half
                # is drawn as shaded lengthwise strips rather than one flat line -- see viewer_cylinder_strips.
                if dash:
                    # The inner line runs between the two atoms pulled toward the ring centre, rather than
                    # being the bond shifted sideways. Every bond of the ring is drawn between the same
                    # contracted vertices, so neighbouring dashes share an endpoint exactly: they meet at the
                    # corners instead of crossing past each other or stopping short of one another.
                    if inner_a is None or inner_b is None:
                        continue
                    primitives.append((z, ('line', inner_a[0], inner_a[1], inner_b[0], inner_b[1],
                                           colour_a, max(1, int(thin * 0.5)), dash)))
                    continue
                unit_x = offset_x / (stick * VIEWER_MULTIPLE_BOND_GAP or 1.0)
                unit_y = offset_y / (stick * VIEWER_MULTIPLE_BOND_GAP or 1.0)
                along_x, along_y = (xb - xa) / length, (yb - ya) / length
                strips = viewer_cylinder_strips(thin, unit_x, unit_y,
                                                VIEWER_SHADING_STRIPS if thin >= 4 else 5)
                # Slight overlap between neighbouring strips, so the cylinder reads as a gradient rather than
                # as a set of bands with seams between them
                strip_width = max(1, int(math.ceil(thin / len(strips))) + 1)
                for across, brightness, overhang in strips:
                    sx, sy = unit_x * across, unit_y * across
                    # Each half-stick runs from its atom to the bond midpoint, extended past the atom by this
                    # strip's share of the hemisphere. The two halves meeting at an atom both overhang it in
                    # that atom's own colour, so the joint closes into a rounded end with no separate sphere.
                    cap_x, cap_y = along_x * overhang, along_y * overhang
                    primitives.append((z, ('line', xa + dx + sx - cap_x, ya + dy + sy - cap_y,
                                           mid_x + dx + sx, mid_y + dy + sy,
                                           viewer_shade(colour_a, brightness), strip_width, None)))
                    primitives.append((z, ('line', mid_x + dx + sx, mid_y + dy + sy,
                                           xb + dx + sx + cap_x, yb + dy + sy + cap_y,
                                           viewer_shade(colour_b, brightness), strip_width, None)))

        # An unbonded atom would be invisible in a stick representation, so it gets a small dot
        # Bonded atoms need nothing here: the sticks meeting at an atom each overhang it by a hemisphere in
        # that atom's colour, so the joint is already a rounded cylinder end. Only an atom with no bonds at
        # all would otherwise be invisible.
        bonded = {atom for bond in self.bonds for atom in bond}
        for index, (x, y) in enumerate(screen):
            if (index + 1) in bonded:
                continue
            atom_depth = float(depth[index])
            base = viewer_blend_toward_background(viewer_element_colour(self.elements[index]),
                                                  nearness(atom_depth))
            for shell_radius, shift_x, shift_y, brightness in viewer_sphere_shells(stick / 2.0):
                if shell_radius < 0.6:
                    continue
                primitives.append((atom_depth,
                                   ('dot', x + shift_x, y + shift_y, shell_radius,
                                    viewer_shade(base, brightness))))

        # Painter's algorithm: far primitives first so nearer ones overlap them. Without a depth buffer this
        # ordering is the only thing giving the structure a sense of front and back.
        primitives.sort(key=lambda item: item[0])
        scene = [primitive for _z, primitive in primitives]

        if self.show_labels and self.labels:
            for index in sorted(range(len(screen)), key=lambda i: depth[i]):
                text = self.labels.get(index + 1)
                if not text:
                    continue
                x, y = screen[index]
                # A dark outline behind the gold keeps labels readable over pale atoms
                for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    scene.append(('text', x + dx, y + dy - 9, text, '#000000'))
                scene.append(('text', x, y - 9, text, VIEWER_LABEL_COLOR))

        return scene

    def redraw(self):
        """Draw the current scene. The only part of the viewer that talks to Tk."""
        canvas = self.canvas
        canvas.delete('all')
        width = canvas.winfo_width() or 600
        height = canvas.winfo_height() or 420
        for primitive in self.build_scene(width, height):
            kind = primitive[0]
            if kind == 'line':
                _, x1, y1, x2, y2, colour, thickness, dash = primitive
                if dash:
                    canvas.create_line(x1, y1, x2, y2, fill=colour, width=thickness, dash=dash)
                else:
                    canvas.create_line(x1, y1, x2, y2, fill=colour, width=thickness, capstyle='round')
            elif kind == 'dot':
                _, x, y, radius, colour = primitive
                canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=colour, outline='')
            elif kind == 'text':
                _, x, y, text, colour = primitive
                canvas.create_text(x, y, text=text, fill=colour, font=('Consolas', 8, 'bold'))


# ==================================================================================================================
# PORTING NOTE -- 3D VIEWER
# ==================================================================================================================
# Read this before reimplementing the viewer in another language. The structure above was chosen to make that
# port mechanical rather than to be the fastest possible Python.
#
# WHAT PORTS UNCHANGED
#   build_scene() is pure arithmetic: rotate, project, sort, assign colours. No Tk, no I/O, no global state. It
#   translates line for line into any language, and its output -- a flat, depth-ordered primitive list -- is the
#   natural input to every 2D backend. Port this first and test it against the Python by comparing primitive
#   lists for the same structure and camera; they should match to floating-point noise.
#
#   The rotation matrices, CPK colour table, deep-gold label colour and stick geometry are all plain data.
#
# WHAT DOES NOT PORT, AND THE DECISION TO MAKE
#   redraw() is the only Tk-dependent code, and Tk's Canvas has no direct equivalent. The realistic choices:
#     - egui / eframe        immediate-mode; its Painter takes lines, circles and text almost one for one with
#                            the primitive list above. The smallest possible port -- keep painter's algorithm.
#     - wgpu / three-d       a real GPU pipeline with a depth buffer. Then DELETE the depth sort entirely and
#                            draw bonds as actual cylinder meshes, which is what the standalone OpenGL viewer
#                            does. Better looking and correct at any angle, but a rewrite of the drawing half.
#     - tiny-skia / raqote   software 2D, closest to the current behaviour without a window toolkit.
#
#   Take the first if the goal is parity; take the second only if cylinders and real lighting are wanted, and
#   accept that the painter's-algorithm code becomes dead.
#
# THINGS THAT ARE WORKAROUNDS, NOT REQUIREMENTS
#   The painter's algorithm exists only because a Canvas has no depth buffer. Half-bonds split at the midpoint
#   are a genuine stick-representation convention and should be kept either way. The four offset copies behind
#   each label fake an outline because Canvas text has no stroke; any backend with real text stroking should
#   replace those five draws with one.
#
# PERFORMANCE, IF IT EVER MATTERS
#   Every redraw currently destroys and recreates every canvas item, which is O(atoms + bonds) allocation per
#   frame. That is invisible at the 20-60 atom sizes this handles and would be the first thing to fix if it
#   were ever pointed at something large: keep the item handles and move them with coords() instead. In a GPU
#   port the question disappears -- upload the geometry once and update only the transform matrix per frame.
#
# WHAT IS DELIBERATELY ABSENT
#   No lighting, no spheres, no ribbons, no selection, no measurement. The viewer exists to read shift labels
#   against a geometry. Anything beyond that belongs in the standalone viewer, which already has it.

class AnalysisTab(ttk.Frame):
    """
    Tab 2: Gaussian LOG files in, NMR predictions out.

    The analysis engine expects to find {compound}_{conformer}.log files in the working directory and discovers
    compounds from those filenames, so this tab's job is to establish that directory, set the output switches
    from the checkboxes, and run. Selecting fewer outputs suppresses only the WRITING of the ones left out --
    shifts, energies and populations feed each other, so the computation is unchanged and every output produced
    is byte-identical to a full run.
    """

    def __init__(self, parent, app):
        super().__init__(parent, padding=10)
        self.app = app
        self.working_directory = None

        left = ttk.Frame(self)
        # The viewer has the left side to itself, and every control lives in one scrolling column on the
        # right. Sharing a grid between them is what put two sections in the same cell and left the viewer
        # half off-screen; with the split, no control can be pushed out of reach by the window size.
        left.grid(row=0, column=0, sticky='nsew', padx=(0, 8))
        right_container = ScrollableFrame(self, "Analysis settings", padding=8)
        right_container.grid(row=0, column=1, sticky='nsew')
        right = right_container.interior
        self._right_container = right_container
        self.columnconfigure(0, weight=3)
        self.columnconfigure(1, weight=2)
        self.rowconfigure(0, weight=1)

        viewer_frame = ttk.LabelFrame(left, text="Structure and predicted shifts", padding=6)
        viewer_frame.grid(row=0, column=0, sticky='nsew')
        left.columnconfigure(0, weight=1)
        left.rowconfigure(0, weight=1)
        viewer_frame.columnconfigure(0, weight=1)
        viewer_frame.rowconfigure(1, weight=1)

        controls = ttk.Frame(viewer_frame)
        controls.grid(row=0, column=0, sticky='ew', pady=(0, 4))
        # Compound first, then that compound's conformers. One flat list mixing every conformer of every
        # compound is unreadable past a couple of molecules, and it hides the fact that "lowest energy" is a
        # per-compound property rather than a property of the whole run.
        ttk.Label(controls, text="Compound:").grid(row=0, column=0, sticky='w')
        self.viewer_compound = tk.StringVar(value='')
        self.viewer_compound_box = ttk.Combobox(controls, textvariable=self.viewer_compound,
                                                state='readonly', width=24, values=[])
        self.viewer_compound_box.grid(row=0, column=1, sticky='w', padx=(4, 12))
        self.viewer_compound_box.bind('<<ComboboxSelected>>', lambda event: self._on_viewer_compound_changed())

        ttk.Label(controls, text="Conformer:").grid(row=0, column=2, sticky='w')
        self.viewer_conformer = tk.StringVar(value='')
        self.viewer_conformer_box = ttk.Combobox(controls, textvariable=self.viewer_conformer,
                                                 state='readonly', width=28, values=[])
        self.viewer_conformer_box.grid(row=0, column=3, sticky='w', padx=(4, 12))
        self.viewer_conformer_box.bind('<<ComboboxSelected>>', lambda event: self._load_viewer_structure())

        self.viewer_show_labels = tk.BooleanVar(value=True)
        ttk.Checkbutton(controls, text="Show shift labels", variable=self.viewer_show_labels,
                        command=lambda: self.viewer.set_labels_visible(self.viewer_show_labels.get())
                        ).grid(row=0, column=4, sticky='w')
        self.viewer_status = ttk.Label(controls, text="Run an analysis to view a structure.",
                                       foreground='#555555')
        self.viewer_status.grid(row=1, column=0, columnspan=5, sticky='w', pady=(4, 0))
        controls.columnconfigure(4, weight=1)

        self.viewer = StructureViewer(viewer_frame)
        self.viewer.grid(row=1, column=0, sticky='nsew')
        ttk.Label(viewer_frame,
                  text="Drag to rotate, scroll to zoom, right-drag to pan. Labels are the weighted shifts -- "
                       "the same values written to the PyMOL script.",
                  foreground='#555555').grid(row=2, column=0, sticky='w', pady=(3, 0))

        header = ttk.Frame(right)
        header.grid(row=0, column=0, sticky='ew', pady=(0, 4))
        ttk.Button(header, text="How to use this tab",
                   command=lambda: show_help_window(self, "Analysis - how to use", ANALYSIS_HELP)
                   ).pack(side='right')

        self.file_panel = FileListPanel(right, "1. Gaussian output (.log)", [("Gaussian log files", ".log")],
                                        on_change=self._on_files_changed)
        self.file_panel.grid(row=1, column=0, sticky='ew')
        right.columnconfigure(0, weight=1)

        detected = ttk.LabelFrame(right, text="2. Detected compounds", padding=8)
        detected.grid(row=2, column=0, sticky='ew', pady=(8, 0))
        self.detected_label = ttk.Label(
            detected, text="No log files loaded.", wraplength=560, justify='left')
        self.detected_label.grid(row=0, column=0, sticky='w')
        self.naming_warning = ttk.Label(detected, text="", wraplength=560, justify='left', foreground='#8a4b00')
        self.naming_warning.grid(row=1, column=0, sticky='w', pady=(4, 0))
        detected.columnconfigure(0, weight=1)

        options = ttk.LabelFrame(right, text="3. Analysis options", padding=8)
        options.grid(row=3, column=0, sticky='ew', pady=(8, 0))
        # No temperature field: it is read from each compound's own log files, where the value that was
        # actually used is recorded. Asking again here would only create a way to disagree with the
        # calculation, and the right answer can differ between compounds in one directory.
        self.temperature_summary = ttk.Label(options, text="Temperature: read from each compound's logs.",
                                             wraplength=300, foreground='#555555', justify='left')
        self.temperature_summary.grid(row=0, column=0, columnspan=3, sticky='w')
        self.enable_dedup = tk.BooleanVar(value=True)
        ttk.Checkbutton(options, text="Deduplicate conformers", variable=self.enable_dedup).grid(
            row=1, column=0, columnspan=3, sticky='w', pady=(4, 0))
        ttk.Label(options,
                  text=(f"Merges two conformers only when EVERY gate agrees: energy within "
                        f"{DEDUP_ENERGY_WINDOW:.2f} kcal/mol, symmetry-corrected RMSD within "
                        f"{DEDUP_RMSD_THRESHOLD:.2f} A with no single atom displaced more than "
                        f"{DEDUP_MAX_DEVIATION_THRESHOLD:.2f} A, and -- where frequency data exists for both -- "
                        f"vibrational spectra agreeing within {DEDUP_FREQUENCY_RMSD_THRESHOLD:.1f} cm^-1 overall "
                        f"and {DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD:.1f} cm^-1 in every single mode."),
                  wraplength=540, foreground='#555555', justify='left').grid(row=2, column=0, columnspan=3,
                                                                             sticky='w', pady=(2, 0))
        ttk.Label(options,
                  text="Switching it off weights every valid conformer, which double-counts any basin the "
                       "search reached twice.",
                  wraplength=540, foreground='#555555', justify='left').grid(row=3, column=0, columnspan=3,
                                                                             sticky='w', pady=(2, 0))
        options.columnconfigure(2, weight=1)

        # ---- output selection ----
        outputs = ttk.LabelFrame(right, text="4. Outputs to produce", padding=8)
        outputs.grid(row=4, column=0, sticky='ew', pady=(8, 0))
        outputs.columnconfigure(0, weight=1)

        selector_row = ttk.Frame(outputs)
        selector_row.grid(row=90, column=0, sticky='ew', pady=(0, 6))
        ttk.Label(selector_row, text="Outputs for:").grid(row=0, column=0, sticky='w')
        self.output_compound_var = tk.StringVar(value='(all compounds)')
        self.output_compound_box = ttk.Combobox(selector_row, textvariable=self.output_compound_var,
                                                state='readonly', width=26, values=['(all compounds)'])
        self.output_compound_box.grid(row=0, column=1, sticky='w', padx=(4, 0))
        self.output_compound_box.bind('<<ComboboxSelected>>', lambda event: self._on_output_compound_changed())
        selector_row.columnconfigure(1, weight=1)

        ttk.Label(outputs, text="Unticked outputs are simply not written. The calculation behind them still "
                                "runs, because the shifts, energies and populations depend on each other, so "
                                "everything you do keep is identical to a full run.",
                  wraplength=380, foreground='#555555', justify='left').grid(row=0, column=0, sticky='w',
                                                                             pady=(0, 8))

        ttk.Label(outputs, text="Save results to:").grid(row=98, column=0, sticky='w', pady=(10, 0))
        self.results_var = tk.StringVar(value='')
        results_row = ttk.Frame(outputs)
        results_row.grid(row=99, column=0, sticky='ew')
        ttk.Entry(results_row, textvariable=self.results_var).grid(row=0, column=0, sticky='ew')
        ttk.Button(results_row, text="Choose...", command=self._choose_results).grid(row=0, column=1,
                                                                                     padx=(4, 0))
        results_row.columnconfigure(0, weight=1)
        ttk.Label(outputs,
                  text="Leave blank to keep the results beside the log files, which is where the analysis "
                       "writes them. Give a folder and they are copied there as well.",
                  wraplength=380, foreground='#555555', justify='left').grid(row=100, column=0, sticky='w',
                                                                             pady=(2, 0))

        self.output_vars = {}
        # Output choices are stored per compound, the same way the job-setup tab stores its settings: one
        # compound may only need shifts while another needs the full distance and NOE set.
        self.per_compound_outputs = {}
        self._current_output_compound = None
        output_options = [
            ('chemical_shifts', "Chemical shifts (unweighted + weighted)"),
            ('coupling_constants', "Coupling constants"),
            ('conformer_sdf', "Conformer SDF files"),
            ('distances', "Atomic distances"),
            ('noe_intensities', "NOE intensities"),
            ('noe_multipliers', "NOE equivalence multipliers"),
            ('frequencies', "Vibrational frequency listings"),
            ('pymol_script', "PyMOL labelling script"),
            ('dedup_report', "Deduplication report"),
            ('wiberg_report', "Wiberg bond index report (diagnostic)"),
        ]
        holder = ttk.Frame(outputs)
        holder.grid(row=1, column=0, sticky='nsew')
        for index, (key, label) in enumerate(output_options):
            variable = tk.BooleanVar(value=True)
            self.output_vars[key] = variable
            ttk.Checkbutton(holder, text=label, variable=variable).grid(row=index, column=0, sticky='w')

        buttons = ttk.Frame(outputs)
        buttons.grid(row=2, column=0, sticky='ew', pady=(8, 0))
        ttk.Button(buttons, text="Select all", command=lambda: self._set_all(True)).grid(row=0, column=0, sticky='ew')
        ttk.Button(buttons, text="Select none", command=lambda: self._set_all(False)).grid(row=0, column=1,
                                                                                           sticky='ew', padx=(6, 0))
        buttons.columnconfigure(0, weight=1)
        buttons.columnconfigure(1, weight=1)
        outputs.columnconfigure(0, weight=1)
        outputs.rowconfigure(1, weight=1)

        self.run_button = ttk.Button(right, text="Run analysis", command=self.run_analysis, state='disabled')
        self.run_button.grid(row=5, column=0, sticky='ew', pady=(10, 0))

        if not NUMPY_AVAILABLE:
            self.run_button.configure(state='disabled')
            ttk.Label(right, text="numpy is not installed in this Python, so the analysis engine cannot run.",
                      wraplength=380, foreground='#8a2b00').grid(row=2, column=0, sticky='w', pady=(6, 0))

    def _set_all(self, value):
        for variable in self.output_vars.values():
            variable.set(value)

    def _choose_results(self):
        folder = filedialog.askdirectory(title="Where should the analysis results be saved?",
                                         initialdir=self.results_var.get() or self.working_directory
                                         or os.getcwd())
        if folder:
            self.results_var.set(folder)

    def _capture_outputs(self):
        return {key: variable.get() for key, variable in self.output_vars.items()}

    def _on_output_compound_changed(self):
        """Save the selections for the compound being left, then load those for the one chosen."""
        if self._current_output_compound is not None:
            self.per_compound_outputs[self._current_output_compound] = self._capture_outputs()
        chosen = self.output_compound_var.get()
        self._current_output_compound = chosen
        stored = self.per_compound_outputs.get(chosen)
        if stored:
            for key, value in stored.items():
                if key in self.output_vars:
                    self.output_vars[key].set(value)

    def outputs_for(self, compound):
        """
        The output selection that applies to one compound.

        Its own selection when it has one, otherwise whatever '(all compounds)' is set to -- so the common
        case of wanting the same thing everywhere needs no per-compound work at all.
        """
        if self._current_output_compound is not None:
            self.per_compound_outputs[self._current_output_compound] = self._capture_outputs()
        return (self.per_compound_outputs.get(compound)
                or self.per_compound_outputs.get('(all compounds)')
                or self._capture_outputs())

    def _on_files_changed(self, paths):
        """
        Group the loaded logs by compound using the {compound}_{conformer}.log convention the engine relies on,
        and warn about any file that does not match it -- such a file is invisible to the analysis rather than
        being an error, which is easy to miss when a run silently covers fewer conformers than expected.
        """
        if not paths:
            self.detected_label.configure(text="No log files loaded.")
            self.naming_warning.configure(text="")
            self.run_button.configure(state='disabled')
            self.working_directory = None
            return

        compounds = defaultdict(list)
        unmatched = []
        directories = set()
        for path in paths:
            directories.add(os.path.dirname(path))
            name = os.path.basename(path)
            match = re.match(r"^(.+)_(\d+)\.log$", name)
            if not match:
                unmatched.append(name)
                continue
            compound = match.group(1)
            if compound.endswith('-csulfur'):
                compound = compound[:-8]
            elif compound.endswith('-chalogen'):
                compound = compound[:-9]
            compounds[compound].append(int(match.group(2)))

        summary = "\n".join(
            f"  {name}: {len(numbers)} conformer(s)  (numbers {min(numbers)}-{max(numbers)})"
            for name, numbers in sorted(compounds.items()))
        self.detected_label.configure(
            text=(f"{len(compounds)} compound(s) across {len(paths)} log file(s):\n{summary}"
                  if compounds else "No files matched the {compound}_{conformer}.log naming convention."))

        warnings = []
        if unmatched:
            shown = ", ".join(unmatched[:4]) + (f", and {len(unmatched) - 4} more" if len(unmatched) > 4 else "")
            warnings.append(f"Ignored (name does not match {{compound}}_{{conformer}}.log): {shown}")
        if len(directories) > 1:
            warnings.append(
                f"The selected logs span {len(directories)} directories. The analysis runs in one working "
                f"directory at a time and will use the one holding the most files; logs elsewhere will be "
                f"skipped. Load one directory at a time to analyse them all.")
        self.naming_warning.configure(text="\n".join(warnings))

        existing = list(self.output_compound_box.cget('values') or [])
        names_for_outputs = ['(all compounds)'] + sorted(compounds)
        self.output_compound_box.configure(values=names_for_outputs)
        if self.output_compound_var.get() not in names_for_outputs:
            self.output_compound_var.set('(all compounds)')
            self._current_output_compound = None
        self.per_compound_outputs = {k: v for k, v in self.per_compound_outputs.items()
                                     if k in names_for_outputs}

        self._compound_paths = {name: [p for p in paths
                                       if os.path.basename(p).startswith(name + '_')]
                                for name in compounds}
        counts = defaultdict(int)
        for path in paths:
            counts[os.path.dirname(path)] += 1
        self.working_directory = max(counts, key=counts.get) if counts else None
        self.run_button.configure(state='normal' if compounds and NUMPY_AVAILABLE else 'disabled')


    # ---- structure viewer ----

    def _populate_viewer(self, directory):
        """
        After an analysis, offer its conformers and open the lowest-energy one.

        The SDF files the analysis writes carry the Gibbs free energy in their header, so the ordering comes
        from the same numbers that drove the Boltzmann weighting rather than from filename order -- the
        lowest-energy conformer is the one the ensemble is most weighted toward, which makes it the useful
        default to look at.
        """
        candidates = []
        for compound in sorted(os.listdir(directory)):
            sdf_directory = os.path.join(directory, compound, "Conformer SDF Files")
            if not os.path.isdir(sdf_directory):
                continue
            pymol_script = os.path.join(directory, compound, f"{compound}_chemical_shifts.pml")
            if not os.path.exists(pymol_script):
                matches = [n for n in os.listdir(os.path.join(directory, compound)) if n.endswith('.pml')]
                pymol_script = os.path.join(directory, compound, matches[0]) if matches else None
            for name in sorted(os.listdir(sdf_directory)):
                if not name.lower().endswith('.sdf'):
                    continue
                path = os.path.join(sdf_directory, name)
                energy = None
                try:
                    with open(path, 'r', errors='replace') as handle:
                        header = [next(handle, '') for _ in range(3)]
                    match = re.search(r'Total Gibbs Free Energy \(Hartrees\):\s*(-?\d+\.?\d*)',
                                      ''.join(header))
                    if match:
                        energy = float(match.group(1))
                except (OSError, StopIteration, ValueError):
                    pass
                candidates.append({'compound': compound, 'path': path, 'energy': energy,
                                   'pymol': pymol_script, 'name': os.path.splitext(name)[0]})

        if not candidates:
            # Name the cause rather than just the symptom: the usual reason is that the output was switched
            # off on purpose, which otherwise reads as a malfunction
            if not self.output_vars.get('conformer_sdf', tk.BooleanVar(value=True)).get():
                message = ("No structure to show: 'Conformer SDF files' was unticked for this run, and the "
                           "viewer reads those files. Re-run with it enabled to view structures.")
            else:
                message = "No conformer SDF files were produced, so there is nothing to show."
            self.viewer_status.configure(text=message)
            self.viewer_compound_box.configure(values=[])
            self.viewer_conformer_box.configure(values=[])
            self.viewer.clear()
            return

        # Grouped by compound, and within each compound ordered by Gibbs free energy so the lowest sits first.
        # Conformers whose energy could not be read follow, since they cannot be placed in that ordering.
        grouped = defaultdict(list)
        for entry in candidates:
            grouped[entry['compound']].append(entry)
        self._viewer_by_compound = {}
        for compound, entries in grouped.items():
            with_energy = sorted((e for e in entries if e['energy'] is not None), key=lambda e: e['energy'])
            without = [e for e in entries if e['energy'] is None]
            ordered = with_energy + without
            for position, entry in enumerate(ordered):
                # The lowest-energy conformer is marked in the list itself, so which one is being shown is
                # visible without reading the status line
                suffix = "   (lowest energy)" if position == 0 and entry['energy'] is not None else ""
                entry['label'] = entry['name'] + suffix
            self._viewer_by_compound[compound] = ordered

        compounds = sorted(self._viewer_by_compound)
        self.viewer_compound_box.configure(values=compounds)
        self.viewer_compound.set(compounds[0])
        self._on_viewer_compound_changed()

    def _on_viewer_compound_changed(self):
        """Repopulate the conformer list for the chosen compound and open its lowest-energy structure."""
        entries = getattr(self, '_viewer_by_compound', {}).get(self.viewer_compound.get()) or []
        labels = [entry['label'] for entry in entries]
        try:
            self.viewer_conformer_box.configure(values=labels)
        except tk.TclError:
            pass
        if not labels:
            self.viewer.clear()
            self.viewer_status.configure(text="No conformers available for this compound.")
            return
        self.viewer_conformer.set(labels[0])
        self._load_viewer_structure()

    def _load_viewer_structure(self):
        """Load the selected conformer and overlay the shift labels from its PyMOL script."""
        entries = getattr(self, '_viewer_by_compound', {}).get(self.viewer_compound.get()) or []
        chosen = self.viewer_conformer.get()
        entry = next((item for item in entries if item['label'] == chosen), None)
        if not entry:
            return
        try:
            elements, coordinates, connectivity, bond_orders = cluster_parse_sdf(entry['path'])
        except Exception as error:
            self.viewer_status.configure(text=f"Could not read that structure ({error}).")
            self.viewer.clear()
            return

        bonds = set()
        for atom, neighbours in (connectivity or {}).items():
            for neighbour in neighbours:
                bonds.add((min(atom, neighbour), max(atom, neighbour)))

        labels = parse_pymol_label_file(entry['pymol']) if entry.get('pymol') else {}
        self.viewer.load_structure(elements, coordinates, sorted(bonds), labels, bond_orders)
        self.viewer.set_labels_visible(self.viewer_show_labels.get())

        position = entries.index(entry) + 1
        energy_note = ("lowest energy" if entry['energy'] is not None and position == 1
                       else f"#{position} of {len(entries)} by energy" if entry['energy'] is not None
                       else "energy not recorded")
        self.viewer_status.configure(
            text=f"{entry['compound']}: showing {entry['name']} ({energy_note}), "
                 f"{len(entries)} conformer(s) available.")
        if not labels:
            if not self.output_vars.get('pymol_script', tk.BooleanVar(value=True)).get():
                self.viewer_status.configure(
                    text="Structure shown without labels: 'PyMOL labelling script' was unticked for this run, "
                         "and the shift labels are read from that file.")
            else:
                self.viewer_status.configure(
                    text="Structure shown without labels: no PyMOL shift file was found for this compound.")

    def run_analysis(self):
        if not self.working_directory:
            return
        # Temperature comes from each compound's own logs, so nothing to validate here
        temperature = None
        compounds = sorted(getattr(self, '_compound_paths', {}) or {})
        selected_by_compound = {name: self.outputs_for(name) for name in compounds}
        selected = self.outputs_for('(all compounds)')
        if not any(selected.values()) and not any(any(v.values()) for v in selected_by_compound.values()):
            if not messagebox.askyesno(
                    "No outputs selected",
                    "Every output is unticked, so the analysis will run and write nothing. Continue anyway?"):
                return
        # Checked before the run: logs without scaling factors in their titles cannot be scaled correctly,
        # and finding that out partway through wastes the wait
        missing = check_logs_carry_scaling_factors(getattr(self, '_compound_paths', {}))
        if missing:
            listed = ", ".join(missing[:6]) + (f", and {len(missing) - 6} more" if len(missing) > 6 else "")
            if not messagebox.askyesno(
                    "Scaling factors missing from job titles",
                    f"These compounds' logs do not record their scaling factors in the job titles:\n\n"
                    f"{listed}\n\n"
                    f"That means they were produced before the factors travelled there. Their carbon and "
                    f"proton shifts cannot be scaled correctly, and the analysis will stop when it reaches "
                    f"them.\n\nRe-run the job setup for these compounds to record the factors.\n\n"
                    f"Continue anyway?"):
                return

        problems = check_output_location(self.working_directory)
        if problems:
            blocking = [p for p in problems if 'Low disk space' not in p]
            if blocking:
                messagebox.showerror("Output folder problem",
                                     "The analysis writes its results beside the log files.\n\n"
                                     + "\n".join(blocking))
                return
            if not messagebox.askyesno("Low disk space", "\n".join(problems) + "\n\nContinue anyway?"):
                return

        self.app.run_worker(self._analysis_worker,
                            (self.working_directory, selected, temperature, self.enable_dedup.get(),
                             self.results_var.get().strip() or None, selected_by_compound, compounds),
                            "Running NMR analysis")

    def _analysis_worker(self, directory, selected, temperature, enable_dedup, results_directory=None,
                         selected_by_compound=None, only_compounds=None):
        """
        Run the analysis engine against a directory of Gaussian logs.

        The engine discovers compounds by listing the current working directory, so this changes into the target
        directory for the duration and restores the previous one afterwards -- including when the run raises, so
        a failed analysis does not leave the rest of the application pointed somewhere unexpected.
        """
        previous_directory = os.getcwd()
        previous_switches = dict(NGP_OUTPUT_SWITCHES)
        previous_dedup = ENABLE_CONFORMER_DEDUPLICATION
        try:
            os.chdir(directory)
            NGP_OUTPUT_SWITCHES.update(selected)
            # Applied per compound as the analysis reaches each one, so two compounds in one directory can
            # produce different output sets from a single run
            if selected_by_compound:
                globals()['NGP_OUTPUT_SWITCHES_BY_COMPOUND'] = dict(selected_by_compound)
            # Only the compounds whose logs were actually loaded
            globals()['NGP_RESTRICT_TO_COMPOUNDS'] = set(only_compounds or [])
            globals()['ENABLE_CONFORMER_DEDUPLICATION'] = bool(enable_dedup)

            skipped = [key for key, value in selected.items() if not value]
            final_directory = directory   # where the results end up, which is what the viewer must read
            print(f"Log directory: {directory}")
            if only_compounds:
                print(f"Compounds selected: {', '.join(sorted(only_compounds))}")
            print("Temperature: read from each compound's log files")
            print(f"Deduplication: {'on' if enable_dedup else 'off'}")
            if results_directory:
                print(f"Results will be copied to: {results_directory}")
            if skipped:
                print(f"Outputs suppressed: {', '.join(sorted(skipped))}")
            print("")

            # run_ngp_analysis is the analysis entry point. It was previously called as main(), which the
            # interface's own main() shadowed -- so the analysis worker opened a SECOND application window and
            # ran mainloop() on a worker thread, producing the "main thread is not in main loop" error and no
            # results at all. The two are named apart now so neither can stand in for the other.
            run_ngp_analysis()

            # The analysis writes its result folders beside the logs. When a destination was given they are
            # MOVED there, not copied: leaving a second set behind means two copies that drift apart the next
            # time either is regenerated, and no way to tell which is current.
            #
            # Only the folders this run produced are touched, matched against the compounds analysed, so a
            # folder belonging to some earlier run of a different compound is left where it is.
            if results_directory and os.path.abspath(results_directory) != os.path.abspath(directory):
                moved = 0
                produced = set(only_compounds or [])
                try:
                    os.makedirs(results_directory, exist_ok=True)
                    for name in sorted(os.listdir(directory)):
                        source = os.path.join(directory, name)
                        if not os.path.isdir(source) or name.startswith('.'):
                            continue
                        if produced and name not in produced:
                            continue
                        destination = os.path.join(results_directory, name)
                        if os.path.exists(destination):
                            shutil.rmtree(destination, ignore_errors=True)
                        shutil.move(source, destination)
                        moved += 1
                    print(f"Moved {moved} result folder(s) to {results_directory}")
                    if moved:
                        # The viewer reads the result folders, so it has to be told where they ended up.
                        # Returning the log directory after moving them elsewhere is why no structure loaded.
                        final_directory = results_directory
                except OSError as error:
                    print(f"  Could not move the results ({error}); they remain beside the log files.")

            print("\nAnalysis complete.")
            return ('analysis_done', final_directory)
        finally:
            os.chdir(previous_directory)
            NGP_OUTPUT_SWITCHES.clear()
            NGP_OUTPUT_SWITCHES.update(previous_switches)
            globals()['NGP_OUTPUT_SWITCHES_BY_COMPOUND'] = {}
            globals()['NGP_RESTRICT_TO_COMPOUNDS'] = set()
            # Left set by the last compound processed. Anything asking about output switches afterwards would
            # otherwise resolve against that compound's overrides rather than the shared selection.
            globals()['NGP_ACTIVE_COMPOUND'] = None
            globals()['ENABLE_CONFORMER_DEDUPLICATION'] = previous_dedup




class WorkbenchApp(tk.Tk):
    """
    The main window: a tabbed container plus a shared log pane and a single worker thread.

    Only one job runs at a time by design. These are CPU- and disk-heavy operations over the same directories,
    and letting two of them overlap would interleave their console output into something unreadable while
    competing for the same cores -- so the Run buttons disable while work is in flight rather than queueing.
    """

    def __init__(self):
        super().__init__()
        self.title("NMR Gaussian Workbench 1.1.0")
        self.geometry("1180x820")
        self.minsize(980, 700)

        self.message_queue = queue.Queue()
        self.worker = None
        self.cancel_requested = threading.Event()

        notebook = ttk.Notebook(self)
        notebook.grid(row=0, column=0, sticky='nsew', padx=8, pady=(8, 4))
        self.job_tab = JobSetupTab(notebook, self)
        notebook.add(self.job_tab, text="  1. Job setup  (SDF to Gaussian)  ")
        self.analysis_tab = AnalysisTab(notebook, self)
        notebook.add(self.analysis_tab, text="  2. Analysis  (LOG to NMR)  ")

        log_frame = ttk.LabelFrame(self, text="Log", padding=6)
        log_frame.grid(row=1, column=0, sticky='nsew', padx=8, pady=(0, 4))
        self.log_widget = scrolledtext.ScrolledText(log_frame, height=13, wrap='word', state='disabled',
                                                    font=('Consolas', 9))
        self.log_widget.pack(fill='both', expand=True)

        status_frame = ttk.Frame(self)
        status_frame.grid(row=2, column=0, sticky='ew', padx=8, pady=(0, 8))
        self.status_label = ttk.Label(status_frame, text="Ready.")
        self.status_label.pack(side='left')
        self.progress = ttk.Progressbar(status_frame, mode='indeterminate', length=180)
        self.progress.pack(side='right', padx=(8, 0))
        self.cancel_button = ttk.Button(status_frame, text="Cancel", command=self.request_cancel, state='disabled')
        self.cancel_button.pack(side='right')
        ttk.Button(status_frame, text="Save log...", command=self.save_log).pack(side='right', padx=(0, 8))
        ttk.Button(status_frame, text="Clear log", command=self.clear_log).pack(side='right', padx=(0, 8))

        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=3)
        self.rowconfigure(1, weight=2)

        if not NUMPY_AVAILABLE:
            self.log("WARNING: numpy is not installed in this Python. The analysis tab cannot run without it.")
        if not SCIPY_AVAILABLE:
            self.log("NOTE: SciPy is not installed, so clustering is unavailable. Everything else works normally.")
        if WORKBENCH_CONFIG_PATH:
            self.log(f"Configuration: {WORKBENCH_CONFIG_PATH}")
            self.log(f"  {len(WORKBENCH_METHODS)} method(s), {len(WORKBENCH_MACHINES)} machine profile(s). "
                     f"Edit that file to add or change either, then restart.")
        for problem in WORKBENCH_CONFIG_PROBLEMS:
            self.log(f"  NOTE: {problem}")
        self.log("Ready. Add conformer SDF files on tab 1, or Gaussian LOG files on tab 2.")

        # One wheel binding for the whole application, routed to whichever scroll area the pointer is inside.
        # bind_all reaches every widget including ones created later, which per-widget binding could not.
        for sequence in ('<MouseWheel>', '<Button-4>', '<Button-5>'):
            self.bind_all(sequence, route_wheel_to_scroll_area)

        self.after(80, self._drain_queue)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---- logging ----
    def log(self, text):
        self.log_widget.configure(state='normal')
        self.log_widget.insert(tk.END, text + '\n')
        self.log_widget.see(tk.END)
        self.log_widget.configure(state='disabled')

    def clear_log(self):
        self.log_widget.configure(state='normal')
        self.log_widget.delete('1.0', tk.END)
        self.log_widget.configure(state='disabled')

    def save_log(self):
        path = filedialog.asksaveasfilename(title="Save log", defaultextension=".txt",
                                            filetypes=[("Text files", "*.txt")])
        if not path:
            return
        try:
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write(self.log_widget.get('1.0', tk.END))
            self.log(f"Log saved to {path}")
        except OSError as error:
            messagebox.showerror("Could not save", str(error))

    # ---- worker plumbing ----
    def run_worker(self, function, arguments, description):
        """
        Start a background job. Widgets are never touched from the worker; it prints, and the redirector routes
        that through the queue to the main thread (see ConsoleRedirector for why).
        """
        if self.worker and self.worker.is_alive():
            messagebox.showinfo("Busy", "A job is already running. Wait for it to finish or cancel it first.")
            return
        self.cancel_requested.clear()
        self.status_label.configure(text=description + "...")
        self.progress.start(12)
        self.cancel_button.configure(state='normal')
        self._set_run_buttons('disabled')
        self.log("")
        self.log("=" * 96)
        self.log(description)
        self.log("=" * 96)

        def target():
            redirector = ConsoleRedirector(self.message_queue)
            original_stdout, original_stderr = sys.stdout, sys.stderr
            sys.stdout = sys.stderr = redirector
            try:
                result = function(*arguments)
                redirector.flush()
                self.message_queue.put(('done', result))
            except Exception:
                redirector.flush()
                self.message_queue.put(('error', traceback.format_exc()))
            finally:
                sys.stdout, sys.stderr = original_stdout, original_stderr

        self.worker = threading.Thread(target=target, daemon=True)
        self.worker.start()

    def request_cancel(self):
        """
        Signal a cancel. The embedded scripts have no cancellation points of their own, so this cannot interrupt
        a job mid-operation -- it is honoured between compounds. Saying so plainly is better than a button that
        appears to do nothing.
        """
        self.cancel_requested.set()
        self.log("Cancel requested. The current compound will finish first; no further compounds will start.")
        self.cancel_button.configure(state='disabled')

    def _set_run_buttons(self, state):
        for tab in (self.job_tab, self.analysis_tab):
            button = getattr(tab, 'run_button', None)
            if button is not None:
                try:
                    button.configure(state=state)
                except tk.TclError:
                    pass

    def _drain_queue(self):
        try:
            while True:
                kind, payload = self.message_queue.get_nowait()
                if kind == 'log':
                    self.log(payload)
                elif kind == 'done':
                    self._finish("Done.")
                    self._handle_result(payload)
                elif kind == 'error':
                    self._finish("Failed.")
                    self.log(payload)
                    messagebox.showerror("Job failed", "The job stopped with an error. See the log for details.")
        except queue.Empty:
            pass
        self.after(80, self._drain_queue)

    def _handle_result(self, result):
        """
        React to a finished job. Splitting no longer reports back separately: it happens inside the job-setup
        run, so the file list the user assembled stays exactly as they left it rather than being rewritten
        underneath them partway through a pipeline.
        """
        if not isinstance(result, tuple) or len(result) != 2:
            return
        kind, payload = result
        if kind == 'pipeline_done':
            self.log(f"{len(payload)} Gaussian input file(s) generated.")
        elif kind == 'analysis_done':
            self.log(f"Analysis finished in {payload}")
            try:
                self.analysis_tab._populate_viewer(payload)
            except Exception as error:
                self.log(f"  (structure viewer unavailable: {error})")

    def _finish(self, status):
        self.progress.stop()
        self.status_label.configure(text=status)
        self.cancel_button.configure(state='disabled')
        self._set_run_buttons('normal')

    def _on_close(self):
        if self.worker and self.worker.is_alive():
            if not messagebox.askyesno("Quit", "A job is still running. Quit anyway?"):
                return
        self.destroy()


# ==================================================================================================================
# SELF TEST
# ==================================================================================================================
# Run with:  python nmr_workbench.pyw --self-test
#
# WHY THIS EXISTS. Almost every defect found in this program during development compiled cleanly and failed only
# when the code actually ran, and most produced WRONG NUMBERS rather than errors: clustering that silently did
# not reduce, scaling constants inherited from the wrong calculation, shifts averaged over the wrong equivalence
# classes, an analysis half that skipped every compound. Nothing about a wrong chemical shift announces itself in
# the output, so reading the code is not enough and neither is checking that it imports.
#
# The checks below are all on pure logic and need no Gaussian output, no SciPy and no display. They cover the
# round trips (what the job setup writes, the analysis must read back), the invariants (an alignment cannot
# change a bond length; a rotation matrix has determinant +1), and the agreements (the preview must equal the
# file; a configuration method must equal the built-in it replaced).
#
# Everything is written to a timestamped report file as well as the console, so the whole run can be sent to
# someone else to read.

SELF_TEST_REPORT_NAME = "nmr_workbench_selftest.txt"


class SelfTestReport:
    """Collects results and writes both a console line and a detailed report."""

    def __init__(self):
        self.lines = []
        self.passed = 0
        self.failed = 0
        self.section = None

    def begin(self, title):
        self.section = title
        self.lines.append("")
        self.lines.append("=" * 110)
        self.lines.append(title)
        self.lines.append("=" * 110)

    def detail(self, text):
        """Context that is not itself a pass or fail -- inputs, intermediate values, what was compared."""
        for line in str(text).split('\n'):
            self.lines.append("      " + line)

    def check(self, description, condition, expected=None, actual=None):
        ok = bool(condition)
        if ok:
            self.passed += 1
        else:
            self.failed += 1
        self.lines.append(f"  [{'PASS' if ok else 'FAIL'}] {description}")
        if expected is not None or actual is not None:
            self.lines.append(f"         expected: {expected!r}")
            self.lines.append(f"         actual  : {actual!r}")
        print(f"  [{'PASS' if ok else 'FAIL'}] {description}")
        if not ok and (expected is not None or actual is not None):
            print(f"         expected: {expected!r}")
            print(f"         actual  : {actual!r}")
        return ok

    def error(self, description, exception):
        self.failed += 1
        self.lines.append(f"  [ERROR] {description}")
        self.lines.append("         " + traceback.format_exc().replace('\n', '\n         '))
        print(f"  [ERROR] {description}: {type(exception).__name__}: {exception}")

    def write(self, path):
        header = [
            "NMR Gaussian Workbench -- self test report",
            "=" * 110,
            f"Generated : {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"Python    : {sys.version.split()[0]} on {sys.platform}",
            f"numpy     : {'available' if NUMPY_AVAILABLE else 'MISSING'}",
            f"SciPy     : {'available' if SCIPY_AVAILABLE else 'not installed (clustering unavailable)'}",
            f"Config    : {WORKBENCH_CONFIG_PATH or '(not loaded)'}",
            f"Methods   : {', '.join(sorted(WORKBENCH_METHODS)) or '(none)'}",
            f"Machines  : {', '.join(sorted(WORKBENCH_MACHINES)) or '(none)'}",
            "",
            f"RESULT    : {self.passed} passed, {self.failed} failed",
        ]
        try:
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write('\n'.join(header + self.lines) + '\n')
            return True
        except OSError as error:
            print(f"Could not write the report to {path}: {error}")
            return False


def _self_test_molecule(kind):
    """Small hand-built molecules with known correct answers, so a failure points at the code not the input."""
    if kind == 'benzene':
        elements = ['C'] * 6 + ['H'] * 6
        coordinates = []
        for index in range(6):
            angle = 2 * math.pi * index / 6
            coordinates.append((1.39 * math.cos(angle), 1.39 * math.sin(angle), 0.0))
        for index in range(6):
            angle = 2 * math.pi * index / 6
            coordinates.append((2.49 * math.cos(angle), 2.49 * math.sin(angle), 0.0))
        bonds = {}
        for index in range(6):
            bonds[(index + 1, (index + 1) % 6 + 1)] = 1.5
            bonds[(index + 1, index + 7)] = 1.0
        return elements, coordinates, bonds
    if kind == 'ethanol':
        elements = ['C', 'C', 'O', 'H', 'H', 'H', 'H', 'H', 'H']
        coordinates = [(0, 0, 0), (1.5, 0, 0), (2.1, 1.2, 0), (-0.4, 1.0, 0), (-0.4, -0.5, 0.87),
                       (-0.4, -0.5, -0.87), (1.9, -0.5, 0.89), (1.9, -0.5, -0.89), (3.0, 1.1, 0)]
        bonds = {(1, 2): 1.0, (2, 3): 1.0, (1, 4): 1.0, (1, 5): 1.0, (1, 6): 1.0,
                 (2, 7): 1.0, (2, 8): 1.0, (3, 9): 1.0}
        return elements, coordinates, bonds
    raise ValueError(kind)


def run_self_test(output_directory=None):
    """Run every check and write the report. Returns the number of failures."""
    global WORKBENCH_METHODS, WORKBENCH_MACHINES, WORKBENCH_CONFIG_PATH, WORKBENCH_CONFIG_PROBLEMS

    report = SelfTestReport()
    workspace = tempfile.mkdtemp(prefix='workbench_selftest_')

    WORKBENCH_CONFIG_PATH = os.path.join(workspace, CONFIG_FILENAME)
    WORKBENCH_METHODS, WORKBENCH_MACHINES, WORKBENCH_CONFIG_PROBLEMS = \
        load_workbench_config(WORKBENCH_CONFIG_PATH)

    print("NMR Gaussian Workbench -- self test")
    print("=" * 70)

    # ---------------------------------------------------------------- configuration
    report.begin("1. CONFIGURATION")
    report.detail(f"config written to {WORKBENCH_CONFIG_PATH}")
    report.detail(f"methods loaded: {sorted(WORKBENCH_METHODS)}")
    report.detail(f"machines loaded: {sorted(WORKBENCH_MACHINES)}")
    report.check("configuration file is created when absent", os.path.exists(WORKBENCH_CONFIG_PATH))
    report.check("at least one method is defined", len(WORKBENCH_METHODS) >= 1,
                 ">=1", len(WORKBENCH_METHODS))
    report.check("at least one machine is defined", len(WORKBENCH_MACHINES) >= 1,
                 ">=1", len(WORKBENCH_MACHINES))
    for problem in WORKBENCH_CONFIG_PROBLEMS:
        report.detail(f"note: {problem}")

    # a method added by hand must behave exactly like a built-in one
    try:
        with open(WORKBENCH_CONFIG_PATH, 'a', encoding='utf-8') as handle:
            handle.write("\n[method:zz]\nlabel = zz test\nopt_basis = 6-31g(d)\ncarbon_basis = def2tzvp\n"
                         "proton_basis = def2tzvp\ncarbon_slope = -1.0\ncarbon_intercept = 180.0\n"
                         "proton_slope = -1.1\nproton_intercept = 31.0\n"
                         "opt_route = # opt freq=noraman{temperature} m062x/{opt_basis} geom=connectivity pop=nboread\n"
                         "carbon_route = # nmr=giao m062x/{carbon_basis} geom=check guess=read\n"
                         "proton_route = # nmr=giao m062x/{proton_basis} geom=check guess=read\n")
        WORKBENCH_METHODS, WORKBENCH_MACHINES, _ = load_workbench_config(WORKBENCH_CONFIG_PATH)
        report.check("a hand-added method appears without code changes", 'zz' in WORKBENCH_METHODS)
        added = get_method_parameters('zz', False, False, False, 298.0)
        report.detail(f"zz opt route: {added['opt'] if added else None}")
        report.check("a hand-added method builds its routes", bool(added and 'm062x' in added['opt']))
        report.check("a hand-added method carries its scaling factors",
                     resolve_scaling_factors('zz', 'carbon') == ('-1.0', '180.0'),
                     ('-1.0', '180.0'), resolve_scaling_factors('zz', 'carbon'))
        with_iodine = build_basis_set_block({'C', 'H', 'I'}, 'zz', 'opt')
        report.check("a hand-added method produces a gen block for iodine",
                     'I' in with_iodine and len(with_iodine.splitlines()) > 10)
        report.check("an undefined method reports rather than raising",
                     get_method_parameters('nosuch', False, False, False, 298.0) is None)
    except Exception as error:
        report.error("configuration-driven method", error)

    # ---------------------------------------------------------------- route guarantees
    report.begin("2. OPTIMIZATION ROUTE GUARANTEES")
    try:
        for label, route, must_add in (
                ("bare route", "# b3lyp/6-31g(d)", True),
                ("already complete",
                 "# opt freq=noraman b3lyp/6-31g(d) geom=connectivity pop=nboread temperature=298.0", False),
                ("grouped pop=(nboread,nbo)",
                 "# opt freq b3lyp/6-31g(d) geom=(connectivity,check) pop=(nboread,nbo) temperature=298.0",
                 False)):
            result, added = enforce_optimization_keywords(route, 298.0)
            report.detail(f"{label}\n  in : {route}\n  out: {result}\n  added: {added}")
            for keyword in ('opt', 'freq', 'connectivity', 'nboread'):
                report.check(f"{label}: '{keyword}' present after enforcement", keyword in result.lower())
            if not must_add:
                report.check(f"{label}: nothing added to an already-complete route", not added, [], added)
            report.check(f"{label}: no duplicated keyword", result.lower().count('pop=') <= 1,
                         "<=1 'pop='", result.lower().count('pop='))
    except Exception as error:
        report.error("optimization guarantees", error)

    # ---------------------------------------------------------------- title round trips
    report.begin("3. JOB TITLE ROUND TRIPS  (what job setup writes, analysis must read back)")
    try:
        charged = serialize_connectivity_and_charge({1: ['2 1.0']}, {3: -1, 7: 1})
        neutral = serialize_connectivity_and_charge({1: ['2 1.0']}, {})
        report.detail(f"charged molecule block: {charged!r}\nneutral molecule block: {neutral!r}")
        report.check("charge block lists only charged atoms", charged == "[3:-1|7:1]", "[3:-1|7:1]", charged)
        report.check("neutral molecule produces no charge block", neutral == "", "", neutral)

        halogen_title = "x_1_carbon hal{2:s:-1.03,i:192.0|5:s:-1.02,i:177.1}"
        parsed = parse_halogen_scaling_from_title(halogen_title)
        report.detail(f"halogen title: {halogen_title}\nparsed back  : {parsed}")
        report.check("per-atom halogen factors round trip",
                     parsed == {2: (-1.03, 192.0), 5: (-1.02, 177.1)},
                     {2: (-1.03, 192.0), 5: (-1.02, 177.1)}, parsed)
        report.check("a bare-brace block is not mistaken for halogen factors",
                     parse_halogen_scaling_from_title("x {2:s:-1.0,i:1.0}") == {}, {},
                     parse_halogen_scaling_from_title("x {2:s:-1.0,i:1.0}"))

        for job_type, expected in (('fluorine', (FLUORINE_SCALING['slope'], FLUORINE_SCALING['intercept'])),
                                   ('nitrogen', (NITROGEN_SCALING['slope'], NITROGEN_SCALING['intercept'])),
                                   ('csulfur', (SULFUR_SCALING_BY_METHOD['1']['slope'],
                                                SULFUR_SCALING_BY_METHOD['1']['intercept'])),
                                   ('cc', (None, None))):
            got = resolve_scaling_factors('1', job_type)
            report.detail(f"{job_type}: {got}")
            report.check(f"{job_type} scaling resolves to its own constants", got == expected, expected, got)

        report.check("csulfur does NOT inherit the method's carbon factors",
                     resolve_scaling_factors('1', 'csulfur') != resolve_scaling_factors('1', 'carbon'))
    except Exception as error:
        report.error("title round trips", error)

    # ---------------------------------------------------------------- alignment invariants
    report.begin("4. ALIGNMENT INVARIANTS  (a rigid motion cannot change the molecule)")
    try:
        rng = random.Random(17)
        points = [(rng.uniform(-6, 6), rng.uniform(-6, 6), rng.uniform(-6, 6)) for _ in range(30)]

        def rotate(point, axis, angle):
            ax, ay, az = axis
            length = math.sqrt(ax * ax + ay * ay + az * az)
            ax, ay, az = ax / length, ay / length, az / length
            cosine, sine = math.cos(angle), math.sin(angle)
            dot = point[0] * ax + point[1] * ay + point[2] * az
            return (point[0] * cosine + (ay * point[2] - az * point[1]) * sine + ax * dot * (1 - cosine),
                    point[1] * cosine + (az * point[0] - ax * point[2]) * sine + ay * dot * (1 - cosine),
                    point[2] * cosine + (ax * point[1] - ay * point[0]) * sine + az * dot * (1 - cosine))

        moved = [tuple(v + s for v, s in zip(rotate(p, (0.4, 0.6, 0.7), 2.1), (100, -60, 35)))
                 for p in points]

        def distance_matrix(coordinates):
            array = np.asarray(coordinates)
            return np.array([np.linalg.norm(array[i] - array[j])
                             for i in range(len(array)) for j in range(i + 1, len(array))])

        transform = kabsch_transform(points, moved)
        aligned = apply_rigid_transform(moved, transform)
        distance_change = float(np.abs(distance_matrix(points) - distance_matrix(aligned)).max())
        rmsd = float(np.sqrt(((aligned - np.asarray(points)) ** 2).sum(axis=1).mean()))
        determinant = float(np.linalg.det(transform[0]))
        report.detail(f"30 atoms, 435 pairwise distances\n"
                      f"max change in any interatomic distance: {distance_change:.3e} A\n"
                      f"RMSD to reference after alignment     : {rmsd:.3e} A\n"
                      f"det(rotation)                         : {determinant:+.12f}")
        report.check("alignment preserves every interatomic distance", distance_change < 1e-9,
                     "< 1e-9 A", f"{distance_change:.3e} A")
        report.check("alignment superimposes the structures", rmsd < 1e-9, "< 1e-9 A", f"{rmsd:.3e} A")
        report.check("the transform is a proper rotation (no reflection, chirality preserved)",
                     abs(determinant - 1.0) < 1e-9, "+1.0", f"{determinant:+.12f}")
    except Exception as error:
        report.error("alignment invariants", error)

    # ---------------------------------------------------------------- equivalence
    report.begin("5. CHEMICAL EQUIVALENCE  (drives shift and NOE averaging)")
    try:
        for name, expected in (('benzene', [(1, 2, 3, 4, 5, 6), (7, 8, 9, 10, 11, 12)]),
                               ('ethanol', [(4, 5, 6), (7, 8)])):
            elements, coordinates, bonds = _self_test_molecule(name)
            groups = equiv_equivalent_groups_from_graph(elements, coordinates, bonds, {})
            found = sorted(tuple(sorted(group['atoms'])) for group in groups.values())
            report.detail(f"{name}: {found}")
            report.check(f"{name} equivalence classes are correct", found == expected, expected, found)
    except Exception as error:
        report.error("equivalence detection", error)

    # ---------------------------------------------------------------- Wiberg
    report.begin("6. WIBERG BOND ORDERS")
    try:
        for wbi, expected in ((0.20, None), (0.95, 1), (1.45, 4), (1.90, 2), (2.85, 3)):
            got = classify_wiberg_bond_order(wbi)
            report.detail(f"WBI {wbi:.2f} -> order {got}")
            report.check(f"WBI {wbi:.2f} classifies as {expected}", got == expected, expected, got)

        log_path = os.path.join(workspace, 'wiberg.log')
        with open(log_path, 'w', encoding='utf-8') as handle:
            handle.write(" Wiberg bond index matrix in the NAO basis:\n\n"
                         "     Atom    1       2       3\n"
                         "     ---- ------- ------- -------\n"
                         "    1.  C  0.0000  1.4512  0.0421\n"
                         "    2.  C  1.4512  0.0000  2.8800\n"
                         "    3.  N  0.0421  2.8800  0.0000\n\n"
                         " Wiberg bond index, Totals by atom:\n    1.  C  2.4056\n"
                         " Atom-atom overlap-weighted NAO bond order:\n     Atom    1\n    1.  C  9.9999\n")
        matrix = parse_wiberg_bond_index_matrix(log_path)
        report.detail(f"parsed matrix: {matrix}")
        report.check("Wiberg matrix parses", bool(matrix))
        report.check("aromatic bond read correctly", matrix and abs(matrix[1][2] - 1.4512) < 1e-9)
        report.check("triple bond read correctly", matrix and abs(matrix[2][3] - 2.88) < 1e-9)
        report.check("parsing stops before the overlap-weighted matrix",
                     matrix and not any(9.9 < v < 10.1 for row in matrix.values() for v in row.values()))
        report.check("a log with no matrix returns nothing rather than failing",
                     parse_wiberg_bond_index_matrix(os.path.join(workspace, 'absent.log')) is None)

        # The whole path from matrix to written SDF. Each half worked alone while the join did not: the
        # classifier returns MDL code 4 for aromatic, and the SDF writer accepted only the fractional 1.5,
        # so every aromatic bond was rejected as "unusual" and written single.
        ring_connectivity = {1: [(2, 1.0), (6, 1.0)], 2: [(1, 1.0), (3, 1.0)],
                             3: [(2, 1.0), (4, 1.0), (7, 1.0)], 4: [(3, 1.0), (5, 1.0)],
                             5: [(4, 1.0), (6, 1.0)], 6: [(5, 1.0), (1, 1.0)], 7: [(3, 1.0)]}
        ring_matrix = {}
        for first, second in ((1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 1)):
            ring_matrix.setdefault(first, {})[second] = 1.4512
            ring_matrix.setdefault(second, {})[first] = 1.4512
        ring_matrix.setdefault(3, {})[7] = 1.92
        ring_matrix.setdefault(7, {})[3] = 1.92

        updated, changed, _missing = apply_wiberg_bond_orders(ring_connectivity, ring_matrix)
        report.detail(f"{changed} bond order(s) changed from the matrix")
        report.check("aromatic bonds are recognised from their indices",
                     any(order == 4 for bonds in updated.values() for _n, order in bonds))
        report.check("the carbonyl is recognised as a double bond",
                     any(order == 2 for bonds in updated.values() for _n, order in bonds))

        sdf_path = os.path.join(workspace, 'orders.sdf')
        write_v3000_sdf(sdf_path, 'demo', 1, ['C'] * 6 + ['O'],
                        [(0, 0, 0), (1.4, 0, 0), (2.1, 1.2, 0), (1.4, 2.4, 0),
                         (0, 2.4, 0), (-0.7, 1.2, 0), (2.8, 2.4, 0)], updated, {})
        written = open(sdf_path, encoding='utf-8').read()
        bond_types = [line.split()[3] for line in written.split('\n')
                      if line.strip().startswith('M  V30') and len(line.split()) == 6
                      and line.split()[3] in '1234']
        report.detail(f"bond types written to the SDF: {bond_types}")
        report.check("aromatic bonds survive into the written SDF", '4' in bond_types,
                     "a '4' present", bond_types)
        report.check("double bonds survive into the written SDF", '2' in bond_types)
        report.check("the SDF is not written entirely single-bonded", set(bond_types) != {'1'},
                     "mixed orders", set(bond_types))

        report_path = os.path.join(workspace, 'wiberg_report.txt')
        write_wiberg_report('demo', 1, updated, ring_matrix, ['C'] * 6 + ['O'], report_path)
        report_text = open(report_path, encoding='utf-8').read()
        report.check("the Wiberg diagnostic report lists raw indices",
                     '1.4512' in report_text and 'Classification boundaries' in report_text)
    except Exception as error:
        report.error("Wiberg parsing", error)

    # ---------------------------------------------------------------- SDF handling
    report.begin("7. SDF HANDLING")
    try:
        v2000 = ("x_1\n  gen\n\n  5  4  0  0  0  0            999 V2000\n"
                 "    0.0000    0.0000    0.0000 C   0  0  0  0  0  0\n"
                 "    1.5000    0.0000    0.0000 C   0  0  0  0  0  0\n"
                 "    2.2000    1.3000    0.0000 Cl  0  0  0  0  0  0\n"
                 "   -1.0000    1.2000    0.0000 O   0  0  0  0  0  0\n"
                 "    0.5000   -1.5000    0.0000 S   0  0  0  0  0  0\n"
                 "  1  2  1  0\n  2  3  1  0\n  1  4  1  0\n  1  5  1  0\n"
                 "M  CHG  1   4  -1\nM  END\n$$$$\n")
        path = os.path.join(workspace, 'v2000_1.sdf')
        with open(path, 'w', encoding='utf-8') as handle:
            handle.write(v2000)
        connectivity, atom_types, total_charge = parse_sdf_connectivity(path)
        report.detail(f"V2000 -> {len(atom_types)} atoms {atom_types}, charge {total_charge}\n"
                      f"connectivity: {dict(connectivity)}")
        report.check("V2000 atoms parse", atom_types == ['C', 'C', 'Cl', 'O', 'S'],
                     ['C', 'C', 'Cl', 'O', 'S'], atom_types)
        report.check("V2000 connectivity parses", sorted(connectivity.get(1, [])) == [2, 4, 5],
                     [2, 4, 5], sorted(connectivity.get(1, [])))
        report.check("V2000 formal charge parses", total_charge == -1, -1, total_charge)

        entries = sms_split_sdf_entries(v2000 * 3)
        report.detail(f"splitting a 3-record file produced {len(entries)} records")
        report.check("multi-structure SDF splits", len(entries) == 3, 3, len(entries))
        report.check("split records keep a counts line on line 4",
                     entries[0].split('\n')[3].strip().endswith('V2000'))

        elements = detect_elements_in_sdf(path)
        report.detail(f"elements detected: {sorted(elements)}")
        report.check("element detection finds every element", elements == {'C', 'Cl', 'O', 'S'},
                     {'C', 'Cl', 'O', 'S'}, elements)
    except Exception as error:
        report.error("SDF handling", error)

    # ---------------------------------------------------------------- NOE
    report.begin("8. NOE EQUIVALENCE MULTIPLIERS  (additive r^-6)")
    try:
        for counts, expected in (((3, 1), 3 ** (-1 / 6)), ((3, 3), 9 ** (-1 / 6)),
                                 ((2, 1), 2 ** (-1 / 6)), ((1, 1), 1.0)):
            got = noe_equivalence_multiplier(*counts)
            report.detail(f"{counts[0]}x{counts[1]} -> {got:.6f}")
            report.check(f"multiplier for {counts[0]}x{counts[1]} groups", abs(got - expected) < 1e-12,
                         f"{expected:.6f}", f"{got:.6f}")
    except Exception as error:
        report.error("NOE multipliers", error)

    # ---------------------------------------------------------------- deduplication
    report.begin("9. DEDUPLICATION GATES")
    try:
        report.detail(f"energy window {DEDUP_ENERGY_WINDOW} kcal/mol, RMSD {DEDUP_RMSD_THRESHOLD} A, "
                      f"max deviation {DEDUP_MAX_DEVIATION_THRESHOLD} A,\n"
                      f"frequency RMSD {DEDUP_FREQUENCY_RMSD_THRESHOLD} cm^-1, "
                      f"max mode {DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD} cm^-1")
        spectrum = [100.0 + 7.3 * i for i in range(60)]
        identical = dedup_frequency_agreement(spectrum, spectrum)
        noisy = dedup_frequency_agreement(spectrum, [f + 0.25 for f in spectrum])
        shifted = dedup_frequency_agreement(spectrum, [f + (12.0 if i == 30 else 0.0)
                                                       for i, f in enumerate(spectrum)])
        report.detail(f"identical spectra      : rmsd {identical[0]:.3f}, max {identical[1]:.3f}\n"
                      f"convergence noise only : rmsd {noisy[0]:.3f}, max {noisy[1]:.3f}\n"
                      f"one mode shifted 12    : rmsd {shifted[0]:.3f}, max {shifted[1]:.3f}")
        report.check("identical spectra agree", identical[1] < DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD)
        report.check("convergence noise does not block a merge",
                     noisy[1] < DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD)
        report.check("a single shifted mode blocks a merge",
                     shifted[1] > DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD,
                     f"> {DEDUP_FREQUENCY_MAX_DIFF_THRESHOLD}", f"{shifted[1]:.3f}")
        report.check("the all-mode RMSD alone would NOT have caught it (why max is the binding metric)",
                     shifted[0] < DEDUP_FREQUENCY_RMSD_THRESHOLD,
                     f"< {DEDUP_FREQUENCY_RMSD_THRESHOLD}", f"{shifted[0]:.3f}")
        report.check("differing mode counts are reported as incomparable",
                     dedup_frequency_agreement([1.0, 2.0], [1.0])[2] is False)
    except Exception as error:
        report.error("deduplication gates", error)

    # ---------------------------------------------------------------- preview vs file
    report.begin("10. PREVIEW MATCHES THE GENERATED FILE")
    try:
        sdf_text = ("prev_1\n  gen\n\n  4  3  0  0  0  0            999 V2000\n"
                    "    0.0000    0.0000    0.0000 C   0  0  0  0  0  0\n"
                    "    1.5000    0.0000    0.0000 C   0  0  0  0  0  0\n"
                    "    2.2000    1.3000    0.0000 O   0  0  0  0  0  0\n"
                    "   -1.0000    1.2000    0.0000 H   0  0  0  0  0  0\n"
                    "  1  2  1  0\n  2  3  1  0\n  1  4  1  0\nM  END\n$$$$\n")
        source = os.path.join(workspace, 'prev_1.sdf')
        with open(source, 'w', encoding='utf-8') as handle:
            handle.write(sdf_text)

        settings = {'prev': dict(method_key='1', temperature=298.0, machine='default', tier='medium',
                                 include_cc=True, include_fluorine=False, include_nitrogen=False,
                                 include_csulfur=False, include_chalogen=False,
                                 output_dir=os.path.join(workspace, 'out'), cluster=None)}
        tab = JobSetupTab.__new__(JobSetupTab)
        captured = StringIO()
        original = sys.stdout
        sys.stdout = captured
        try:
            JobSetupTab._pipeline_worker(tab, [source], settings)
        finally:
            sys.stdout = original
        report.detail("pipeline output:\n" + captured.getvalue().strip())

        generated = os.path.join(workspace, 'out', GJF_OUTPUT_DIR, 'prev_1.gjf')
        report.check("the pipeline produced an input file", os.path.exists(generated))
        if os.path.exists(generated):
            real_lines = open(generated, encoding='utf-8').read().split('\n')
            coordinate_lines, connectivity, charges, _ = ngig_parse_sdf(source)
            elements = [line.split()[0] for line in coordinate_lines]
            preview = [line for line in
                       build_route_preview('1', True, False, False, 298.0, 'default', 'medium',
                                           compound_name='prev',
                                           structure=(elements, connectivity, charges)).split('\n')
                       if not line.startswith('=====')]

            def normalise(lines, is_real):
                out = []
                for line in lines:
                    if is_real:
                        line = line.replace('prev_1', 'prev_{conformer}')
                        if re.match(r'^\s*[A-Z][a-z]?\s+-?\d+\.\d+\s+-?\d+\.\d+\s+-?\d+\.\d+\s*$', line):
                            line = '{coordinates}'
                    out.append(line.rstrip())
                collapsed = []
                for line in out:
                    if collapsed and line == '{coordinates}' and collapsed[-1] == '{coordinates}':
                        continue
                    collapsed.append(line)
                return [line for line in collapsed if line.strip()]

            real_norm, preview_norm = normalise(real_lines, True), normalise(preview, False)
            report.detail("generated file:\n" + '\n'.join(real_norm))
            report.detail("preview:\n" + '\n'.join(preview_norm))
            report.check("preview is line-for-line identical to the generated file",
                         real_norm == preview_norm,
                         f"{len(real_norm)} matching lines", f"{len(preview_norm)} lines")
            if real_norm != preview_norm:
                for index, (a, b) in enumerate(zip(real_norm, preview_norm)):
                    if a != b:
                        report.detail(f"first difference at line {index}:\n  file   : {a!r}\n  preview: {b!r}")
                        break

            text = open(generated, encoding='utf-8').read()
            report.check("pop=nboread present in the optimization route", 'pop=nboread' in text)
            report.check("NBO block present", NBO_INPUT_BLOCK in text)

            # Section order is load-bearing: Gaussian reads connectivity, then the gen basis, then the NBO
            # input. $NBO emitted before the basis block is parsed as an atom label and ends the job.
            file_lines = text.split('\n')
            nbo_index = file_lines.index(NBO_INPUT_BLOCK)
            connectivity_index = max((i for i, line in enumerate(file_lines[:nbo_index])
                                      if re.match(r'^\d+( \d+ [\d.]+)*$', line.strip())), default=-1)
            report.detail(f"connectivity ends at line {connectivity_index}, $NBO at line {nbo_index}")
            report.check("NBO block follows the connectivity block", nbo_index > connectivity_index)
            report.check("job titles carry no method number",
                         'prev_1_1carbon' not in text and 'prev_1_carbon' in text)
            report.check("neutral molecule has no charge block", 'prev_1_opt []' not in text)
            raw = open(generated, 'rb').read()
            report.check("file uses Unix line endings", raw.count(b'\r\n') == 0,
                         "0 CRLF", raw.count(b'\r\n'))
    except Exception as error:
        report.error("preview versus generated file", error)

    # ---------------------------------------------------------------- log title reading
    report.begin("9a. READING TITLES BACK FROM LOGS")
    try:
        import inspect as _inspect
        for label, title, number, expected in (
                ("neutral molecule (no charge block)", "piperine_1_opt", 1, "piperine_1_opt"),
                ("charged molecule", "piperine_2_opt [5:-1]", 2, "piperine_2_opt[5:-1]")):
            path = os.path.join(workspace, f"piperine_{number}.log")
            with open(path, 'w', encoding='utf-8') as handle:
                handle.write("noise\n " + title + "\n" + "filler\n" * 600)
            got = extract_full_serialized_block(path, 'piperine', number, 'opt')
            report.detail(f"{label}: {title!r} -> {got!r}")
            report.check(f"{label} reads back without running to the line cap", got == expected,
                         expected, got)

        charged_block = extract_full_serialized_block(os.path.join(workspace, "piperine_2.log"),
                                                      'piperine', 2, 'opt')
        charges, _connectivity = parse_serialized_connectivity_and_charges(charged_block, {5: [(1, 1.0)]})
        report.check("formal charges still parse out of a charged title", dict(charges) == {5: -1},
                     {5: -1}, dict(charges))

        # Matched on the print statement rather than the phrase: the phrase appears in this check itself, so
        # searching for it plainly would always find a hit and never pass
        warning_call = 'print(f"Warning: Could not ' + 'detect method key'
        report.check("a missing method number is not reported as a problem",
                     warning_call not in _inspect.getsource(sys.modules[__name__]))

        worker_source = _inspect.getsource(AnalysisTab._analysis_worker)
        report.check("the analysis is restricted to the compounds whose logs were loaded",
                     "NGP_RESTRICT_TO_COMPOUNDS'] = set(only_compounds" in worker_source)
        report.check("that restriction is cleared after the run",
                     worker_source.count('NGP_RESTRICT_TO_COMPOUNDS') >= 2)
        report.check("results are moved to the chosen folder, not left in both places",
                     'shutil.move(source, destination)' in worker_source
                     and 'copytree' not in worker_source)
        report.check("the discovery step honours the restriction",
                     'NGP_RESTRICT_TO_COMPOUNDS' in _inspect.getsource(run_ngp_analysis))
    except Exception as error:
        report.error("log title reading", error)

    # ---------------------------------------------------------------- entry points
    report.begin("9b. ENTRY POINTS  (a name collision here silently ran the wrong half of the program)")
    try:
        import inspect as _inspect
        analysis_source = _inspect.getsource(run_ngp_analysis)
        launcher_source = _inspect.getsource(launch_workbench)
        worker_source = _inspect.getsource(AnalysisTab._analysis_worker)
        report.detail("The interface's entry point and the analysis entry point were both named main(). The\n"
                      "later definition shadowed the earlier, so the analysis worker called the interface --\n"
                      "opening a second window, running mainloop() on a worker thread, and producing nothing.")
        report.check("no function named 'main' exists to be shadowed",
                     'main' not in {name for name, value in globals().items()
                                    if _inspect.isfunction(value)})
        report.check("the analysis entry point builds no window",
                     'WorkbenchApp' not in analysis_source and 'mainloop' not in analysis_source)
        report.check("the launcher builds the window", 'WorkbenchApp' in launcher_source)
        report.check("the analysis worker calls the analysis, not the launcher",
                     'run_ngp_analysis()' in worker_source
                     and 'launch_workbench' not in worker_source)
        report.check("worker pools are disabled while the interface is running",
                     'RUNNING_UNDER_GUI' in _inspect.getsource(process_files))
    except Exception as error:
        report.error("entry points", error)

    # ---------------------------------------------------------------- output tidiness
    report.begin("10a. OUTPUT LAYOUT AND CLEANUP  (shared folders must survive other runs)")
    try:
        tidy_out = os.path.join(workspace, 'tidy_out')
        base_settings = dict(method_key='1', temperature=298.0, machine='default', tier='medium',
                             include_cc=False, include_fluorine=False, include_nitrogen=False,
                             include_csulfur=False, include_chalogen=False, output_dir=tidy_out,
                             cluster=None, keep_split=False, keep_aligned=False, keep_clustered=False)
        made = []
        for compound in ('alpha', 'beta'):
            text = ""
            for number in (1, 2):
                text += (f"{compound}_{number}\n  gen\n\n"
                         "  3  2  0  0  0  0            999 V2000\n"
                         f"    {number}.0000    0.0000    0.0000 C   0  0  0  0  0  0\n"
                         "    1.5000    0.0000    0.0000 C   0  0  0  0  0  0\n"
                         "   -1.0000    1.0000    0.0000 O   0  0  0  0  0  0\n"
                         "  1  2  1  0\n  2  3  1  0\nM  END\n$$$$\n")
            source = os.path.join(workspace, f'{compound}_confs.sdf')
            with open(source, 'w', encoding='utf-8') as handle:
                handle.write(text)
            if compound == 'beta':
                # a file left by an earlier run, which this run must not touch
                os.makedirs(os.path.join(tidy_out, 'split_conformers'), exist_ok=True)
                with open(os.path.join(tidy_out, 'split_conformers', 'PRIOR_RUN_9.sdf'), 'w') as handle:
                    handle.write('x')
            tab = JobSetupTab.__new__(JobSetupTab)
            captured = StringIO()
            original = sys.stdout
            sys.stdout = captured
            try:
                JobSetupTab._pipeline_worker(tab, [source], {compound: dict(base_settings)})
            finally:
                sys.stdout = original
            made.append(captured.getvalue())
        report.detail("second run output:\n" + made[-1].strip())

        stray = [name for name in os.listdir(tidy_out) if name.lower().endswith('.gjf')]
        report.check("no job files are left loose in the output root", stray == [], [], stray)
        report.check("job files are all in the job folder",
                     len(os.listdir(os.path.join(tidy_out, GJF_OUTPUT_DIR))) == 4,
                     4, len(os.listdir(os.path.join(tidy_out, GJF_OUTPUT_DIR))))
        survivor = os.path.join(tidy_out, 'split_conformers', 'PRIOR_RUN_9.sdf')
        report.check("cleanup does not delete another run's files from a shared folder",
                     os.path.exists(survivor))
    except Exception as error:
        report.error("output layout and cleanup", error)

    # ---------------------------------------------------------------- gen basis ordering
    report.begin("10b. GEN BASIS AND NBO ORDERING  (iodine: the case that breaks a real Gaussian run)")
    try:
        iodine_sdf = ("iod_1\n  gen\n\n  3  2  0  0  0  0            999 V2000\n"
                      "    0.0000    0.0000    0.0000 C   0  0  0  0  0  0\n"
                      "    1.5000    0.0000    0.0000 I   0  0  0  0  0  0\n"
                      "   -1.0000    1.0000    0.0000 H   0  0  0  0  0  0\n"
                      "  1  2  1  0\n  1  3  1  0\nM  END\n$$$$\n")
        source = os.path.join(workspace, 'iod_1.sdf')
        with open(source, 'w', encoding='utf-8') as handle:
            handle.write(iodine_sdf)
        settings = {'iod': dict(method_key='1', temperature=298.0, machine='default', tier='medium',
                                include_cc=False, include_fluorine=False, include_nitrogen=False,
                                include_csulfur=False, include_chalogen=False,
                                output_dir=os.path.join(workspace, 'iod_out'), cluster=None)}
        tab = JobSetupTab.__new__(JobSetupTab)
        captured = StringIO()
        original = sys.stdout
        sys.stdout = captured
        try:
            JobSetupTab._pipeline_worker(tab, [source], settings)
        finally:
            sys.stdout = original

        generated = os.path.join(workspace, 'iod_out', GJF_OUTPUT_DIR, 'iod_1.gjf')
        report.check("an iodine-containing job is generated", os.path.exists(generated))
        if os.path.exists(generated):
            all_lines = open(generated, encoding='utf-8').read().split('\n')
            report.check("the route requests a gen basis",
                         any('/gen' in line for line in all_lines if line.startswith('#')))
            # Scoped to the FIRST job section. Every Link1 section carries its own gen basis, so comparing
            # against the last '****' in the file would measure the proton job's basis against the opt job's
            # NBO block and report a failure that is not one.
            first_link1 = all_lines.index('--Link1--') if '--Link1--' in all_lines else len(all_lines)
            file_lines = all_lines[:first_link1]
            terminator = max((i for i, line in enumerate(file_lines) if line.strip() == '****'), default=-1)
            nbo_index = file_lines.index(NBO_INPUT_BLOCK) if NBO_INPUT_BLOCK in file_lines else -1
            report.detail(f"first job section is lines 0-{first_link1}\n"
                          f"gen basis ends at line {terminator}; $NBO at line {nbo_index}")
            report.check("the gen basis block is present", terminator > 0)
            report.check("$NBO comes AFTER the gen basis block, not before it",
                         nbo_index > terminator, f"> {terminator}", nbo_index)
            report.check("a blank line separates the basis block from $NBO",
                         nbo_index > 0 and file_lines[nbo_index - 1].strip() == '')
            report.check("the iodine basis is actually written",
                         any('I     0' in line or 'I 0' in line for line in all_lines))
    except Exception as error:
        report.error("gen basis and NBO ordering", error)

    # ---------------------------------------------------------------- pre-flight checks
    report.begin("11. PRE-FLIGHT CHECKS")
    try:
        good = os.path.join(workspace, 'good_1.log')
        with open(good, 'w', encoding='utf-8') as handle:
            handle.write("noise\ngood_1_carbon s:-1.0065 i:196.0386\nnoise\n")
        old = os.path.join(workspace, 'old_1.log')
        with open(old, 'w', encoding='utf-8') as handle:
            handle.write("noise\nold_1_1carbon\nnoise\n")
        missing = check_logs_carry_scaling_factors({'good': [good], 'old': [old]})
        report.detail(f"compounds missing scaling factors: {missing}")
        report.check("a log without scaling factors is flagged before the run", missing == ['old'],
                     ['old'], missing)
        report.check("a writable directory passes", check_output_location(workspace) == [])
        report.check("the unknown-method sentinel cannot collide with a real method",
                     UNKNOWN_METHOD_KEY not in scaling_factors
                     and UNKNOWN_METHOD_KEY not in SULFUR_SCALING_BY_METHOD)
    except Exception as error:
        report.error("pre-flight checks", error)

    # ---------------------------------------------------------------- viewer
    report.begin("12. STRUCTURE VIEWER  (scene geometry, no display required)")
    try:
        elements, coordinates, bonds = _self_test_molecule('benzene')
        viewer = StructureViewer.__new__(StructureViewer)
        viewer.rotation = StructureViewer._rotation_y(-30.0).dot(StructureViewer._rotation_x(20.0))
        points = np.asarray(coordinates, dtype=float)
        viewer.coordinates = points - points.mean(axis=0)
        viewer.elements = elements
        viewer.bonds = sorted(bonds)
        viewer.labels = {1: '128.5', 7: '7.26'}
        viewer.bond_orders = {}
        viewer.show_labels = True
        viewer.zoom = 28.0
        viewer.pan = [0.0, 0.0]

        scene = viewer.build_scene(700, 480)
        kinds = {}
        for primitive in scene:
            kinds[primitive[0]] = kinds.get(primitive[0], 0) + 1
        report.detail(f"scene primitives: {kinds}")
        # Each half-stick is drawn as VIEWER_SHADING_STRIPS lengthwise strips, which is what makes it read
        # as a lit cylinder rather than a flat band
        expected_lines = 2 * len(bonds) * VIEWER_SHADING_STRIPS
        report.check("each bond draws two half-sticks of shaded strips",
                     kinds.get('line') == expected_lines, expected_lines, kinds.get('line'))
        report.check("each label draws with an outline", kinds.get('text') == 5 * len(viewer.labels),
                     5 * len(viewer.labels), kinds.get('text'))
        # Shells smaller than a pixel are skipped, so the count is at most one per shell per atom
        # Bonded atoms are capped by the sticks themselves, so no separate sphere is drawn for them
        report.check("bonded atoms need no separate sphere primitive", kinds.get('dot', 0) == 0,
                     0, kinds.get('dot', 0))
        report.check("scene building is a pure function", viewer.build_scene(700, 480) == scene)
        viewer.show_labels = False
        report.check("hiding labels removes only the text",
                     all(p[0] != 'text' for p in viewer.build_scene(700, 480)))
        # Carbon is lightened from the standalone viewer's near-black, which vanished against this
        # background once shading was applied; the other elements keep their usual CPK hues
        report.check("element colours are the expected CPK hues",
                     viewer_element_colour('O') == '#e51111'
                     and viewer_element_colour('N') == '#1133f7')
        report.check("carbon is light enough to read against the background",
                     int(viewer_element_colour('C')[1:3], 16) > int(VIEWER_BACKGROUND[1:3], 16) + 40)
        report.check("label colour is the expected gold", VIEWER_LABEL_COLOR == '#ffcc00')

        # Bond order character and depth cueing
        ring_elements = ['C'] * 6 + ['O', 'H']
        ring_coordinates = []
        for index in range(6):
            angle = 2 * math.pi * index / 6
            ring_coordinates.append((1.4 * math.cos(angle), 1.4 * math.sin(angle),
                                     0.35 if index % 2 else -0.35))
        ring_coordinates += [(2.8, 1.2, 0.0), (-2.4, 0.0, 0.0)]
        ring_bonds = [(1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 1), (3, 7), (1, 8)]
        # (6, 1) is deliberately the reverse of how the bond is listed, since a parser may record it either way
        ring_orders = {(1, 2): 4, (2, 3): 4, (3, 4): 4, (4, 5): 4, (5, 6): 4, (6, 1): 4,
                       (3, 7): 2, (1, 8): 1}

        orders_viewer = StructureViewer.__new__(StructureViewer)
        orders_viewer.rotation = (StructureViewer._rotation_y(-30.0)
                                  .dot(StructureViewer._rotation_x(20.0)))
        orders_viewer.bond_orders = {(min(int(a), int(b)), max(int(a), int(b))): order
                                     for (a, b), order in ring_orders.items()}
        ring_points = np.asarray(ring_coordinates, dtype=float)
        orders_viewer.coordinates = ring_points - ring_points.mean(axis=0)
        orders_viewer.elements, orders_viewer.bonds = ring_elements, ring_bonds
        orders_viewer.labels, orders_viewer.show_labels = {}, False
        aromatic_pairs = [pair for pair, order in orders_viewer.bond_orders.items() if order == 4]
        orders_viewer.bond_rings = {}
        for pair in aromatic_pairs:
            members = StructureViewer.find_ring_members(aromatic_pairs, pair[0], pair[1])
            if members:
                orders_viewer.bond_rings[pair] = members
        orders_viewer.zoom, orders_viewer.pan = 40.0, [0.0, 0.0]

        order_scene = [p for p in orders_viewer.build_scene(700, 480) if p[0] == 'line']
        report.detail(f"6 aromatic + 1 double + 1 single -> {len(order_scene)} line primitives "
                      f"(2 lanes x 2 halves for aromatic and double, 1 x 2 for single)")
        # 6 aromatic: 1 shaded lane (2 halves x strips) + 1 dashed partner drawn whole
        # 1 double: 2 shaded lanes; 1 single: 1 shaded lane
        # Each shaded lane is 2 halves x strips; each aromatic bond adds one dashed inner line
        strips = VIEWER_SHADING_STRIPS
        expected = (6 * (2 * strips + 1)) + (1 * 2 * 2 * strips) + (1 * 2 * strips)
        report.check("multiple bonds draw as parallel shaded lanes", len(order_scene) == expected,
                     expected, len(order_scene))
        report.check("each aromatic bond carries exactly one dashed partner",
                     len([p for p in order_scene if p[7]]) == 6, 6,
                     len([p for p in order_scene if p[7]]))
        report.check("a bond order recorded in reverse order is still found",
                     orders_viewer.bond_orders.get((1, 6)) == 4)
        report.check("depth cueing varies colour with distance",
                     len({p[5] for p in order_scene}) > 3, "> 3 shades",
                     len({p[5] for p in order_scene}))
        # Checked on the function rather than the rendered widths: a nearly planar test ring gives too small
        # a depth span for the rounded pixel widths to differ
        report.check("depth cueing varies stick width with distance",
                     VIEWER_DEPTH_MIN_WIDTH < 1.0, "< 1.0", VIEWER_DEPTH_MIN_WIDTH)
        report.check("the nearest atom keeps its full colour",
                     viewer_blend_toward_background('#333333', 1.0) == '#333333')
        report.check("the furthest atom is mixed toward the background but still visible",
                     viewer_blend_toward_background('#333333', 0.0) not in ('#333333', VIEWER_BACKGROUND))
        # With no orders at all everything falls back to a single line per bond: 8 bonds x 2 halves
        saved_orders = orders_viewer.bond_orders
        orders_viewer.bond_orders = {}
        plain_scene = [p for p in orders_viewer.build_scene(700, 480) if p[0] == 'line']
        orders_viewer.bond_orders = saved_orders
        report.check("a structure with no bond orders still draws as plain sticks",
                     len(plain_scene) == 8 * 2 * VIEWER_SHADING_STRIPS,
                     8 * 2 * VIEWER_SHADING_STRIPS, len(plain_scene))

        report.check("every scroll area is reachable by one wheel handler",
                     callable(route_wheel_to_scroll_area))

        # Cylinder shading: a lit profile across each stick, consistent whichever way the bond points
        for label, perpendicular in (("horizontal bond", (1.0, 0.0)), ("vertical bond", (0.0, 1.0)),
                                     ("diagonal bond", (0.707, 0.707))):
            profile = viewer_cylinder_strips(9, perpendicular[0], perpendicular[1])
            values = [brightness for _offset, brightness, _cap in profile]
            report.detail(f"{label}: " + " ".join(f"{v:.2f}" for v in values))
            report.check(f"{label} has a highlight brighter than full colour", max(values) > 1.0,
                         "> 1.0", f"{max(values):.2f}")
            # The shaded edge sits at the ambient floor, which is deliberately generous: darker than this
            # and a carbon stick is indistinguishable from the background
            report.check(f"{label} has a shaded far edge",
                         abs(min(values) - VIEWER_AMBIENT) < 0.02,
                         f"~{VIEWER_AMBIENT:.2f}", f"{min(values):.2f}")
            report.check(f"{label} spans a wide brightness range", max(values) / min(values) > 2.0,
                         "> 2x", f"{max(values) / min(values):.2f}x")
            report.check(f"{label} varies smoothly across the stick",
                         len(set(values)) >= VIEWER_SHADING_STRIPS // 2,
                         f">= {VIEWER_SHADING_STRIPS // 2} distinct", len(set(values)))
            overhangs = [cap for _offset, _brightness, cap in profile]
            report.check(f"{label} caps are rounded, longest at the centre",
                         max(overhangs) == overhangs[len(overhangs) // 2] and min(overhangs) < 0.5)
        report.check("the highlight is equally strong on any bond orientation",
                     abs(max(b for _o, b, _c in viewer_cylinder_strips(9, 1.0, 0.0))
                         - max(b for _o, b, _c in viewer_cylinder_strips(9, 0.0, 1.0))) < 0.15)
        report.check("shading above full brightness tints toward white",
                     viewer_shade('#333333', 1.5) > '#333333')

        # Aromatic dashes belong inside the ring, whichever way the perpendicular happens to point
        ring_bonds = [(1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 1)]
        found = {pair: StructureViewer.find_ring_members(ring_bonds, pair[0], pair[1])
                 for pair in ring_bonds}
        report.detail(f"ring found for each of the 6 aromatic bonds: "
                      f"{all(v and len(v) == 6 for v in found.values())}")
        report.check("every bond of a six-ring resolves to that ring",
                     all(members and sorted(members) == [1, 2, 3, 4, 5, 6]
                         for members in found.values()))
        report.check("a bond outside any ring resolves to nothing",
                     StructureViewer.find_ring_members(ring_bonds + [(3, 9)], 3, 9) is None)

        # Keys normalised, as load_structure produces them: an entry stored as (6, 1) is never found by the
        # (1, 6) lookup, and that one bond silently loses its inner line
        orders_viewer.bond_rings = {(min(pair), max(pair)): found[pair]
                                    for pair in ring_bonds if found[pair]}
        aromatic_scene = orders_viewer.build_scene(700, 480)
        dashes = [p for p in aromatic_scene if p[0] == 'line' and p[7]]
        ring_centre_x = sum(p[1] for p in dashes) / len(dashes)
        ring_centre_y = sum(p[2] for p in dashes) / len(dashes)
        report.check("aromatic bonds each contribute one dashed partner", len(dashes) == 6,
                     6, len(dashes))

        # The dashes must not run past each other at the ring vertices, which is what made them cross
        def _segments_cross(first, second):
            (x1, y1, x2, y2), (x3, y3, x4, y4) = first, second
            denominator = (x2 - x1) * (y4 - y3) - (y2 - y1) * (x4 - x3)
            if abs(denominator) < 1e-9:
                return False
            t = ((x3 - x1) * (y4 - y3) - (y3 - y1) * (x4 - x3)) / denominator
            u = ((x3 - x1) * (y2 - y1) - (y3 - y1) * (x2 - x1)) / denominator
            return 0.02 < t < 0.98 and 0.02 < u < 0.98

        dash_segments = [(p[1], p[2], p[3], p[4]) for p in dashes]
        crossings = sum(1 for i in range(len(dash_segments))
                        for j in range(i + 1, len(dash_segments))
                        if _segments_cross(dash_segments[i], dash_segments[j]))
        report.detail(f"crossings between neighbouring dashes: {crossings}")
        report.check("dashes do not cross one another", crossings == 0, 0, crossings)

        endpoints = []
        for segment in dash_segments:
            endpoints += [(round(segment[0], 1), round(segment[1], 1)),
                          (round(segment[2], 1), round(segment[3], 1))]
        shared = {point: endpoints.count(point) for point in set(endpoints)}
        report.detail(f"{len(dash_segments)} dashes over {len(shared)} distinct endpoints")
        report.check("dashes meet at shared vertices, forming a closed inner ring",
                     len(shared) == len(dash_segments) and all(count == 2 for count in shared.values()),
                     "each endpoint used twice", sorted(shared.values()))

        # A ring fused to a saturated ring must not send its inner line into the saturated one
        mixed_bonds = [(1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 1),
                       (2, 7), (7, 8), (8, 9), (9, 10), (10, 1)]
        aromatic_only = [(1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 1)]
        report.check("the ring search stays inside the conjugated system",
                     sorted(StructureViewer.find_ring_members(aromatic_only, 1, 2) or []) ==
                     [1, 2, 3, 4, 5, 6])

        # A bond shared between two fused rings must take the small ring, not the surrounding envelope
        fused = [(1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 1),
                 (2, 7), (7, 8), (8, 9), (9, 10), (10, 1)]
        shared_ring = StructureViewer.find_ring_members(fused, 1, 2)
        outer_ring = StructureViewer.find_ring_members(fused, 8, 9)
        report.detail(f"fused system: shared bond -> {sorted(shared_ring or [])}, "
                      f"outer bond -> {sorted(outer_ring or [])}")
        report.check("a fused bond resolves to its own six-ring, not the whole envelope",
                     shared_ring is not None and len(shared_ring) == 6, 6,
                     len(shared_ring or []))
        report.check("a bond in the second ring resolves to that ring",
                     outer_ring is not None and sorted(outer_ring) == [1, 2, 7, 8, 9, 10])

        report.check("the darkest shaded stick stays distinguishable from the background",
                     viewer_shade(viewer_blend_toward_background(viewer_element_colour('C'), 0.0),
                                  VIEWER_AMBIENT) != VIEWER_BACKGROUND)
        sphere = viewer_sphere_shells(5.0)
        report.check("sphere shells run dark rim to bright spot",
                     sphere[0][3] < sphere[-1][3], "increasing", (sphere[0][3], sphere[-1][3]))
        report.check("sphere shells shrink toward the highlight",
                     sphere[0][0] > sphere[-1][0])

        # Conformer selection: grouped by compound, ordered by energy, lowest marked and chosen
        viewer_root = os.path.join(workspace, 'viewer_results')
        for compound, energies in (('alpha', {1: -100.5, 2: -101.9, 3: -100.1}), ('beta', {1: -50.2})):
            sdf_directory = os.path.join(viewer_root, compound, "Conformer SDF Files")
            os.makedirs(sdf_directory, exist_ok=True)
            for number, energy in energies.items():
                with open(os.path.join(sdf_directory, f"{compound}_{number}.sdf"), 'w') as handle:
                    handle.write(f"{compound}_{number}\n  gen\n"
                                 f"Total Gibbs Free Energy (Hartrees): {energy}\n"
                                 "  2  1  0  0  0  0            999 V2000\n"
                                 "    0.0000    0.0000    0.0000 C   0  0  0  0  0  0\n"
                                 "    1.5000    0.0000    0.0000 O   0  0  0  0  0  0\n"
                                 "  1  2  1  0\nM  END\n$$$$\n")

        class _StubBox:
            def __init__(self): self.values = []
            def configure(self, **kw):
                if 'values' in kw: self.values = list(kw['values'])
            def cget(self, key): return self.values
        class _StubVar:
            def __init__(self): self.value = ''
            def get(self): return self.value
            def set(self, value): self.value = value
        class _StubLabel:
            def __init__(self): self.text = ''
            def configure(self, **kw): self.text = kw.get('text', self.text)
        class _StubViewer:
            def clear(self): pass
            def load_structure(self, *a, **k): pass
            def set_labels_visible(self, *a): pass

        stub = AnalysisTab.__new__(AnalysisTab)
        stub.viewer_compound_box, stub.viewer_conformer_box = _StubBox(), _StubBox()
        stub.viewer_compound, stub.viewer_conformer = _StubVar(), _StubVar()
        stub.viewer_status, stub.viewer = _StubLabel(), _StubViewer()
        stub.output_vars = {}
        stub.viewer_show_labels = _StubVar(); stub.viewer_show_labels.set(True)
        AnalysisTab._populate_viewer(stub, viewer_root)

        report.detail(f"compounds offered : {stub.viewer_compound_box.values}\n"
                      f"alpha conformers  : {stub.viewer_conformer_box.values}\n"
                      f"selected          : {stub.viewer_conformer.get()}")
        report.check("compounds get their own dropdown",
                     stub.viewer_compound_box.values == ['alpha', 'beta'],
                     ['alpha', 'beta'], stub.viewer_compound_box.values)
        report.check("conformers are ordered by energy, not by filename",
                     stub.viewer_conformer_box.values[0].startswith('alpha_2'),
                     "alpha_2 first (-101.9)", stub.viewer_conformer_box.values[0])
        report.check("the lowest-energy conformer is marked as such",
                     '(lowest energy)' in stub.viewer_conformer_box.values[0])
        report.check("only the lowest carries the marker",
                     sum('(lowest energy)' in v for v in stub.viewer_conformer_box.values) == 1)
        report.check("the lowest-energy conformer is selected by default",
                     stub.viewer_conformer.get().startswith('alpha_2'))
        stub.viewer_compound.set('beta')
        AnalysisTab._on_viewer_compound_changed(stub)
        report.check("switching compound repopulates its conformers",
                     stub.viewer_conformer_box.values[0].startswith('beta_1'),
                     "beta_1 first", stub.viewer_conformer_box.values[0])

        pml = os.path.join(workspace, 'labels.pml')
        with open(pml, 'w', encoding='utf-8') as handle:
            handle.write("load x.sdf\nlabel id 1, '128.44' # replaced\nlabel id 7, '7.26'\nbg_color black\n")
        labels = parse_pymol_label_file(pml)
        report.detail(f"PyMOL labels parsed: {labels}")
        report.check("PyMOL shift labels parse, comments stripped",
                     labels == {1: '128.44', 7: '7.26'}, {1: '128.44', 7: '7.26'}, labels)
    except Exception as error:
        report.error("structure viewer", error)

    # ---------------------------------------------------------------- report
    destination = os.path.join(output_directory or os.getcwd(), SELF_TEST_REPORT_NAME)
    written = report.write(destination)

    print("=" * 70)
    print(f"{report.passed} passed, {report.failed} failed")
    if written:
        print(f"Detailed report written to: {destination}")
    print("Send that file if anything failed, or to have the run checked over.")

    shutil.rmtree(workspace, ignore_errors=True)
    return report.failed

def launch_workbench():
    # Load methods and machine profiles before any widget is built, since the dropdowns are populated from them
    global WORKBENCH_METHODS, WORKBENCH_MACHINES, WORKBENCH_CONFIG_PATH, WORKBENCH_CONFIG_PROBLEMS
    WORKBENCH_CONFIG_PATH = workbench_config_path()
    WORKBENCH_METHODS, WORKBENCH_MACHINES, WORKBENCH_CONFIG_PROBLEMS = load_workbench_config(WORKBENCH_CONFIG_PATH)

    if not NUMPY_AVAILABLE:
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showwarning(
                "numpy missing",
                "numpy is not installed in this Python interpreter. The analysis tab will not work.\n\n"
                "The job setup tab will still run.")
            root.destroy()
        except Exception:
            print("numpy is not installed; the analysis tab will not work.")
    # Every worker pool is disabled from here on: see RUNNING_UNDER_GUI. Set before the window is built so a
    # run started immediately after startup is already covered.
    global RUNNING_UNDER_GUI
    RUNNING_UNDER_GUI = True

    app = WorkbenchApp()
    app.mainloop()


def _run_from_command_line():
    """
    Handle --self-test before any window is created.

    Kept out of main() so the checks run without a display: they exercise pure logic, and requiring a working
    Tk to verify the chemistry would defeat the purpose on a machine where the interface is what needs
    diagnosing.
    """
    if '--self-test' in sys.argv:
        freeze_support()
        raise SystemExit(1 if run_self_test() else 0)


if __name__ == '__main__':
    # Required before anything spawns a worker process. Windows has no fork, so each pool worker re-launches
    # this file and re-imports it; without this call that re-import can recursively spawn further processes.
    # In a .pyw there is no console, so the failure appears as a window that simply never responds, with no
    # error text anywhere -- which is why this is called unconditionally rather than only where a pool is used.
    _run_from_command_line()
    freeze_support()
    launch_workbench()
