$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    & cargo build --locked --release --target x86_64-pc-windows-msvc
    if ($LASTEXITCODE -ne 0) { throw 'Rust build failed.' }
    & cargo test --locked --release --target x86_64-pc-windows-msvc
    if ($LASTEXITCODE -ne 0) { throw 'Rust regression checks failed.' }
    $targetDir = if ($env:CARGO_TARGET_DIR) { $env:CARGO_TARGET_DIR } else { 'target' }
    $binary = Join-Path $targetDir 'x86_64-pc-windows-msvc\release\tensor.exe'
    $check = Start-Process -FilePath (Resolve-Path $binary).Path -ArgumentList '--self-test' -NoNewWindow -Wait -PassThru
    if ($check.ExitCode -ne 0) { throw 'Scientific or interface checks failed.' }
    $artifactDir = 'dist\TENSOR-1.0.0-public-windows'
    New-Item -ItemType Directory -Force -Path $artifactDir | Out-Null
    $configTarget = Join-Path $artifactDir 'tensor_config.txt'
    # Public test packages deliberately start from the shipped TENSOR defaults.
    Copy-Item 'assets\tensor_config.txt' -Destination $configTarget -Force
    Copy-Item $binary, 'README.md', 'CHANGES.md', 'AUDIT.md', 'VALIDATION.md', 'SPECTRA.md', 'THIRD_PARTY_NOTICES.md' -Destination $artifactDir -Force
    Copy-Item 'third-party-licenses' -Destination $artifactDir -Recurse -Force
    Write-Host "Built $artifactDir\tensor.exe"
} finally {
    Pop-Location
}
