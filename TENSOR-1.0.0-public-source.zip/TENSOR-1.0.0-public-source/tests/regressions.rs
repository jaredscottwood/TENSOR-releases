use std::{
    fs,
    path::PathBuf,
    sync::atomic::{AtomicUsize, Ordering},
};
use tensor::{
    analysis::*,
    config::*,
    gaussian::*,
    jobs::*,
    molecule::*,
    symmetry::*,
    verification::{ETHANOL_LOGS, ethanol_logs, quiet},
};
static SEQ: AtomicUsize = AtomicUsize::new(0);
struct Temp(PathBuf);
impl Temp {
    fn new() -> Self {
        let p = std::env::temp_dir().join(format!(
            "tensor-test-{}-{}",
            std::process::id(),
            SEQ.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir_all(&p).unwrap();
        Self(p)
    }
}
impl Drop for Temp {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

#[test]
fn supplied_logo_decodes_and_rounded_icons_have_alpha() {
    let (width, height, rounded) = tensor::branding::rounded().unwrap();
    assert_eq!(rounded[3], 0);
    assert_eq!(rounded[((height / 2) * width + width / 2) * 4 + 3], 255);
    let icon = tensor::branding::icon(128).unwrap();
    assert_eq!((icon.width, icon.height), (128, 128));
    assert_eq!(icon.rgba[3], 0);
    assert_eq!(icon.rgba[(64 * 128 + 64) * 4 + 3], 255);
    assert!(
        icon.rgba
            .chunks_exact(4)
            .any(|p| p[1] > 160 && p[2] > 160 && p[0] < 100)
    );
    let tmp = Temp::new();
    tensor::branding::write_icons(&tmp.0).unwrap();
    let ico = fs::read(tmp.0.join("tensor.ico")).unwrap();
    assert_eq!(&ico[..6], &[0, 0, 1, 0, 6, 0]);
}

#[test]
fn setup_overlay_combines_every_cluster_conformer() {
    use tensor::viewer::Viewer;
    let first = parse_sdf(include_str!("fixtures/sdf/ethanol_1.sdf")).unwrap();
    let second = parse_sdf(include_str!("fixtures/sdf/ethanol_2.sdf")).unwrap();
    let single_solids = tensor::render3d::Scene::from_molecule(&first, &first.coords())
        .solids
        .len();
    let mut viewer = Viewer::default();
    viewer.load_overlay(&[&first, &second]);
    assert_eq!(
        viewer.coordinates.len(),
        first.atoms.len() + second.atoms.len()
    );
    assert_eq!(viewer.scene.solids.len(), single_solids * 2);
    assert!(
        viewer.labels.is_empty()
            && viewer.label_mode == tensor::viewer::LabelMode::None
            && viewer.selected_atoms.is_empty()
    );
}

#[test]
fn analysis_viewer_picks_in_screen_space_and_measures_ordered_atoms() {
    use eframe::egui::{Pos2, Rect, Vec2};
    use tensor::viewer::{SelectionMeasurement, Viewer};

    let atom = |element: &str, xyz| Atom {
        element: element.into(),
        xyz,
        ..Default::default()
    };
    let molecule = Molecule {
        title: "selection fixture".into(),
        atoms: vec![
            atom("C", [0., 0., 0.]),
            atom("C", [1., 0., 0.]),
            atom("N", [1., 1., 0.]),
            atom("O", [2., 1., 1.]),
            atom("H", [3., 1., 1.]),
        ],
        bonds: [(pair(0, 1), 1.), (pair(1, 2), 1.), (pair(2, 3), 1.)].into(),
    };
    let rect = Rect::from_min_size(Pos2::ZERO, Vec2::new(500., 400.));
    let mut viewer = Viewer::default();
    viewer.load(&molecule, Default::default());
    viewer.rotation = tensor::math::IDENTITY;
    viewer.zoom = 55.;
    viewer.pan = [0.; 2];
    viewer.fit_next = false;

    for expected in 0..4 {
        let position = viewer.atom_screen_position(expected, rect).unwrap();
        assert_eq!(viewer.select_nearest_atom(position, rect), Some(expected));
    }
    assert_eq!(viewer.selected_atoms, vec![0, 1, 2, 3]);
    match viewer.selection_measurement().unwrap() {
        SelectionMeasurement::Dihedral { atoms, degrees } => {
            assert_eq!(atoms, [0, 1, 2, 3]);
            assert!(degrees.is_finite() && degrees.abs() <= 180.);
        }
        measurement => panic!("unexpected four-atom measurement: {measurement:?}"),
    }

    let fifth = viewer.atom_screen_position(4, rect).unwrap();
    assert_eq!(viewer.select_nearest_atom(fifth, rect), Some(4));
    assert_eq!(viewer.selected_atoms, vec![0, 1, 2, 3]);
    let third = viewer.atom_screen_position(2, rect).unwrap();
    viewer.select_nearest_atom(third, rect);
    assert_eq!(viewer.selected_atoms, vec![0, 1, 3]);
    assert_eq!(
        viewer.selection_measurement(),
        Some(SelectionMeasurement::NotConnected)
    );

    viewer.selected_atoms = vec![0, 1];
    match viewer.selection_measurement().unwrap() {
        SelectionMeasurement::Distance { angstrom, .. } => {
            assert!((angstrom - 1.).abs() < 1e-12)
        }
        measurement => panic!("unexpected distance measurement: {measurement:?}"),
    }
    viewer.selected_atoms.push(2);
    match viewer.selection_measurement().unwrap() {
        SelectionMeasurement::Angle { degrees, .. } => {
            assert!((degrees - 90.).abs() < 1e-12)
        }
        measurement => panic!("unexpected angle measurement: {measurement:?}"),
    }

    viewer.load(&molecule, Default::default());
    assert!(viewer.selected_atoms.is_empty());

    let overlap = Molecule {
        title: "depth tie fixture".into(),
        atoms: vec![atom("C", [0., 0., -1.]), atom("O", [0., 0., 1.])],
        bonds: Default::default(),
    };
    viewer.load(&overlap, Default::default());
    viewer.rotation = tensor::math::IDENTITY;
    viewer.zoom = 50.;
    viewer.pan = [0.; 2];
    viewer.fit_next = false;
    assert_eq!(viewer.select_nearest_atom(rect.center(), rect), Some(1));
}

#[test]
fn transparent_figure_exports_preserve_pixels_dpi_and_label_choice() {
    use tensor::{
        figure::{self, FigureOptions, Format},
        viewer::Viewer,
    };
    let tmp = Temp::new();
    let molecule = parse_sdf(include_str!("fixtures/sdf/ethanol_1.sdf")).unwrap();
    let mut viewer = Viewer::default();
    viewer.load(&molecule, [(0, "18.40".to_string())].into());
    viewer.fit(800., 600.);
    let options = FigureOptions {
        width: 400,
        labels: false,
        ..Default::default()
    };
    let path = figure::export(&viewer, &options, &tmp.0.join("structure")).unwrap();
    assert_eq!(path.extension().unwrap(), "png");
    let mut decoder = png::Decoder::new(std::io::BufReader::new(fs::File::open(&path).unwrap()))
        .read_info()
        .unwrap();
    let size = decoder.output_buffer_size().unwrap();
    let mut plain = vec![0; size];
    let info = decoder.next_frame(&mut plain).unwrap();
    assert_eq!(
        (info.width, info.height, info.color_type),
        (400, 300, png::ColorType::Rgba)
    );
    assert_eq!(plain[3], 0);
    assert!(plain.chunks_exact(4).any(|p| p[3] == 255));
    assert!(plain.chunks_exact(4).any(|p| p[3] > 0 && p[3] < 255));
    let physical = decoder.info().pixel_dims.unwrap();
    assert_eq!(
        (physical.xppu, physical.yppu, physical.unit),
        (11811, 11811, png::Unit::Meter)
    );
    let labeled = figure::export(
        &viewer,
        &FigureOptions {
            labels: true,
            ..options.clone()
        },
        &tmp.0.join("labels.png"),
    )
    .unwrap();
    assert_ne!(fs::read(path).unwrap(), fs::read(labeled).unwrap());
    let svg = figure::export(
        &viewer,
        &FigureOptions {
            format: Format::Svg,
            labels: true,
            ..options.clone()
        },
        &tmp.0.join("labels.svg"),
    )
    .unwrap();
    let svg = fs::read_to_string(svg).unwrap();
    assert!(
        svg.contains("data:image/png;base64,")
            && svg.contains("depth-tested chemical-shift labels: 18.40")
    );
    viewer.label_mode = tensor::viewer::LabelMode::AtomNumbers;
    let numbered_svg = figure::export(
        &viewer,
        &FigureOptions {
            format: Format::Svg,
            labels: true,
            ..options.clone()
        },
        &tmp.0.join("atom-numbers.svg"),
    )
    .unwrap();
    let numbered_svg = fs::read_to_string(numbered_svg).unwrap();
    assert!(
        numbered_svg.contains("depth-tested atom-number labels:")
            && numbered_svg.contains("1, 2, 3")
    );
    let pdf = figure::export(
        &viewer,
        &FigureOptions {
            format: Format::Pdf,
            ..options.clone()
        },
        &tmp.0.join("structure.pdf"),
    )
    .unwrap();
    let pdf = fs::read(pdf).unwrap();
    let text = String::from_utf8_lossy(&pdf);
    assert!(
        text.starts_with("%PDF-1.4")
            && text.contains("/MediaBox [0 0 96.000000 72.000000]")
            && text.contains("/SMask")
    );
    assert!(figure::export(&viewer, &options, &tmp.0.join("wrong.svg")).is_err());
}

#[test]
fn regeneration_replaces_existing_outputs_and_removes_stale_files() {
    let tmp = Temp::new();
    let p = quiet();
    fs::write(tmp.0.join("notes.txt"), "outside generated paths").unwrap();
    fs::write(tmp.0.join("stale.txt"), "old untracked export").unwrap();
    let first = vec![
        OutputFile::new("data/value.txt", "first".into()),
        OutputFile::new("stale.txt", "now tracked".into()),
    ];
    commit_files(&tmp.0, "test", &first, &p).unwrap();
    fs::write(tmp.0.join("data/value.txt"), "user edit").unwrap();
    commit_files(
        &tmp.0,
        "test",
        &[OutputFile::new("data/value.txt", "new".into())],
        &p,
    )
    .unwrap();
    assert_eq!(
        fs::read_to_string(tmp.0.join("data/value.txt")).unwrap(),
        "new"
    );
    assert!(!tmp.0.join("stale.txt").exists());
    assert!(tmp.0.join("notes.txt").exists());
    assert!(
        commit_files(
            &tmp.0,
            "test",
            &[OutputFile::new("../outside.txt", "bad".into())],
            &p
        )
        .is_err()
    );
}
#[test]
fn analysis_replaces_complete_folder_but_cancellation_preserves_previous_results() {
    let tmp = Temp::new();
    let root = tmp.0.join("compound");
    fs::create_dir(&root).unwrap();
    fs::create_dir(root.join("stale")).unwrap();
    fs::write(root.join("stale/old.txt"), "obsolete").unwrap();
    let cancelled = quiet();
    cancelled.cancel.store(true, Ordering::Relaxed);
    let files = vec![OutputFile::new("new.txt", "fresh results".into())];
    assert!(replace_result_directory(&root, &files, &[], &cancelled).is_err());
    assert!(root.join("stale/old.txt").exists());
    replace_result_directory(&root, &files, &[], &quiet()).unwrap();
    assert!(!root.join("stale").exists());
    assert_eq!(
        fs::read_to_string(root.join("new.txt")).unwrap(),
        "fresh results"
    );
    let input = root.join("input.log");
    fs::write(&input, "a calculation").unwrap();
    assert!(
        replace_result_directory(&root, &files, std::slice::from_ref(&input), &quiet()).is_err()
    );
    assert!(input.exists());
}
#[test]
fn setup_replaces_unmanaged_python_jobs_and_retires_unselected_conformers() {
    let tmp = Temp::new();
    let folder = tmp.0.join("gjf_files");
    fs::create_dir(&folder).unwrap();
    for name in [
        "ethanol_1.gjf",
        "ethanol_99.gjf",
        "ethanol-csulfur_99.gjf",
        "other_1.gjf",
    ] {
        fs::write(folder.join(name), "old job").unwrap();
    }
    let files = vec![PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("examples/sdf/ethanol_1.sdf")];
    let (inputs, errors) = load_inputs(&files);
    assert!(errors.is_empty());
    let settings = [("ethanol".into(), JobSettings::default())].into();
    run_setup(
        &inputs,
        &settings,
        &Config::parse(DEFAULT_CONFIG).unwrap(),
        &tmp.0,
        &quiet(),
    )
    .unwrap();
    assert!(
        fs::read_to_string(folder.join("ethanol_1.gjf"))
            .unwrap()
            .contains("nmr")
    );
    assert!(!folder.join("ethanol_99.gjf").exists());
    assert!(!folder.join("ethanol-csulfur_99.gjf").exists());
    assert!(folder.join("other_1.gjf").exists());
}
#[test]
fn every_nucleus_uses_explicit_title_scaling_without_method_fallback() {
    let text = include_str!("fixtures/logs/multinuc_1.log");
    let changed = text
        .replace("fluorine s:-0.924 i:207.78", "fluorine s:-2.0 i:180.0")
        .replace("nitrogen s:-0.9776 i:253.23", "nitrogen s:-3.0 i:240.0");
    let log = parse_log_text(
        &changed,
        std::path::Path::new("multinuc_1.log"),
        "multinuc",
        1,
    )
    .unwrap();
    assert_eq!(log.scaling["fluorine"], Scaling::new(-2., 180.));
    assert_eq!(log.scaling["nitrogen"], Scaling::new(-3., 240.));
    let temp = Temp::new();
    let c = analyze_compound(
        "multinuc",
        vec![log.clone()],
        &AnalysisSettings::default(),
        &temp.0,
        &quiet(),
    )
    .unwrap();
    let (&index, &sigma) = log.shieldings["fluorine"].iter().next().unwrap();
    assert!((c.shifts[&index] - (sigma - 180.) / -2.).abs() < 1e-10);
    for (old, new) in [
        (
            "multinuc_1_carbon s:-1.0065 i:196.0386",
            "multinuc_1_1carbon",
        ),
        (
            "multinuc_1_proton s:-1.0311 i:32.2654",
            "multinuc_1_1proton",
        ),
        ("fluorine s:-0.924 i:207.78", "fluorine"),
        ("nitrogen s:-0.9776 i:253.23", "nitrogen"),
    ] {
        let log = parse_log_text(
            &text.replace(old, new),
            std::path::Path::new("multinuc_1.log"),
            "multinuc",
            1,
        )
        .unwrap();
        let err = analyze_compound(
            "multinuc",
            vec![log],
            &AnalysisSettings::default(),
            &temp.0,
            &quiet(),
        )
        .unwrap_err()
        .to_string();
        assert!(err.contains("scaling"), "{err}");
    }
}
#[test]
fn special_carbon_missing_title_scaling_never_uses_average_or_halogen_tables() {
    let tmp = Temp::new();
    let standard = parse_log_text(
        include_str!("fixtures/logs/multinuc_1.log"),
        std::path::Path::new("multinuc_1.log"),
        "multinuc",
        1,
    )
    .unwrap();
    for (kind, text) in [
        (
            "csulfur",
            include_str!("fixtures/logs/multinuc-csulfur_1.log").replace("s:-0.9124 i:193.639", ""),
        ),
        (
            "chalogen",
            include_str!("fixtures/logs/multinuc-chalogen_1.log")
                .replace("hal{1:s:-1.02,i:177.1|2:s:-1.07,i:207.3}", ""),
        ),
    ] {
        let log = parse_log_text(
            &text,
            &PathBuf::from(format!("multinuc-{kind}_1.log")),
            &format!("multinuc-{kind}"),
            1,
        )
        .unwrap();
        let error = analyze_compound(
            "multinuc",
            vec![standard.clone(), log],
            &AnalysisSettings::default(),
            &tmp.0,
            &quiet(),
        )
        .unwrap_err()
        .to_string();
        assert!(error.contains("scaling"), "{error}");
    }
}
#[test]
fn setup_defaults_and_default_machine_label_preserve_resources() {
    let settings = JobSettings::default();
    assert!(
        !settings.coupling
            && !settings.fluorine
            && !settings.nitrogen
            && !settings.sulfur
            && !settings.halogen
            && !settings.keep_split
            && !settings.keep_aligned
            && !settings.keep_clustered
    );
    let original = Config::parse(DEFAULT_CONFIG).unwrap();
    let custom =
        Config::parse(&DEFAULT_CONFIG.replace("label = Default", "label = Remote cluster"))
            .unwrap();
    assert_eq!(custom.machines["default"].label, "Default");
    assert_eq!(
        custom.machines["default"].chk,
        original.machines["default"].chk
    );
    assert_eq!(
        custom.machines["default"].rwf,
        original.machines["default"].rwf
    );
    assert_eq!(
        custom.machines["default"].tiers[1].cores,
        original.machines["default"].tiers[1].cores
    );
    let app = tensor::ui::Workbench::new(custom, PathBuf::from("config.txt"));
    assert!(!app.apply_all);
}
#[test]
fn manual_populations_renormalize_only_surviving_conformers() {
    let tmp = Temp::new();
    fs::write(
        tmp.0.join("ethanol_boltzmann.txt"),
        "Conformer 1: 60%\nConformer 2: 20%\nConformer 3: 20%\n",
    )
    .unwrap();
    let c = analyze_compound(
        "ethanol",
        ethanol_logs().unwrap(),
        &AnalysisSettings::default(),
        &tmp.0,
        &quiet(),
    )
    .unwrap();
    assert_eq!(c.conformers.len(), 2);
    assert!((c.conformers[0].population - 0.75).abs() < 1e-12);
    assert!((c.conformers[1].population - 0.25).abs() < 1e-12);
    fs::write(tmp.0.join("ethanol_boltzmann.txt"), "Conformer 1: -1%\n").unwrap();
    assert!(population_file(&tmp.0.join("ethanol_boltzmann.txt")).is_err());
    fs::write(tmp.0.join("ethanol_boltzmann.txt"), "Conformer 1: 0%\n").unwrap();
    assert!(population_file(&tmp.0.join("ethanol_boltzmann.txt")).is_err());
}
#[test]
fn frequency_gate_prevents_geometry_only_merge() {
    let logs = ethanol_logs().unwrap();
    let a = &logs[0];
    let b = &logs[1];
    let input = |l: &GaussianLog| DedupInput {
        number: l.number,
        energy: l.energy,
        coordinates: l.molecule.coords(),
        frequencies: l.frequencies.values.clone(),
    };
    let mut changed = input(b);
    changed.frequencies.iter_mut().for_each(|x| *x += 4.);
    assert!(
        deduplicate(&a.molecule, &[input(a), changed], true, &quiet())
            .unwrap()
            .duplicates
            .is_empty()
    );
    let d = deduplicate(&a.molecule, &[input(a), input(b)], true, &quiet()).unwrap();
    assert_eq!(d.duplicates.len(), 1);
    assert!(
        deduplicate(&a.molecule, &[input(a), input(b)], false, &quiet())
            .unwrap()
            .duplicates
            .is_empty()
    );
}
#[test]
fn missing_couplings_are_reported_without_zero_filled_weighting() {
    let tmp = Temp::new();
    let mut logs = ethanol_logs().unwrap();
    logs[2].couplings.clear();
    let c = analyze_compound(
        "ethanol",
        logs,
        &AnalysisSettings::default(),
        &tmp.0,
        &quiet(),
    )
    .unwrap();
    assert!(c.couplings.is_empty());
    assert!(!c.conformers[0].couplings.is_empty());
    assert!(
        c.warnings
            .iter()
            .any(|s| s.contains("coupling") || s.contains("Coupling"))
    );
}
#[test]
fn equivalence_averaging_cannot_hide_a_missing_raw_atom() {
    let tmp = Temp::new();
    let mut logs = ethanol_logs().unwrap();
    logs[2].shieldings.get_mut("proton").unwrap().remove(&3);
    assert!(
        analyze_compound(
            "ethanol",
            logs,
            &AnalysisSettings::default(),
            &tmp.0,
            &quiet()
        )
        .is_err()
    );
}
#[test]
fn configuration_roundtrip_and_invalid_scaling() {
    let tmp = Temp::new();
    let path = tmp.0.join("new/folder/config.txt");
    let _ = Config::load(&path).unwrap();
    let custom = format!(
        "{DEFAULT_CONFIG}\n[method:custom]\nlabel = Custom method\nopt_basis = 6-31g(d)\ncarbon_basis = def2svp\nproton_basis = 6-31g(d)\nopt_route = # b3lyp/{{opt_basis}}\ncarbon_route = # nmr=giao b3lyp/{{carbon_basis}} geom=check guess=read\nproton_route = # nmr=giao b3lyp/{{proton_basis}} geom=check guess=read\ncarbon_slope = -1\ncarbon_intercept = 190\nproton_slope = -1\nproton_intercept = 32\n[machine:portable]\nlabel = Portable\nchk = %chk={{compound}}_{{conformer}}.chk\nrwf =\ntier.local = 4, 8GB\n"
    );
    fs::write(&path, &custom).unwrap();
    let config = Config::load(&path).unwrap();
    assert_eq!(fs::read_to_string(&path).unwrap(), custom);
    let molecule = parse_sdf(include_str!("fixtures/sdf/ethanol_1.sdf")).unwrap();
    let settings = JobSettings {
        method: "custom".into(),
        machine: "portable".into(),
        tier: "local".into(),
        ..Default::default()
    };
    let s = generate_input(&config, &settings, &molecule, "x", "1", None, false).unwrap();
    assert!(!s.contains("%rwf"));
    assert!(s.contains("pop=nboread"));
    assert!(s.contains("s:-1.0 i:190.0"));
    assert!(Scaling::new(0., 190.).apply(25.).is_err());
}
#[test]
fn truncated_last_geometry_and_final_job_are_rejected() {
    let text = format!(
        "{}\n Standard orientation:\n ------\n Center Atomic Atomic Coordinates\n Number Number Type X Y Z\n ------\n 1 6 0 0.0 0.0 0.0\n",
        ETHANOL_LOGS[0]
    );
    assert!(parse_log_text(&text, &PathBuf::from("ethanol_1.log"), "ethanol", 1).is_err());
    let final_text = ETHANOL_LOGS[0].rsplit_once("Normal termination").unwrap().0;
    assert!(
        !parse_log_text(final_text, &PathBuf::from("ethanol_1.log"), "ethanol", 1)
            .unwrap()
            .valid()
    );
}
#[test]
fn v2000_charge_and_isotope_property_records() {
    let text = "test\nprogram\n\n  2  1  0  0  0  0            999 V2000\n    0.0000    0.0000    0.0000 N   0  0  0  0  0  0  0  0  0  0  0  0\n    1.0000    0.0000    0.0000 H   0  0  0  0  0  0  0  0  0  0  0  0\n  1  2  1  0  0  0  0\nM  CHG  1   1   1\nM  ISO  1   2   2\nM  END\n$$$$\n";
    let m = parse_sdf(text).unwrap();
    assert_eq!(m.atoms[0].charge, 1);
    assert_eq!(m.atoms[1].isotope, 2);
    assert!(m.same_topology(&parse_sdf(&v3000(&m, "test", 1, None)).unwrap()));
}

#[test]
fn blank_setup_destination_writes_beside_source_conformers() {
    let tmp = Temp::new();
    let source = tmp.0.join("inputs/ethanol_1.sdf");
    fs::create_dir_all(source.parent().unwrap()).unwrap();
    fs::copy("tests/fixtures/sdf/ethanol_1.sdf", &source).unwrap();
    let (items, errors) = load_inputs(&[source]);
    assert!(errors.is_empty());
    let result = run_setup_beside(
        &items,
        &[("ethanol".into(), JobSettings::default())].into(),
        &Config::default(),
        &quiet(),
    )
    .unwrap();
    assert!(!result.paths.is_empty());
    let expected = tmp.0.join("inputs/gjf_files").canonicalize().unwrap();
    assert!(
        result
            .paths
            .iter()
            .all(|path| path.starts_with(&expected))
    );
}

#[test]
fn beside_destination_rejects_one_compound_spanning_folders() {
    let tmp = Temp::new();
    let first = tmp.0.join("a/ethanol_1.sdf");
    let second = tmp.0.join("b/ethanol_2.sdf");
    fs::create_dir_all(first.parent().unwrap()).unwrap();
    fs::create_dir_all(second.parent().unwrap()).unwrap();
    fs::copy("tests/fixtures/sdf/ethanol_1.sdf", &first).unwrap();
    fs::copy("tests/fixtures/sdf/ethanol_2.sdf", &second).unwrap();
    let (items, errors) = load_inputs(&[first, second]);
    assert!(errors.is_empty());
    let error = run_setup_beside(
        &items,
        &[("ethanol".into(), JobSettings::default())].into(),
        &Config::default(),
        &quiet(),
    )
    .unwrap_err();
    assert!(format!("{error:#}").contains("multiple source folders"));
}
