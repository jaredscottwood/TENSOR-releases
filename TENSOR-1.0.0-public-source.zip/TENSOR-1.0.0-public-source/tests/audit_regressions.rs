use std::{
    fs,
    path::PathBuf,
    sync::atomic::{AtomicUsize, Ordering},
};
use tensor::{
    analysis::*,
    config::*,
    gaussian::*,
    jobs::*,
    molecule::*,
    symmetry::*,
    ui::Workbench,
    verification::{ETHANOL_LOGS, ethanol_logs, quiet},
};

static SEQUENCE: AtomicUsize = AtomicUsize::new(0);
struct Temp(PathBuf);
impl Temp {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!(
            "tensor-audit-{}-{}",
            std::process::id(),
            SEQUENCE.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir_all(&path).unwrap();
        Self(path)
    }
}
impl Drop for Temp {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

#[test]
fn configured_f_n_s_i_and_cl_factors_reach_gaussian_titles() {
    let mut config = Config::default();
    let method = config.methods.get_mut("1").unwrap();
    for (key, value) in [
        ("fluorine_slope", "-2"),
        ("fluorine_intercept", "180"),
        ("nitrogen_slope", "-3"),
        ("nitrogen_intercept", "240"),
        ("sulfur_slope", "-4"),
        ("sulfur_intercept", "170"),
        ("iodine_1_slope", "-5"),
        ("iodine_1_intercept", "120"),
        ("chlorine_1_slope", "-6"),
        ("chlorine_1_intercept", "220"),
    ] {
        method.insert(key.into(), value.into());
    }
    let molecule = parse_log_text(
        include_str!("fixtures/logs/multinuc_1.log"),
        &PathBuf::from("multinuc_1.log"),
        "multinuc",
        1,
    )
    .unwrap()
    .molecule;
    let settings = JobSettings {
        fluorine: true,
        nitrogen: true,
        sulfur: true,
        halogen: true,
        ..Default::default()
    };
    let job = generate_input(&config, &settings, &molecule, "multinuc", "1", None, false).unwrap();
    assert!(job.contains("multinuc_1_fluorine s:-2.0 i:180.0"));
    assert!(job.contains("multinuc_1_nitrogen s:-3.0 i:240.0"));
    let sulfur = generate_input(
        &config,
        &settings,
        &molecule,
        "multinuc",
        "1",
        Some("csulfur"),
        false,
    )
    .unwrap();
    assert!(sulfur.contains("multinuc-csulfur_1_carbon s:-4.0 i:170.0"));
    let halogen = generate_input(
        &config,
        &settings,
        &molecule,
        "multinuc",
        "1",
        Some("chalogen"),
        false,
    )
    .unwrap();
    assert!(halogen.contains("1:s:-5.0,i:120.0"));
    assert!(halogen.contains("2:s:-6.0,i:220.0"));
    config
        .methods
        .get_mut("1")
        .unwrap()
        .remove("nitrogen_intercept");
    assert!(generate_input(&config, &settings, &molecule, "multinuc", "1", None, false).is_err());
}

#[test]
fn bundled_methods_expose_complete_scaling_inventory_and_provenance() {
    let config = Config::default();
    let pairs = [
        "carbon",
        "proton",
        "fluorine",
        "nitrogen",
        "sulfur",
        "chlorine_1",
        "chlorine_2",
        "chlorine_3",
        "bromine_1",
        "bromine_2",
        "bromine_3",
        "iodine_1",
        "iodine_2",
        "iodine_3",
    ];
    for (name, method) in &config.methods {
        assert!(
            method
                .get("scaling_provenance")
                .is_some_and(|value| !value.is_empty()),
            "method {name} lacks provenance"
        );
        assert!(
            method
                .get("sulfur_calculation_reference")
                .is_some_and(|value| value.contains("10.1002/jcc.23638")),
            "method {name} lacks the sulfur-calculation reference"
        );
        assert!(
            method
                .get("halogen_calculation_reference")
                .is_some_and(|value| value.contains("10.1039/B206245C")),
            "method {name} lacks the halogen-calculation reference"
        );
        for pair in pairs {
            assert!(method.contains_key(&format!("{pair}_slope")));
            assert!(method.contains_key(&format!("{pair}_intercept")));
        }
    }
}

#[test]
fn editable_method_fields_control_standard_special_and_iodine_inputs() {
    let mut config = Config::default();
    let method = config.methods.get_mut("1").unwrap();
    for (key, value) in [
        ("solvent", "testsolvent"),
        ("carbon_functional", "pbe0"),
        ("carbon_basis", "test-carbon-basis"),
        ("carbon_keywords", "scf=tight geom=check guess=read"),
        ("carbon_slope", "-7"),
        ("carbon_intercept", "211"),
        ("sulfur_carbon_functional", "m06"),
        ("sulfur_carbon_basis", "test-sulfur-basis"),
        ("sulfur_carbon_keywords", "scf=xqc geom=check guess=read"),
        ("halogen_opt_functional", "pbe1pbe"),
        ("iodine_basis", "test-iodine"),
    ] {
        method.insert(key.into(), value.into());
    }
    config.basis_blocks.insert(
        "test-iodine".into(),
        "I 0\nS 1 1.00\n  1.0  1.0\n****".into(),
    );

    let ethanol = parse_sdf(include_str!("fixtures/sdf/ethanol_1.sdf")).unwrap();
    let standard = generate_input(
        &config,
        &JobSettings::default(),
        &ethanol,
        "editable",
        "1",
        None,
        false,
    )
    .unwrap();
    assert!(standard.contains("# nmr=giao pbe0/test-carbon-basis scf=tight"));
    assert!(standard.contains("scrf=(iefpcm,solvent=testsolvent)"));
    assert!(standard.contains("editable_1_carbon s:-7.0 i:211.0"));

    let iodine = parse_log_text(
        include_str!("fixtures/logs/multinuc_1.log"),
        &PathBuf::from("multinuc_1.log"),
        "multinuc",
        1,
    )
    .unwrap()
    .molecule;
    let sulfur = generate_input(
        &config,
        &JobSettings::default(),
        &iodine,
        "editable",
        "1",
        Some("csulfur"),
        false,
    )
    .unwrap();
    assert!(sulfur.contains("# nmr=giao m06/gen scf=xqc"));
    assert!(sulfur.contains("C 0\ntest-sulfur-basis\n****"));
    assert!(sulfur.contains("I 0\nS 1 1.00\n  1.0  1.0\n****"));
    let halogen = generate_input(
        &config,
        &JobSettings::default(),
        &iodine,
        "editable",
        "1",
        Some("chalogen"),
        false,
    )
    .unwrap();
    assert!(halogen.contains("# opt freq=noraman temperature=298.0 pbe1pbe/gen"));
}

#[test]
fn loading_an_old_builtin_method_adds_new_visible_fields_without_overwriting() {
    let tmp = Temp::new();
    let path = tmp.0.join("tensor_config.txt");
    let legacy = r#"[method:1]
label = My retained method
opt_basis = 6-31g(d)
carbon_basis = 6-31g(d)
proton_basis = 6-31g(d)
opt_route = # opt b3lyp/{opt_basis}
carbon_route = # nmr=giao b3lyp/{carbon_basis} geom=check guess=read
proton_route = # nmr=giao b3lyp/{proton_basis} geom=check guess=read
carbon_slope = -8
carbon_intercept = 222

[machine:default]
label = My machine
chk = %chk={compound}_{conformer}.chk
rwf =
tier.medium = 4, 8GB
"#;
    fs::write(&path, legacy).unwrap();
    let config = Config::load(&path).unwrap();
    let upgraded = fs::read_to_string(&path).unwrap();
    assert_eq!(config.methods["1"]["label"], "My retained method");
    assert_eq!(config.scaling("1", "carbon").unwrap().unwrap().slope, -8.);
    for field in [
        "carbon_functional",
        "proton_slope",
        "fluorine_slope",
        "nitrogen_slope",
        "sulfur_carbon_route",
        "halogen_carbon_route",
        "iodine_basis",
        "sulfur_calculation_reference",
        "halogen_calculation_reference",
    ] {
        assert!(config.methods["1"].contains_key(field), "missing {field}");
    }
    assert!(upgraded.contains("[basis:iodine_midix]"));
    assert_eq!(
        fs::read_to_string(tmp.0.join(format!(
            "tensor_config.txt.pre-{}.bak",
            env!("CARGO_PKG_VERSION")
        )))
        .unwrap(),
        legacy
    );
    Config::load(&path).unwrap();
    assert_eq!(fs::read_to_string(&path).unwrap(), upgraded);
}

#[test]
fn scaling_rejects_nonfinite_observations_and_overflow() {
    assert!(Scaling::new(-1., 190.).apply(f64::NAN).is_err());
    assert!(Scaling::new(f64::MIN_POSITIVE, 0.).apply(f64::MAX).is_err());
    assert_eq!(Scaling::new(-2., 190.).apply(150.).unwrap(), 20.);
}

#[test]
fn continued_v3000_coordinates_preserve_atom_properties_and_record_data() {
    let sdf = "continued\nprogram\ncomment\n  0  0  0  0  0  0            999 V3000\nM  V30 BEGIN CTAB\nM  V30 COUNTS 3 2 0 0 0\nM  V30 BEGIN ATOM\nM  V30 7 N 0.0 0.0 -\nM  V30 0.0 0 CHG=1 -\nM  V30 MASS=15\nM  V30 12 C 1.0 0.0 0.0 0\nM  V30 99 H 0.0 1.0 0.0 0\nM  V30 END ATOM\nM  V30 BEGIN BOND\nM  V30 1 1 7 12\nM  V30 2 1 7 99\nM  V30 END BOND\nM  V30 END CTAB\nM  END\n> <note>\nPreserve this record.\n\n$$$$\n";
    let before = parse_sdf(sdf).unwrap();
    let coordinates = [[2., 3., 4.], [3., 3., 4.], [2., 4., 4.]];
    let rewritten = rewrite_coordinates(sdf, &coordinates).unwrap();
    let after = parse_sdf(&rewritten).unwrap();
    assert!(before.same_topology(&after));
    assert_eq!(after.coords(), coordinates);
    assert_eq!((after.atoms[0].charge, after.atoms[0].isotope), (1, 15));
    assert!(rewritten.contains("Preserve this record."));
    assert!(rewritten.contains("M  V30 1 1 7 12"));
    let v2000 = "plain\nprogram\ncomment\n  1  0  0  0  0  0            999 V2000\n    0.0000    0.0000    0.0000 H   0  0  0  0  0  0  0  0  0  0  0  0\nM  END\n$$$$\n";
    for structure in [v2000, include_str!("fixtures/sdf/ethanol_1.sdf")] {
        let with_data = structure.replace(
            "$$$$",
            "> <note>\nM  CHG  1   1   9\nM  V30 BEGIN ATOM\nM  V30 arbitrary property text -\nkeep this literally\n\n$$$$",
        );
        let parsed = parse_sdf(&with_data).unwrap();
        assert_eq!(parsed.charge(), parse_sdf(structure).unwrap().charge());
        let coordinates = parsed.coords();
        let rewritten = rewrite_coordinates(&with_data, &coordinates).unwrap();
        assert!(rewritten.contains("M  V30 arbitrary property text -\nkeep this literally"));
        assert_eq!(parse_sdf(&rewritten).unwrap().coords(), coordinates);
    }
}

#[test]
fn tiny_ensembles_still_require_matching_atom_identities() {
    let molecule = |element: &str| Molecule {
        atoms: vec![
            Atom {
                element: "H".into(),
                ..Default::default()
            },
            Atom {
                element: element.into(),
                xyz: [1., 0., 0.],
                ..Default::default()
            },
        ],
        bonds: [((0, 1), 1.)].into(),
        ..Default::default()
    };
    let mut inputs: Vec<_> = [molecule("H"), molecule("F")]
        .into_iter()
        .enumerate()
        .map(|(i, molecule)| ConformerInput {
            compound: "tiny".into(),
            number: i + 1,
            source: PathBuf::from(format!("tiny_{}.sdf", i + 1)),
            sdf: v3000(&molecule, "tiny", i + 1, None),
            molecule,
            split: false,
        })
        .collect();
    assert!(align_inputs(&mut inputs).is_err());
}

#[test]
fn setup_never_retires_its_loaded_sdf_inputs() {
    let tmp = Temp::new();
    let source = tmp.0.join("aligned_conformers/ethanol/ethanol_1.sdf");
    fs::create_dir_all(source.parent().unwrap()).unwrap();
    fs::write(&source, include_str!("fixtures/sdf/ethanol_1.sdf")).unwrap();
    fs::create_dir(tmp.0.join("gjf_files")).unwrap();
    let previous = tmp.0.join("gjf_files/ethanol_99.gjf");
    fs::write(&previous, "previous job").unwrap();
    let (inputs, errors) = load_inputs(std::slice::from_ref(&source));
    assert!(errors.is_empty());
    let result = run_setup(
        &inputs,
        &[("ethanol".into(), JobSettings::default())].into(),
        &Config::default(),
        &tmp.0,
        &quiet(),
    );
    assert!(result.is_err());
    assert!(source.is_file());
    assert_eq!(fs::read_to_string(previous).unwrap(), "previous job");
}

#[test]
fn analysis_preserves_selected_logs_even_when_they_fail_to_parse() {
    let tmp = Temp::new();
    let valid = tmp.0.join("ethanol_1.log");
    fs::write(&valid, ETHANOL_LOGS[0]).unwrap();
    let invalid = tmp.0.join("ethanol/broken.log");
    fs::create_dir(invalid.parent().unwrap()).unwrap();
    fs::write(&invalid, "original incomplete calculation").unwrap();
    let result = run_analysis(
        &[valid, invalid.clone()],
        &AnalysisSettings::default(),
        &quiet(),
    );
    assert!(result.is_err());
    assert_eq!(
        fs::read_to_string(invalid).unwrap(),
        "original incomplete calculation"
    );
}

#[test]
fn zero_population_conformers_do_not_suppress_weighted_couplings() {
    let tmp = Temp::new();
    fs::write(
        tmp.0.join("ethanol_boltzmann.txt"),
        "Conformer 1: 100%\nConformer 3: 0%\n",
    )
    .unwrap();
    let mut logs = ethanol_logs().unwrap();
    logs.retain(|l| l.number != 2);
    logs[0].couplings = [((0, 1), 12.0)].into();
    logs[1].couplings = [((0, 1), 11.0), ((0, 2), 3.0)].into();
    let c = analyze_compound(
        "ethanol",
        logs,
        &AnalysisSettings {
            dedup: false,
            ..Default::default()
        },
        &tmp.0,
        &quiet(),
    )
    .unwrap();
    assert_eq!(c.couplings, [((0, 1), 12.0)].into());
    assert_eq!(c.conformers.len(), 2); // Retain its unweighted observations.
}

#[test]
fn zero_population_conformers_may_use_different_scaling_without_changing_average() {
    let tmp = Temp::new();
    fs::write(
        tmp.0.join("ethanol_boltzmann.txt"),
        "Conformer 1: 100%\nConformer 3: 0%\n",
    )
    .unwrap();
    let mut logs = ethanol_logs().unwrap();
    logs.retain(|l| l.number != 2);
    logs[1]
        .scaling
        .insert("carbon".into(), Scaling::new(-2., 150.));
    let c = analyze_compound(
        "ethanol",
        logs,
        &AnalysisSettings {
            dedup: false,
            ..Default::default()
        },
        &tmp.0,
        &quiet(),
    )
    .unwrap();
    let populated = c.conformers.iter().find(|c| c.population == 1.).unwrap();
    assert_eq!(c.shifts, populated.shifts);
}

#[test]
fn saved_viewer_results_reject_labels_outside_the_structure() {
    let tmp = Temp::new();
    let root = tmp.0.join("ethanol");
    fs::create_dir_all(root.join("Conformer SDF Files")).unwrap();
    fs::write(
        root.join("Conformer SDF Files/ethanol_1.sdf"),
        include_str!("fixtures/sdf/ethanol_1.sdf"),
    )
    .unwrap();
    fs::write(
        root.join("ethanol_chemical_shifts.pml"),
        "label id 999, '12.34'\n",
    )
    .unwrap();
    let mut app = Workbench::new(Config::default(), tmp.0.join("config.txt"));
    assert!(app.open_results(&root).is_err());
    assert!(app.analysis.is_none());
}

#[test]
fn graph_matching_does_not_exchange_distinct_isotopes() {
    let points = [
        [0., 0., 0.],
        [1., 1., 1.],
        [1., -1., -1.],
        [-1., 1., -1.],
        [-1., -1., 1.],
    ];
    let molecule = Molecule {
        atoms: ["C", "H", "H", "F", "Cl"]
            .into_iter()
            .zip(points)
            .enumerate()
            .map(|(i, (element, xyz))| Atom {
                element: element.into(),
                xyz,
                isotope: if i == 2 { 2 } else { 0 },
                charge: 0,
            })
            .collect(),
        bonds: (1..5).map(|i| ((0, i), 1.)).collect(),
        ..Default::default()
    };
    let mut other = points;
    other.swap(1, 2);
    let (fit, _) = graph_superposition(&molecule, &points, &other, &quiet()).unwrap();
    assert!(fit.unwrap().rmsd > RMSD_LIMIT);
}

#[test]
fn saved_results_accept_scientific_notation_and_reject_nonfinite_labels() {
    let tmp = Temp::new();
    let root = tmp.0.join("ethanol");
    fs::create_dir_all(root.join("Conformer SDF Files")).unwrap();
    let molecule = parse_sdf(include_str!("fixtures/sdf/ethanol_1.sdf")).unwrap();
    let sdf = v3000(&molecule, "ethanol", 1, Some(-100.));
    fs::write(
        root.join("Conformer SDF Files/ethanol_1.sdf"),
        sdf.replace("-100.0000000000", "-1.0D+02"),
    )
    .unwrap();
    fs::write(
        root.join("ethanol_boltzmann_populations.txt"),
        "Conformer 1: 100%\n",
    )
    .unwrap();
    let labels = root.join("ethanol_chemical_shifts.pml");
    fs::write(&labels, "label id 1, '12.34'\n").unwrap();
    let mut app = Workbench::new(Config::default(), tmp.0.join("config.txt"));
    app.open_results(&root).unwrap();
    let c = &app.analysis.as_ref().unwrap().compounds[0];
    assert_eq!(c.conformers[0].energy, Some(-100.));
    assert_eq!(c.conformers[0].population, 1.);
    assert_eq!(c.shifts[&0], 12.34);
    fs::write(&labels, "label id 1, 'NaN'\n").unwrap();
    assert!(app.open_results(&root).is_err());
    // A failed reopen preserves the already loaded, valid result.
    assert_eq!(
        app.analysis.as_ref().unwrap().compounds[0].shifts[&0],
        12.34
    );
}

#[cfg(unix)]
#[test]
fn cli_accepts_inputs_inside_non_utf8_parent_paths() {
    use std::os::unix::ffi::OsStringExt;
    let tmp = Temp::new();
    let folder = tmp
        .0
        .join(std::ffi::OsString::from_vec(b"structures-\xff".to_vec()));
    fs::create_dir(&folder).unwrap();
    let source = folder.join("ethanol_1.sdf");
    fs::write(&source, include_str!("fixtures/sdf/ethanol_1.sdf")).unwrap();
    let output = std::process::Command::new(env!("CARGO_BIN_EXE_tensor"))
        .arg("--setup")
        .arg(&source)
        .arg("--out")
        .arg(tmp.0.join("jobs"))
        .arg("--config")
        .arg(PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("assets/tensor_config.txt"))
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert!(tmp.0.join("jobs/gjf_files/ethanol_1.gjf").is_file());
}

#[test]
fn public_first_run_uses_clean_tensor_roaming_configuration() {
    let tmp = Temp::new();
    let working = tmp.0.join("working");
    let roaming = tmp.0.join("roaming");
    let old_folder = roaming.join("nmr-workbench");
    fs::create_dir_all(&working).unwrap();
    fs::create_dir_all(&old_folder).unwrap();
    fs::write(
        old_folder.join("nmr_workbench_config.txt"),
        "This deliberately invalid legacy file must not be imported.\n",
    )
    .unwrap();
    let source = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/sdf/ethanol_1.sdf");
    let output = std::process::Command::new(env!("CARGO_BIN_EXE_tensor"))
        .current_dir(&working)
        .env("APPDATA", &roaming)
        .env_remove("XDG_CONFIG_HOME")
        .env_remove("HOME")
        .arg("--setup")
        .arg(source)
        .arg("--out")
        .arg(tmp.0.join("jobs"))
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    let clean = roaming.join("TENSOR/tensor_config.txt");
    assert!(clean.is_file());
    assert_eq!(fs::read_to_string(&clean).unwrap(), DEFAULT_CONFIG);
    assert_eq!(
        fs::read_to_string(old_folder.join("nmr_workbench_config.txt")).unwrap(),
        "This deliberately invalid legacy file must not be imported.\n"
    );
}

#[test]
fn embedded_demo_can_still_generate_into_an_existing_output_folder() {
    let tmp = Temp::new();
    let mut app = Workbench::new(Config::default(), tmp.0.join("config.txt"));
    tensor::verification::load_demo(&mut app).unwrap();
    let result = run_setup(
        &app.inputs,
        &[("ethanol".into(), JobSettings::default())].into(),
        &app.config,
        &tmp.0,
        &quiet(),
    )
    .unwrap();
    assert_eq!(result.paths.len(), 3);
    assert!(result.paths.iter().all(|p| p.is_file()));
}

#[test]
fn setup_returns_the_exact_aligned_cluster_overlay_used_for_generation() {
    let tmp = Temp::new();
    let mut app = Workbench::new(Config::default(), tmp.0.join("config.txt"));
    tensor::verification::load_demo(&mut app).unwrap();
    let settings = JobSettings {
        clustering: Some(tensor::cluster::ClusterSettings::shifts()),
        ..Default::default()
    };
    let result = run_setup(
        &app.inputs,
        &[("ethanol".into(), settings.clone())].into(),
        &app.config,
        &tmp.0,
        &quiet(),
    )
    .unwrap();
    assert_eq!(result.overlays.len(), 1);
    let overlay = &result.overlays[0];
    assert_eq!(overlay.compound, "ethanol");
    assert_eq!(overlay.settings, settings.clustering.unwrap());
    assert_eq!(overlay.items.len(), app.inputs.len());
    assert!(!overlay.groups.is_empty());
    assert_eq!(
        overlay
            .signature
            .iter()
            .map(|(_, number)| *number)
            .collect::<Vec<_>>(),
        vec![1, 2, 3]
    );
}

#[cfg(unix)]
#[test]
fn setup_source_protection_resolves_directory_aliases() {
    let tmp = Temp::new();
    let source = tmp.0.join("inputs/ethanol/ethanol_1.sdf");
    fs::create_dir_all(source.parent().unwrap()).unwrap();
    fs::write(&source, include_str!("fixtures/sdf/ethanol_1.sdf")).unwrap();
    let root = tmp.0.join("outputs");
    fs::create_dir(&root).unwrap();
    std::os::unix::fs::symlink(tmp.0.join("inputs"), root.join("aligned_conformers")).unwrap();
    let (inputs, errors) = load_inputs(std::slice::from_ref(&source));
    assert!(errors.is_empty());
    assert!(
        run_setup(
            &inputs,
            &[("ethanol".into(), JobSettings::default())].into(),
            &Config::default(),
            &root,
            &quiet()
        )
        .is_err()
    );
    assert!(source.is_file());
    assert!(!root.join("gjf_files").exists());
}
