load multinuc_1.sdf
hide everything
show sticks

# Adding chemical shifts as labels
label id 1, '29.62' # Replaced by chalogen results
label id 2, '30.62' # Replaced by chalogen results
label id 3, '61.47' # Replaced by csulfur results
label id 4, '-123.21'
label id 7, '41.39'
label id 9, '3.08'
label id 10, '3.29'
label id 11, '3.50'
label id 12, '3.82'
label id 13, '3.82'
label id 14, '4.13'

# Set background color to black
bg_color black

# Set licorice stick radius
set stick_radius, 0.15

# Set atom colors
set_color dark_grey, [0.5, 0.5, 0.5]
set_color bright_grey, [0.8, 0.8, 0.8]
set_color deep_blue, [0.0, 0.0, 0.8]
set_color deep_red, [0.8, 0.0, 0.0]
set_color light_pink, [1.0, 0.75, 0.8]
color dark_grey, elem C
color bright_grey, elem H
color deep_blue, elem N
color deep_red, elem O
color light_pink, elem F

# Set label properties
set label_font_id, 5
set label_size, 15

# Set label color
set_color deep_gold, [1.0, 0.8, 0.0]
set label_color, deep_gold

# General settings for enhanced visual quality
set antialias_shader, 2
set line_smooth, 1
set specular, 1.00000
set use_shaders, 0
set stick_use_shader, 1
set render_as_cylinders, 1
set line_as_cylinders, 1
set stick_as_cylinders, 1
set dot_as_spheres, 1
set depth_cue, 0

# Apply visualization settings
show sticks, all
