load ethanol_1.sdf
hide everything
show sticks

# Adding chemical shifts as labels
label id 1, '18.40'
label id 2, '58.70'
label id 4, '2.15'
label id 5, '2.15'
label id 6, '2.15'
label id 7, '2.68'
label id 8, '2.68'
label id 9, '2.99'

# Set background color to black
bg_color black

# Set licorice stick radius
set stick_radius, 0.15

# Set atom colors
set_color dark_grey, [0.5, 0.5, 0.5]
set_color bright_grey, [0.8, 0.8, 0.8]
set_color deep_blue, [0.0, 0.0, 0.8]
set_color deep_red, [0.8, 0.0, 0.0]
set_color light_pink, [1.0, 0.75, 0.8]
color dark_grey, elem C
color bright_grey, elem H
color deep_blue, elem N
color deep_red, elem O
color light_pink, elem F

# Set label properties
set label_font_id, 5
set label_size, 15

# Set label color
set_color deep_gold, [1.0, 0.8, 0.0]
set label_color, deep_gold

# General settings for enhanced visual quality
set antialias_shader, 2
set line_smooth, 1
set specular, 1.00000
set use_shaders, 0
set stick_use_shader, 1
set render_as_cylinders, 1
set line_as_cylinders, 1
set stick_as_cylinders, 1
set dot_as_spheres, 1
set depth_cue, 0

# Apply visualization settings
show sticks, all
