use std::sync::atomic::AtomicBool;
use tensor::{
    analysis::*, branding, math::*, molecule::*, render3d::Scene, spectrum::*, verification,
};
fn input(spins: &[(Nucleus, f64)], js: &[(usize, usize, f64)]) -> Input {
    Input {
        name: "test".into(),
        spins: spins
            .iter()
            .enumerate()
            .map(|(atom, &(nucleus, ppm))| Spin {
                atom,
                nucleus,
                ppm,
                area: 1.,
            })
            .collect(),
        calculated: js.iter().map(|&(a, b, j)| (pair(a, b), j)).collect(),
        ..Input::default()
    }
}
fn settings() -> Settings {
    Settings {
        proton_mhz: 100.,
        rotor_average: false,
        estimate: false,
        cutoff_hz: 0.,
        ..Settings::default()
    }
}
fn run(i: &Input, s: &Settings) -> Output {
    simulate(i, s, &AtomicBool::new(false)).unwrap()
}
fn close(a: f64, b: f64, tol: f64) {
    assert!((a - b).abs() < tol, "{a} != {b}");
}
#[test]
fn isolated_nuclei_have_correct_positions_and_spin_area() {
    let i = input(
        &[
            (Nucleus::H, 1.2),
            (Nucleus::C, 72.3),
            (Nucleus::F, -123.4),
            (Nucleus::N, -55.),
        ],
        &[],
    );
    let s = settings();
    let o = run(&i, &s);
    assert_eq!(o.predictions.len(), 4);
    for p in o.predictions {
        assert_eq!(p.lines.len(), 1);
        let spin = i.spins.iter().find(|x| x.nucleus == p.nucleus).unwrap();
        close(p.lines[0].hz, spin.ppm * 100. * p.nucleus.ratio(), 1e-8);
        close(p.lines[0].area, 1., 1e-8);
    }
}
#[test]
fn exact_ab_quartet_matches_analytical_roofing() {
    let i = input(&[(Nucleus::H, 1.), (Nucleus::H, 1.2)], &[(0, 1, 10.)]);
    let p = run(&i, &settings()).predictions.remove(0);
    assert_eq!(p.lines.len(), 4);
    let r = 500_f64.sqrt();
    let positions = [
        110. - (r + 10.) / 2.,
        110. - (r - 10.) / 2.,
        110. + (r - 10.) / 2.,
        110. + (r + 10.) / 2.,
    ];
    for (k, l) in p.lines.iter().enumerate() {
        close(l.hz, positions[k], 1e-8);
        let area = 0.5 * (1. + if k == 0 || k == 3 { -10. / r } else { 10. / r });
        close(l.area, area, 1e-8);
    }
}
#[test]
fn magnetically_equivalent_pair_does_not_split_itself() {
    let i = input(&[(Nucleus::H, 2.), (Nucleus::H, 2.)], &[(0, 1, 14.)]);
    let p = run(&i, &settings()).predictions.remove(0);
    assert_eq!(p.lines.len(), 1);
    close(p.lines[0].hz, 200., 1e-8);
    close(p.lines[0].area, 2., 1e-8);
}
#[test]
fn equal_shifts_do_not_erase_magnetic_inequivalence() {
    let i = input(
        &[(Nucleus::H, 2.), (Nucleus::H, 2.), (Nucleus::F, -100.)],
        &[(0, 1, 12.), (0, 2, 7.), (1, 2, 13.)],
    );
    let o = run(&i, &settings());
    assert!(o.predictions[0].lines.len() > 2);
    close(o.couplings[&(0, 2)], 7., 1e-9);
    close(o.couplings[&(1, 2)], 13., 1e-9);
}
#[test]
fn heteronuclear_decoupling_is_specific_to_observed_spectrum() {
    let i = input(&[(Nucleus::H, 1.), (Nucleus::F, -100.)], &[(0, 1, 40.)]);
    let mut s = settings();
    let o = run(&i, &s);
    assert_eq!(o.predictions[0].lines.len(), 2);
    close(
        o.predictions[0].lines[1].hz - o.predictions[0].lines[0].hz,
        40.,
        1e-8,
    );
    s.decouple[0][2] = true;
    let o = run(&i, &s);
    assert_eq!(o.predictions[0].lines.len(), 1);
    assert_eq!(o.predictions[1].lines.len(), 2);
}
#[test]
fn rare_isotopes_do_not_split_every_proton_at_natural_abundance() {
    let i = input(
        &[(Nucleus::H, 1.), (Nucleus::C, 60.), (Nucleus::N, -50.)],
        &[(0, 1, 140.), (0, 2, 8.), (1, 2, 12.)],
    );
    let mut s = settings();
    let o = run(&i, &s);
    assert!(o.predictions.iter().all(|p| p.lines.len() == 1));
    s.enriched = true;
    s.decouple = [[false; 4]; 4];
    let o = run(&i, &s);
    assert!(o.predictions.iter().all(|p| p.lines.len() >= 4));
}
#[test]
fn first_order_quartet_has_binomial_areas() {
    let i = input(
        &[
            (Nucleus::H, 1.),
            (Nucleus::H, 3.),
            (Nucleus::H, 3.),
            (Nucleus::H, 3.),
        ],
        &[(0, 1, 7.), (0, 2, 7.), (0, 3, 7.)],
    );
    let mut s = settings();
    s.first_order = true;
    let p = run(&i, &s).predictions.remove(0);
    let quartet: Vec<_> = p.lines.iter().filter(|l| l.hz < 200.).collect();
    assert_eq!(quartet.len(), 4);
    for (k, l) in quartet.iter().enumerate() {
        close(l.hz, 89.5 + 7. * k as f64, 1e-8);
        close(l.area, [0.125, 0.375, 0.375, 0.125][k], 1e-8);
    }
}
#[test]
fn large_components_report_first_order_and_strong_coupling() {
    let spins: Vec<_> = (0..11)
        .map(|i| (Nucleus::H, 1. + i as f64 * 0.005))
        .collect();
    let js: Vec<_> = (1..11).map(|i| (0, i, 1.)).collect();
    let o = run(&input(&spins, &js), &settings());
    let p = &o.predictions[0];
    assert!(p.notes.iter().any(|n| n.contains("1 first-order")));
    assert!(p.notes.iter().any(|n| n.contains("Δν/|J|")));
    close(p.lines.iter().map(|l| l.area).sum(), 11., 1e-8);
}
#[test]
fn karplus_limits_and_calculated_precedence() {
    close(karplus(0.), 8.06, 1e-8);
    close(karplus(std::f64::consts::FRAC_PI_2), 1.4, 1e-8);
    close(karplus(std::f64::consts::PI), 10.26, 1e-8);
    let mut i = input(&[(Nucleus::H, 1.), (Nucleus::H, 3.)], &[(0, 1, 4.)]);
    i.estimated.insert((0, 1), 10.26);
    let mut s = settings();
    s.estimate = true;
    let o = run(&i, &s);
    close(o.couplings[&(0, 1)], 4., 1e-9);
    assert!(o.estimated.is_empty());
}
#[test]
fn extraction_averages_raw_j_and_karplus_per_populated_conformer() {
    let mut c = analyze_compound(
        "ethanol",
        verification::ethanol_logs().unwrap(),
        &AnalysisSettings::default(),
        std::path::Path::new("/synthetic-no-pop-file"),
        &verification::quiet(),
    )
    .unwrap();
    for l in &mut c.logs {
        l.couplings.clear();
    }
    let initial = Input::from_compound(&c, &AtomicBool::new(false)).unwrap();
    assert!(!initial.estimated.is_empty());
    let (&key, &expected) = initial.estimated.iter().next().unwrap();
    let adj = c.structure.adjacency();
    let (x, y) = (adj[key.0][0], adj[key.1][0]);
    let total: f64 = c.conformers.iter().map(|x| x.population).sum();
    let manual: f64 = c
        .conformers
        .iter()
        .map(|conf| {
            let a = &conf.molecule.atoms;
            conf.population / total
                * karplus(dihedral(a[key.0].xyz, a[x].xyz, a[y].xyz, a[key.1].xyz))
        })
        .sum();
    close(expected, manual, 1e-8);
    for l in &mut c.logs {
        l.couplings.insert(key, l.number as f64 * 3.);
    }
    let extracted = Input::from_compound(&c, &AtomicBool::new(false)).unwrap();
    let calculated: f64 = c
        .conformers
        .iter()
        .map(|x| x.population / total * x.number as f64 * 3.)
        .sum();
    close(extracted.calculated[&key], calculated, 1e-8);
    assert!(!extracted.estimated.contains_key(&key));
    let number = c
        .conformers
        .iter()
        .find(|x| x.population > 0.)
        .unwrap()
        .number;
    c.logs
        .iter_mut()
        .find(|l| l.number == number)
        .unwrap()
        .couplings
        .remove(&key);
    let extracted = Input::from_compound(&c, &AtomicBool::new(false)).unwrap();
    assert!(!extracted.calculated.contains_key(&key));
    close(extracted.estimated[&key], expected, 1e-8);
}
#[test]
fn rotor_averaging_preserves_unknown_pairs_and_can_be_disabled() {
    let mut i = input(
        &[
            (Nucleus::H, 1.),
            (Nucleus::H, 1.),
            (Nucleus::H, 1.),
            (Nucleus::H, 3.),
        ],
        &[(0, 3, 1.), (1, 3, 4.), (2, 3, 10.)],
    );
    i.rotor_groups = vec![vec![0, 1, 2]];
    let mut s = settings();
    s.rotor_average = true;
    let o = run(&i, &s);
    for j in 0..3 {
        close(o.couplings[&(j, 3)], 5., 1e-9);
    }
    i.calculated.remove(&(2, 3));
    let o = run(&i, &s);
    assert!(!o.couplings.contains_key(&(2, 3)));
    close(o.couplings[&(0, 3)], 1., 1e-9);
}
#[test]
fn lorentzian_area_and_fwhm_are_in_hz() {
    let p = run(&input(&[(Nucleus::H, 0.)], &[]), &settings())
        .predictions
        .remove(0);
    let s = settings();
    let y = p.curve(&s, [-1., 1.], 20000);
    let dx = 0.01;
    close(
        y.iter().sum::<f64>() * dx,
        2. / std::f64::consts::PI * 200_f64.atan(),
        1e-8,
    );
    let peak = y.iter().copied().fold(0_f64, f64::max);
    let width = y.iter().filter(|&&v| v >= peak / 2.).count() as f64 * dx;
    close(width, 1., 0.03);
}
#[test]
fn invalid_settings_and_cancel_are_rejected() {
    let i = input(&[(Nucleus::H, 0.)], &[]);
    let mut s = settings();
    s.linewidth_hz = f64::NAN;
    assert!(simulate(&i, &s, &AtomicBool::new(false)).is_err());
    assert!(simulate(&i, &settings(), &AtomicBool::new(true)).is_err());
}
#[test]
fn splash_is_opaque_original_and_ui_fonts_cover_scientific_symbols() {
    use ab_glyph::{Font, FontRef};
    let (_, _, rgba) = branding::original().unwrap();
    assert!(rgba.chunks_exact(4).all(|p| p[3] == 255));
    let font = FontRef::try_from_slice(branding::SYMBOL_FONT).unwrap();
    for c in "⁻¹²³⁴⁵⁶⁷⁸⁹⁰ατδθΔνσÅ½".chars() {
        assert_ne!(font.glyph_id(c).0, 0, "Missing {c}");
    }
    let ctx = eframe::egui::Context::default();
    branding::install_fonts(&ctx);
    ctx.run_ui(Default::default(), |ui| {
        ui.label("kcal mol⁻¹ Hartree⁻¹ K⁻¹");
        ui.monospace("cm⁻¹");
    })
    .drop_without_applying_deltas();
}
#[test]
fn bonded_atoms_have_only_hemispherical_rod_caps() {
    let m = Molecule {
        atoms: [
            ("C", [0., 0., 0.]),
            ("O", [1.3, 0., 0.]),
            ("H", [-0.5, 0.8, 0.]),
            ("F", [3., 0., 0.]),
        ]
        .into_iter()
        .map(|(element, xyz)| Atom {
            element: element.into(),
            xyz,
            ..Atom::default()
        })
        .collect(),
        bonds: [((0, 1), 2.), ((0, 2), 1.)].into_iter().collect(),
        ..Molecule::default()
    };
    let scene = Scene::from_molecule(&m, &m.coords());
    assert_eq!(scene.solids.len(), 4);
    let spheres: Vec<_> = scene.solids.iter().filter(|s| s.a == s.b).collect();
    assert_eq!(spheres.len(), 1);
    assert_eq!(spheres[0].a, m.atoms[3].xyz);
    close(spheres[0].radius, 0.27, 1e-9);
}

#[test]
fn reopened_results_restore_weighted_coupling_export() {
    let root = std::env::temp_dir().join(format!(
        "tensor-spectra-reopen-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    let paths: Vec<_> = (1..=3)
        .map(|n| {
            std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
                .join(format!("tests/fixtures/logs/ethanol_{n}.log"))
        })
        .collect();
    let options = AnalysisSettings {
        output_root: Some(root.clone()),
        ..AnalysisSettings::default()
    };
    let results = run_analysis(&paths, &options, &verification::quiet()).unwrap();
    assert_eq!(results.compounds.len(), 1);
    let mut app =
        tensor::ui::Workbench::new(tensor::config::Config::default(), root.join("config.txt"));
    app.open_results(&root).unwrap();
    let c = &app.analysis.as_ref().unwrap().compounds[0];
    assert!(!c.couplings.is_empty());
    for (&p, &j) in &c.couplings {
        close(
            j,
            round_decimal(results.compounds[0].couplings[&p], 2),
            1e-8,
        );
    }
    let input = Input::from_compound(c, &AtomicBool::new(false)).unwrap();
    assert!(!input.calculated.is_empty());
    assert!(
        input
            .notes
            .iter()
            .any(|n| n.contains("magnetic inequivalence"))
    );
    std::fs::remove_dir_all(root).unwrap();
}
